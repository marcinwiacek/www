
#include <stdio.h>

typedef enum {
	GE_NONE=0,
	GE_DEVICEOPENERROR,		/* Error during opening device */
	GE_DEVICECHANGESPEEDERROR	/* Error during changing speed in device */
} GSM_Error;

#ifdef WIN32
#  define mili_sleep(x) Sleep(((x) < 1000) ? 1 : ((x) / 1000))
#else
#  define mili_sleep(x) usleep(x)
#endif

#ifdef WIN32

#include <windows.h>

HANDLE hPhone;
OVERLAPPED osRead;

static GSM_Error serial_open (char *portdevice)
{
	COMMTIMEOUTS  CommTimeOuts;

	hPhone = CreateFile(	portdevice,
				GENERIC_READ | GENERIC_WRITE,
				0,                    /* exclusive access */
				NULL,                 /* no security attrs */
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL |
				FILE_FLAG_OVERLAPPED, /* overlapped I/O */
			NULL);

	if (hPhone == INVALID_HANDLE_VALUE) return GE_DEVICEOPENERROR;

	/* get any early notifications */
	SetCommMask(hPhone, EV_RXCHAR);

	/* setup device buffers */
	SetupComm(hPhone, 4096, 4096);

	/* purge any information in the buffer */
	PurgeComm(hPhone, PURGE_TXABORT | PURGE_RXABORT |
			     PURGE_TXCLEAR | PURGE_RXCLEAR);

	/* set up for overlapped I/O */
	CommTimeOuts.ReadIntervalTimeout = 0xFFFFFFFF;
	CommTimeOuts.ReadTotalTimeoutMultiplier = 0;
	CommTimeOuts.ReadTotalTimeoutConstant = 1000;
	CommTimeOuts.WriteTotalTimeoutMultiplier = 10;
	CommTimeOuts.WriteTotalTimeoutConstant = 0;

	SetCommTimeouts(hPhone, &CommTimeOuts);

	return GE_NONE;
}

static GSM_Error serial_setspeed(int speed)
{
	DCB        dcb;

	dcb.DCBlength = sizeof(DCB);

	GetCommState(hPhone, &dcb);

	dcb.BaudRate = speed;

	if (SetCommState(hPhone, &dcb)!=0) return GE_NONE;

	/* purge any outstanding reads/writes and close device handle */
	PurgeComm(hPhone, PURGE_TXABORT | PURGE_RXABORT |
			     PURGE_TXCLEAR | PURGE_RXCLEAR);

	return GE_DEVICECHANGESPEEDERROR;
}

static int serial_read(void *buf, size_t nbytes, long timeout)
{
	BOOL		fReadStat;
	COMSTAT		ComStat;
	DWORD		dwErrorFlags;
	DWORD		dwLength=0;
	DWORD		dwError;
	int		i=0;

	/* only try to read number of bytes in queue */
	ClearCommError(hPhone, &dwErrorFlags, &ComStat);
	dwLength = min((DWORD) nbytes, ComStat.cbInQue);

	if (dwLength > 0) {
		fReadStat = ReadFile(hPhone, buf, dwLength, &dwLength, &osRead);
		if (!fReadStat) {
			if (GetLastError() == ERROR_IO_PENDING) {
				printf("IO Pending\n");
				/* We have to wait for read to complete.
				 * This function will timeout according to the
				 * CommTimeOuts.ReadTotalTimeoutConstant variable
				 * Every time it times out, check for port errors
				 */
				while(!GetOverlappedResult(hPhone,
						   &osRead, &dwLength, TRUE)) {
					dwError = GetLastError();
					if (dwError == ERROR_IO_INCOMPLETE)
						/* normal result if not finished */
						continue;
					else {
						/* an error occurred, try to recover */
						ClearCommError(hPhone, &dwErrorFlags, &ComStat);
						break;
					}
				}
			} else {
				/* some other error occurred */
				dwLength = 0;
				ClearCommError(hPhone, &dwErrorFlags, &ComStat);
			}
		}
	}

	return (dwLength);
}

#else
#endif

void main(int argc, char *argv[])
{
	char buffer[300];
	FILE *file;
	int bytes;

	if (argc<3) {
		printf("Usage: sniff serial_port speed\n");
		exit(-1);
	} else {
		serial_open(argv[1]);
		serial_setspeed(atoi(argv[2]));
	}
	file = fopen("out.trc","wb");
	while (!0) {
		bytes=serial_read(buffer, 255, 100);
		fwrite(buffer,1,bytes,file);
		fflush(file);
	}
	fclose(file);
}
