#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <curses.h>

unsigned long i;

double SA(void)
{
 char s[20]="x",*ok;
 double v,suma=0.0;
 for (i=1; s[0]!=0; i++)
 {
        printf("  Podaj %u liczbe: ",i);
        fflush(stdout);
        fflush(stdin);
        v=strtod(gets(s),&ok);
        if (ok[0]!=0) i--;
        suma+=v;
}
 return suma/(i-=2);
}

double SG(void)
{
 char s[20]="x",*ok;
 double v,iloczyn=1.0;
 for (i=1; s[0]!=0; i++)
 {
        printf("  Podaj %u liczbe: ",i);
        fflush(stdout);
        fflush(stdin);
        v=strtod(gets(s),&ok);
        if ((ok[0]!=0)||((ok[0]==0)&&(v<=0))) {i--; continue;}
        iloczyn*=v;
 }
 v=--i;
 v=1/v;
 return pow(iloczyn,v);
}

int main(void)
{
 char z;
 double x;
 int wyjscie=0;
 initscr();
 mvprintw(2,2,"Program sluzy do obliczania sredniej arytmetycznej");
 mvprintw(3,2,"lub geometrycznej wprowadzonych z klawiatury liczb.");
 mvprintw(4,2,"Koniec wprowadzania - wprowadzenie pustego wiersza.");
 do
 {
        noecho();
        mvprintw(6,2,"Wybierz srednia do obliczania:");
        mvprintw(7,2," a - arytmetyczna");
        mvprintw(8,2," g - geometryczna");
        mvprintw(9,2,"Esc - wyjscie\n\n");
        z=getch();
        endwin();
        switch (z)
        {
         case 'a':
         case 'A':
         {
                x=SA();
                initscr();
                if (i!=0) mvprintw(11,2,"Srednia arytmetyczna %u wprowadzonych liczb wynosi: %g\n",i,x);
                endwin();
                break;
         }
         case 'g':
         case 'G':
         {
                x=SG();
                initscr();
                if (i!=0) mvprintw(11,2,"Srednia geometryczna %u wprowadzonych liczb wynosi: %g\n",i,x);
                endwin();
                break;
         }
         case 27:
                wyjscie=1;
        }
 }
 while (wyjscie!=1);
}
