//   Projekt 3 PROG
//       -FFT-
// Bartlomiej Zdanowski
//

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//#define debug

typedef unsigned int dword;
typedef unsigned short word;
typedef unsigned char byte;

typedef struct complex{
        double re,im;
        };

complex *C,*F,Wx,E,N;
 
double Treal,Timag;             //zmienne pomocnicze real i imag
double *A;
dword args = 0;
dword n;
word K1;
dword nd;
word M=0;
FILE *outp=stdout;			//strumien, na ktory ma zostac wyslany wynik

//opcje programu
byte matlab=1;                  //wy "zjadliwe" dla matlaba
byte real=1;                    //wy w liczbach rzeczywistych
byte help=0;                    //pomoc
byte samples=0;                 //czy uzytkownik podal liczbe probek


//pobiera dane ze stdin
void PobierzDane()
{
char c;
double *B;                      //jak A, ale tymczasowe
dword i=0;
dword j=0;

A = (double *)malloc(sizeof(double));

if (A==NULL)
  {
  printf ("PobierzDane(): Blad 1\n");
  exit(1);
  }

fflush(stdin);

while (!feof(stdin))                    //pobiera dane
  {
  if (!fscanf(stdin,"%lf,\n",&A[i++]))
    {
    fprintf(stderr,"\nWystapil blad podczas wprowadzania danych!\nDana nr. %i\n",i-1);
    exit(1);
    }
  A = (double *)realloc(A,(1+i)*sizeof(double));

  if (A==NULL)
    {
    fprintf(stderr,"PobierzDane(): Blad 2\n");
    exit(1);
    }
#ifdef debug  
  fprintf(stderr,"licz %d, A: %lf\n",i-1,A[i-1]);
#endif
  }

//oblicza ilosc danych - by byly 2^M
while (i>n)             //kolejne potegi 2
  n=2<<++M;             //2^M;

nd = n>>1;
#ifdef debug
fprintf(stderr,"Liczba wejsciowych probek: %i\n",n);
#endif

for (i++;i<n;i++)
  A[i]=0;               //dopelnia 0 do 2^M

if (A==NULL)
  {
  fprintf (stderr,"PobierzDane(): Blad 3\n");
  exit(1);
  }

C = (complex *)malloc(n*sizeof(complex));       //tyle ile probek wejsciowych
if (C==NULL)
  {
  fprintf(stderr,"PobierzDane(): Blad 4\n");
  exit(1);
  }

}

//wlasciwe obliczenia
void Obliczenia()
{
dword K;
double re,im;
double n1 = (1/(double)n);                      //optymalizacja

#ifdef debug
fprintf(stderr,"Obliczenia petla1: K=0..n/2\n");
#endif

for (K=0;K<(nd);K++)
  {
  K1 = K;
  N.re=0;
  N.im=0;
  E.re=0;
  E.im=0;
  for (dword B1=0;B1<nd;B1++)
    {
    //***E***
    //W^2*K1*B1
    re = -4*M_PI*K1*B1/(double)n;       //temp
    Wx.re = cos(re);       //Wx real
    Wx.im = sin(re);       //Wx imag

    //E += 1/n*A[2*B1]*Wx;
    E.re += Wx.re*A[B1<<1];
    E.im += Wx.im*A[B1<<1];

    //N += 1/n*A[2*B1+1]*Wx;
    N.re += A[(B1<<1)+1]*Wx.re;
    N.im += A[(B1<<1)+1]*Wx.im;
    }
  //a = (1/n)*f(xb)
  //n1 = 1/n;

  //W^k
  Treal = -2*M_PI*K/(double)n;          //temp
  re = cos(Treal);
  im = sin(Treal);

  //N*W^k
  Treal = re*N.re - im*N.im;              //czesc real
  Timag = im*N.re + re*N.im;              //czesc imag

  //n1=1/n pochodzi z Ab=(1/n)f(Xb)
  C[K].re = n1*(E.re + Treal);
  C[K].im = n1*(E.im + Timag);
  }

#ifdef debug
fprintf(stderr,"Obliczenia petla2: K=n/2..n\n");
#endif

//K1 = K - (n/2);
K1 = 0;
for (K=nd;K<n;K++,K1++)
  {
  //K1 = K - nd;
  N.re=0;
  N.im=0;
  E.re=0;
  E.im=0;
  for (dword B1=0;B1<nd;B1++)
    {
    //***E***
    //W^2*K1*B1
    re = -4*M_PI*K1*B1/(double)n;
    Wx.re = cos(re);       //Wx real
    Wx.im = sin(re);       //Wx imag

    //E += 1/n*A[2*B1]*Wx;
    E.re += Wx.re*A[B1<<1];
    E.im += Wx.im*A[B1<<1];

    //N += 1/n*A[2*B1+1]*Wx;
    N.re += A[(B1<<1)+1]*Wx.re;
    N.im += A[(B1<<1)+1]*Wx.im;
    }
  //a = (1/n)*f(xb)
  //n1 = 1/n;
  E.re *= n1;
  E.im *= n1;
  N.re *= n1;
  N.im *= n1;

  //W^k
  Treal = -2*M_PI*K/(double)n;
  re = cos(Treal);
  im = sin(Treal);

  //N*W^k
  Treal = re*N.re - im*N.im;              //czesc real
  Timag = im*N.re + re*N.im;              //czesc imag

  C[K].re = E.re + Treal;
  C[K].im = E.im + Timag;
  }

if (!args)                      //jesli nie podano ile probek
  args = 2<<M;                  //tyle co wej.

F = (complex *)malloc(args*sizeof(complex));    //F tyle ile probek na wyjscie
if (F==NULL)
  {
  fprintf(stderr,"Obliczenia(): Blad 1\n");
  exit(1);
  }

for (dword i=0;i<args;i++)
  {
  F[i].re = 0;
  F[i].im = 0;
  }

#ifdef debug
fprintf(stderr,"Obliczenia petla3: wartosci funkcji dla %i probek\n",args);
#endif

double x=0;
double xchg=(2*M_PI/(double)args);
for (int i=0;i<args;i++)
  {
  //E(K=0:n-1) Ck*exp(jkx)
  for (K=0;K<n;K++)
    {
    F[i].re += C[K].re*cos(K*x) - C[K].im*sin(K*x);
    F[i].im += C[K].im*cos(K*x) + C[K].re*sin(K*x);
    }
  A[i]=x;                       //teraz A[] jako tablica argumentow
  x+= xchg;
  }
}

void OutComplex()
{
for (int i=0;i<args;i++)
  {
  fprintf(outp,"%f ",F[i].re);
  if (F[i].im>=0)
    fprintf(outp,"+ %fi",F[i].im);
  else
    fprintf(outp,"- %fi",(-1)*F[i].im);
  if ((i<args-1)&&(matlab))               //tylko dla matlaba oddziela ,\n
    fprintf(outp,",\n");
  else
    fprintf(outp," ");                        //tylko spacja
  }
}


void OutReal()
{
for (dword i=0;i<args;i++)
  {
  fprintf(outp,"%f",(F[i].re*F[i].re+F[i].im*F[i].im));      //wyswietla liczbe ze sprzezeniem
  if ((i<args-1)&&(matlab))               //tylko dla matlaba oddziela ,\n
    fprintf(outp,",\n");
  else
    fprintf(outp," ");                        //tylko spacja
  }
}


void FreeMem()
{
free(A);
free(C);
}

void Wyjscie()
{

if (matlab)
  {
  //jesli ma wyslac do pliku, a nie do stdout

  if ((outp = fopen("four.m","wt"))==NULL)
    {
    fprintf(stderr,"\nWyjscie(): Wystapil blad podczas tworzenia pliku wynikowego four.m\n");
    exit(2);
    FreeMem();
    }

  }


if (matlab)                             //jesli out na potrzeby matlab'u
  {
  fprintf(outp,"x = [");              //x = [0,1,..,n-1];
 for (int i=0;i<args;i++)
    fprintf(outp,"%f,\n",A[i]);
  fprintf(outp,"];\n");

  fprintf(outp,"y = [");
  }

if (real)
  OutReal();                    //wyswietla liczby real
else
  OutComplex();                 //complex

if (matlab)
  fprintf(outp,"];\n");

if (matlab)                    //tylko teraz plot(x,y) ma sens
  fprintf(outp,"%%rysuje wykres\nplot(""x(1:%i),y(1:%i)"");",args,args);

if (matlab)			//jesli matlab, to zamyka four.m
  fclose(outp);

FreeMem();
}


//uruchamia matlaba
void Matlab()
{
FILE *st;

if ((st = fopen("startup.m","wt"))==NULL)
  {
  fprintf(stderr,"\nMatlab(): Blad przy tworzeniu startup.m\n");
  FreeMem();
  exit(3);
  }

fprintf(st,"echo off;\n");
fprintf(st,"disp('Witam! Tworze wykres.');\n");
fprintf(st,"four.m\n");
fflush(st);
fclose(st);

fprintf(stderr,"\n* Po obejrzeniu wykresu, prosze zamknac okienko oraz Matlab'a komenda 'quit'\n\n");
system("xterm -T Wykres! -bg black -fg grey -title Matlab! -iconic -e matlab");
}

//wyswietla naglowek programu, pomoc, analizuje przelaczniki wejsciowe programu
void Opcje(int _argc,char *_argv[])
{
fprintf(stderr,"\n\n      Projekt III, PROG\n");
fprintf(stderr,"           FFT v. 1.0\n");
fprintf(stderr," (C) 2001 Bartlomiej Zdanowski\n");
fprintf(stderr,"     bzdanows@elka.pw.edu.pl\n");
fprintf(stderr,"\n FFT - Szybka Transformacja Fouriera\n\n");

//zawsze 1 arg to sciezka dostepu+nazwa
//zatem parametrow jest _argc-1
if (_argc>1)                            //jesli sa jakies arg
  {
  for (byte i=1;i<_argc;i++)           //sprawdza parametry
    {
    if (strstr(_argv[i],"help")!=NULL)
      help=1;
    if (strstr(_argv[i],"nomatlab")!=NULL)
        matlab=0;
    if (strstr(_argv[i],"real")!=NULL)
       if (!matlab)  			//jesli matlab, to dane musza byc real 
         real=1;

    //maly trick: atoi da 0 jesli string nie jest liczba, inaczej da ta liczbe
    if (!args)
      args=atoi(_argv[i]);              //zdefiniowano liczbe probek
    }

  if (help)
    {
    printf("\nUzycie:\n");
    printf("%s [n] [--help]\n\n",_argv[0]);
    printf(" n        - funkcja wynikowa bedzie sie skladala z n probek, prawidlowy wynik\n");
    printf("            jesli bedzie to potega 2. Domyslnie tyle samo ile danych wejsciowych\n");
    printf("            zwiekszone do najblizszej potegi 2\n");
    printf(" --help   - krotka pomoc, ta wlasnie ;-)\n");
    printf(" nomatlab - nie uruchamia Matlab'a, tylko kieruje dane wynikowe na stdout\n");
	printf(" real     - razem z nomatlab, dane wyjsciowe zamienia na liczby rzeczywiste\n"); 
	printf("\n* Na wejscie programu nalezy podac kolejne wartosci badanej funkcji\n");
    printf("! Zalecam zapisanie funkcji do pliku, a potem:\n cat nazwa_pliku | %s [n]\n\n\n",_argv[0]);
    fflush(stdout);
    exit(0);
    }
  }
}

int main(int _argc,char *_argv[])
{
fprintf(stderr,"\nWczytuje opcje...\n");
Opcje(_argc,_argv);             //opcje programu, pomoc
fprintf(stderr,"\nPobieram dane...\n");
PobierzDane();                  //pobiera dane
fprintf(stderr,"\nWykonuje obliczenia...\n");
Obliczenia();                   //wykonuje obliczenia
fprintf(stderr,"\nGeneruje dane wyjsciowe...");
Wyjscie();                      //zapisuje rezultat "four.m"
if (matlab)
  {
  fprintf(stderr,"\nUruchamiam Matlab'a\n");
  Matlab();
  }
fprintf(stderr,"\nGotowe! Dziekuje bardzo!\n");
return 0;
}


