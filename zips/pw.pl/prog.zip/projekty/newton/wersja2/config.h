
/* Plik konfiguracyjny projektu z PROG
   
   Rozprowadzany na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

/* Definiowac tylko przy sprawdzaniu poprawnosci dzialania programu */
//#define DEBUG

/* Tutaj definiujemy, ile klockow (liczb, funkcji, itp.) moze zawierac
   dzialanie obrabiane przez przygotuj_string, wartosc_funkcji */
#define MAX_ELEMENTOW 100

// Przyrost delta x uzywany przy liczeniu pochodnej
#define przyrost 0.0001
