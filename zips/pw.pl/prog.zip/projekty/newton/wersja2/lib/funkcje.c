
/* Biblioteka projektu zawierajaca funkcje pozwalajace
   wykonywac rozne ciekawe rzeczy z wzorami funkcji podanymi
   w postaci ciagu znakow.
   
   Rozprowadzana na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

/* Definicje uzywanych bibliotek */
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "funkcje.h"
#include "config.h"

char napis[100];

/* Definicja stalych uzywanych przy wagach */
#define ST_DODAWANIE   1
#define ST_ODEJMOWANIE 2
#define ST_MNOZENIE    3
#define ST_DZIELENIE   4
#define ST_POTEGOWANIE 5
#define ST_FUNKCJA     6

/* Struktura zawierajaca struktury potrzebne do rozkladania i obliczania funkcji
   i pochodnych */
typedef struct {
    /* Tablice sluzace do przechowywania rozlozonego na elementy pierwsze */
    /* dzialania - liczb, napisow i wag ich dzialan */
    double liczby[MAX_ELEMENTOW];
    char stringi[MAX_ELEMENTOW][100];
    int wagi[MAX_ELEMENTOW];

    /* Po uzyciu przygotuj_funkcja zmienna okresla, ile "klockow" zawiera dzialanie */
    int ile;
} LICZBA;

/* Funkcja podaje dzialanie zawarte w wadze podanej jako "wartosc" */
int oblicz_dzialanie(int wartosc) {
    int zwracana; //wartosc zwracana

    zwracana=wartosc;
    while (zwracana>6) {zwracana=zwracana-6;};

    return zwracana;
}

/* Dodaje jedno podane dzialanie do struktury "mojaliczba" */
int dodaj_klocek(int numer, unsigned char *string, double liczba, int waga, LICZBA *mojaliczba) {
    if (numer+1>MAX_ELEMENTOW) return 6; //za malo pamieci
    
    mojaliczba->liczby[numer]=liczba;
    strcpy(mojaliczba->stringi[numer],string);
    mojaliczba->wagi[numer]=waga;
    mojaliczba->ile++;
    
    return 0;
}

/* Usuwa ze struktury "mojaliczba" dzialania od numeru "numer".
   "ileusunac" okresla, ile dzialan usunac */
int usun_klocek(int numer, int ileusunac, LICZBA *mojaliczba) {
    int i;

    if (numer-ileusunac>mojaliczba->ile) {
	dprintf("Blad w usun. Prosze raportowac\n");
	return 1;
    }
        
    for (i=numer;i<mojaliczba->ile-ileusunac+1;i++) {	
	mojaliczba->liczby[i]=mojaliczba->liczby[i+ileusunac];
	strcpy(mojaliczba->stringi[i],mojaliczba->stringi[i+ileusunac]);
	mojaliczba->wagi[i]=mojaliczba->wagi[i+ileusunac];
    }
    mojaliczba->ile=mojaliczba->ile-ileusunac;
    
    return 0;
}

/* Oblicza wartosc funkcji podanej w strukturze "moja liczba" dla x o wartosci
   "iks". Wynik zwracany w "zwroc_wartosc" */
int wartosc_funkcji(unsigned char *ciag, double *zwroc_wartosc, double iks)
{
    int i,j; //petle
    
    LICZBA mojaliczba;

    int poziom=0;

    char znaki[100]; //przy parsowaniu ciagu znakow

    double wynik=0; //jezeli parsujemy liczbe - tutaj jest jej aktualna wartosc
    double mnoznik=1; //mnoznik dla kolejnej cyfry liczby
    
    int stan=0; // zmienna okreslajaca stan parsowania: 0-glowna petla,1-liczba,2-napis
    
    int num=0;  // numer kolejnego obrabianego znaku/dzialania

    /* Warunki poczatkowe */
    znaki[0]=0;
    mojaliczba.wagi[0]=0;
    mojaliczba.ile=0;

    /* Znak 0x00 konczy ciag. Wykonujemy petle az do niego */    
    while (*ciag!=0x00) {
	if (stan==0) { //start i znaki dzialan, nawiasy
	    if ((*ciag>='0' && *ciag<='9') || *ciag=='.') { //cyfry lub kropka
		wynik=0; mnoznik=1; //wartosc domyslne dla liczby
		znaki[0]=0; //czyscimy
		stan=1; //teraz bedziemy obrabiac liczbe
	    } else {
    		if ((*ciag>='a' && *ciag<='z') || /* znaki alfabetu */
		    (*ciag>='A' && *ciag<='Z')) { /*     -"-        */
		    znaki[0]=0; //czyscimy
		    wynik=0; //czyscimy
		    stan=2; //teraz bedziemy obrabiac ciag znakow
		} else {
    		    switch (*ciag) {
			case '+': /* Znaki dzialan */
			case '-': /*      -"-      */
			case '*': /*      -"-      */
			case '/': /*      -"-      */
			case '^': /*      -"-      */
			    if (*(ciag+1)==0x00) return 7; //znak dzialania jest ostatni w ciagu
		    	    /* Tworzymy nowa pozycje */
			    switch (*ciag) {
				case '+':
				    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_DODAWANIE+6*poziom, &mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '-':
				    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_ODEJMOWANIE+6*poziom, &mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '*':
				    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_MNOZENIE+6*poziom, &mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '/':
				    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_DZIELENIE+6*poziom, &mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '^':
				    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_POTEGOWANIE+6*poziom, &mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
			    }
		    	    ciag++;num++; //przechodzimy znak do przodu
			    break;
			case '(': /* Otwieramy nawias */
			    if (*(ciag+1)==0x00) return 7; //nawias jest ostatni w ciagu
			    poziom++;
		    	    mojaliczba.liczby[mojaliczba.ile]=0; //czyscimy
		    	    strcpy(znaki,""); //czyscimy
			    wynik=0; //czyscimy
			    ciag++;num++; //przechodzimy znak do przodu
			    break;
			case ')': /* Zamykamy nawias */
			    if (poziom==0) { /* Za duzo nawiasow prawych */
				mojaliczba.ile=num;
				return 1;
			    }
			    poziom--;
			    ciag++;num++; //przechodzimy znak do przodu
			    break;			
			case ' ': /* Spacje po prostu ignorujemy */
		    	    ciag++;num++; //przechodzimy znak do przodu
			    break;
			default: //nieznany znak
			    mojaliczba.ile=num;
			    return 5;
		    }
		}
	    }
	}
	if (stan==1) { //cyfry i kropka dziesietna
	    /* Mamy cyfre */
	    if (*ciag>='0' && *ciag<='9') {
		/* ... wiec dodajemy odpowiednio do naszej liczby */
		if (mnoznik>=1) { //liczby bez czesci ulamkowej
		    mnoznik=mnoznik*10;
		    wynik=wynik*10+(*ciag-'0');
		} else { //i z czescia ulamkowa
		    wynik=wynik+mnoznik*(*ciag-'0');
		    mnoznik=mnoznik*0.1;
		}
		ciag++;num++; //przechodzimy znak do przodu
	    } else {
		switch (*ciag) {
		    case '.': /* Kropka wprowadza znaki dziesietne */
			if (mnoznik>0.9) {
			    mnoznik=0.1;
			} else {
			    /* Nie moze byc dwoch kropek w liczbie */
			    mojaliczba.ile=num;
			    return 3;
			}
			ciag++;num++; //przechodzimy znak do przodu
			break;
		    case ' ':
			ciag++;num++; //przechodzimy znak do przodu
			break;
		    default: //nieznany znak w liczbie - wracamy do glownej petli
			stan=0;
		}
	    }
	}
	if (stan==2) { //znaki
	    if (*ciag>='a' && *ciag<='z') { //male znaki
		znaki[strlen(znaki)+1]=0; //zamykamy zwiekszony ciag znakiem 0
		znaki[strlen(znaki)]=*ciag;  //dodajemy znak
		ciag++;num++; //przechodzimy znak do przodu
	    } else {
		if (*ciag>='A' && *ciag<='Z') { //duze znaki
    		    znaki[strlen(znaki)+1]=0; //zamykamy zwiekszony ciag znakiem 0
		    znaki[strlen(znaki)]=*ciag-('A'-'a'); //dodajemy+ konwersja na male litery
    		    ciag++;num++; //przechodzimy znak do przodu
		} else {
		    if (*ciag=='(') { //dla funkcji typu cos(x)..
			if (dodaj_klocek(mojaliczba.ile, znaki, wynik, ST_FUNKCJA+6*poziom, &mojaliczba)!=0)
			    return 6; //za malo pamieci
		    }
		    stan=0; //do glownej petli
		}   
	    } 
	}
    }
    
    /* Po wyjsciu z petli cos tam zawsze zostalo niedokonczone. Wstawmy to */
    if (dodaj_klocek(mojaliczba.ile, znaki, wynik, 0 , &mojaliczba)!=0)
	return 6; //za malo pamieci

    /* Wzor rozlozony i gotowy. Obliczmy teraz wartosc funkcji */
    
    /* Zamieniamy napisy "pi" i "e" na odpowiadajace im stale matematyczne,
       jak rowniez zamiast iksa wstawiamy odpowiadajaca mu wartosc */
    for (i=0;i<mojaliczba.ile;i++) {
	if (!strcmp(mojaliczba.stringi[i],"pi")) { //liczba PI
	    mojaliczba.liczby[i]=M_PI;
	    strcpy(mojaliczba.stringi[i],"");
	}    
	if (!strcmp(mojaliczba.stringi[i],"e")) { //liczba Eulera
	    mojaliczba.liczby[i]=M_E;
	    strcpy(mojaliczba.stringi[i],"");
	}    
	if (!strcmp(mojaliczba.stringi[i],"x")) { //iks
	    mojaliczba.liczby[i]=iks;
	    strcpy(mojaliczba.stringi[i],"");
	}    
    }

    /* Dopoki waga dzialania!=0. Czyli dopoki mamy dzialania */    
    while (mojaliczba.ile!=0) {
        j=mojaliczba.wagi[0];num=0; //warunki poczatkowe
	/* szukamy dzialania o najwyzszej wadze */
	for (i=0;i<mojaliczba.ile;i++) {
	    if (mojaliczba.wagi[i]>j) {j=mojaliczba.wagi[i];num=i;}
	}
	j=oblicz_dzialanie(j);
	switch (j) {
	    case ST_DODAWANIE  : /* Dodawanie   */
	    case ST_ODEJMOWANIE: /* odejmowanie */
	    case ST_MNOZENIE   : /* mnozenie    */
	    case ST_DZIELENIE  : /* dzielenie   */
	    case ST_POTEGOWANIE: /* potegowanie */
		if (strcmp(mojaliczba.stringi[num+1],"")) { //jakis dziwny string
    		    strcpy(napis,mojaliczba.stringi[num+1]);
		    return 4;
		}
		switch (j) {
		    case 1:mojaliczba.liczby[num]=mojaliczba.liczby[num]+mojaliczba.liczby[num+1];break;
		    case 2:mojaliczba.liczby[num]=mojaliczba.liczby[num]-mojaliczba.liczby[num+1];break;
		    case 3:mojaliczba.liczby[num]=mojaliczba.liczby[num]*mojaliczba.liczby[num+1];break;
		    case 4:if (mojaliczba.liczby[num+1]==0) return 2;
    			   mojaliczba.liczby[num]=mojaliczba.liczby[num]/mojaliczba.liczby[num+1];
			   break;
		    case 5:mojaliczba.liczby[num]=pow(mojaliczba.liczby[num],mojaliczba.liczby[num+1]);
		}
		mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		break;
	    case ST_FUNKCJA: //funkcje matematyczne
		if (!strcmp(mojaliczba.stringi[num],"ln")) {
		    mojaliczba.liczby[num]=log(mojaliczba.liczby[num+1]);
		    if (isnan(mojaliczba.liczby[num])) return 9;
		    strcpy(mojaliczba.stringi[num],"");
		    mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		} else {
		if (!strcmp(mojaliczba.stringi[num],"sin")) {
		    mojaliczba.liczby[num]=sin(mojaliczba.liczby[num+1]);
		    if (isnan(mojaliczba.liczby[num])) return 9;
		    strcpy(mojaliczba.stringi[num],"");
		    mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		} else {
		if (!strcmp(mojaliczba.stringi[num],"cos")) {
		    mojaliczba.liczby[num]=cos(mojaliczba.liczby[num+1]);
		    if (isnan(mojaliczba.liczby[num])) return 9;
		    strcpy(mojaliczba.stringi[num],"");
		    mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		} else {
		if (!strcmp(mojaliczba.stringi[num],"tan")) {
		    mojaliczba.liczby[num]=tan(mojaliczba.liczby[num+1]);
		    if (isnan(mojaliczba.liczby[num])) return 9;
		    strcpy(mojaliczba.stringi[num],"");
		    mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		} else {
		if (!strcmp(mojaliczba.stringi[num],"ctg")) {
		    if (mojaliczba.liczby[num+1]==0) return 2;
		    mojaliczba.liczby[num]=1/tan(mojaliczba.liczby[num+1]);
		    if (isnan(mojaliczba.liczby[num])) return 9;
		    strcpy(mojaliczba.stringi[num],"");
		    mojaliczba.wagi[num]=mojaliczba.wagi[num+1];		
		} else {
		    strcpy(napis,mojaliczba.stringi[num]);
		    return 4;
		}
		}
		}
		}
		}
	}
	usun_klocek(num+1,1,&mojaliczba);
    }

    *zwroc_wartosc=mojaliczba.liczby[0];    

    return 0;
}

/* Oblicza wartosc pochodnej funkcji o wzorze podanym w zmiennej "ciag"
dla x o wartosci "iks". Wynik zwracany w "zwroc_wartosc" */
int wartosc_pochodnej(unsigned char *ciag, double *zwroc_wartosc, double iks)
{
    double wynik,wynik2;
    int i;
    
    i=wartosc_funkcji(ciag,&wynik,iks+przyrost);
    if (i!=0) return i;

    i=wartosc_funkcji(ciag,&wynik2,iks);
    if (i!=0) return i;
    
    *zwroc_wartosc=(wynik-wynik2)/przyrost;    
    
    return 0;
}

/* Z ciagu "ciag" wyciaga liczbe rzeczywista */
int wez_liczba(unsigned char *ciag, double *wartosc)
{
    double wynik=0; //aktualna wartosc liczby
    double mnoznik=1; //mnoznik dla kolejnej cyfry liczby
    int num=0; //ktory znak "ciagu" parsujemy
    int minus=0; //czy liczba ujemna

    /* Znak 0x00 konczy ciag. Wykonujemy petle az do niego */    
    while (*ciag!=0x00) {
	/* Mamy cyfre */
	if (*ciag>='0' && *ciag<='9') {
	    /* ... wiec dodajemy odpowiednio do naszej liczby */
	    if (mnoznik>=1) { //liczby bez czesci ulamkowej
		mnoznik=mnoznik*10;
		wynik=wynik*10+(*ciag-'0');
	    } else { //i z czescia ulamkowa
		wynik=wynik+mnoznik*(*ciag-'0');
		mnoznik=mnoznik*0.1;
	    }
	    ciag++;num++;
	} else {
	    switch (*ciag) {
		case '-':
		    if (num!=0) return 11; //minus nie na poczatku
		    minus=1;
		    ciag++;num++;
		    break;
		case '.': /* Kropka wprowadza znaki dziesietne */
		    if (mnoznik>0.9) {
			mnoznik=0.1;
		    } else {
			/* Nie moze byc dwoch kropek w liczbie */
			*wartosc=num;
			return 3;
		    }
		    ciag++;num++;
		    break;
		case ' ':
		    ciag++;num++;
		    break;
		default: //nieznany znak w liczbie
		    return 5;
	    }
	}
    }
    
    *wartosc=wynik;
    if (minus==1) *wartosc=-wynik;

    return 0;
}