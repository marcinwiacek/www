
/* Plik naglowkowy projektu z PROG
   
   Rozprowadzany na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

#include "config.h"

/* Definicja nowej funkcji wypisujacej tekst
   tylko przy zdefiniowanej stalej DEBUG */
#ifndef DEBUG
    #define dprintf(a...) do { } while (0)
#else
    #define dprintf(a...) do { fprintf(stderr, a); fflush(stderr); } while (0) 
#endif

extern char napis[100];

/* Deklaracje publicznych funkcji */
int wartosc_funkcji(unsigned char *ciag, double *zwroc_wartosc, double iks);
int wartosc_pochodnej(unsigned char *ciag, double *zwroc_wartosc, double iks);
int wez_liczba(unsigned char *ciag, double *wartosc);
