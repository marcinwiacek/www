
/* Biblioteka projektu zawierajaca funkcje pozwalajace
   wykonywac rozne ciekawe rzeczy z wzorami funkcji podanymi
   w postaci ciagu znakow.
   
   Rozprowadzana na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

/* Definicje uzywanych bibliotek */
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "funkcje.h"
#include "config.h"

char napis[100];

/* Funkcja oblicza poziom wartosci wagi podanej jako "wartosc" */
int oblicz_poziom(int wartosc) {
    int zwracana; //wartosc zwracana

    zwracana=0;
    while (wartosc>6) {wartosc=wartosc-6;zwracana++;};

    return zwracana;
}

/* Funkcja podaje dzialanie zawarte w wadze podanej jako "wartosc" */
int oblicz_dzialanie(int wartosc) {
    int zwracana; //wartosc zwracana

    zwracana=wartosc;
    while (zwracana>6) {zwracana=zwracana-6;};

    return zwracana;
}

/* Dodaje jedno podane dzialanie do struktury "mojaliczba" */
int dodaj_klocek(int numer, unsigned char *string, double liczba, int waga, LICZBA *mojaliczba) {
    if (numer+1>MAX_ELEMENTOW) return 6; //za malo pamieci
    
    mojaliczba->liczby[numer]=liczba;
    strcpy(mojaliczba->stringi[numer],string);
    mojaliczba->wagi[numer]=waga;
    mojaliczba->ile++;
    
    return 0;
}

/* Usuwa ze struktury "mojaliczba" dzialania od numeru "numer".
   "ileusunac" okresla, ile dzialan usunac */
int usun_klocek(int numer, int ileusunac, LICZBA *mojaliczba) {
    int i;

    if (numer-ileusunac>mojaliczba->ile) {
	dprintf("Blad w usun. Prosze raportowac\n");
	return 1;
    }
        
    for (i=numer;i<mojaliczba->ile-ileusunac+1;i++) {	
	mojaliczba->liczby[i]=mojaliczba->liczby[i+ileusunac];
	strcpy(mojaliczba->stringi[i],mojaliczba->stringi[i+ileusunac]);
	mojaliczba->wagi[i]=mojaliczba->wagi[i+ileusunac];
    }
    mojaliczba->ile=mojaliczba->ile-ileusunac;
    
    return 0;
}

/* Funkcja wypisuje wzor funkcji podanej jako "mojaliczba" */
void pisz_funkcja(LICZBA *mojaliczba)
{
    int i;        //zmienna do petli
    int poziom=1; //tutaj zapisujemy poziom kolejnych wag

    dprintf("wchodzi do pisz_funkcja\n");
    
#ifdef DEBUG    
    /* Wypisuje calosc liczby */
    dprintf("lp liczby stringi wagi\n");
    for (i=0;i<mojaliczba->ile;i++) {
	dprintf("%i %f \"%s\" %i %i \n",i,mojaliczba->liczby[i],mojaliczba->stringi[i],mojaliczba->wagi[i],oblicz_dzialanie(mojaliczba->wagi[i]));
    }
    dprintf("\n");
    printf("funkcja : ");
#endif

    for (i=0;i<mojaliczba->ile;i++) {

	if (oblicz_poziom(poziom)<oblicz_poziom(mojaliczba->wagi[i])) printf("(");
	
	if (strcmp(mojaliczba->stringi[i],"")) {
	    printf("%s",mojaliczba->stringi[i]);
	} else {
	    printf("%f",mojaliczba->liczby[i]);
	}

	if (oblicz_poziom(poziom)>oblicz_poziom(mojaliczba->wagi[i])) printf(")");

	poziom=mojaliczba->wagi[i];
	
	switch (oblicz_dzialanie(poziom)) {
	    case 1: printf("+"); break;
	    case 2: printf("-"); break;
	    case 3: printf("*"); break;
	    case 4: printf("/"); break;
	    case 5: printf("^"); break;
	}
    }
    
    printf("\n");
}

/* Funkcja rozklada dzialanie podane jako ciag na jak najmniejsze elementy.
   Zwraca 0, gdy ciag jest dla niej poprawny (lub odpowiednie kody bledow)
   W przypadku bledu w zmiennej ile w strukturze mojaliczba
   znajduje sie numer blednego znaku w podanym ciagu */
int przygotuj_funkcja(unsigned char *ciag, LICZBA *mojaliczba)
{
    int poziom=0;

    char znaki[100]; //przy parsowaniu ciagu znakow

    double wynik=0; //jezeli parsujemy liczbe - tutaj jest jej aktualna wartosc
    double mnoznik=1; //mnoznik dla kolejnej cyfry liczby
    
    int stan=0; // zmienna okreslajaca stan parsowania: 0-glowna petla,1-liczba,2-napis
    
    int num=0;  // numer kolejnego obrabianego znaku

    dprintf("wchodzi do przygotuj_string\n");

    /* Warunki poczatkowe */
    znaki[0]=0;
    mojaliczba->wagi[0]=0;
    mojaliczba->ile=0;

    /* Znak 0x00 konczy ciag. Wykonujemy petle az do niego */    
    while (*ciag!=0x00) {
	if (stan==0) { //start i znaki dzialan, nawiasy
	    if ((*ciag>='0' && *ciag<='9') || *ciag=='.') { //cyfry lub kropka
		wynik=0; mnoznik=1; //wartosc domyslne dla liczby
		znaki[0]=0; //czyscimy
		stan=1; //teraz bedziemy obrabiac liczbe
	    } else {
    		if ((*ciag>='a' && *ciag<='z') || /* znaki alfabetu */
		    (*ciag>='A' && *ciag<='Z')) { /*     -"-        */
		    znaki[0]=0; //czyscimy
		    wynik=0; //czyscimy
		    stan=2; //teraz bedziemy obrabiac ciag znakow
		} else {
    		    switch (*ciag) {
			case '+': /* Znaki dzialan */
			case '-': /*      -"-      */
			case '*': /*      -"-      */
			case '/': /*      -"-      */
			case '^': /*      -"-      */
			    if (*(ciag+1)==0x00) return 7; //znak dzialania jest ostatni w ciagu
		    	    /* Tworzymy nowa pozycje */
			    switch (*ciag) {
				case '+':
				    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_DODAWANIE+6*poziom, mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '-':
				    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_ODEJMOWANIE+6*poziom, mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '*':
				    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_MNOZENIE+6*poziom, mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '/':
				    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_DZIELENIE+6*poziom, mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
				case '^':
				    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_POTEGOWANIE+6*poziom, mojaliczba)!=0)
					return 6; //za malo pamieci
				    break;
			    }
		    	    ciag++;num++; //przechodzimy znak do przodu
			    break;
			case '(': /* Otwieramy nawias */
			    if (*(ciag+1)==0x00) return 7; //nawias jest ostatni w ciagu
			    poziom++;
		    	    mojaliczba->liczby[mojaliczba->ile]=0; //czyscimy
		    	    strcpy(znaki,""); //czyscimy
			    wynik=0; //czyscimy
			    ciag++;num++; //przechodzimy znak do przodu
			    break;
			case ')': /* Zamykamy nawias */
			    if (poziom==0) { /* Za duzo nawiasow prawych */
				mojaliczba->ile=num;
				return 1;
			    }
			    poziom--;
			    ciag++;num++; //przechodzimy znak do przodu
			    break;			
			case ' ': /* Spacje po prostu ignorujemy */
		    	    ciag++;num++; //przechodzimy znak do przodu
			    break;
			default: //nieznany znak
			    mojaliczba->ile=num;
			    return 5;
		    }
		}
	    }
	}
	if (stan==1) { //cyfry i kropka dziesietna
	    /* Mamy cyfre */
	    if (*ciag>='0' && *ciag<='9') {
		/* ... wiec dodajemy odpowiednio do naszej liczby */
		if (mnoznik>=1) { //liczby bez czesci ulamkowej
		    mnoznik=mnoznik*10;
		    wynik=wynik*10+(*ciag-'0');
		} else { //i z czescia ulamkowa
		    wynik=wynik+mnoznik*(*ciag-'0');
		    mnoznik=mnoznik*0.1;
		}
		ciag++;num++; //przechodzimy znak do przodu
	    } else {
		switch (*ciag) {
		    case '.': /* Kropka wprowadza znaki dziesietne */
			if (mnoznik>0.9) {
			    mnoznik=0.1;
			} else {
			    /* Nie moze byc dwoch kropek w liczbie */
			    mojaliczba->ile=num;
			    return 3;
			}
			ciag++;num++; //przechodzimy znak do przodu
			break;
		    case ' ':
			ciag++;num++; //przechodzimy znak do przodu
			break;
		    default: //nieznany znak w liczbie - wracamy do glownej petli
			stan=0;
		}
	    }
	}
	if (stan==2) { //znaki
	    if (*ciag>='a' && *ciag<='z') { //male znaki
		znaki[strlen(znaki)+1]=0; //zamykamy zwiekszony ciag znakiem 0
		znaki[strlen(znaki)]=*ciag;  //dodajemy znak
		ciag++;num++; //przechodzimy znak do przodu
	    } else {
		if (*ciag>='A' && *ciag<='Z') { //duze znaki
    		    znaki[strlen(znaki)+1]=0; //zamykamy zwiekszony ciag znakiem 0
		    znaki[strlen(znaki)]=*ciag-('A'-'a'); //dodajemy+ konwersja na male litery
    		    ciag++;num++; //przechodzimy znak do przodu
		} else {
		    if (*ciag=='(') { //dla funkcji typu cos(x)..
			if (dodaj_klocek(mojaliczba->ile, znaki, wynik, ST_FUNKCJA+6*poziom, mojaliczba)!=0)
			    return 6; //za malo pamieci
		    }
		    stan=0; //do glownej petli
		}   
	    } 
	}
    }
    
    /* Po wyjsciu z petli cos tam zawsze zostalo niedokonczone. Wstawmy to */
    if (dodaj_klocek(mojaliczba->ile, znaki, wynik, 0 , mojaliczba)!=0)
	return 6; //za malo pamieci

#ifdef DEBUG
    pisz_funkcja(mojaliczba);
#endif    

    return 0;
}

/* Oblicza wartosc funkcji podanej w strukturze "moja liczba" dla x o wartosci
   "iks". Wynik zwracany w "zwroc_wartosc" */
int wartosc_funkcji(double *zwroc_wartosc, double iks, LICZBA *mojaliczba)
{
    int i,j; //petle
    int num; //okresla numer obrabianego dzialania

    dprintf("wchodzi do wartosc funkcji\n");

    /* Zamieniamy napisy "pi" i "e" na odpowiadajace im stale matematyczne,
       jak rowniez zamiast iksa wstawiamy odpowiadajaca mu wartosc */
    for (i=0;i<mojaliczba->ile;i++) {
	if (!strcmp(mojaliczba->stringi[i],"pi")) { //liczba PI
	    mojaliczba->liczby[i]=M_PI;
	    strcpy(mojaliczba->stringi[i],"");
	}    
	if (!strcmp(mojaliczba->stringi[i],"e")) { //liczba Eulera
	    mojaliczba->liczby[i]=M_E;
	    strcpy(mojaliczba->stringi[i],"");
	}    
	if (!strcmp(mojaliczba->stringi[i],"x")) { //iks
	    mojaliczba->liczby[i]=iks;
	    strcpy(mojaliczba->stringi[i],"");
	}    
    }

    /* Dopoki waga dzialania!=0. Czyli dopoki mamy dzialania */    
    while (mojaliczba->ile!=0) {
        j=mojaliczba->wagi[0];num=0; //warunki poczatkowe
	/* szukamy dzialania o najwyzszej wadze */
	for (i=0;i<mojaliczba->ile;i++) {
	    if (mojaliczba->wagi[i]>j) {j=mojaliczba->wagi[i];num=i;}
	}
	j=oblicz_dzialanie(j);
	switch (j) {
	    case 1: /* Dodawanie   */
	    case 2: /* odejmowanie */
	    case 3: /* mnozenie    */
	    case 4: /* dzielenie   */
	    case 5: /* potegowanie */
		if (strcmp(mojaliczba->stringi[num+1],"")) { //jakis dziwny string
    		    strcpy(napis,mojaliczba->stringi[num+1]);
		    return 4;
		}
		switch (j) {
		    case 1:mojaliczba->liczby[num]=mojaliczba->liczby[num]+mojaliczba->liczby[num+1];break;
		    case 2:mojaliczba->liczby[num]=mojaliczba->liczby[num]-mojaliczba->liczby[num+1];break;
		    case 3:mojaliczba->liczby[num]=mojaliczba->liczby[num]*mojaliczba->liczby[num+1];break;
		    case 4:if (mojaliczba->liczby[num+1]==0) return 2;
    			   mojaliczba->liczby[num]=mojaliczba->liczby[num]/mojaliczba->liczby[num+1];
			   break;
		    case 5:mojaliczba->liczby[num]=pow(mojaliczba->liczby[num],mojaliczba->liczby[num+1]);
		}
		mojaliczba->wagi[num]=mojaliczba->wagi[num+1];		
		break;
	    case 6: //funkcje matematyczne
		if (!strcmp(mojaliczba->stringi[num],"ln")) {
		    mojaliczba->liczby[num]=log(mojaliczba->liczby[num+1]);
		    if (isnan(mojaliczba->liczby[num])) return 9;
		    strcpy(mojaliczba->stringi[num],"");
		    mojaliczba->wagi[num]=mojaliczba->wagi[num+1];		
		} else {
		    strcpy(napis,mojaliczba->stringi[num]);
		    return 4;
		}
	}
	usun_klocek(num+1,1,mojaliczba);
    }

    *zwroc_wartosc=mojaliczba->liczby[0];    

    return 0;
}

/* We wzoru funkcji podanej jako "ciag" probuje utworzyc pochodna
   i zapisac ja od razu w strukturze "mojaliczba" */
int przygotuj_pochodna(unsigned char *ciag, LICZBA *mojaliczba)
{
    LICZBA mojaliczba2;
    int poziom=0;
    int i;

    /* Rozkladamy ciag na elementy "pierwsze" */    
    i=przygotuj_funkcja(ciag,&mojaliczba2);
    if (i!=0) return i;
        
    /* Wyczyscmy */
    mojaliczba->ile=0;
    mojaliczba->wagi[0]=0;
    
    dprintf("wchodzi do pochodna\n");

    /* Zamieniamy napisy "pi" i "e" na odpowiadajace im stale matematyczne */
    for (i=0;i<mojaliczba2.ile;i++) {
	if (!strcmp(mojaliczba2.stringi[i],"pi")) { //liczba PI
	    mojaliczba2.liczby[i]=M_PI;
	    strcpy(mojaliczba2.stringi[i],"");
	}    
	if (!strcmp(mojaliczba2.stringi[i],"e")) { //liczba Eulera
	    mojaliczba2.liczby[i]=M_E;
	    strcpy(mojaliczba2.stringi[i],"");
	}    
    }

    i=0;
    while (i!=mojaliczba2.ile) { //musimy z i dojsc do konca wzoru funkcji
	switch(oblicz_dzialanie(mojaliczba2.wagi[i])) {
	    case 0: // koniec
	    case 1: // dodawanie
	    case 2: // odejmowanie
		if (strcmp(mojaliczba2.stringi[i],"")) {
		    /* Jezeli mamy x, potega = 1 */
		    if (dodaj_klocek(mojaliczba->ile,"",1,oblicz_dzialanie(mojaliczba2.wagi[i])+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		}
#ifdef DEBUG
		pisz_funkcja(mojaliczba);
#endif
		break;
	    case 3: //mnozenie
		if (strcmp(mojaliczba2.stringi[i+1],"")) { //mamy string na tej pozycji
		    if (strcmp(mojaliczba2.stringi[i],"")) {
			/* x*x. Pochodna = 2*x */
    			if (dodaj_klocek(mojaliczba->ile,"",2,ST_MNOZENIE+poziom*6,mojaliczba)!=0) return 6;  //za malo pamieci
    			if (dodaj_klocek(mojaliczba->ile,"x",0,ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		    } else {
			/* liczba*x. Pochodna = liczba */
    			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i],ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		    }
		} else {
		    if (strcmp(mojaliczba2.stringi[i],"")) { //jest string.
			/* x*liczba. Pochodna=liczba */
    			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i+1],ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		    }
		}
		i++;
		switch (oblicz_dzialanie(mojaliczba2.wagi[i])) {
		    case ST_DODAWANIE:
			break;
		    case ST_ODEJMOWANIE:
			mojaliczba->wagi[mojaliczba->ile-1]=oblicz_dzialanie(mojaliczba2.wagi[i])+poziom*6;
			break;
		    case ST_MNOZENIE:
			return 10; //zbyt skomplikowane ;-)
		    case ST_POTEGOWANIE:
			mojaliczba->wagi[mojaliczba->ile-1]=ST_MNOZENIE+poziom*6;
			i--;
			break;
		    case ST_FUNKCJA:
			return 10;
		}
#ifdef DEBUG
		pisz_funkcja(mojaliczba);
#endif
		break;
	    case 4: //dzielenie
		/* Mamy 1/2. Pochodna = (1'*2-1*2')/2^2 */
		
		/* Pochodna 1 wyrazenia */
		if (strcmp(mojaliczba2.stringi[i],"")) { //czy x na tej pozycji
    		    if (dodaj_klocek(mojaliczba->ile,"",1,ST_MNOZENIE+(poziom+1)*6,mojaliczba)!=0) return 6; //za malo pamieci
		} else {
    		    if (dodaj_klocek(mojaliczba->ile,"",0,ST_MNOZENIE+(poziom+1)*6,mojaliczba)!=0) return 6; //za malo pamieci
		}

		/* 2 wyrazenie */
    		if (dodaj_klocek(mojaliczba->ile,mojaliczba2.stringi[i+1],mojaliczba2.liczby[i+1],ST_ODEJMOWANIE+(poziom+1)*6,mojaliczba)!=0) return 6; //za malo pamieci
		
		/* pierwsze wyrazenie */
    		if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i],ST_MNOZENIE+(poziom+1)*6,mojaliczba)!=0) return 6; //za malo pamieci
		
		/* Pochodna drugiego */
		if (strcmp(mojaliczba2.stringi[i+1],"")) { //czy x na tej pozycji
    		    if (dodaj_klocek(mojaliczba->ile,"",1,ST_DZIELENIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		} else {
    		    if (dodaj_klocek(mojaliczba->ile,"",0,ST_DZIELENIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		}

		/* 2 wyrazenie */
    		if (dodaj_klocek(mojaliczba->ile,mojaliczba->stringi[i+1],mojaliczba2.liczby[i+1],ST_POTEGOWANIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci

		/* kwadrat */
    		if (dodaj_klocek(mojaliczba->ile,"",2,ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6; //za malo pamieci
		
		i++;
#ifdef DEBUG
		pisz_funkcja(mojaliczba);
#endif
		break;
	    case 5: //potegowanie
		if (strcmp(mojaliczba2.stringi[i],"")) { //mamy string
		    if (strcmp(mojaliczba2.stringi[i+1],"")) {
			/* x^x */
			return 8; //jak obliczac x^x ? ;-)
		    } else {
			/* x^liczba. Pochodna = liczba*x^(liczba-1) */
			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i+1],ST_MNOZENIE+poziom*6,mojaliczba)!=0) return 6;
			if (dodaj_klocek(mojaliczba->ile,"x",0,ST_POTEGOWANIE+poziom*6,mojaliczba)!=0) return 6;
			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i+1]-1,ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6;
		    }
		} else {
		    if (strcmp(mojaliczba2.stringi[i+1],"")) {
			/* liczba^x. Potega= liczba^x*ln(liczba) */
			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i],ST_POTEGOWANIE+poziom*6,mojaliczba)!=0) return 6;
			if (dodaj_klocek(mojaliczba->ile,"x",0,ST_MNOZENIE+poziom*6,mojaliczba)!=0) return 6;
			if (dodaj_klocek(mojaliczba->ile,"ln",0,ST_FUNKCJA+(poziom+1)*6,mojaliczba)!=0) return 6;
			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i],ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6;
		    }
		}
		i++;
		switch (oblicz_dzialanie(mojaliczba2.wagi[i])) {
		    case ST_DODAWANIE:
			break;
		    case ST_ODEJMOWANIE:
			mojaliczba->wagi[mojaliczba->ile-1]=oblicz_dzialanie(mojaliczba2.wagi[i])+poziom*6;
			break;
		    case ST_MNOZENIE:
			return 10; //zbyt skomplikowane ;-)
		    case ST_POTEGOWANIE:
			return 10;
		    case ST_FUNKCJA:
			return 10;
		}
#ifdef DEBUG
		pisz_funkcja(mojaliczba);
#endif
		break;
	    case 6: // funkcje
		if (!strcmp(mojaliczba2.stringi[i],"ln"))	{
		    /* pochodna (1/x)*x' */
		    if (dodaj_klocek(mojaliczba->ile,"",1,ST_DZIELENIE+(poziom+1)*6,mojaliczba)!=0) return 6;
		    if (strcmp(mojaliczba2.stringi[i+1],"")) { //czy x
			if (dodaj_klocek(mojaliczba->ile,"x",0,ST_MNOZENIE+poziom*6,mojaliczba)!=0) return 6;
		    } else {
			if (dodaj_klocek(mojaliczba->ile,"",mojaliczba2.liczby[i+1],ST_MNOZENIE+poziom*6,mojaliczba)!=0) return 6;
		    }
		    if (strcmp(mojaliczba2.stringi[i+1],"")) { //czy x
			if (dodaj_klocek(mojaliczba->ile,"",1,ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6;
		    } else {
			if (dodaj_klocek(mojaliczba->ile,"",0,ST_DODAWANIE+poziom*6,mojaliczba)!=0) return 6;
		    }
		    i++;		    
		} else return 4; //nieznana funkcja
	}
	i++;
    }

    if (dodaj_klocek(mojaliczba->ile,"",0,0,mojaliczba)!=0) return 6;

#ifdef DEBUG        
    pisz_funkcja(mojaliczba);
#endif    

    return 0;
}

/* Z ciagu "ciag" wyciaga liczbe rzeczywista */
int wez_liczba(unsigned char *ciag, double *wartosc)
{
    double wynik=0; //aktualna wartosc liczby
    double mnoznik=1; //mnoznik dla kolejnej cyfry liczby
    int num=0; //ktory znak "ciagu" parsujemy
    int minus=0; //czy liczba ujemna

    /* Znak 0x00 konczy ciag. Wykonujemy petle az do niego */    
    while (*ciag!=0x00) {
	/* Mamy cyfre */
	if (*ciag>='0' && *ciag<='9') {
	    /* ... wiec dodajemy odpowiednio do naszej liczby */
	    if (mnoznik>=1) { //liczby bez czesci ulamkowej
		mnoznik=mnoznik*10;
		wynik=wynik*10+(*ciag-'0');
	    } else { //i z czescia ulamkowa
		wynik=wynik+mnoznik*(*ciag-'0');
		mnoznik=mnoznik*0.1;
	    }
	    ciag++;num++;
	} else {
	    switch (*ciag) {
		case '-':
		    if (num!=0) return 11; //minus nie na poczatku
		    minus=1;
		    ciag++;num++;
		    break;
		case '.': /* Kropka wprowadza znaki dziesietne */
		    if (mnoznik>0.9) {
			mnoznik=0.1;
		    } else {
			/* Nie moze byc dwoch kropek w liczbie */
			*wartosc=num;
			return 3;
		    }
		    ciag++;num++;
		    break;
		case ' ':
		    ciag++;num++;
		    break;
		default: //nieznany znak w liczbie
		    return 5;
	    }
	}
    }
    
    *wartosc=wynik;
    if (minus==1) *wartosc=-wynik;

    return 0;
}