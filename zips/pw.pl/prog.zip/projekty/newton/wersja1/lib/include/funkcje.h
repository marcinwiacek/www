
/* Plik naglowkowy projektu z PROG
   
   Rozprowadzany na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

#include "config.h"

/* Definicja nowej funkcji wypisujacej tekst
   tylko przy zdefiniowanej stalej DEBUG */
#ifndef DEBUG
    #define dprintf(a...) do { } while (0)
#else
    #define dprintf(a...) do { fprintf(stderr, a); fflush(stderr); } while (0) 
#endif

/* Definicja stalych uzywanych przy wagach */
#define ST_DODAWANIE   1
#define ST_ODEJMOWANIE 2
#define ST_MNOZENIE    3
#define ST_DZIELENIE   4
#define ST_POTEGOWANIE 5
#define ST_FUNKCJA     6

/* Struktura zawierajaca struktury potrzebne do rozkladania i obliczania funkcji
   i pochodnych */
typedef struct {
    /* Tablice sluzace do przechowywania rozlozonego na elementy pierwsze */
    /* dzialania - liczb, napisow i wag ich dzialan */
    double liczby[MAX_ELEMENTOW];
    char stringi[MAX_ELEMENTOW][100];
    int wagi[MAX_ELEMENTOW];

    /* Po uzyciu przygotuj_funkcja zmienna okresla, ile "klockow" zawiera dzialanie */
    int ile;
} LICZBA;

extern char napis[100];

/* Deklaracje publicznych funkcji */
void pisz_funkcja(LICZBA *mojaliczba);
int wartosc_funkcji(double *zwroc_wartosc, double iks, LICZBA *mojaliczba);
int przygotuj_funkcja(unsigned char *ciag, LICZBA *mojaliczba);
int przygotuj_pochodna(unsigned char *ciag, LICZBA *mojaliczba);
int wez_liczba(unsigned char *ciag, double *wartosc);
