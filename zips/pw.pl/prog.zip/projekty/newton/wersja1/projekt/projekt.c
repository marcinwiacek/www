
/* Plik glowny projektu.
   
   Rozprowadzany na licencji GNU GPL.
   
   Autor:   Marcin Wiacek <marcin-wiacek@topnet.pl>
   Grupa:   2P14
   Semestr: zimowy 2001
   
*/

/* Definicje uzywanych bibliotek */
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "funkcje.h"
#include "config.h"

double wart_funkcji,wart_pochodnej; //wartosci funkcji i pochodnej
LICZBA moja_liczba; //tutaj zapiszemy pochodna i funkcje
char wzor[1000]; //wzor funkcji od uzytkownika
int mojblad; // tutaj bedzie zapisywany blad zwracany przez funkcje z funkcje.c

/* Generalnie tutaj sa zebrane prawie wszystkie bledy numeryczne i skladniowe */
void blad(int i, double value, char liczba[1000], int dodaj) {
    int j,z;
    
    switch (i) {
	case 0:
	    break;
	case 1:
	    for (j=0;j<dodaj;j++) {printf(" ");}
	    for (j=0;j<mojblad-1;j++) {printf(" ");}
	    printf("^\n");
	    printf("Blad: za duzo nawiasow prawych\n");
	    break;
	case 2:
	    for (j=0;j<strlen(liczba)-1;j++) {
		if (!strcmp(liczba+j,"/0")) {
		    printf("                     ");
		    for (z=0;z<j;z++) {printf(" ");}
		    printf("^\n");
		}
	    }
	    printf("Blad: dzielenie przez zero\n");
	    break;
	case 3:
	    for (j=0;j<dodaj;j++) {printf(" ");}
	    for (j=0;j<mojblad-1;j++) {printf(" ");}
	    printf("^\n");
	    printf("Blad: w liczbie moze byc tylko jedna kropka czesci dziesietnej\n");
	    break;
	case 4:
	    printf("Blad: nieznana funkcja matematyczna \"%s\"\n",liczba);
	    break;
	case 5:
	    for (j=0;j<dodaj;j++) {printf(" ");}
	    for (j=0;j<mojblad-1;j++) {printf(" ");}
	    printf("^\n");
	    printf("Blad: nie znam takiego operatora matematycznego\n");
	    break;
	case 6:
	    printf("Blad: za duzo elementow w dzialaniu (max %i)\n",MAX_ELEMENTOW);
	    break;
	case 7:
	    printf("Blad: Podane wyrazenie konczy sie znakiem dzialania (nawiasem) !\n");
	    break;
	case 8:
	    printf("Blad: jak obliczyc pochodna x^x ?\n");
	    break;	
	case 9:
	    printf("Blad: funkcja ln jest zdefiniowana tylko dla wartosci dodatnich\n");
	    break;	
	case 10:
	    printf("Blad: zbyt skomplikowana pochodna\n");
	    break;	
	case 11:
	    printf("Blad: minus moze byc TYLKO na poczatku liczby\n");
	    break;	
	case 12:
	    printf("Blad: dopuszczam tylko dodatnie liczby\n");
	    break;	
	default:
	    dprintf("BLAD w programie. Prosze raportowac (wartosc %i dla i)\n",i);
	    break;
    }
}

/* Liczenie wartosci funkcji i pochodnej i przyporzadkowanie do wart_funkcji
   i wart_pochodnej. Parametrem jest iks, dla ktorego jest to liczone */
int licz_funkcja_pochodna(double iks) {

    int i;

    printf("Liczenie pochodnej i wartosci funkcji dla x=%f\n",iks);
    
    printf("Funkcja wejsciowa : %s\n",wzor);
    /* Rozkladamy ciag na male elementy */
    i=przygotuj_funkcja(wzor,&moja_liczba);
    if (i!=0) { //mamy blad
	blad(i,wart_funkcji,wzor,21);
	return i;
    }
    /* Liczmy wartosc funkcji */
    i=wartosc_funkcji(&wart_funkcji,iks,&moja_liczba);
    if (i!=0) {
	blad(i,wart_funkcji,wzor,21);
	return i;
    } else {
	/* Wynik nie jest liczba */
	if (isinf(wart_funkcji)) {
	    printf("wynik niewlasciwy \n");
	} else {
	    printf("wynik %f \n",wart_funkcji);
	}
    }

    /* Z wzoru funkcji robimy pochodna */
    i=przygotuj_pochodna(wzor,&moja_liczba);
    if (i!=0) {
	blad(i,wart_pochodnej,wzor,21);
	return i;
    }
    printf("Pochodna: ");    
    pisz_funkcja(&moja_liczba); //wypiszemy jej wzor
    /* i policzymy wartosc */
    i=wartosc_funkcji(&wart_pochodnej,iks,&moja_liczba);
    if (i!=0) {
	blad(i,wart_pochodnej,wzor,21);
	return i;
    } else {
	/* Wynik nie jest liczba */
	if (isinf(wart_pochodnej)) {
	    printf("wynik niewlasciwy \n");
	} else {
	    printf("wynik %f \n",wart_pochodnej);
	}
    }

    return 0;
}

/* Pobieramy linie z pliku "File". Funkcja z (my)gnokii */
int GetLine(FILE *File, char *Line, int count) {

  char *ptr;

  if (fgets(Line, count, File)) {
    ptr=Line+strlen(Line)-1;

    while ( (*ptr == '\n' || *ptr == '\r') && ptr>=Line)
      *ptr--='\0';

      return strlen(Line);
  }
  else
    return -1;
}

/* Wczytuje liczbe z pliku */
int wczytaj_liczba(double *liczba, int dodatnia) {
    char ciag[1000]; //tutaj wczytujemy kolejna linijke
    double wartosc; //wartosc liczby
    int i; //kod bledu
    
    GetLine(stdin, ciag,1000); //pobieramy linijke z wejscia

    dprintf("ciag = %s\n",ciag);

    i=wez_liczba(ciag,&wartosc);
    mojblad=wartosc;
    if (i!=0) {
	blad(i,wartosc,ciag,31);
	return i;
    }
    if (dodatnia==1 && wartosc<0) {
	i=12;
	blad(i,wartosc,ciag,31);
	return i;
    }
    *liczba=wartosc;
    
    return 0;
}

int main()
{
    int i,j;
    double oldiks; //stara wartosc iksa
    double delta; //wartosc delty

    int ile_krokow=50;       // ile maksymalnie krokow
    double iks=2;            // punkt startowy
    double dokladnosc=0.005; // zadana dokladnosc obliczen

    printf("Wczytywanie wzoru funkcji     ");
    GetLine(stdin, wzor,1000); //pobieramy wzor funkcji z wejscia
    printf("\n");

    printf("Wczytywanie dokladnosci       ");
    i=wczytaj_liczba(&dokladnosc,1);
    if (i!=0) return i;
    printf("\n");
    
    printf("Wczytywanie punktu startowego ");
    i=wczytaj_liczba(&iks,0);
    if (i!=0) return i;
    printf("\n");
    
    printf("Wczytywanie ilosci krokow     ");
    i=wczytaj_liczba(&oldiks,1);
    if (i!=0) return i;
    ile_krokow=oldiks;
    printf("\n");
    
    printf("Wczytano dane: dokladnosc=%f, punkt startowy=%f, ile_krokow=%i\n",dokladnosc,iks,ile_krokow);

    /* Obliczanie pierwszego punktu */
    i=licz_funkcja_pochodna(iks);
    if (i!=0) return i;
    
    for (j=0;j<ile_krokow;j++) {

	if (wart_funkcji==0) {
	    printf("Pierwiastek osiagnieto dla x=%f przy kroku %i\n",iks,j);
	    return 0;
	}

	/* Pochodna = 0, a my musimy przez nia dzielic (obliczanie nowego iks. */
	if (wart_pochodnej==0)
	{
	    printf("Blad: dla x=%f pochodna=0\n",iks);
	    return 20;
	}

	/* Stary punkt bedzie potrzebny do delty */
	oldiks=iks;

	/* Liczymy nowy punkt */
	iks=iks-(wart_funkcji/wart_pochodnej);
	i=licz_funkcja_pochodna(iks);
	if (i!=0) return i;

	/* Badanie dokladnosci */
	if (iks>1 || iks<-1) {
	    /* dla modul z iks > 1 */
	    delta=(iks-oldiks)/iks;
	} else {
	    delta=(iks-oldiks);
	}

	/* modul z Delta <= dokladnosc i modul z iks <= 100*dokladnosc */
	if ((delta<=dokladnosc && delta>=(-dokladnosc)) &&
	    (iks<(100*dokladnosc) && iks>-(100*dokladnosc))) {
	    printf("Pierwiastek osiagnieto dla x=%f przy kroku %i\n",iks,j);
	    return 0;
	}
    }
    printf("Blad: nie znaleziono pierwiastka w %i krokach\n",ile_krokow);
    printf("\n");

    return 0;
}          