/*  Witold W�jcik gr 2P25     ULOG S.00L */

/*  Nastepnik w kodzie Graya */

#include <stdio.h>
#define n 10

nastepnik(int tabwe[])
{
 int i,ip;
 int ile;
 int koniec;

i=0;
koniec=0;

while (koniec==0)
{
	ile=0;

if (i==n-1)
 {
  tabwe[i]=1-tabwe[i];
  koniec=1;
 }

if (i!=n-1)
 {

	 for (ip=i+1;ip<n;ip++)
	  {
		if (tabwe[ip]==1) ile++;
	  }


	if ((ile%2) == 0)
	 {
		if (tabwe[i]==0)
		 {
		  tabwe[i]=1;
		  koniec=1;
		 }
	 }
	 else
	 {
		if (tabwe[i]==1)
		 {
		  tabwe[i]=0;
		  koniec=1;
		 }
	 }

  i++;
 }
}
// return 0;
}


main()
{
int tablica[n];
int i;



printf("Podaj liczbe w kodzie Graya : \n");

 i=0;
	while (i<n)
	  {
		scanf("%d",&tablica[i]);
		i++;
	  }


i=0;
	while (i<n)
	  {
		printf("%d ",tablica[i]);
		i++;
	  }


nastepnik(tablica);

printf("\n");

i=0;
	while (i<n)
	  {
		printf("%d ",tablica[i]);
		i++;
	  }

return 0;
}