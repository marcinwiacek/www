#define COMMAND_LENGTH 10
typedef struct
	{
	char nazwa[COMMAND_LENGTH+1];
	void (*funkcja)(char *poczatek,char *koniec);
	}
	COMMAND;

void    NEW    (char *poczatek,char *koniec);		//ok
void    FREE   (char *poczatek,char *koniec);		//ok
void    SAVE   (char *poczatek,char *koniec);           //no
void    RUN    (char *poczatek,char *koniec);           //no
void    HELP   (char *poczatek,char *koniec);           //no
void    ONE    (char *poczatek,char *koniec);           //
void    ZERO   (char *poczatek,char *koniec);           //
void    STEP   (char *poczatek,char *koniec);           //ok
void    PRINT  (char *poczatek,char *koniec);           //ok
void    LOAD   (char *poczatek,char *koniec);           //
void    TEST   (char *poczatek,char *koniec);           //ok
void    CZESC  (char *poczatek,char *koniec);           //ok
void    FUCK   (char *poczatek,char *koniec);           //ok


int     is_command	 (char *poczatek,char *koniec);
void    wiersz_polecen   (char *);

COMMAND commands[]=
	{
	{"NEW"	,       &NEW	},
	{"FREE"	,       &FREE	},
	{"SAVE"	,       &SAVE	},
	{"RUN"	,       &RUN	},
	{"HELP"	,       &HELP	},
	{"ONE"	,       &ONE	},
	{"ZERO"	,       &ZERO	},
	{"STEP"	,       &STEP	},
	{"PRINT",       &PRINT	},
	{"LOAD"	,       &LOAD	},
	{"TEST"	,       &TEST	},
	{"FUCK"	,      	&FUCK   },
	{"CZESC",      	&CZESC  }
	};
int commands_number=sizeof(commands)/sizeof(commands[0]);
int d;
int tested=1;

void    usun_lewe(char *linia)
{
int i,j;

for (i=0;isspace(linia[i])&&(linia[i]);i++);
for (j=0;linia[i];)
    linia[j++]=linia[i++];
linia[j]='\0';
}

void 	usun_spacje(char *linia)
{
int i=0,j=0;

for (;linia[i];i++)
    if (!isspace(linia[i])) linia[j++]=linia[i];
linia[j]='\0';
}

char 	*analiza(char *poczatek,char *koniec)
{
char *nastepne,*a;
NAZWA n;
int i;
//	NULL-analiza poprawna
//      !=NULL-blad skladniowy

if (poczatek>koniec) return(koniec);

if (poczatek==koniec)
   if (*poczatek=='0'||*poczatek=='1') return(NULL);

if (*poczatek=='(')
   {
   nastepne=nawias(poczatek,koniec);
   if (nastepne==NULL) return(poczatek);
   if (nastepne==koniec) return(analiza(poczatek+1,koniec-1));
   };

//if (*poczatek==')') return(poczatek);

nastepne=dzialanie(poczatek,koniec,'+');
if (nastepne!=NULL)
   {
   a=analiza(poczatek,nastepne-1);
   if (a!=NULL) return(a);
   a=analiza(nastepne+1,koniec);
   return(a);
   };

nastepne=dzialanie(poczatek,koniec,'*');
if (nastepne!=NULL)
   {
   a=analiza(poczatek,nastepne-1);
   if (a!=NULL) return(a);
   a=analiza(nastepne+1,koniec);
   return(a);
   };

nastepne=dzialanie(poczatek,koniec,'/');
if (nastepne!=NULL)
   {
   a=analiza(poczatek,nastepne-1);
   if (a!=NULL) return(a);
   a=analiza(nastepne+1,koniec);
   return(a);
   };

nastepne=dzialanie(poczatek,koniec,'!');
if (nastepne!=NULL)
   {
   if (nastepne!=poczatek) return (nastepne);
   if (nastepne==poczatek) return (analiza(poczatek+1,koniec));
   };

for(nastepne=poczatek,i=0;nastepne<=koniec;nastepne++)
   n[i++]=(*nastepne);
n[i]='\0';
i=get_value(n);
if (i==-1) return(poczatek);
return(NULL);
}

int 	is_command(char *poczatek,char *koniec)
{
NAZWA n;
int i,a;

for (i=0;poczatek<=koniec;poczatek++)
    n[i++]=*poczatek;
n[i]='\0';
for (i=0;i<commands_number;i++)
    if (!strcmp(n,commands[i].nazwa)) return(i);
return(-1);
}

void    wiersz_polecen   (char *linia)
{
int 	l,n;
char    *a;

for (l=0;linia[l];l++) if isspace(linia[l]) break;
n=is_command(linia,linia+l-1);

if (n!=-1)	//polecenie
   {
   usun_spacje(linia+l);
   d=0;
   commands[n].funkcja(linia+l,linia+strlen(linia)-1);
   return;
   };
		//nie polecenie  -- wyrazenie np: "(x1+!y1)*d1+!a"
usun_spacje(linia);
a=analiza(linia,linia+strlen(linia)-1);
if (a)
   {
   printf("Your expression : %s\n",linia);
   printf("ERROR AT        :");
   for (n=0;n<(a-linia);n++) printf(" ");
   printf("^%s\n",a);
   return;
   }
n=value(linia,linia+strlen(linia)-1);
printf("   ANS = %d\n",n);
}



void    FUCK  (char *poczatek,char *koniec)
{
static int ile=0;
char teksty[][30]=
     {
     {"Dlaczego tak mnie traktujesz"},
     {"Nie badz taki"},
     {"I nawzajem"},
     {"Bo poskarze mamie"},
     {"Wal na ryj"},
     {"Idz sie wyspowiadac"},
     {"Mam Cie dosc"},
     {"I chuj ci w dupe"},
     {"I kamieni kupe"},
     };

poczatek=koniec;koniec=poczatek;
ile%=(sizeof(teksty)/sizeof(teksty[0]));
printf("%s\n",teksty[ile]);
ile++;
}


void    CZESC  (char *poczatek,char *koniec)
{
char teksty[][30]=
     {
     {"Ja tez Cie witam"},
     {"Buzka"},
     {"Siemano"},
     {"Czesc glabie"},
     {"Daj grabe"},
     {"Przybij piatke"},
     {"Czolko"},
     {"Mam dosc powitan"},
     {"Howgh"},
     {"Skoncz bo sie zapetle"},
     };
static int ile=0;

poczatek=koniec;koniec=poczatek;
ile%=(sizeof(teksty)/sizeof(teksty[0]));
printf("%s\n",teksty[ile]);
ile++;
}

void    NEW    (char *poczatek,char *koniec)
{
NAZWA n;
struct item *nowy;
char *nastepny=poczatek;
int i;

if (((d++)==0)&&(poczatek>koniec))
   {
   printf("Brak parametrow polecenia \"new\" !!!\n");
   return;
   }
if (poczatek>koniec) return;


for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
nowy=find_item(n);
if (nowy)
   {
   printf("Element %s juz istnieje !!!\n",n);
   NEW(nastepny+1,koniec);
   return;
   };
nowy=(struct item *)malloc(sizeof(struct item));
if (!nowy) {printf("Brak dostepnej pamieci !!!\n");return;};
strcpy(nowy->nazwa,n);
tested=0;
do
  {
  printf("Okresl rodzaj elementu %s\n(0-czujnik,1-zawor,2-stan) : ",
	  &nowy->nazwa);
  scanf("%d",&i);
  fflush(stdin);
  }
while (i<0||i>2);
nowy->type=i;
if (i) 		// nie czojnik
   {
   printf("Zdefiniuj funkcje          : %s = ",&nowy->nazwa);
   gets(nowy->funkcja);
   fflush(stdin);
   }
else nowy->funkcja[0]='\0';
usun_spacje(nowy->funkcja);
strupr(nowy->funkcja);
do
  {
  printf("Podaj wartosc poczatkowa   : %s(0) = ",&nowy->nazwa);
  scanf("%d",&i);
  fflush(stdin);
  }
while (i<0||i>1);
nowy->value=i;
nowy->n_value=i;
nowy->next=first;
first=nowy;
NEW(nastepny+1,koniec);
}

void    FREE   (char *poczatek,char *koniec)
{
NAZWA n;
struct item *act,*last;
char *nastepny=poczatek;
int i;

if (((d++)==0)&&(poczatek>koniec))
   {
   printf("Brak parametrow polecenia \"free\" !!!\n");
   return;
   }
if (poczatek>koniec) return;
for (;*nastepny==',';nastepny++);
for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
for (last=NULL,act=first;act&&strcmp(n,act->nazwa);last=act,act=act->next);
if (act)
   {
   if (act==first) first=first->next;
   else
      last->next=act->next;
   free(act);
   printf("Element %s zostal usuniety\n",n);
   tested=0;
   }
else printf("Element %s nie istnieje !!!\n",n);
FREE(nastepny+1,koniec);
}

void    SAVE   (char *poczatek,char *koniec)
{
printf("Polecenie jescze nie jest gotowe !!!\n");
}

void    RUN    (char *poczatek,char *koniec)
{
printf("Polecenie jescze nie jest gotowe !!!\n");
}

void    HELP   (char *poczatek,char *koniec)
{
printf("Polecenie jescze nie jest gotowe !!!\n");
}

void    ONE    (char *poczatek,char *koniec)
{
NAZWA n;
struct item *tmp;
char *nastepny=poczatek;
int i;

if (((d++)==0)&&(poczatek>koniec))
   {
   printf("Brak parametrow polecenia \"one\" !!!\n");
   return;
   }
if (poczatek>koniec) return;


for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
tmp=find_item(n);
if (tmp)
   {
   tmp->value=1;
   tmp->n_value=1;
   }
else printf("Brak elementu %s !!!\n",n);
ONE(nastepny+1,koniec);
}

void    ZERO   (char *poczatek,char *koniec)
{
NAZWA n;
struct item *tmp;
char *nastepny=poczatek;
int i;

if (((d++)==0)&&(poczatek>koniec))
   {
   printf("Brak parametrow polecenia \"one\" !!!\n");
   return;
   }
if (poczatek>koniec) return;


for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
tmp=find_item(n);
if (tmp)
   {
   tmp->value=0;
   tmp->n_value=0;
   }
else printf("Brak elementu %s !!!\n",n);
ZERO(nastepny+1,koniec);
}

void    STEP   (char *poczatek,char *koniec)
{
NAZWA n;
struct item *tmp;
char *a;

if (!first) {printf("Brak elementow.Nie moge nic zrobic!!!\n");return;}
if (!tested)
   {
   tested=1;
   for (tmp=first;tmp;tmp=tmp->next)
       {
       if (!strlen(tmp->funkcja)) continue;
       a=analiza(tmp->funkcja,tmp->funkcja+strlen(tmp->funkcja)-1);
       if (a)
	  {
	  printf("Element %s . Blad w funkcji : %s\n",
		tmp->nazwa,tmp->funkcja);
	  tested=0;
	  }
       }
   }
if (!tested) {printf("Nie moge symulowac tego ukladu !!!\n");return;}
for (tmp=first;tmp;tmp=tmp->next)
    {
    if (!strlen(tmp->funkcja)) continue;
    tmp->n_value=value(tmp->funkcja,tmp->funkcja+strlen(tmp->funkcja)-1);
    }
for (tmp=first;tmp;tmp=tmp->next)
    tmp->value=tmp->n_value;
n[0]=*poczatek;n[0]=*koniec;n[0]=0;n[1]=0;
PRINT(&n[1],&n[0]);
}

void    PRINT  (char *poczatek,char *koniec)
{
NAZWA n;
struct item *tmp;
char *nastepny=poczatek;
int i;

if (((d++)==0)&&(poczatek>koniec))
   {
   if (!first) printf("Brak elementow do wyswietlenia !!!\n");
   for (tmp=first;tmp;tmp=tmp->next)
       {
       printf("Element %.10s : Value = %1d Type = %1d ",
	    tmp->nazwa,tmp->value,tmp->type);
       if (tmp->type) printf("Funkcja = %s\n",tmp->funkcja);
       else printf("\n");
       }
   return;
   }
if (poczatek>koniec) return;
for (;*nastepny==',';nastepny++);
for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
tmp=find_item(n);
if (tmp)
   {
   printf("Element %.10s : Value = %1d Type = %1d ",
	    tmp->nazwa,tmp->value,tmp->type);
   if (tmp->type) printf("Funkcja = %s\n",tmp->funkcja);
   else printf("\n");
   }
else printf("Element %s nie istnieje !!!\n",n);
PRINT(nastepny+1,koniec);
}

void    LOAD   (char *poczatek,char *koniec)
{
printf("Polecenie jescze nie jest gotowe !!!\n");
}

void    TEST   (char *poczatek,char *koniec)
{
NAZWA n;
struct item *tmp;
char *nastepny=poczatek,*a;
int i;


if (((d++)==0)&&(poczatek>koniec))
   {
   if (tested) {printf("Uklad juz przetestowany !!!\n");return;}
   if (!first) printf("Brak elementow do testowania !!!\n");
   tested=1;
   for (tmp=first;tmp;tmp=tmp->next)
       {
       if (!strlen(tmp->funkcja)) continue;
       a=analiza(tmp->funkcja,tmp->funkcja+strlen(tmp->funkcja)-1);
       if (a)
	  {
	  printf("Element %s . Blad w funkcji : %s\n",
		tmp->nazwa,tmp->funkcja);
	  tested=0;
	  }
       }
   if (tested) printf("Uklad dziala poprawnie\n");
   }
if (poczatek>koniec) return;
for (;*nastepny==',';nastepny++);
for (i=0;*nastepny!=','&&(nastepny<=koniec);nastepny++) n[i++]=*nastepny;
n[i]=0;
if (strlen(n)>=10) n[10]=0;
tmp=find_item(n);
if (tmp)
   {
   if (strlen(tmp->funkcja))
      {
      a=analiza(tmp->funkcja,tmp->funkcja+strlen(tmp->funkcja)-1);
      if (a)
	  {
	  printf("Element %s . Blad w funkcji : %s\n",
		tmp->nazwa,tmp->funkcja);
	  tested=0;
	  }
      else printf("Element %s . Funkcja poprawna : %s\n",
		 tmp->nazwa,tmp->funkcja);
      }
   else printf("Element %s . Funkcja poprawna : %s\n",
		 tmp->nazwa,tmp->funkcja);
   }
else printf("Element %s nie istnieje !!!\n",n);
TEST(nastepny+1,koniec);
}