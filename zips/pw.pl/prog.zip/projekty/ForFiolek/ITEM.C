typedef char NAZWA[130];
struct item
	{
	char nazwa[11];
	int value,n_value;
	int type;		/*0-czojnik,1-zawor,2-stan */
	char funkcja[130];
	struct item *next;
	}*first;

struct item* find_item(NAZWA n)
{
struct item *act=first;

//if (!act) return(act);
for(; act; act=act->next)
   if (!strcmp(n,act->nazwa)) break;
return(act);
}


int	get_value(NAZWA n)
{
struct item *act;

act=find_item(n);
if (act)
   return(act->value);
else
   return(-1);
}

char	*nawias(char *poczatek,char *koniec)
{
int lewe=0,prawe=0;

for (;poczatek<=koniec;poczatek++)
    {
    if (*poczatek=='(') lewe++;
    if (*poczatek==')') prawe++;
    if (lewe==prawe) return(poczatek);
    }
return(NULL);
}

char *dzialanie(char *poczatek,char *koniec,char d)
{
for(;poczatek<=koniec;poczatek++)
   {
   if (*poczatek==d) return(poczatek);
   if (*poczatek=='(') poczatek=nawias(poczatek,koniec);
   if (poczatek==NULL) break;
   }
return(NULL);
}


int	value(char *poczatek,char *koniec)
{
char *nastepne=poczatek;
NAZWA n;
int i=0;

if (poczatek==koniec)
   {
   if (*poczatek=='0') return(0);
   if (*poczatek=='1') return(1);
   };

for(; nastepne<=koniec;nastepne++)
   n[i++]=(*nastepne);
n[i]='\0';
i=get_value(n);
if (i!=-1) return(i);

if (*poczatek=='(')
   if (nawias(poczatek,koniec)==koniec)
       return(value(poczatek+1,koniec-1));

nastepne=dzialanie(poczatek,koniec,'+');
if (nastepne) return value(poczatek,nastepne-1)|value(nastepne+1,koniec);

nastepne=dzialanie(poczatek,koniec,'*');
if (nastepne) return value(poczatek,nastepne-1)&value(nastepne+1,koniec);

nastepne=dzialanie(poczatek,koniec,'/');
if (nastepne) return value(poczatek,nastepne-1)^value(nastepne+1,koniec);

if (*poczatek=='!')
   return !value(poczatek+1,koniec);

return(-1);
}