#include <stdio.h>
#include <alloc.h>
#include <string.h>
#include <ctype.h>
#include "item.c"
#include "commands.c"


void main (void)
{
NAZWA linia;
do
	{
	printf(">");
	fflush(stdin);
	gets(linia);
	fflush(stdin);
	strupr(linia);
	usun_lewe(linia);
	if (!strlen(linia)) continue;
	if (!strcmp(linia,"QUIT")||!strcmp(linia,"EXIT")||!strcmp(linia,"BYE")) break;
	wiersz_polecen(linia);
	}
while(1);
printf("God bye!\n");
}