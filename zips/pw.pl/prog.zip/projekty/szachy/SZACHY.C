#include <stdio.h>
#include <stdlib.h>
#include "dek.h"
#include "czytaj.c"
#include "zapis.c"
#include "analiza.c"
#include "ruchy.c"

struct bierkabiala  *bialaptr ;       /* wskaznik do tablicy struktur */
struct bierkaczarna *czarnaptr;       /* wskaznik do tablicy struktur */
char *plikptr;                        /* wskaznik do zawartosci pliku */
int nb;                               /* liczba bierek bialych */
int nc;                               /* liczba bierek czarnych */
int szachownica[8][8];
     
void main(void)
{
   char c;
   char tab[15];
   int i,j,ret0,ret1,ret2;
   FILE *fptr;
   char chartab[200];
   long int linie=-1;


   printf("\n\n                              ****  SZACHY  ****");
   while(JEDEN)
   {
      for(i=0;i<8;i++)
         for(j=0;j<8;j++)
            szachownica[i][j]=0;
      nb=0;
      nc=0;
      
      bialaptr =NULL;
      czarnaptr=NULL;
      
      printf("\n\n     MENU : ");    
      printf("\n  s - start ");
      printf("\n  h - help  ");
      printf("\n  q - quit: ");
      
      gets(&c);
      switch(c)
      {
	 case 's' :  
	    printf("\n\nPodaj nazwe pliku:");
	    gets(tab);
	    ret0=czytaj(tab);
	    if(ret0==BLAD)
	       break;
	    else
	    {   
	       ret1=zapis(ret0);
	       if(ret1==BLAD)
	       {
	          printf("\nZly format zapisu danych w pliku");
	          printf("\nInformacje na temat poprawnego formatu");
	          printf("\nznajduja sie w help");
	          break;
	       }
	       if(ret1==BLAD1)
	       {
	          printf("\nNie moge przydzielic pamieci");
	          break;
	       }
	       if(ret1==BLAD2)
	       {
	          printf("\nBlad: na jednym polu wiecej niz jedna bierka");
	          break;
	       }
	       if(ret1==NIE_MA_BLEDU)
	       {
	          ret2=analiza();   
	          if(ret2==BLAD)
	          {
	             printf("\nNiepoprawna sytuacja na szachownicy");
	             break;
	          }
	          if(ret2==NIE_MA_BLEDU)
	          {  
	             ruchy();
	          }   
	       }                  
            }   	   
	    break;
	 case 'h' :
	    if((fptr=fopen("help","r"))==NULL)
	       {printf("\nNie moge otworzyc pliku");break;}
	    while (fgets(chartab,200,fptr))
	    {
	       chartab[strlen(chartab)]=0;
	       printf("%s",chartab);
	       linie++;
	       if (linie%24==23)
	       {
		  printf("Wcisnij enter : ");
		  gets(chartab);
		  printf("\n\n\n");
	       }
	     }
	     fclose(fptr);
	     break;
	  case 'q' :
	     exit(0);
	     break;
	  default :
	     printf("\nNieznana opcja");
	     break;
      }
   }
}       