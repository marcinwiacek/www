#include <stdio.h>   
#include "dek4.h"

 void ruchy(void)
{

   char c,p,r,r1,r2,enter;
   char tab[]="abcdefgh"; 
   char buf[10];
   int i,j,x,y,stronaA,stronaB,flaga,flaga1,flaga2,flaga3;

   while(JEDEN)
   {   
      printf("\n\n    Opcje :");
      printf("\n  b  ruchy bierek bialych");
      printf("\n  c  ruchy bierek czarnych");
      printf("\n  p  powrot:");
      c=getchar();
      getchar();
      switch(c)
      {
         case 'b' :
	    while(JEDEN)
	    {
	       flaga=IN;
	       printf("\n\n    Opcje :");
	       printf("\n  w  ruchy wszystkich bierek");
	       printf("\n  j  ruchy jednej bierki");
	       printf("\n  p  powrot:");
	       stronaA=1;
	       stronaB=2;
	       p=getchar();
	       getchar();
	       switch(p)
	       {
	          case 'w' :
	            flaga2=NIE_MA;
	            for(j=0;j<20;j=j+6)
	            {
	               enter='c';
	               while(enter!='\n')
	               {
	                  printf("\n\n\n\n\nNacisnij enter");
	                  enter=getchar();
	               }   
	               for(i=0;i<nb && i<6;i++)
	               {
		          x=bialaptr[i+j].x;
		          y=bialaptr[i+j].y;
		          if((r=bialaptr[i+j].n)=='P')
		          {
		             printf("\n\nRuchy piona %c%d :",tab[x],y+1);
		             pionekb(x,y,stronaA,stronaB);
		          }
		          else
		             procedury(r,x,y,stronaA,stronaB);
	                  if(j+i==nb)
	                     flaga2=JEST;
	               }
	               if(flaga2==JEST)
	                  break;
	            } 
	            break;
	          case 'j' :
	             flaga1=NIE_MA;
	             printf("\nPodaj nazwe i wspolrzedne bierki w postaci np. P-d5 :");
	             gets(buf);
                     r=*buf;
                     r1=*(buf+2);
                     r2=*(buf+3);
                     switch(r)
                     {
                        case 'P' : case 'K' : case 'H' :
                        case 'W' : case 'G' : case 'S' :
                           break;
                        default :
                           flaga1=JEST;
                           break;
                     }
                     switch(r1)
                     {
                        case 'a' : x=0; break;
                        case 'b' : x=1; break;
                        case 'c' : x=2; break;
                        case 'd' : x=3; break;
                        case 'e' : x=4; break;
                        case 'f' : x=5; break;
                        case 'g' : x=6; break;
                        case 'h' : x=7; break;
                        default : 
                           flaga1=JEST;
                           break;
                     }
                     switch(r2)
                     {
                        case '1' : y=0; break;
                        case '2' : y=1; break;
                        case '3' : y=2; break;
                        case '4' : y=3; break;
                        case '5' : y=4; break;
                        case '6' : y=5; break;
                        case '7' : y=6; break;
                        case '8' : y=7; break;
                        default : 
                           flaga1=JEST;
                           break;
                     }  
	             if(flaga1==JEST)
	                printf("\nZly format zapisu danych.");  
	             flaga3=NIE_MA;
	             for(i=0;i<nb;i++)
	             {
	                if(bialaptr[i].n==r &&
	                   bialaptr[i].x==x &&
	                   bialaptr[i].y==y )
	                 {
	                    flaga3=JEST;
	                    if(r=='P')
		            {
		               printf("\n\nRuchy piona %c%d :",tab[x],y+1);
		               pionekb(x,y,stronaA,stronaB);
		            }
		            else
		               procedury(r,x,y,stronaA,stronaB);
   
	                 }
                                 
	             }    
	             if(flaga3!=JEST)
	                printf("\nNa szachownicy nie ma takiej bierki");  	             
	             break;
	          case 'p' :
	             flaga=OUT;
	             break;
	          default :
	             printf("\nNieznana opcja");
	             break;    
	       }
	       if(flaga==OUT)
	          break;
	    }
	    break;
         case 'c' :
	    while(JEDEN)
	    {
	       flaga=IN;
	       printf("\n\n    Opcje :");
	       printf("\n  w  ruchy wszystkich bierek");
	       printf("\n  j  ruchy jednej bierki");
	       printf("\n  p  powrot:");
	       p=getchar();
	       getchar();
	       stronaA=2;
	       stronaB=1;
	       switch(p)
	       {
	          case 'w' :
	             flaga2=NIE_MA;
	             for(j=0;j<20;j=j+6)
	             {
	                enter='c';
	                while(enter!='\n')
	                {
	                   printf("\n\n\n\n\nNacisnij enter");
	                   enter=getchar();
	                }   
	                for(i=0;i<nc && i<6;i++)
	                {
		           x=czarnaptr[i+j].x;
		           y=czarnaptr[i+j].y;
		           if((r=czarnaptr[i+j].n)=='P')
		           {
		              printf("\n\nRuchy piona %c%d :",tab[x],y+1);
		              pionekc(x,y,stronaA,stronaB);
		           } 
		           else
		              procedury(r,x,y,stronaA,stronaB);
	                   if(j+i==nc)
	                      flaga2=JEST;
	                }
	                if(flaga2==JEST)
	                   break;
	             }
	             break;
	          case 'j' :
	             flaga1=NIE_MA;
	             printf("\nPodaj nazwe i wspolrzedne bierki w postaci np. P-d5 :");
	             gets(buf);
                     r=*buf;
                     r1=*(buf+2);
                     r2=*(buf+3);
                     switch(r)
                     {
                        case 'P' : case 'K' : case 'H' :
                        case 'W' : case 'G' : case 'S' :
                           break;
                        default :
                           flaga1=JEST;
                           break;
                     }
                     switch(r1)
                     {
                        case 'a' : x=0; break;
                        case 'b' : x=1; break;
                        case 'c' : x=2; break;
                        case 'd' : x=3; break;
                        case 'e' : x=4; break;
                        case 'f' : x=5; break;
                        case 'g' : x=6; break;
                        case 'h' : x=7; break;
                        default : 
                           flaga1=JEST;
                           break;
                     }
                     switch(r2)
                     {
                        case '1' : y=0; break;
                        case '2' : y=1; break;
                        case '3' : y=2; break;
                        case '4' : y=3; break;
                        case '5' : y=4; break;
                        case '6' : y=5; break;
                        case '7' : y=6; break;
                        case '8' : y=7; break;
                        default : 
                           flaga1=JEST;
                           break;
                     }  
	             if(flaga1==JEST)
	                printf("\nZly format zapisu danych.");  
	             flaga3=NIE_MA;
	             for(i=0;i<nc;i++)
	             {
	                if(czarnaptr[i].n==r &&
	                   czarnaptr[i].x==x &&
	                   czarnaptr[i].y==y )
	                {
	                   flaga3=JEST;
	                   if(r=='P')
		           {
		              printf("\n\nRuchy piona %c%d :",tab[x],y+1);
		              pionekc(x,y,stronaA,stronaB);
		           }
		           else
		              procedury(r,x,y,stronaA,stronaB);
   
	                }
	                
	             }    
	             if(flaga3!=JEST)
	                printf("\nNa szachownicy nie ma takiej bierki");  	             
	             break;
	             
	          case 'p' :
	             flaga=OUT;
	             break;
	          default :
	             printf("\nNieznana opcja");
	             break;
	       }
	       if(flaga==OUT)
	          break;
	    }
	    break;
         case 'p' :
            free(bialaptr);
            free(czarnaptr);
            return ;
            break;
         default :
            printf("\nNieznana opcja");
            break;   
      }
   }
}

void procedury(char c,int x,int y,int stronaA,int stronaB)
{
   char tab[]="abcdefgh";
   stb tabs[8];
      
   switch(c)
   {
      case 'W' :
	 printf("\n\nRuchy wiezy %c%d :",tab[x],y+1);           
	 wieza(x,y,stronaA,stronaB,tabs);

	 if(tabs[0].bicie==JEST || tabs[1].bicie==JEST || 
	    tabs[2].bicie==JEST || tabs[3].bicie==JEST)
	 {
	    printf("\nbicie na :");
	    if(tabs[0].bicie==JEST)
	       printf(" %c%d,",tabs[0].c,tabs[0].x);  
	    if(tabs[1].bicie==JEST)
	       printf(" %c%d,",tabs[1].c,tabs[1].x);  
	    if(tabs[2].bicie==JEST)
	       printf(" %c%d,",tabs[2].c,tabs[2].x);  
	    if(tabs[3].bicie==JEST)
	       printf(" %c%d,",tabs[3].c,tabs[3].x);  
	 }
	 break;
      case 'G' :
	 printf("\n\nRuchy gonca %c%d :",tab[x],y+1);           
	 goniec(x,y,stronaA,stronaB, tabs);

	 if(tabs[4].bicie==JEST || tabs[5].bicie==JEST || 
	    tabs[6].bicie==JEST || tabs[7].bicie==JEST)
	 {
	    printf("\nbicie na :");
	    if(tabs[4].bicie==JEST)
	       printf(" %c%d,",tabs[4].c,tabs[4].x);  
	    if(tabs[5].bicie==JEST)
	       printf(" %c%d,",tabs[5].c,tabs[5].x);  
	    if(tabs[6].bicie==JEST)
	       printf(" %c%d,",tabs[6].c,tabs[6].x);  
	    if(tabs[7].bicie==JEST)
	       printf(" %c%d,",tabs[7].c,tabs[7].x);  
	 }
	 break;
      case 'H' :
	 printf("\n\nRuchy hetmana %c%d :",tab[x],y+1);           
	 wieza(x,y,stronaA,stronaB, tabs);
         goniec(x,y,stronaA,stronaB, tabs);
  	 
        
         if(tabs[0].bicie==JEST || tabs[1].bicie==JEST || 
	    tabs[2].bicie==JEST || tabs[3].bicie==JEST ||
	    tabs[4].bicie==JEST || tabs[5].bicie==JEST || 
	    tabs[6].bicie==JEST || tabs[7].bicie==JEST ) 
	 {
	     printf("\nbicie na :");
	     if(tabs[0].bicie==JEST)
	        printf(" %c%d,",tabs[0].c,tabs[0].x);  
	     if(tabs[1].bicie==JEST)
	        printf(" %c%d,",tabs[1].c,tabs[1].x);  
	     if(tabs[2].bicie==JEST)
	        printf(" %c%d,",tabs[2].c,tabs[2].x);  
	     if(tabs[3].bicie==JEST)
	        printf(" %c%d,",tabs[3].c,tabs[3].x);  
	     if(tabs[4].bicie==JEST)
	        printf(" %c%d,",tabs[4].c,tabs[4].x);  
	     if(tabs[5].bicie==JEST)
	        printf(" %c%d,",tabs[5].c,tabs[5].x);  
	     if(tabs[6].bicie==JEST)
	        printf(" %c%d,",tabs[6].c,tabs[6].x);  
	     if(tabs[7].bicie==JEST)
	        printf(" %c%d,",tabs[7].c,tabs[7].x);  
 
	 }
	 break;
      case 'S' :
	 printf("\n\nRuchy skoczka %c%d :",tab[x],y+1);
	 skoczek(x,y,stronaA,stronaB);
	 break;
      case 'K' :
	 printf("\n\nRuchy krola %c%d :",tab[x],y+1);
	 krol(x,y,stronaA,stronaB);
	 break;
   }
}

void pionekb(int x,int y,int stronaA,int stronaB)
{
   int ruch;
   int bicie;   
   char tab[]="abcdefgh"; 

   ruch=NIE_MA;
   bicie=NIE_MA;
   if(y+1<8)
   {
      if(szachownica[y+1][x]==0)
      {   
	 ruch=JEST;
	 printf(" %c%d,",tab[x],y+2);
	 if(y==1)
	    if(y+2<8)
	       if(szachownica[y+2][x]==0)
		  printf(" %c%d,",tab[x],y+3);   
      }   
      else               
      ruch=NIE_MA;             
	     
      if(x+1<8)
	 if(szachownica[y+1][x+1]==stronaB)
	    if(bicie==NIE_MA)
	    {
	       bicie=JEST;
	       printf("\nbicie na :");
	       printf(" %c%d,",tab[x+1],y+2); 
	    }
	    else
	       printf(" %c%d,",tab[x+1],y+2);                    

      if(x-1>=0)
	 if(szachownica[y+1][x-1]==stronaB)
	    if(bicie==NIE_MA)
	    {   
	       bicie=JEST;
	       printf("\nbicie na :");
	       printf(" %c%d,",tab[x-1],y+2);  
	    }
	    else
	       printf(" %c%d,",tab[x-1],y+2);  

   }
   else
      ruch=NIE_MA;
   if(ruch==NIE_MA && bicie==NIE_MA)
      printf(" nie ma ruchu.");
}      
void pionekc(int x,int y,int stronaA,int stronaB)
{
   int ruch;
   int bicie;   
   char tab[]="abcdefgh"; 

   ruch=NIE_MA;
   bicie=NIE_MA;
   if(y-1>=0)
   {
      if(szachownica[y-1][x]==0)
      {   
	 ruch=JEST;
	 printf(" %c%d,",tab[x],y);
	 if(y==6)
	    if(y-2>=0)
	       if(szachownica[y-2][x]==0)
		  printf(" %c%d,",tab[x],y-1);   
      }   
      else               
      ruch=NIE_MA;             
	     
      if(x+1<8)
	 if(szachownica[y-1][x+1]==stronaB)
	    if(bicie==NIE_MA)
	    {
	       bicie=JEST;
	       printf("\nbicie na :");
	       printf(" %c%d,",tab[x+1],y); 
	    }
	    else
	       printf(" %c%d,",tab[x+1],y);                    

      if(x-1>=0)
	 if(szachownica[y-1][x-1]==stronaB)
	    if(bicie==NIE_MA)
	    {   
	       bicie=JEST;
	       printf("\nbicie na :");
	       printf(" %c%d,",tab[x-1],y);  
	    }
	    else
	       printf(" %c%d,",tab[x-1],y);  

   }
   else
      ruch=NIE_MA;
   if(ruch==NIE_MA && bicie==NIE_MA)
      printf(" nie ma ruchu.");
}      
      
void wieza(int x,int y,int stronaA,int stronaB,stb tabs[])
{
   int j;	    
   int ruch,ruch1,ruch2,ruch3,ruch4;	    
   char tab[]="abcdefgh"; 


   ruch=JEST;
   ruch1=JEST;
   tabs[0].bicie=NIE_MA;
   if(szachownica[y][x+1]==stronaA || x+1>7)
      ruch1=NIE_MA;
   for(j=x+1;j<8;j++)
   {
      if(szachownica[y][j]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {  
	 if(szachownica[y][j]==0)
	    printf(" %c%d,",tab[j],y+1);
	 if(szachownica[y][j]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[0].bicie=JEST;
	    tabs[0].c=tab[j];
	    tabs[0].x=y+1;
	 }
      }
   }
   ruch=JEST;
   ruch2=JEST;
   tabs[1].bicie=NIE_MA;
   if(szachownica[y][x-1]==stronaA || x-1<0)
      ruch2=NIE_MA;
   for(j=x-1;j>=0;j--)
   {
      if(szachownica[y][j]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[y][j]==0)
	    printf(" %c%d,",tab[j],y+1);
	 if(szachownica[y][j]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[1].bicie=JEST;
	    tabs[1].c=tab[j];
	    tabs[1].x=y+1;
	 }   
      }	     
   }
   ruch=JEST;
   ruch3=JEST;
   tabs[2].bicie=NIE_MA;
   if(szachownica[y+1][x]==stronaA || y+1 >7)
      ruch3=NIE_MA;
   for(j=y+1;j<8;j++)
   {
      if(szachownica[j][x]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[j][x]==0)
	    printf(" %c%d,",tab[x],j+1);
	 if(szachownica[j][x]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[2].bicie=JEST;
	    tabs[2].c=tab[x];
	    tabs[2].x=j+1;
	 }   
      }	     
   }
   ruch=JEST;
   ruch4=JEST;
   tabs[3].bicie=NIE_MA;
   if(szachownica[y-1][x]==stronaA || y-1<0)
      ruch4=NIE_MA;
   for(j=y-1;j>=0;j--)
   {
      if(szachownica[j][x]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[j][x]==0)
	    printf(" %c%d,",tab[x],j+1);
	 if(szachownica[j][x]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[3].bicie=JEST;
	    tabs[3].c=tab[x];
	    tabs[3].x=j+1;
	 }  
      }	     
   }
   if(tabs[0].bicie==NIE_MA && tabs[1].bicie==NIE_MA && 
      tabs[2].bicie==NIE_MA && tabs[3].bicie==NIE_MA && 
      ruch1==NIE_MA && ruch2==NIE_MA && ruch3==NIE_MA && ruch4==NIE_MA)
	 printf(" nie ma ruchu");
}
void goniec(int x,int y,int stronaA,int stronaB,stb tabs[])
{
   int j,k;	    
   int ruch,ruch1,ruch2,ruch3,ruch4;	    
   char tab[]="abcdefgh"; 


   ruch=JEST;
   ruch1=JEST;
   tabs[4].bicie=NIE_MA;
   if(szachownica[y+1][x+1]==stronaA || y+1>7 || x+1>7)
      ruch1=NIE_MA;
   for(j=x+1,k=y+1;j<8 && k<8;j++,k++)
   {
      if(szachownica[k][j]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {  
	 if(szachownica[k][j]==0)
	    printf(" %c%d,",tab[j],k+1);
	 if(szachownica[k][j]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[4].bicie=JEST;
	    tabs[4].c=tab[j];
	    tabs[4].x=k+1;
	 }
      }
   }
   ruch=JEST;
   ruch2=JEST;
   tabs[5].bicie=NIE_MA;
   if(szachownica[y-1][x-1]==stronaA || y-1<0 || x-1<0)
      ruch2=NIE_MA;
   for(j=x-1,k=y-1;j>=0 && k>=0;j--,k--)
   {
      if(szachownica[k][j]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[k][j]==0)
	    printf(" %c%d,",tab[j],k+1);
	 if(szachownica[k][j]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[5].bicie=JEST;
	    tabs[5].c=tab[j];
	    tabs[5].x=k+1;
	 }   
      }	     
   }
   ruch=JEST;
   ruch3=JEST;
   tabs[6].bicie=NIE_MA;
   if(szachownica[y+1][x-1]==stronaA || y+1>7 || x-1<0)
      ruch3=NIE_MA;
   for(j=y+1,k=x-1;j<8 && k>=0;j++,k--)
   {
      if(szachownica[j][k]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[j][k]==0)
	    printf(" %c%d,",tab[k],j+1);
	 if(szachownica[j][k]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[6].bicie=JEST;
	    tabs[6].c=tab[k];
	    tabs[6].x=j+1;
	 }   
      }	     
   }
   ruch=JEST;
   ruch4=JEST;
   tabs[7].bicie=NIE_MA;
   if(szachownica[y-1][x+1]==stronaA || y-1<0 || x+1>7)
      ruch4=NIE_MA;
   for(j=y-1,k=x+1;j>=0 && k<8;j--,k++)
   {
      if(szachownica[j][k]==stronaA)
	 ruch=NIE_MA;
      else if(ruch==JEST)
      {
	 if(szachownica[j][k]==0)
	    printf(" %c%d,",tab[k],j+1);
	 if(szachownica[j][k]==stronaB)
	 {
	    ruch=NIE_MA;
	    tabs[7].bicie=JEST;
	    tabs[7].c=tab[k];
	    tabs[7].x=j+1;
	 }   
      }	     
   }
   if(tabs[4].bicie==NIE_MA && tabs[5].bicie==NIE_MA && 
      tabs[6].bicie==NIE_MA && tabs[7].bicie==NIE_MA && 
      ruch1==NIE_MA && ruch2==NIE_MA && ruch3==NIE_MA && ruch4==NIE_MA)
	 printf(" nie ma ruchu");
}
		  
void skoczek(int x,int y,int stronaA,int stronaB)
{
   int ruch=NIE_MA;
   int bicie1=NIE_MA;
   int bicie2=NIE_MA;
   int bicie3=NIE_MA;
   int bicie4=NIE_MA;
   int bicie5=NIE_MA;
   int bicie6=NIE_MA;
   int bicie7=NIE_MA;
   int bicie8=NIE_MA;
   int x1,x2,x3,x4,x5,x6,x7,x8;
   char c1,c2,c3,c4,c5,c6,c7,c8;
   char tab[]="abcdefgh";		    

   if(y+2<8)
   {
      if(x+1<8)
      {
	 if(szachownica[y+2][x+1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x+1],y+3);
	 }
	 if(szachownica[y+2][x+1]==stronaB)
	 {
	    bicie1=JEST;
	    c1=tab[x+1];
	    x1=y+3;
	 }
      }
      if(x-1>=0)
      {
	 if(szachownica[y+2][x-1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-1],y+3);
	 }
	 if(szachownica[y+2][x-1]==stronaB)
	 {
	    bicie2=JEST;
	    c2=tab[x-1];
	    x2=y+3;
	 }
      }	
   }   
   if(y-2>=0)
   {
      if(x+1<8)
      {
	 if(szachownica[y-2][x+1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x+1],y-1);
	 }
	 if(szachownica[y-2][x+1]==stronaB)
	 {
	    bicie3=JEST;
	    c3=tab[x+1];
	    x3=y-1;
	 }
      }
      if(x-1>=0)
      {
	 if(szachownica[y-2][x-1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-1],y-1);
	 }
	 if(szachownica[y-2][x-1]==stronaB)
	 {
	    bicie4=JEST;
	    c4=tab[x-1];
	    x4=y-1;
	 }
      }
   }    
   if(x+2<8)
   {
      if(y+1<8)
      {
	 if(szachownica[y+1][x+2]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x+2],y+2);
	 }
	 if(szachownica[y+1][x+2]==stronaB)
	 {
	    bicie5=JEST;
	    c5=tab[x+2];
	    x5=y+2;
	 }
      }
      if(y-1>=0)
      {
	 if(szachownica[y-1][x+2]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x+2],y);
	 }
	 if(szachownica[y-1][x+2]==stronaB)
	 {
	    bicie6=JEST;
	    c6=tab[x+2];
	    x6=y;
	 }
      }	
   }   
   if(x-2>=0)
   {
      if(y+1<8)
      {
	 if(szachownica[y+1][x-2]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-2],y+2);
	 }
	 if(szachownica[y+1][x-2]==stronaB)
	 {
	    bicie7=JEST;
	    c7=tab[x-2];
	    x7=y+2;
	 }
      }
      if(y-1>=0)
      {
	 if(szachownica[y-1][x-2]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-2],y);
	 }
	 if(szachownica[y-1][x-2]==stronaB)
	 {
	    bicie8=JEST;
	    c8=tab[x-2];
	    x8=y;
	 }
      }	
   }   
   if(bicie1==JEST || bicie2==JEST || bicie3==JEST ||
      bicie4==JEST || bicie5==JEST || bicie6==JEST ||
      bicie7==JEST || bicie8==JEST )
   {
      printf("\nbicie na :");
      if(bicie1==JEST)
	 printf(" %c%d,",c1,x1);  
      if(bicie2==JEST)
	 printf(" %c%d,",c2,x2);  
      if(bicie3==JEST)
	 printf(" %c%d,",c3,x3);  
      if(bicie4==JEST)
	 printf(" %c%d,",c4,x4);  
      if(bicie5==JEST)
	 printf(" %c%d,",c5,x5);  
      if(bicie6==JEST)
	 printf(" %c%d,",c6,x6);  
      if(bicie7==JEST)
	 printf(" %c%d,",c7,x7);  
      if(bicie8==JEST)
	 printf(" %c%d,",c8,x8);  
   }
   if(bicie1==NIE_MA && bicie2==NIE_MA && bicie3==NIE_MA &&
      bicie4==NIE_MA && bicie5==NIE_MA && bicie6==NIE_MA &&
      bicie7==NIE_MA && bicie8==NIE_MA && ruch==NIE_MA)

      printf(" nie ma ruchu.");
}      
void krol(int x,int y,int stronaA,int stronaB)
{
   int ruch=NIE_MA;
   int bicie1=NIE_MA;
   int bicie2=NIE_MA;
   int bicie3=NIE_MA;
   int bicie4=NIE_MA;
   int bicie5=NIE_MA;
   int bicie6=NIE_MA;
   int bicie7=NIE_MA;
   int bicie8=NIE_MA;
   int x1,x2,x3,x4,x5,x6,x7,x8;
   char c1,c2,c3,c4,c5,c6,c7,c8;
   char tab[]="abcdefgh"; 

   if(y+1<8)
   {
      if(szachownica[y+1][x]==0)
      {   
	 ruch=JEST;
	 printf(" %c%d,",tab[x],y+2);
      }   
      else               
	 ruch=NIE_MA;             
      if(szachownica[y+1][x]==stronaB)
      {
	 bicie1=JEST;
	 c1=tab[x];
	 x1=y+2;
      }
      if(x+1<8)
      {
	 if(szachownica[y+1][x+1]==0)
	 {                       
	    ruch=JEST;
	    printf(" %c%d,",tab[x+1],y+2);
	 }   
	 else               
	    ruch=NIE_MA;             
	 if(szachownica[y+1][x+1]==stronaB)
	 {
	    bicie2=JEST;
	    c2=tab[x+1];
	    x2=y+2;
	 }
      }
      if(x-1>=0)
      {
	 if(szachownica[y+1][x-1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-1],y+2);
	 }   
	 else               
	    ruch=NIE_MA;             
	 if(szachownica[y+1][x-1]==stronaB)
	 {
	    bicie3=JEST;
	    c3=tab[x-1];
	    x3=y+2;
	 }
      }
   }  
   else               
      ruch=NIE_MA;             
   if(y-1>=0)
   {
      if(szachownica[y-1][x]==0)
      {   
	 ruch=JEST;
	 printf(" %c%d,",tab[x],y);
      }   
      else               
	 ruch=NIE_MA;             
      if(szachownica[y-1][x]==stronaB)
      {
	 bicie4=JEST;
	 c4=tab[x];
	 x4=y;
      }
      if(x+1<8)
      {
	 if(szachownica[y-1][x+1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x+1],y);
	 }   
	 else               
	    ruch=NIE_MA;             
	 if(szachownica[y-1][x+1]==stronaB)
	 {
	    bicie5=JEST;
	    c5=tab[x+1];
	    x5=y;
	 }
      }
      if(x-1>=0)
      {
	 if(szachownica[y-1][x-1]==0)
	 {
	    ruch=JEST;
	    printf(" %c%d,",tab[x-1],y);
	 }   
	 else               
	    ruch=NIE_MA;             
	 if(szachownica[y-1][x-1]==stronaB)
	 {
	    bicie6=JEST;
	    c6=tab[x-1];
	    x6=y;
	 }
      }
   }
   else
      ruch=NIE_MA;
   if(x+1<8)
   {
      if(szachownica[y][x+1]==0)
      {
	 ruch=JEST;
	 printf(" %c%d,",tab[x+1],y+1);
      }   
      else               
	 ruch=NIE_MA;             
      if(szachownica[y][x+1]==stronaB)
      {
	 bicie7=JEST;
	 c7=tab[x+1];
	 x7=y+1;
      }
   }
   if(x-1>=0)
   {
      if(szachownica[y][x-1]==0)
      {
	 ruch=JEST;
	 printf(" %c%d,",tab[x-1],y+1);
      }   
      else               
	 ruch=NIE_MA;             
      if(szachownica[y][x-1]==stronaB)
      {
	 bicie8=JEST;
	 c8=tab[x-1];
	 x8=y+1;
      }
   }	       
   if(bicie1==JEST || bicie2==JEST || bicie3==JEST ||
      bicie4==JEST || bicie5==JEST || bicie6==JEST ||
      bicie7==JEST || bicie8==JEST )
   {
      printf("\nbicie na :");
      if(bicie1==JEST)
	 printf(" %c%d,",c1,x1);  
      if(bicie2==JEST)
	 printf(" %c%d,",c2,x2);  
      if(bicie3==JEST)
	 printf(" %c%d,",c3,x3);  
      if(bicie4==JEST)
	 printf(" %c%d,",c4,x4);  
      if(bicie5==JEST)
	 printf(" %c%d,",c5,x5);  
      if(bicie6==JEST)
	 printf(" %c%d,",c6,x6);  
      if(bicie7==JEST)
	 printf(" %c%d,",c7,x7);  
      if(bicie8==JEST)
	 printf(" %c%d,",c8,x8);  
   }

   if(bicie1==NIE_MA && bicie2==NIE_MA && bicie3==NIE_MA &&
      bicie4==NIE_MA && bicie5==NIE_MA && bicie6==NIE_MA &&
      bicie7==NIE_MA && bicie8==NIE_MA && ruch==NIE_MA)

      printf(" nie ma ruchu.");
}      
		  




				 