#include <stdio.h>
#include "dek1.h"

long int czytaj(char *nazwa)
{
   FILE *ptr;                               /* wskaznik do pliku */      
   long int file_size;                      /* rozmiar pliku */ 

   if((ptr=fopen(nazwa,"r"))==NULL)
   {
      printf("\nNie moge znalezc pliku o takiej nazwie.\n");
      return BLAD;
   }
   
   fseek(ptr,0,SEEK_END);                   /* badanie  */ 
   file_size=ftell(ptr);                    /* rozmiaru */
   fseek(ptr,0,SEEK_SET);                   /* pliku    */
   
   if((plikptr=(char *)malloc((size_t)file_size))==NULL)   /* przydzielanie */
   {                                                       /* pamieci       */
      printf("\nNie moge dokonac przydzialu pamieci");
      fclose(ptr);
      return BLAD;
   }
   
   fread(plikptr,file_size,1,ptr);          /* wczytywanie zawartosci pliku */     
   fclose(ptr);                             /* do pamieci                   */
   return file_size;       
}   
      