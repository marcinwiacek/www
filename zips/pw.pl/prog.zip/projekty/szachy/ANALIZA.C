#include <stdio.h>
#include "dek3.h"

int analiza(void)
{
    int kb=0,pb=0,wb=0,sb=0,gb=0,hb=0;      /* liczba poszczegolnych bierek */
    int kc=0,pc=0,wc=0,sc=0,gc=0,hc=0;      /* bialych i czarnych           */ 
    int i,stanb,stanc;     
    
    for(i=0;i<nb;i++)
    {
       if( bialaptr[i].n=='K')
          kb++;
       if( bialaptr[i].n=='P')
       {
          if( bialaptr[i].y==0 || bialaptr[i].y==7)
          { 
             free(bialaptr);
             free(czarnaptr);           
             return BLAD;
          }          
          pb++;
       }   
       if( bialaptr[i].n=='G')
          gb++;
       if( bialaptr[i].n=='S')
          sb++;  
       if( bialaptr[i].n=='H')
          hb++;  
       if( bialaptr[i].n=='W')
          wb++;
    }
    for(i=0;i<nc;i++)
    {
       if( czarnaptr[i].n=='K')
          kc++;
       if( czarnaptr[i].n=='P')
       {
          if(czarnaptr[i].y==7 || czarnaptr[i].y==0)
          {   
             free(bialaptr);
             free(czarnaptr);
             return BLAD; 
          }
          pc++;
       }
       if( czarnaptr[i].n=='G')
          gc++;
       if( czarnaptr[i].n=='S')
          sc++;  
       if( czarnaptr[i].n=='H')
          hc++;  
       if( czarnaptr[i].n=='W')
          wc++;
    }                        
    if( (kb!=1) || (kc!=1)  )
    {
       printf("\nNa szachownicy znajduje sie niedozwolona liczba kroli\n");   
       free(bialaptr);
       free(czarnaptr);   
       return BLAD;
    }

    if(  (pb>8) || (pc>8) )
    {
       printf("\nNa szachownicy znajduje sie niedozwolona liczba pionow\n");   
       free(bialaptr);
       free(czarnaptr);
       return BLAD;  
    }

    for(i=0;i<=8;i++)
    {
       if(pb==i)          
       {
          if( (wb<=10-i) && (sb<=10-i) && (gb<=10-i) 
                && (hb<=9-i) && (wb+sb+gb+hb<=15-i))
             stanb=NIE_MA_BLEDU;
          else
             stanb=BLAD;     
       }
    }      

    for(i=0;i<=8;i++)
    { 
       if(pc==i)          
       {
          if( (wc<=10-i) && (sc<=10-i) && (gc<=10-i) 
                && (hc<=9-i) && (wc+sc+gc+hc<=15-i))
             stanc=NIE_MA_BLEDU;
          else
             stanc=BLAD;     
       }
    }     

    if( (stanb==NIE_MA_BLEDU) && (stanc==NIE_MA_BLEDU) )
       return NIE_MA_BLEDU;
    
    if( (stanb==BLAD) || (stanc==BLAD) )
    {   
       free(bialaptr);
       free(czarnaptr);
       return BLAD;
    }
}                            