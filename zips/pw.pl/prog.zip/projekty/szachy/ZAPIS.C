#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "dek2.h"


int zapis(int file_size)
{   
   char *bptr,*cptr;            /* wskazniki do stringow "biale:","czarne:" */
   char c;
   int i,v,h;
   int stan=OUT;
   
   if(((bptr=strstr(plikptr,"biale:"))==NULL)||
      ((cptr=strstr(plikptr,"czarne:"))==NULL))
   { 
      return BLAD;
   }     
   
   for (i=0;i<(cptr-(bptr+6));i++)
   {
      c=*(plikptr+i+((bptr+6)-plikptr));       
      if(isspace(c))
      {  
         if(stan==IN)
            stan=OUT;
      }      
      else
         if(stan==OUT)
         {
            stan=IN;
            bialaptr=(struct bierkabiala*)realloc(bialaptr,(nb+1)*sizeof(struct bierkabiala));
	    if(bialaptr==NULL)
	    {
	       return BLAD1;
	    }
	    switch(*(plikptr+i+((bptr+6)-plikptr)))
	    {
	       case 'P' : case 'W' : case 'G' : 
	       case 'S' : case 'H' : case 'K' : 
		  bialaptr[nb].n=*(plikptr+i+((bptr+6)-plikptr)); break;
	       default :
                  free(bialaptr);
		  free(czarnaptr);
		  return BLAD;
	    }
	    switch(*(plikptr+i+2+((bptr+6)-plikptr)))
	    {
	       case 'a' :
		  bialaptr[nb].x=0; h=0; break;
	       case 'b' :
		  bialaptr[nb].x=1; h=1; break;
	       case 'c' :
		  bialaptr[nb].x=2; h=2; break;
	       case 'd' :
		  bialaptr[nb].x=3; h=3; break;
	       case 'e' :
		  bialaptr[nb].x=4; h=4; break;
	       case 'f' :
		  bialaptr[nb].x=5; h=5; break;
	       case 'g' :
		  bialaptr[nb].x=6; h=6; break;
	       case 'h' :
		  bialaptr[nb].x=7; h=7; break;								       
	       default :
                  free(bialaptr);
		  free(czarnaptr);
		  return BLAD;
	    }
	    switch(*(plikptr+i+3+((bptr+6)-plikptr)))
	    {
	       case '1' :
		  bialaptr[nb++].y=0; v=0; break;
	       case '2' :
		  bialaptr[nb++].y=1; v=1; break;
	       case '3' :
		  bialaptr[nb++].y=2; v=2; break;
	       case '4' :
		  bialaptr[nb++].y=3; v=3; break;
	       case '5' :
		  bialaptr[nb++].y=4; v=4; break;
	       case '6' :
		  bialaptr[nb++].y=5; v=5; break;
	       case '7' :
		  bialaptr[nb++].y=6; v=6; break;
	       case '8' :
		  bialaptr[nb++].y=7; v=7; break;								       
	       default :
	       	  free(bialaptr);
		  free(czarnaptr);
		  return BLAD;
	    }
	    if(szachownica[v][h]==0)
	       szachownica[v][h]=1;		 
	    else
	    {
	       return BLAD2;
	    }       
	 }
   }      
   stan=OUT;
   for(i=0;i<((plikptr+file_size)-(cptr+7));i++)
   {
      c=*(plikptr+i+((cptr+7)-plikptr));       
	if(isspace(c))
	{  
	   if(stan==IN)
	      stan=OUT;
	}      
	else
	   if(stan==OUT)
	   {
	      stan=IN;
	      czarnaptr=(struct bierkaczarna*)realloc(czarnaptr,(nc+1)*sizeof(struct bierkaczarna));
	      if(czarnaptr==NULL)
	      {
		 return BLAD1;
	      }
			 
	      switch(*(plikptr+i+((cptr+7)-plikptr)))
	      {
		 case 'P' : case 'W' : case 'G' : 
		 case 'S' : case 'H' : case 'K' : 
		    czarnaptr[nc].n=*(plikptr+i+((cptr+7)-plikptr)); break;
		 default :
                    free(czarnaptr);
		    free(bialaptr);
		    return BLAD;
	      }
	      switch(*(plikptr+i+2+((cptr+7)-plikptr)))
	      {
		 case 'a' :
		   czarnaptr[nc].x=0; h=0; break;
		 case 'b' :
		   czarnaptr[nc].x=1; h=1; break;
		 case 'c' :
		   czarnaptr[nc].x=2; h=2; break;
		 case 'd' :
		   czarnaptr[nc].x=3; h=3; break;
		 case 'e' :
		   czarnaptr[nc].x=4; h=4; break;
		 case 'f' :
		   czarnaptr[nc].x=5; h=5; break;
		 case 'g' :
		   czarnaptr[nc].x=6; h=6; break;
		 case 'h' :
		   czarnaptr[nc].x=7; h=7; break;								       
		 default :
		    free(czarnaptr);
		    free(bialaptr);
		    return BLAD;
	      }
	      switch(*(plikptr+i+3+((cptr+7)-plikptr)))
	      {
		 case '1' :
		   czarnaptr[nc++].y=0; v=0; break;
		 case '2' :
		   czarnaptr[nc++].y=1; v=1; break;
		 case '3' :
		   czarnaptr[nc++].y=2; v=2; break;
		 case '4' :
		   czarnaptr[nc++].y=3; v=3; break;
		 case '5' :
		   czarnaptr[nc++].y=4; v=4; break;
		 case '6' :
		   czarnaptr[nc++].y=5; v=5; break;
		 case '7' :
		   czarnaptr[nc++].y=6; v=6; break;
		 case '8' :
		   czarnaptr[nc++].y=7; v=7; break;								       
		 default :
		   free(czarnaptr);
		    free(bialaptr);
		    return BLAD;
	      }
	      if(szachownica[v][h]==0)
	         szachownica[v][h]=2;
              else
	      {
	         return BLAD2;
	      }   
           }         
   }
   return NIE_MA_BLEDU;
}      