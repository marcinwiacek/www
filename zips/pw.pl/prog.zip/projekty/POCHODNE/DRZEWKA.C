typedef enum {operacja,liczba,function,ix,minus} typ_elementu;
void print_number(float x);

struct tree
	{
	typ_elementu typ;
	union ELEMENT
	   {
	   struct {
		char znak;
		struct tree *left,*right;
		}oper;				//operator
	   struct {
		float value;
		}number;
	   struct {
		int index;
		struct tree *wewn;		//funkcja wewnetrzna
		}fun;
	   struct {
		struct tree *wewn;		//funkcja wewnetrzna
		}min;
	   }el;
	}*pochodna=NULL,*funkcja=NULL;

struct tree *create_node(typ_elementu typ,union ELEMENT e)
{
struct tree *temp;

temp=(struct tree*)malloc(sizeof(struct tree));
if (!temp) return NULL;
temp->typ=typ;
switch(typ)
      {
      case operacja:
	   temp->el.oper.znak =e.oper.znak;
	   temp->el.oper.left =e.oper.left;
	   temp->el.oper.right=e.oper.right;
	   break;
      case liczba:
	   temp->el.number.value=e.number.value;
	   break;
      case function:
	   temp->el.fun.index=e.fun.index;
	   temp->el.fun.wewn =e.fun.wewn;
	   break;
      case ix:
	   break;
      case minus:
	   temp->el.min.wewn=e.min.wewn;
	   break;
      }
return temp;
}

struct tree *create_oper(char znak)
{
union ELEMENT e;
e.oper.znak=znak;
return create_node(operacja,e);
}

int find_index(char *nazwa)
{
int i;
for(i=0;i<ilosc_funkcji;i++)
    if (!strcmp(nazwa,funkcje[i].nazwa)) return(i);
return(-1);
}

struct tree *create_fun(char *nazwa)
{
union ELEMENT e;

e.fun.index=find_index(nazwa);
if (e.fun.index==-1) return NULL;
return create_node(function,e);
}

struct tree *create_min(struct tree *node)
{
union ELEMENT e;
e.min.wewn=node;
return create_node(minus,e);
}

struct tree *create_number(float f)
{
union ELEMENT e;
e.number.value=f;
return create_node(liczba,e);
}


struct tree *copy_node(struct tree * node)
{
struct tree *temp;

temp=create_node(node->typ,node->el);

switch(node->typ)
{
case operacja:
     temp->el.oper.left =copy_node(node->el.oper.left );
     temp->el.oper.right=copy_node(node->el.oper.right);
case liczba:
case ix:
     return temp;
case function:
     temp->el.fun.wewn=copy_node(node->el.fun.wewn);
     return temp;
case minus:
     temp->el.min.wewn=copy_node(node->el.min.wewn);
     return temp;
}
return NULL;
}


void delete_tree(struct tree *node)
{
if (!node) return;
switch(node->typ)
      {
      case operacja:
	   if (node->el.oper.left ) delete_tree(node->el.oper.left);
	   if (node->el.oper.right) delete_tree(node->el.oper.right);
	   free(node);
	   return;
      case liczba:
	   free(node);
	   return;
      case function:
	   delete_tree(node->el.fun.wewn);
	   free(node);
	   return;
      case ix:
	   free(node);
	   return;
      case minus:
	   delete_tree(node->el.min.wewn);
	   free(node);
	   return;
      }
}


int funkcja_x(struct tree *node)
{
//	zwraca TRUE gdy dany wezel zalezy od x
switch(node->typ)
      {
      case operacja:
	   if (funkcja_x(node->el.oper.left)||funkcja_x(node->el.oper.right))
	   return TRUE; else return FALSE;
      case liczba:
	   return FALSE;
      case function:
	   return funkcja_x(node->el.fun.wewn);
      case ix:
	   return TRUE;
      case minus:
	   return funkcja_x(node->el.min.wewn);
      }
return FALSE;
}

float value(struct tree *node,float x)
{
float a,b;
if (!node) return 0;
switch(node->typ)
{
case operacja:
   switch(node->el.oper.znak)
   {
   case '+': return value(node->el.oper.left,x)+value(node->el.oper.right,x);
   case '-': return value(node->el.oper.left,x)-value(node->el.oper.right,x);
   case '*': return value(node->el.oper.left,x)*value(node->el.oper.right,x);
   case '/':
	a=value(node->el.oper.right,x);
	if (a!=0)
	   return value(node->el.oper.left,x)/a;
	else
	   {
	   printf("ERROR : divide by 0 !!!\n");
	   return value(node->el.oper.left,x);
	   }
   case '^':
	a=value(node->el.oper.left ,x);
	b=value(node->el.oper.right,x);
	if (a==0) return 0;
	if (a<0)
	   return (float)exp(b*log(-a))*cos(b*acos(-1));
	else
	   return (float)exp(b*log( a));
   };
case liczba:
     return node->el.number.value;
case function:
     a=value(node->el.fun.wewn,x);
     return funkcje[node->el.fun.index].value(a);
case ix:
     return x;
case minus:
     return -value(node->el.min.wewn,x);
}
return 0;
}

struct tree *differentiate(struct tree *node)
{
struct tree *left,*right,*temp;

if (!node) return NULL;
if (!funkcja_x(node))
   {
   delete_tree(node);			//Dany wezel nie zalezy od x
   return create_number(0);		//wiec pochodna wynosi 0
   }

switch(node->typ)
{
case operacja:
     switch(node->el.oper.znak)
     {
     case '+':
     case '-':
	  node->el.oper.left =differentiate(node->el.oper.left );
	  node->el.oper.right=differentiate(node->el.oper.right);
	  return node;
     case '*':
	  left =copy_node(node);
	  right=copy_node(node);
	  node ->el.oper.znak ='+';
	  delete_tree(node ->el.oper.left);
	  delete_tree(node ->el.oper.right);
	  node ->el.oper.left =left;
	  node ->el.oper.right=right;
	  left ->el.oper.left =differentiate(left ->el.oper.left );
	  right->el.oper.right=differentiate(right->el.oper.right);
	  return node;
     case '/':                 // F(x)/G(x)
	  if (!funkcja_x(node->el.oper.right))
	     {		//G(x)-mianownik niezalezny od x
	     temp=create_number(1);
	     left=node->el.oper.left;
	     node->el.oper.left=temp;
	     left=differentiate(left);
	     right=create_oper('*');
	     right->el.oper.left =left;
	     right->el.oper.right=node;
	     return node;
	     }
	  left =copy_node(node);
	  right=copy_node(node);
	  temp =create_oper('-');
	  left ->el.oper.znak='*';
	  right->el.oper.znak='*';
	  left ->el.oper.left =differentiate(left ->el.oper.left );
	  right->el.oper.right=differentiate(right->el.oper.right);
	  temp ->el.oper.left =left;
	  temp ->el.oper.right=right;
	  right=create_oper('^');
	  right->el.oper.left =copy_node(node->el.oper.right);
	  right->el.oper.right=create_number(2);
	  delete_tree(node ->el.oper.left);
	  delete_tree(node ->el.oper.right);
	  node ->el.oper.left =temp;
	  node ->el.oper.right=right;
	  return node;
     case '^':
	  if (!funkcja_x(node->el.oper.right))
	     {		// wyrazenie typu f(x)^a
	     temp =create_oper('-');
	     temp ->el.oper.left =copy_node(node->el.oper.right);
	     temp ->el.oper.right=create_number(1);
	     right=create_oper('^');
	     right->el.oper.left =copy_node(node->el.oper.left);
	     right->el.oper.right=temp;
	     left =create_oper('*');
	     left ->el.oper.left =node->el.oper.right;
	     left ->el.oper.right=differentiate(node->el.oper.left);
	     node ->el.oper.znak ='*';
	     node ->el.oper.left =left;
	     node ->el.oper.right=right;
	     return node;
	     }
	  else
	     {  // F(x)^G(x) ,G(x) zalezy od x
		//ma zwrocic F^G*(G'*logF+G*F'/F)
	     temp =create_oper('/'); 		//temp=F'/F
	     temp ->el.oper.right=copy_node(node->el.oper.left);
	     temp ->el.oper.left =differentiate(copy_node(node->el.oper.left));
	     right=create_oper('*');
	     right->el.oper.right=temp;
	     right->el.oper.left =copy_node(node->el.oper.right);
					//right=G*F'/F
	     temp =create_fun("LOG");
	     temp ->el.fun.wewn=copy_node(node->el.oper.left);
	     left =create_oper('*');
	     left ->el.oper.right=temp;
	     left ->el.oper.left =differentiate(copy_node(node->el.oper.right));
					//left=G'*logF
	     temp =create_oper('+');
	     temp ->el.oper.right=right;
	     temp ->el.oper.left =left;
	     right=temp;		//right=G'*logF+G*F'/F
	     left =node;
	     temp =create_oper('*');
	     temp ->el.oper.left =left;
	     temp ->el.oper.right=right;
	     return temp;
	     }
     }

case liczba:
     node->el.number.value=0;
     return node;
case function:
     temp=create_oper('*');
     temp->el.oper.left =differentiate(copy_node(node->el.fun.wewn));
     temp->el.oper.right=
	 funkcje[node->el.fun.index].drzewo_pochodnej(node->el.fun.wewn);
     free(node);
     return temp;
case ix:
     free(node);
     return create_number(1);
case minus:
     node->el.min.wewn=differentiate(node->el.min.wewn);
     return node;
}
return NULL;
}

struct tree *korekta(struct tree *node)
{
struct tree *left,*right,*temp;

if (!node) return NULL;
if (!funkcja_x(node))
   {
   temp=create_number(value(node,0));
   delete_tree(node);			//Dany wezel nie zalezy od x
   return temp;				//wiec podstawiamy jego wartosc
   }

switch(node->typ)
{
case operacja:
     left =node->el.oper.left =korekta(node->el.oper.left);
     right=node->el.oper.right=korekta(node->el.oper.right);
     switch(node->el.oper.znak)
     {
     case '+':
	  if (left ->typ==liczba&&left ->el.number.value==0)
	     {
	     free(node);
	     free(left);
	     return right;
	     }
	  if (right->typ==liczba&&right->el.number.value==0)
	     {
	     free(node);
	     free(right);
	     return left;
	     }
	  if (right->typ==liczba&&right->el.number.value<0)
	     {
	     right->el.number.value=-right->el.number.value;
	     node ->el.oper.znak='-';
	     return node;
	     }
	  if (right->typ==minus)
	     {
	     node ->el.oper.right=korekta(right->el.min.wewn);
	     node ->el.oper.znak ='-';
	     free(right);
	     return node;
	     }
	  return node;
     case '-':
	  if (left ->typ==liczba&&left ->el.number.value==0)
	     {
	     free(node);
	     free(left);
	     temp=create_min(right);
	     return korekta(temp);
	     }
	  if (right->typ==liczba&&right->el.number.value==0)
	     {
	     free(node);
	     free(right);
	     return left;
	     }
	  if (right->typ==liczba&&right->el.number.value<0)
	     {
	     right->el.number.value=-right->el.number.value;
	     node ->el.oper.znak='+';
	     return node;
	     }
	  if (right->typ==minus)
	     {
	     node ->el.oper.right=korekta(right->el.min.wewn);
	     node ->el.oper.znak ='+';
	     free(right);
	     return node;
	     }
	  return node;
     case '*':
	  if (left ->typ==liczba)
	     {
	     if (left ->el.number.value==0)
		{
		delete_tree(node);
		return create_number(0);
		}
	     if (left ->el.number.value==1)
		{
		free(node);
		free(left);
		return right;
		}
	     if (left ->el.number.value==(-1))
		{
		free(node);
		free(left);
		temp=create_min(right);
		return korekta(temp);
		}
	     return node;
	     }
	  if (right->typ==liczba)
	     {
	     if (right->el.number.value==0)
		{
		delete_tree(node);
		return create_number(0);
		}
	     if (right->el.number.value==1)
		{
		free(node);
		free(right);
		return left;
		}
	     if (right->el.number.value==(-1))
		{
		free(node);
		free(right);
		temp=create_min(left);
		return korekta(temp);
		}
	     return node;
	     }
	  return node;
     case '/':
	  if (left ->typ==liczba&&left ->el.number.value==0)
		{
		delete_tree(node);
		return create_number(0);
		}
	  if (right->typ==liczba)
	     {
	     if (right->el.number.value==0)
		{
		printf("ERROR : Divide by 0 !!!\n");
		return node;
		}
	     if (right->el.number.value==1)
		{
		free(node);
		free(right);
		return left;
		}
	     if (right->el.number.value==(-1))
		{
		free(node);
		free(right);
		temp=create_min(left);
		return korekta(temp);
		}
	     temp=create_number(1/right->el.number.value);
	     node->el.oper.znak ='*';
	     node->el.oper.right=left;
	     node->el.oper.left =temp;
	     return node;
	     }
	  return node;
     case '^':
	  if (left ->typ==liczba&&left ->el.number.value==0)
		{
		delete_tree(node);
		return create_number(0);
		}
	  if (left ->typ==liczba&&left ->el.number.value==1)
		{
		delete_tree(node);
		return create_number(1);
		}
	  if (right->typ==liczba&&right->el.number.value==1)
		{
		free(node);
		free(right);
		return left;
		}
	  return node;
     }
case liczba:
case ix    :
     return node;
case function:
     node->el.fun.wewn=korekta(node->el.fun.wewn);
     return node;
case minus:
     node->el.min.wewn=korekta(node->el.min.wewn);
     temp=node->el.min.wewn;
     if (temp->typ==minus)       //F(x)=-(-(G(x)))
	{                        //F(x)=G(x)
	temp=temp->el.min.wewn;
	free(node->el.min.wewn);
	free(node);
	return temp;
	}
     if (temp->typ==liczba&&temp->el.number.value<0)
	{
	temp->el.number.value=-temp->el.number.value;
	free(node);
	return temp;
	}
	return node;
}
return node;
}

void inorder(struct tree *node,char c)
{
if (!node) return;
switch(node->typ)
{
case operacja:
     switch(node->el.oper.znak)
     {
     case '+':
	  if (c=='+')
	     {
	     inorder(node->el.oper.left,'+');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'+');
	     }
	  else
	     {
	     printf("(");
	     inorder(node->el.oper.left,'+');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'+');
	     printf(")");
	     };
	  return;
     case '-':
	  if (c=='+')
	     {
	     inorder(node->el.oper.left,'+');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'-');
	     }
	  else
	     {
	     printf("(");
	     inorder(node->el.oper.left,'-');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'-');
	     printf(")");
	     };
	  return;
     case '*':
     case '/':
	  if (c!='^')
	     {
	     inorder(node->el.oper.left,'*');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'*');
	     }
	  else
	     {
	     printf("(");
	     inorder(node->el.oper.left,'*');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'*');
	     printf(")");
	     };
	  return;
     case '^':
	  if (c!='^')
	     {
	     inorder(node->el.oper.left,'^');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'^');
	     }
	  else
	     {
	     printf("(");
	     inorder(node->el.oper.left,'^');
	     printf("%c",node->el.oper.znak);
	     inorder(node->el.oper.right,'*');
	     printf(")");
	     }
	  return;
     };
case liczba:
     print_number(node->el.number.value);
     break;
case function:
     printf("%s(",funkcje[node->el.fun.index].nazwa);
     inorder(node->el.fun.wewn,'+');
     printf(")");
     break;
case ix:
     printf("X");
     break;
case minus:
     if (c=='+')
	{
	printf("-");
	inorder(node->el.min.wewn,'-');
	}
     else
	{
	printf("(-");
	inorder(node->el.min.wewn,'-');
	printf(")");
	}
      break;
}
}


void print_number(float x)
{
double calkowita,ulamek;
ulamek=modf((double)x,&calkowita);
if (ulamek==0) printf("%.0lf",calkowita);
else printf("%.3f",x);
}