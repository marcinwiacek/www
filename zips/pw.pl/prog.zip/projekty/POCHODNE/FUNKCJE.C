struct tree * SIN  (struct tree *node)
{
struct tree *temp;

temp=create_fun("COS");
temp->el.fun.wewn=node;
return temp;
}

struct tree * COS  (struct tree *node)
{
struct tree *temp;

temp=create_fun("SIN");
temp->el.fun.wewn=node;
return create_min(temp);
}

struct tree * TAN  (struct tree *node)
{
struct tree *left,*right,*temp;

temp =create_fun("COS");
temp ->el.fun.wewn=node;
right=create_oper('^');
right->el.oper.left =temp;
right->el.oper.right=create_number(2);
left =create_number(1);
temp =create_oper('/');
temp ->el.oper.left =left;
temp ->el.oper.right=right;
return temp;
}

struct tree * CTG  (struct tree *node)
{
struct tree *left,*right,*temp;

temp =create_fun("SIN");
temp ->el.fun.wewn=node;
right=create_oper('^');
right->el.oper.left =temp;
right->el.oper.right=create_number(2);
left =create_number(1);
temp =create_oper('/');
temp ->el.oper.left =left;
temp ->el.oper.right=right;
return create_min(temp);
}

struct tree * LN   (struct tree *node)
{
struct tree *left,*right,*temp;

left =create_number(1);
right=node;
temp =create_oper('/');
temp ->el.oper.left =left;
temp ->el.oper.right=right;
return temp;
}

struct tree * EXP  (struct tree *node)
{
struct tree *temp;
temp=create_fun("EXP");
temp->el.fun.wewn=node;
return temp;
}

struct tree * ASIN (struct tree *node)
{
struct tree *left,*right,*temp;

right=create_oper('^');
right->el.oper.left =node;
right->el.oper.right=create_number(2);
left =create_number(1);
temp =create_oper('-');
temp ->el.oper.left =left;
temp ->el.oper.right=right;  //temp = 1-x^2
right=create_fun("SQRT");
right->el.fun.wewn=temp;
left =create_number(1);
temp =create_oper('/');
temp ->el.oper.left =left;
temp ->el.oper.right=right;
return temp;
}

struct tree * ACOS (struct tree *node)
{
struct tree *temp;

temp =ASIN(node);
return create_min(temp);
}

struct tree * ATAN (struct tree *node)
{
struct tree *left,*right,*temp;

left =create_oper('^');
left ->el.oper.left =node;
left ->el.oper.right=create_number(2);  //left=x^2
right=create_oper('+');
right->el.oper.left =left;
right->el.oper.right=create_number(1); //right=x^2+1
temp =create_oper('/');
temp ->el.oper.left =create_number(1);
temp ->el.oper.right=right;
return temp;
}

struct tree * SQRT (struct tree *node)
{
struct tree *left,*right,*temp;

temp =create_fun("SQRT");
temp->el.fun.wewn=node;
right=create_oper('*');
right->el.oper.left =create_number(2);
right->el.oper.right=temp;
left =create_number(1);
temp =create_oper('/');
temp->el.oper.left =left;
temp->el.oper.right=right;
return temp;
}

float SIN_V (float x)
{
return sin(x);
}

float COS_V (float x)
{
return cos(x);
}

float LN_V  (float x)
{
if (x>0) return log(x); else return 666;
}

float EXP_V (float x)
{
return exp(x);
}

float TAN_V (float x)
{
float y;
y=cos(x);
if (y==0) return(666); else return sin(x)/y;
}

float CTG_V (float x)
{
float y;
y=sin(x);
if (y==0) return(666); else return cos(x)/y;
}

float SQRT_V(float x)
{
if (x<0) return(666); else return sqrt(x);
}

float ASIN_V(float x)
{
if (x<-1||x>1) return(666); else return asin(x);
}

float ACOS_V(float x)
{
if (x<-1||x>1) return(666); else return acos(x);
}

float ATAN_V(float x)
{
return atan(x);
}