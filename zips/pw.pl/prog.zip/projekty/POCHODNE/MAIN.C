#include <stdio.h>
#include <alloc.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#define TRUE 1
#define FALSE 0
#include "funkcje.h"
#include "drzewka.c"
#include "commands.c"
#include "funkcje.c"

void STRUPR(char *s)
{
while (*s!='\0')
  *s++=(char)toupper(*s);
}


void main(void)
{
char linia[130];

do
  {
  printf(">");
  fflush(stdin);
  gets(linia);
  STRUPR(linia);
  usun_spacje(linia);
  if (!strlen(linia))
     continue;
  if (!strcmp(linia,"QUIT")||!strcmp(linia,"EXIT")||!strcmp(linia,"BYE"))
     break;
polecenie(linia);
  }
while(TRUE);
printf("God bye!\n");
}