int jest_funkcja(char *poczatek,char *koniec)
{
// (-1) - dany literal nie jest nazwa funkcji
//!(-1) - index w tablicy funkcji
char nazwa[130];
int i=0;

for(;poczatek<=koniec;poczatek++)
   nazwa[i++]=*poczatek;
nazwa[i]='\0';
for(i=0;i<ilosc_funkcji;i++)
    if (!strcmp(nazwa,funkcje[i].nazwa)) return(i);
return(-1);
}

int  jest_liczba           (char *poczatek,char *koniec)
{
int kropki=0;

for(;poczatek<=koniec;poczatek++)
   {
   if (*poczatek=='.') kropki++;
   else if (*poczatek>'9'||*poczatek<'0') return FALSE;
   }
if (kropki>1)
   return FALSE;
if (kropki==1&&*koniec=='.')
   return FALSE;
return TRUE;
}


void 	usun_spacje(char *s)
{
int i=0,j=0;

for (;s[i];i++)
    if (!isspace(s[i])) s[j++]=s[i];
s[j]='\0';
}

char	*nawias(char *poczatek,char *koniec)
{
int lewe=0,prawe=0;

for (;poczatek<=koniec;poczatek++)
    {
    if (*poczatek=='(') lewe++;
    if (*poczatek==')') prawe++;
    if (lewe==prawe) return(poczatek);
    }
return(NULL);
}

int jest_dzialaniem(char d)
{
if (d=='+'||d=='-'||d=='*'||d=='/'||d=='^') return TRUE;
return FALSE;
}

char *dzialanie(char *poczatek,char *koniec,char d)
{
for(;poczatek<=koniec;poczatek++)
   {
   if (*poczatek==d) return(poczatek);
   if (*poczatek=='(') poczatek=nawias(poczatek,koniec);
   if (poczatek==NULL) break;
   }
return(NULL);
}

char *ostatnie(char *poczatek,char *koniec,char d)
{
char *temp=NULL;
for(;poczatek<=koniec;poczatek++)
   {
   if (poczatek==NULL) break;
   if (*poczatek==d) temp=poczatek;
   if (*poczatek=='(') poczatek=nawias(poczatek,koniec);
   }
return temp;
}

char *dowolne_dzialanie(char *poczatek,char *koniec)
{
for(;poczatek<=koniec;poczatek++)
   {
   if (jest_dzialaniem(*poczatek)) return(poczatek);
   if (*poczatek=='(') poczatek=nawias(poczatek,koniec);
   if (poczatek==NULL) break;
   }
return(NULL);
}


char 	*analiza(char *poczatek,char *koniec)
{
char *nastepne,*a;
//	NULL-analiza poprawna
//      !NULL-blad skladniowy, adres wskazuje na znaleziony blad

if (poczatek>koniec) return(koniec);

if (poczatek==koniec)
   if (*poczatek=='X') return(NULL);

if (*poczatek=='-')
   if (jest_dzialaniem(*(poczatek+1)))
      return(poczatek);
   else
      return analiza(poczatek+1,koniec);

if (*poczatek=='(')
   {
   nastepne=nawias(poczatek,koniec);
   if (nastepne==NULL) return(poczatek);
   if (nastepne==koniec) return(analiza(poczatek+1,koniec-1));
   }

nastepne=dowolne_dzialanie(poczatek,koniec);
if (nastepne!=NULL)
   {
   if (jest_dzialaniem(*(nastepne+1))) return(nastepne+1);
   a=analiza(poczatek,nastepne-1);
   if (a!=NULL) return a;
   a=analiza(nastepne+1,koniec);
   return(a);
   }

if (isdigit(*poczatek))
   {
   if (jest_liczba(poczatek,koniec)) return NULL;
   return poczatek;
   }

if (isalpha(*poczatek))
   {
   for(nastepne=poczatek;(nastepne<=koniec)&&(*nastepne!='(');nastepne++);
   a=analiza(nastepne,koniec);
   if (a!=NULL) return a;
   if (jest_funkcja(poczatek,nastepne-1)!=-1) return NULL;
   return poczatek;
   }
return poczatek;
}

struct tree *make_tree(char *poczatek,char *koniec)
{
char *nastepne,c;
int index;
struct tree *tmp;
union ELEMENT e;

if (*poczatek=='-')
   {
   nastepne=dzialanie(poczatek,koniec,'+');
   if (nastepne)
      {
      e.oper.znak ='-';
      e.oper.right=make_tree(poczatek+1,nastepne-1);
      e.oper.left =make_tree(nastepne+1,koniec);
      return create_node(operacja,e);
      };
   nastepne=ostatnie(poczatek+1,koniec,'-');
   if (nastepne)
      {
      e.min.wewn=make_tree(poczatek+1,nastepne-1);
      tmp=create_node(minus,e);
      e.oper.znak =*nastepne;
      e.oper.left =tmp;
      e.oper.right=make_tree(nastepne+1,koniec);
      return create_node(operacja,e);
      }
   else
      {
      e.min.wewn=make_tree(poczatek+1,koniec);
      return create_node(minus,e);
      }
   }

if (poczatek==koniec&&*poczatek=='X')
   return create_node(ix,e);

nastepne=dzialanie(poczatek,koniec,'+');
if (!nastepne) nastepne=ostatnie(poczatek,koniec,'-');

if (nastepne)
   {
   e.oper.znak =*nastepne;
   e.oper.left =make_tree(poczatek,nastepne-1);
   e.oper.right=make_tree(nastepne+1,koniec);
   return create_node(operacja,e);
   }

nastepne=dzialanie(poczatek,koniec,'*');
if (!nastepne) nastepne=dzialanie(poczatek,koniec,'/');
if (nastepne)
   {
   e.oper.znak =*nastepne;
   e.oper.left =make_tree(poczatek,nastepne-1);
   e.oper.right=make_tree(nastepne+1,koniec);
   return create_node(operacja,e);
   }


nastepne=dzialanie(poczatek,koniec,'^');
if (nastepne)
   {
   e.oper.znak ='^';
   e.oper.left =make_tree(poczatek,nastepne-1);
   e.oper.right=make_tree(nastepne+1,koniec);
   return create_node(operacja,e);
   }

if (*poczatek=='(')
   return make_tree(poczatek+1,koniec-1);

if (isdigit(*poczatek))
   {
   c=*(koniec+1);
   e.number.value=(float)atof(poczatek);
   *(koniec+1)=c;
   return create_node(liczba,e);
   }

if (isalpha(*poczatek))
   {
   for(nastepne=poczatek;*nastepne!='(';nastepne++);
   index=jest_funkcja(poczatek,nastepne-1);
   e.fun.index=index;
   e.fun.wewn=make_tree(nastepne+1,koniec-1);
   return create_node(function,e);
   }
return NULL; 		//Niepotrzebne //Aby wyeliminowac Warning
}



void polecenie(char *s)
{
char *a;
int n;

a=analiza(s,s+strlen(s)-1);
if (a)
   {
   printf("Your expression : %s\n",s);
   printf("ERROR AT        :");
   for (n=0;n<=(a-s);n++) printf(" ");
   printf("^%s\n",a+1);
   return;
   }

funkcja=make_tree(s,s+strlen(s)-1);
if (!funkcja_x(funkcja))
   {
   printf("Ans = ");
   print_number(value(funkcja,0));
   printf("\n");
   };
printf("Funkcja  : ");
inorder(funkcja,'+');printf("\n"); 	//wypisanie funkcji

pochodna=copy_node(funkcja);
pochodna=differentiate(pochodna);
pochodna=korekta(pochodna);
printf("Pochodna : ");
inorder(pochodna,'+');printf("\n");

delete_tree(funkcja);funkcja=NULL;
delete_tree(pochodna);pochodna=NULL;
}