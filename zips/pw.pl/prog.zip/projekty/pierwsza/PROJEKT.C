/*Program znajdowania najbliszej liczby pierwszej do zadanej*/
/*Wykonal: Andrzej Malec     gr. 2P14*/

#include <stdio.h>
#include <math.h>
#include <conio.h>

spr(long int);

main()
  {
  long int n,i,j,jesti=0,jestj=0,max=30000000,liczba;
  int opcja;
do
  {
  clrscr();
  printf("\nWprowadzanie liczby - 1");
  printf("\nKoniec - 2");
  scanf("%d",&opcja);

printf("\nPodaj liczbe : ");
  scanf("%ld",&n);                                /*Wprowadzanie liczby*/

  if (n<=0)
	printf("\n Liczba musi byc dodatnia.");
  else                                           /*Sprawdza czy l. jest z zakr.*/
  {
	if (n>max)
	  printf("\n Liczba jest za duza.");
	else
	 {
	  for (i=n;max;i++)
		 if (spr(i))
	{
	  jesti=1;
	  break;
	}

	  for (j=(n-1);2;j--)
		if (spr(j))
	{
	 jestj=1;
	 break;
	}

	if((i-n==n-j) && i!=j)
	  {
		printf("\nNajblizsze liczby pierwsze to: ");
		printf("%ld%c%ld\n\n",jestj==1 ? j : 0,jesti==1 ? ';':' ',jesti==1 ? i : 0);
	  }
		 else
	  {
	  if (i-n<n-j)
		  liczba=i;

	  else
		 liczba=j;
		 printf("\nNajblizsza liczba pierwsza to: ");
		 printf("%ld\n\n",(jestj==1 || jesti==1) ? liczba : 0);
	  }
	 }
  }
  }
  while(opcja!=2);
	getchar();getchar();
  return 0;
 }


spr(long int i)
 {
  long int j,nie=0;
  for (j=2;sqrt(i)>=j;j++)
	if (!(i%j))
		{
		 nie = 1;
		 break;
		}
  if (nie) return 0; else return 1;
 }