#include <stdio.h>
#include <stdlib.h>
#include <curses.h>

#define DRZWI '#'
#define SCIANA 's'
#define DUSZEK '&'
#define KULKA_SILY '.'
#define KULKA_MOCY '*'
#define PUSTE_POLE ' '
#define PACMAN_ZYWY '@'
#define PACMAN_DUCH '@' 

#define ESC 27

#define KOLOR_DRZWI COLOR_BLUE
#define KOLOR_ZYCIA COLOR_RED
#define KOLOR_SCIANY COLOR_GREEN
#define KOLOR_SILY COLOR_RED
#define KOLOR_MOCY COLOR_RED
#define KOLOR_ZYWEGO COLOR_WHITE
#define KOLOR_DUCHA COLOR_MAGENTA

#define SZYBKOSC 14
#define REKURENCJE 10000
#define XX 10
#define YY 02

char plansza[81][25],szuk_tab[81][25];
struct {int x,y,k,kier;} stworki[11];
enum boolean {FALSZ,PRAWDA} moc,jest,level_up;
int liczba_poziomow=99,liczba_duszkow,liczba_kulek_sily,szer,wys;
int licznik,punkty,poprzednie_punkty,ruchy,poziom,zycia,trudnosc=2;
char pacman,klawisz;
WINDOW *win;

int szukaj2(int *x,int *y,int *iter,int kier,int a,int b);

int czysc(void)
{
 int a,b;
 for (b=1;b<=wys;b++)
  for (a=1;a<=szer;a++)
   switch(plansza[a+XX][b+YY])
   {
    case SCIANA: szuk_tab[a+XX][b+YY]=SCIANA; break;
    default: szuk_tab[a+XX][b+YY]=PUSTE_POLE; 
   }
 szuk_tab[stworki[10].x][stworki[10].y]=pacman;
}

int czytaj_plansze(int c)
{
 int a,b;
 FILE *plik;
 liczba_kulek_sily=0;
 plik=fopen("pacman.dat","r");
 fscanf(plik,"%i\n",&liczba_poziomow);
 do
 {
  while (fgetc(plik)!='*');
  fscanf(plik,"%i\n",&a);
 }
 while (a!=c);
 fscanf(plik,"%i %i %i\n",&szer,&wys,&liczba_duszkow);
 for (b=1;b<=wys;b++)
 {
  for (a=1;a<=szer;a++)
   switch (fgetc(plik))
   {
    case '0': plansza[a+XX][b+YY]=SCIANA; szuk_tab[a+XX][b+YY]=SCIANA; break;
    case '1': plansza[a+XX][b+YY]=KULKA_SILY; liczba_kulek_sily++; szuk_tab[a+XX][b+YY]=PUSTE_POLE; break;
   }
  fscanf(plik,"\n");
 }
 fclose(plik);
 liczba_kulek_sily--;
}

int cyfr(int a)
{
 if (a>9999) return 5; 
 if (a>999) return 4; 
 if (a>99) return 3;
 if (a>9) return 2; 
 return 1;
}

int pisz(void)
{
 char t[22]="                      ";
 int a; 
 strcpy(t,"poziom: ");
 strcat(t,ecvt(poziom,cyfr(poziom),&a,&a)); 
 init_pair(20,COLOR_RED,COLOR_BLACK);
 wattrset(win,COLOR_PAIR(20));
 wmove(win,3,60);
 waddstr(win,t);  
 strcpy(t,"zycia: ");
 strcat(t,ecvt(zycia,1,&a,&a));
 init_pair(21,COLOR_GREEN,COLOR_BLACK);
 wattrset(win,COLOR_PAIR(21));
 wmove(win,4,60);
 waddstr(win,t); 
 strcpy(t,"licznik: ");
 strcat(t,ecvt(licznik,cyfr(licznik),&a,&a));
 strcat(t,"     ");
 init_pair(22,COLOR_BLUE,COLOR_BLACK);
 wattrset(win,COLOR_PAIR(22));
 wmove(win,6,60);
 waddstr(win,t); 
 strcpy(t,"ruchy: ");
 strcat(t,ecvt(ruchy,cyfr(ruchy),&a,&a)); 
 init_pair(23,COLOR_MAGENTA,COLOR_BLACK);
 wattrset(win,COLOR_PAIR(23));
 wmove(win,7,60);
 waddstr(win,t); 
 strcpy(t,"punkty: ");
 strcat(t,ecvt(punkty+poprzednie_punkty,cyfr(punkty+poprzednie_punkty),&a,&a)); 
 init_pair(24,COLOR_CYAN,COLOR_BLACK);
 wattrset(win,COLOR_PAIR(24));
 wmove(win,8,60);
 waddstr(win,t);
}

int ustaw(int x,int y,int k,char p)
{
 if (p==SCIANA) 
 {
  init_pair(k,COLOR_BLACK,k);
  wattrset(win,COLOR_PAIR(k));
  wmove(win,y,x);
  waddch(win,PUSTE_POLE);
 }
 else
 {
  init_pair(k,k,COLOR_BLACK);
  wattrset(win,COLOR_PAIR(k));
  wmove(win,y,x);
  waddch(win,p);
 }
}

int rysuj_plansze(void)
{
 int a,b;
 wclear(win);
 for (b=1+YY;b<=wys+YY;b++) for (a=1+XX;a<=szer+XX;a++)
  (plansza[a][b]==SCIANA) ? ({ustaw(a,b,KOLOR_SCIANY,SCIANA);})
                          : ({ustaw(a,b,KOLOR_SILY,plansza[a][b]);});
 wmove(win,20,60);
 waddstr(win,"Q - wyjscie");
 wrefresh(win);                              
}

int losuj_duszki(void)
{
 int a;
 time_t t;
 srand(time(&t));
 for (a=1;a<=liczba_duszkow;a++)
 {
  do
  {
   stworki[a].x=rand()%3+szer/2+XX;
   stworki[a].y=rand()%3+wys/2+YY;
  }
  while (plansza[stworki[a].x][stworki[a].y]==SCIANA);
  switch (a)
  {
   case 1: stworki[1].k=COLOR_BLUE; stworki[1].kier=rand()%4+1; break; 
   case 2: stworki[2].k=COLOR_YELLOW; stworki[2].kier=rand()%4+1; break; 
   case 3: stworki[3].k=COLOR_MAGENTA; stworki[3].kier=rand()%4+1; break;
   case 4: stworki[4].k=COLOR_CYAN; stworki[4].kier=rand()%4+1; break; 
   case 5: stworki[5].k=COLOR_RED; stworki[5].kier=rand()%4+1; break; 
   case 6: stworki[6].k=COLOR_MAGENTA; stworki[6].kier=rand()%4+1; break; 
   case 7: stworki[7].k=COLOR_YELLOW; stworki[7].kier=rand()%4+1; break; 
   case 8: stworki[8].k=COLOR_BLUE; stworki[8].kier=rand()%4+1; break; 
   case 9: stworki[9].k=COLOR_CYAN; stworki[9].kier=rand()%4+1; break; 
  }
  ustaw(stworki[a].x,stworki[a].y,stworki[a].k,DUSZEK);
 }
 wrefresh(win);
}

int po_prostej(int x,int y)
{
 int i;
 if (x==stworki[10].x) 
 {
  if (y<stworki[10].y) 
  {
   for (i=1;y+i<=stworki[10].y;++i) if (plansza[x][y+i]==SCIANA) return 0;
   return 1;
  }
  else if (y==stworki[10].y) return 0; 
  else
  {
   for (i=1;y-i>=stworki[10].y;++i) if (plansza[x][y-i]==SCIANA) return 0;   
   return 2;
  }
 }
 else
 if (y==stworki[10].y)
 {
  if (x<stworki[10].x) 
  {
   for (i=1;x+i<=stworki[10].x;++i) if (plansza[x+i][y]==SCIANA) return 0;
   return 3;
  }
  else if (x==stworki[10].x) return 0; else
  {
   for (i=1;x-i>=stworki[10].x;++i) if (plansza[x-i][y]==SCIANA) return 0;   
   return 4;
  }     
 }
 return 0;                       
}


int szukaj(int x,int y,int kier,int *iter)
{
 if (szuk_tab[x][y]==pacman) return 5;
 switch(kier)
 {
  case 4:  /* lewo */ 
    if (szukaj2(&x,&y,iter,4,-1,0)) return 4;   
    if (szukaj2(&x,&y,iter,2,0,-1)) return 2;
    if (szukaj2(&x,&y,iter,1,0,1)) return 1;
    if (szukaj2(&x,&y,iter,3,1,0)) return 3;    
    break;
  case 3:  /* prawo */
    if (szukaj2(&x,&y,iter,3,1,0)) return 3;
    if (szukaj2(&x,&y,iter,2,0,-1)) return 2;
    if (szukaj2(&x,&y,iter,1,0,1)) return 1;
    if (szukaj2(&x,&y,iter,4,-1,0)) return 4;    
    break;    
  case 2:  /* gora */
    if (szukaj2(&x,&y,iter,2,0,-1)) return 2;
    if (szukaj2(&x,&y,iter,4,-1,0)) return 4;   
    if (szukaj2(&x,&y,iter,3,1,0)) return 3;    
    if (szukaj2(&x,&y,iter,1,0,1)) return 1;
    break;    
  case 1: /* dol */
    if (szukaj2(&x,&y,iter,1,0,1)) return 1;
    if (szukaj2(&x,&y,iter,4,-1,0)) return 4;   
    if (szukaj2(&x,&y,iter,3,1,0)) return 3; 
    if (szukaj2(&x,&y,iter,2,0,-1)) return 2;       
 }
 return 0;
}

int szukaj2(int *x,int *y,int *iter,int kier,int a,int b)
{
 if (*iter>REKURENCJE) return 0; else (*iter)++;
 if ((szuk_tab[*x+a][*y+b]==PUSTE_POLE)||(szuk_tab[*x+a][*y+b]==pacman))
 {
  szuk_tab[*x][*y]='$';
//  ustaw(*x,*y,COLOR_YELLOW,'$');  /* do testowania rekurencji */
//  wgetch(win);                    /* do testowania rekurencji */  
  if (szukaj(*x+a,*y+b,kier,iter)) return 1;
  szuk_tab[*x][*y]=PUSTE_POLE;
//  ustaw(*x,*y,COLOR_YELLOW,' ');  /* do testowania rekurencji */
 }
 return 0;
}

int latajcie_duszki()
{
 int a,e,f,iter=0,kier;
 switch (trudnosc)
 {
  case 1: 
    for (a=1;a<=liczba_duszkow;a++)
    {
     switch ((rand()%4))
     {
      case 0: e=1; f=0; break;
      case 1: e=-1; f=0; break;
      case 2: e=0; f=1; break;
      case 3: e=0; f=-1;
     }      
     if ((plansza[stworki[a].x+e][stworki[a].y+f]!=SCIANA)
         &&(stworki[a].x+e>1+XX)&&(stworki[a].x+e<szer+XX)
         &&(stworki[a].y+f>1+YY)&&(stworki[a].y+f<wys+YY))
     {
      ustaw(stworki[a].x,stworki[a].y,KOLOR_SILY,plansza[stworki[a].x][stworki[a].y]);
      stworki[a].x+=e;
      stworki[a].y+=f;
      ustaw(stworki[a].x,stworki[a].y,stworki[a].k,DUSZEK);
      wrefresh(win);          
     }
    }
    break;
  case 2: 
    for (a=1;a<=liczba_duszkow;a++)
     if (!(licznik%SZYBKOSC))
     {
      if (!(rand()%4))
      {
       if (stworki[a].x>stworki[10].x) 
        if (rand()%2) {e=-1; f=0;}
        else 
        {
         e=0; 
         (stworki[a].y<stworki[10].y) ? ({f=1;}) : ({f=-1;});
        }
       else
       if (rand()%2) {e=1; f=0;}
       else 
       {
        e=0;
        (stworki[a].y<stworki[10].y) ? ({f=1;}) : ({f=-1;});
       }
      }
      else 
      switch ((rand()%4))
      {
       case 0: e=1; f=0; break;
       case 1: e=-1; f=0; break;
       case 2: e=0; f=1; break;
       case 3: e=0; f=-1; break;
      }
      if ((plansza[stworki[a].x+e][stworki[a].y+f]!=SCIANA)
          &&(stworki[a].x+e>1+XX)&&(stworki[a].x+e<szer+XX)
          &&(stworki[a].y+f>1+YY)&&(stworki[a].y+f<wys+YY))      
      {
       ustaw(stworki[a].x,stworki[a].y,KOLOR_SILY,plansza[stworki[a].x][stworki[a].y]);
       stworki[a].x+=e;
       stworki[a].y+=f;
       ustaw(stworki[a].x,stworki[a].y,stworki[a].k,DUSZEK);
       wrefresh(win);           
      }
     }
    break; 
  case 3:  
    if (!(licznik%(SZYBKOSC/2)))  
     for (a=1;a<=liczba_duszkow;a++)  
     {
      kier=po_prostej(stworki[a].x,stworki[a].y);
      if (kier) stworki[a].kier=kier;
      else
      {
       czysc();
//       rysuj_plansze();   /* do testowania rekurencji */
       stworki[a].kier=szukaj(stworki[a].x,stworki[a].y,stworki[a].kier,&iter);
      }
      switch (stworki[a].kier)
      {
       case 0: stworki[a].kier=rand()%4+1; return;
       case 1: e=0;  f=1;  break;
       case 2: e=0;  f=-1; break;
       case 3: e=1;  f=0;  break;
       case 4: e=-1; f=0;  break; 
       case 5: return;
      }
      ustaw(stworki[a].x,stworki[a].y,KOLOR_SILY,plansza[stworki[a].x][stworki[a].y]);
      stworki[a].x+=e;
      stworki[a].y+=f;
      ustaw(stworki[a].x,stworki[a].y,stworki[a].k,DUSZEK);
      wrefresh(win);     
     }  
 }
}

int pomocnicza(int x,int y)
{
 plansza[stworki[10].x][stworki[10].y]=PUSTE_POLE;
 ustaw(stworki[10].x,stworki[10].y,stworki[10].k,PUSTE_POLE);
 stworki[10].x+=x;
 stworki[10].y+=y;
 ruchy++;
 if (plansza[stworki[10].x][stworki[10].y]!=PUSTE_POLE) punkty++; 
 if (plansza[stworki[10].x][stworki[10].y]==DRZWI)
 {
  poziom++;
  level_up=PRAWDA;
  return;
 }
 if (plansza[stworki[10].x][stworki[10].y]==KULKA_MOCY)
 {
  moc=PRAWDA;
  jest=FALSZ;
  licznik=0;
  pacman=PACMAN_DUCH;
  stworki[10].k=KOLOR_DUCHA;
 }
 ustaw(stworki[10].x,stworki[10].y,stworki[10].k,pacman);
 wrefresh(win);
}

int zmykaj_pacmanie(void)
{
 switch (wgetch(win)) 
 {
  case KEY_LEFT : 
    if ((plansza[stworki[10].x-1][stworki[10].y]!=SCIANA)&&(stworki[10].x-1>0)) pomocnicza(-1,0); break;
  case KEY_RIGHT: 
    if ((plansza[stworki[10].x+1][stworki[10].y]!=SCIANA)&&(stworki[10].x+1<80)) pomocnicza(1,0); break;
  case KEY_UP   : 
    if ((plansza[stworki[10].x][stworki[10].y-1]!=SCIANA)&&(stworki[10].y-1>0)) pomocnicza(0,-1); break;
  case KEY_DOWN : 
    if ((plansza[stworki[10].x][stworki[10].y+1]!=SCIANA)&&(stworki[10].y+1<25)) pomocnicza(0,1); break;
  case 'q': case 'Q': klawisz=ESC;  
 }
}

int szansa(void)
{
 if (--zycia)
 {
  rysuj_plansze();
  losuj_duszki();
  stworki[10].x=2+XX;
  stworki[10].y=2+YY;
  stworki[10].k=KOLOR_ZYWEGO;
  ustaw(2+XX,2+YY,KOLOR_ZYWEGO,pacman);
  return PRAWDA;
 }
 else
 {
  wmove(win,17,60);
  waddstr(win,"GAME OVER");
  return FALSZ;
 }
}

int sukces(void)
{
 int b;
 wmove(win,17,60);
 waddstr(win,"SUKCES");
 do b=rand()%(wys-1)+1+YY;
 while ((plansza[szer+XX][b]==SCIANA)&&(plansza[szer-1+XX][b]==SCIANA));
 plansza[szer+XX][b]=DRZWI;
 ustaw(szer+XX,b,KOLOR_DRZWI,DRZWI);
 punkty++;
}

int pac_sila(void)
{
 int a,b;
 do
 {
  a=rand()%(szer-1)+1+XX; 
  b=rand()%(wys-1)+1+YY;
 }
 while (plansza[a][b]==SCIANA);
 plansza[a][b]=KULKA_MOCY;
 ustaw(a,b,KOLOR_MOCY,KULKA_MOCY);
 jest=PRAWDA;
 licznik=0;
}

int zlapany(void)
{
 int a;
 for (a=1;a<=liczba_duszkow;a++)
   if ((stworki[10].x==stworki[a].x)&&(stworki[10].y==stworki[a].y)) return PRAWDA;
 return FALSZ;
}

int gramy()
{
 int a,b;
 char kl;
 level_up=FALSZ;
 losuj_duszki();
 ustaw(2+XX,2+YY,stworki[10].k,pacman);
 wrefresh(win);
 do
 {
  licznik++; 
  latajcie_duszki();
  if (!(jest)) if (!(moc)) if (licznik==15000) pac_sila();
  if (moc) if (licznik==7500)
  {
   moc=FALSZ;
   pacman=PACMAN_ZYWY;
   stworki[10].k=KOLOR_ZYWEGO;
   licznik=0;
  }
  if (licznik==15001)
  {
   licznik=0;
   jest=FALSZ;
   for (b=1+YY;b<=wys+YY;b++)
   {
    for (a=1+XX;a<=szer+XX;a++)
    {
     if (plansza[a][b]==KULKA_MOCY)
     {
      plansza[a][b]=KULKA_SILY;
      ustaw(a,b,KOLOR_SILY,KULKA_SILY);
     }
    }
   }
  }
  if (!(moc)) if (zlapany()) if (!(szansa())) 
  {
   wtimeout(win,-1);
   do kl=wgetch(win);
   while ((kl!='q')&&(kl!='Q'));
   return FALSZ;
  }
  if (punkty==liczba_kulek_sily) sukces();
  zmykaj_pacmanie();
  pisz();
  usleep(200);
 }
 while ((!(level_up))&&(klawisz!=ESC)); 
 return PRAWDA;
}

int start(void)
{
 win=newwin(0,0,0,0);
 keypad(win,PRAWDA);
 punkty=licznik=klawisz=ruchy=poprzednie_punkty=0;
 poziom=1;
 zycia=3; 
 wtimeout(win,0);
 do 
 {
  moc=jest=FALSZ;
  stworki[10].x=2+XX;
  stworki[10].y=2+YY;
  stworki[10].k=KOLOR_ZYWEGO;
  szuk_tab[2+XX][2+YY]=pacman;
  poprzednie_punkty+=punkty;
  punkty=0;
  pacman=PACMAN_ZYWY;  
  czytaj_plansze(poziom);
  rysuj_plansze();
  if (!(gramy())) klawisz=ESC;
 }
 while ((poziom<=liczba_poziomow)&&(klawisz!=ESC));
 wtimeout(win,-1);
 delwin(win);
}

int menu(void)
{
 static int aktywny=1;
 int a,b,c,d; 
 win=newwin(0,0,0,0);
 keypad(win,PRAWDA);
 init_pair(1,COLOR_BLACK,COLOR_GREEN); 
 init_pair(2,COLOR_WHITE,COLOR_BLUE);
 while (1)
 {
  switch (aktywny)
  {
   case 1: a=2; b=1; c=1; d=1; break;
   case 2: a=1, b=2; c=1; d=1; break;
   case 3: a=1; b=1; c=2; d=1; break;
   case 4: a=1; b=1; c=1; d=2; break;
  }
  wattrset(win,COLOR_PAIR(a));
  wmove(win,9,32);
  waddstr(win,"   Start   ");
  wattrset(win,COLOR_PAIR(b));
  wmove(win,10,32);
  waddstr(win,"   Opcje   ");
  wattrset(win,COLOR_PAIR(c));
  wmove(win,11,32);
  waddstr(win,"   Info!   ");
  wattrset(win,COLOR_PAIR(d));
  wmove(win,12,32);
  waddstr(win,"  Wyjscie  ");
  switch (wgetch(win))
  {
   case KEY_UP   : if (aktywny>1) aktywny--; break;
   case KEY_DOWN : if (aktywny<4) aktywny++; break;
   case 's': case 'S': aktywny=1; break;
   case 'o': case 'O': aktywny=2; break; 
   case 'i': case 'I': aktywny=3; break;
   case 'w': case 'W': aktywny=4; break;
   case 10: case 32: delwin(win); return aktywny;
  }
 } 
}

int opcje(void)
{
 int aktywny;
 int a,b,c,d; 
 aktywny=trudnosc;
 win=newwin(0,0,0,0);
 keypad(win,PRAWDA);
 init_pair(1,COLOR_GREEN,COLOR_BLACK); 
 init_pair(2,COLOR_BLACK,COLOR_WHITE);
 init_pair(3,COLOR_BLUE,COLOR_BLACK);
 init_pair(4,COLOR_WHITE,COLOR_BLACK);
 while (1)
 {
  switch (aktywny)
  {
   case 1: a=2; b=1; c=1; d=1; break;
   case 2: a=1, b=2; c=1; d=1; break;
   case 3: a=1; b=1; c=2; d=1; break;
   case 4: a=1; b=1; c=1; d=2; break;
  }
  wattrset(win,COLOR_PAIR(3));
  wmove(win,7,27);
  waddstr(win,"Poziom trudnosci: ");
  wattrset(win,COLOR_PAIR(4));
  switch (trudnosc)
  {
   case 1: waddstr(win,"LATWY "); break;
   case 2: waddstr(win,"SREDNI"); break;
   case 3: waddstr(win,"TRUDNY"); break;
  }
  wattrset(win,COLOR_PAIR(a));
  wmove(win,9,32);
  waddstr(win,"   Latwy    ");
  wattrset(win,COLOR_PAIR(b));
  wmove(win,10,32);
  waddstr(win,"   Sredni   ");
  wattrset(win,COLOR_PAIR(c));
  wmove(win,11,32);
  waddstr(win,"   Trudny   ");
  wattrset(win,COLOR_PAIR(d));
  wmove(win,12,32);
  waddstr(win,"   Powrot   ");
  switch (wgetch(win))
  {
   case KEY_UP   : if (aktywny>1) aktywny--; break;
   case KEY_DOWN : if (aktywny<4) aktywny++; break;
   case 'l': case 'L': aktywny=1; break;
   case 's': case 'S': aktywny=2; break;
   case 't': case 'T': aktywny=3; break;
   case 'p': case 'P': aktywny=4; break;
   case 10: 
   case 32: if (aktywny==4) {delwin(win); return aktywny;}
            else trudnosc=aktywny; 
  }
 } 
}

int info(void)
{
 clear();
 init_pair(1,COLOR_BLUE,COLOR_BLACK);
 init_pair(2,COLOR_BLACK,COLOR_BLUE);
 init_pair(3,COLOR_RED,COLOR_BLACK);
 init_pair(4,COLOR_MAGENTA,COLOR_BLACK);
 init_pair(5,COLOR_GREEN,COLOR_BLACK);
 attrset(COLOR_PAIR(1));
 mvprintw(3,11,"Gra ");
 attrset(COLOR_PAIR(3));
 printw("PACMAN");
 attrset(COLOR_PAIR(1));
 printw(" ma na celu zademonstrowanie prostych mozliwosci");
 mvprintw(4,4,"biblioteki ");
 attrset(COLOR_PAIR(2));
 printw("<curses.h>");
 attrset(COLOR_PAIR(1));
 printw(" pozwalajacej np. wyswietlac kolorowe napisy");
 mvprintw(5,4,"lub uzywac klawiszy kierunkow.");
 
 attrset(COLOR_PAIR(4));
 mvprintw(8,11,"Opis obiektow:");
 mvprintw(9,4,"@ - PACMAN czyli TY");
 mvprintw(10,4,"& - DUSZEK czyli WROG"); 
 mvprintw(11,4,". - KULKA SILY daje punkty"); 
 mvprintw(12,4,"* - KULKA MOCY chroni"); 
 mvprintw(13,4,"# - DRZWI do nastepnej planszy"); 
 
 attrset(COLOR_PAIR(5));
 mvprintw(16,13,"Gdy licznik dojdzie do 15000 gdzies na planszy pojawia");
 mvprintw(17,6,"sie '*'. Gdy ja zjesz - zmieniasz kolor i przez nastepne 7500");
 mvprintw(18,6,"obrotow licznika duszki nic ci nie robia.");
 
 attrset(COLOR_PAIR(2));
 mvprintw(21,34,"nacisnij cos");
 getch();
}


int main(void)
{
 int wyjscie=1;
 initscr();
 curs_set(FALSZ);
 noecho();
 start_color();
 do 
  switch (menu())
  {
   case 1: start(); break;
   case 2: opcje(); break;
   case 3: info(); break;
   case 4: wyjscie=0;
  }
 while (wyjscie);
 clear();
 init_pair(1,COLOR_GREEN,COLOR_BLACK);
 init_pair(2,COLOR_RED,COLOR_BLACK);
 attrset(COLOR_PAIR(1));
 mvprintw(1,1,"Do zobaczenia w klubie ");
 attrset(COLOR_PAIR(2));
 printw("PACMAN"); 
 attrset(COLOR_PAIR(1));
 printw("'a !");
 refresh();
 endwin();
}
