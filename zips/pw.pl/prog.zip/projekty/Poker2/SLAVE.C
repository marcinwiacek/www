#include <stdio.h>
#include <termios.h>
#include <time.h>
#include <string.h>
#include "poker.h"

#define ilosc_graczy 2


int liczba_partii;
int karty[52];


/*pobiera z pliku transfer karty ktore sa w grze z pliku */
int losuj_karty_z_pliku(int karty[2][5])
{
 FILE* plik;
 int i,j;
 char tmp;
 do
 {
  do
  {
	plik=fopen("./transfer","r");
			if (plik==NULL)
		sleep(2);
  } while (plik==NULL);
  fread(&tmp,sizeof(char),1,plik);
  if (tmp!='m') fclose(plik);
 } while (tmp!='m');

 for (j=0;j<2;j++)
  for (i=0;i<5;i++)
	fread(&(karty[j][i]),sizeof(int),1,plik);
 fclose(plik);
 return 0;
}

/*zglasza zadanie wymiany kart i pobiera nowe karty z pliku*/
int wymien_przez_plik(int tab[2][5])
{
 FILE* plik;
 int i,j;
 char tmp;
 int kar[6];

 /* wypisz wszystkie karty*/
 wypisz_karty(tab[1]);
 /* zapytaj ile kart chcesz wymienic*/
 do
 {
  printf("\n Ile kart wymieniasz w tej kolejce: ");
  czyscbufor();
  scanf("%d",&(kar[0]));
 }
 while (kar[0] <0 || kar[0]>4);
 printf("\n");

 /* pytaj ktore ma wymienic*/
 for (i=1; i<=kar[0]; i++)
 {
  do
  {
	printf(" %d karta : ",i);
	czyscbufor();
	scanf("%d",&(kar[i]));
	kar[i];
  }
  while (kar[i]<0 || kar[i]>5);
 }
 sleep(2);
 tmp='s';
 do
 {
  plik=fopen("./transfer","w");
	 if (plik==NULL) sleep(1);
 } while (plik==NULL);
 fwrite(&tmp,sizeof(char),1,plik);
  for (i=0;i<6;i++)
	fwrite(&(kar[i]),sizeof(int),1,plik);
 fclose(plik);
 printf("\nKolej na uzytkownika MASTER...\n");
 do
 {
  do
  {
	plik=fopen("./transfer","r");
	 if (plik==NULL)
	  sleep(2);
  } while (plik==NULL);
  fread(&tmp,sizeof(char),1,plik);
	 if (tmp!='m')
	  sleep(2);
 } while (tmp!='m');
 for (j=0;j<2;j++)
  for (i=0;i<5;i++)
	fread(&(tab[j][i]),sizeof(int),1,plik);
 fclose(plik);
 printf("\n");
 /* wypisuje nowy uklad kart*/
 wypisz_karty(tab[1]);
 printf("\nKolej na uzytkownika MASTER...\n");

 do
 {
  plik=fopen("./transfer","w");
	if (plik==NULL)
	sleep(2);
 } while (plik==NULL);
 tmp='s';
 fwrite(&tmp,sizeof(int),1,plik);
 for (j=0;j<2;j++)
  for (i=0;i<5;i++)
	fwrite(&(tab[j][i]),sizeof(int),1,plik);
 fclose(plik);
 return 0;
}


int odczytajdane(struct dane gracze[2], int* ile)
{
 FILE* plik;
 char tmp;
 unsigned int t;

 do
 {
  do
  {
	plik=fopen("./transfer","r");
	if (plik==NULL)
	  sleep(1);
  } while (plik==NULL);
  fread(&tmp,sizeof(char),1,plik);
	if (tmp!='m') fclose(plik);
 } while (tmp!='m');
 fread(&t,sizeof(int),1,plik);
 fread(&(gracze[0]),sizeof(struct dane),1,plik);
 fread(&(gracze[1]),sizeof(struct dane),1,plik);
 fclose(plik);

 printf("liczba rozgrywanych partii %d\n",t);
 *ile=t;
 do
 {
  plik=fopen("./transfer","w");
  if (plik==NULL)
	sleep(2);
 } while (plik==NULL);
 tmp='s';
 fwrite(&tmp,sizeof(int),1,plik);
 fclose(plik);
 return 0;
}


int main()
{
 int i,best,j;
 char tmp;
 int tab[2][5];
 struct dane gracze[4];
 char text[10];

 printf("\n\n>>>>>>>> POKER  by Andrzej Malec <<<<<<<<\n\n");

 /* wykonaj petle gry liczba_partii razy*/
  printf("\nKolej na uzytkownika MASTER...\n");
 odczytajdane(gracze,&liczba_partii);
 for (i=0; i<liczba_partii; i++)
 {
  /* losuj karty dla gracza SLAVE*/
  printf("\nKolej na uzytkownika MASTER...\n");
  losuj_karty_z_pliku(tab);
  /* wymien karty*/
  wymien_przez_plik(tab);
  /* czekaj na koniec kolejki*/
  /* dopoki nie bedzie dowolnego klawisza*/
  printf(" \n\n Koniec kolejki. ");
  printf(" \n Nacisnij klawisz enter ... \n");
  czyscbufor();
  scanf("%c",&tmp);
  scanf("%c",&tmp);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  /* wyznaczanie wygranego*/
  best = kto_wygral(tab);
  /* wypisanie jego nazwiska*/
  printf(" \n Zwyciezca jest  %s .\n", gracze[best].nazwisko);
  printf("\n Jego karty : \n");
  wypisz_karty(tab[best]);
  gracze[best].punkty++;
  czyscbufor();
 }
 /* wyniki gry po liczba_partii partiach*/
	  wyswietl_wyniki(gracze);
 return 0;
}

