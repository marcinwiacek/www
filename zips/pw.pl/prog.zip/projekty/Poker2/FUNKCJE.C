#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <termios.h>
#include "poker.h"

/* nr kart to liczba  z przedzialu  0.. 51 w kolejnosci jak nizej*/
/* 0 - 2 trefl, 1 - 2 karo,....*/
extern int karty[52];      /* znacznik uzycia kart jesli 1 to dana karta jest juz uzyta*/
extern int liczba_partii;

/* funkcja czyszczaca bufor wejsciowy terminala*/
void czyscbufor(void)
{ 
 tcflush(0,TCIFLUSH);
}

/* funkcja porownujaca do qsorta*/
int porownaj(const void *a,const void *b)
{
 if (*(int*)(a)>*(int*)(b))
  return 1;
 if (*(int*)(a)==*(int*)(b))
  return 0;
 return -1;
}

/* funkcja zwracajaca  kod sekwensow i innych*/
int rozkoduj(int tab[5])
{
 int karta,i,wynik;
 int poker = 1, strit = 1,kolor = 1;
 int index = 0;
 int powtorki[4];
 /* sortowanie tablicy danych*/
 qsort(tab,5,sizeof(int),&porownaj);
 karta = tab[0];
 /* sprawdzanie czy istnieje strit lub poker*/
 for (i=1; i<5; i++)
 {
  if (tab[i]/4 != karta+1 && poker)
   poker = 0;
  if (tab[i]/4 != karta/4+1)
  {
   strit = 0;
   karta++;
   break;
  }
 }
 /* jesli poker*/
 if (poker)
 {
  wynik = 9000 + tab[4];
  return wynik;
 }
 /* jesli strit to czy duzy, czy maly*/
 if (strit)
 {
  if (tab[4]/4 == 12)
	wynik = 5000 + tab[4];
  else
	wynik = 4000 + tab[4];
  return wynik;
 }
 /* inicjacja tablicy powtorek*/
 /* tablica powtorek jest co najwyzej 3 elementowa*/
 for (i = 1; i<5; i++)
 if (tab[i-1]/4 == tab[i]/4)
 {
  powtorki[index] = tab[i];        /* zawsze karta o wiekszym kolorze*/
  index++;
 }
 /* w zaleznosci od liczby powtorek*/
 switch (index)
 {
  case 3:
			/* jesli czterzy powtorki identycznych figur to kareta*/
			if (powtorki[0]/4 == powtorki[1]/4 && powtorki[1]/4== powtorki[2]/4)
			{
			 wynik = 7000 + powtorki[0];
			 return wynik;
			}
			/* w pozostalym przypadku full*/
			wynik = 6000 + powtorki[1];
			return wynik;
  case 2:
			/* jesli obydwie powtroki identycznych figur to trojka*/
			if (powtorki[0]/4 == powtorki[1]/4)
			{
			 wynik = 3000 + powtorki[1];
			 return wynik;
			}
			/* w przeciwnym wypadku dwie pary*/
			/* jesli jedna para starszych figur to oddpowiednio zinterpretuj*/
			/* do wyniku wpisz 2000 plus najwysza karte pierwszej pary*/
			/* (pomnozona aby miala jak najwiekszy wplyw potem drugierj pary*/
			if (powtorki[0]/4 > powtorki[1]/4)
			 wynik = 2000 + 13*4*powtorki[0]/4 +4*powtorki[1]/4 + powtorki[0]%4;
			else
			 wynik = 2000 + 13*4*powtorki[1]/4 +4*powtorki[0]/4 + powtorki[1]%4;
			return wynik;
	case 1:
			/* jesli jedna powtorka to para*/
			wynik = 1000 + powtorki[0];
			return wynik;
	default:
			/* jesli brak powtorek*/
			kolor = 1;
			for (i=1; i<5; i++)
			 if (tab[i]%4 != tab[i-1]%4)
			 {
			  kolor = 0;
			  break;
			 }
			 /* jesli kolor*/
			 if (kolor)
			  wynik = 8000 + tab[i]%4;
			 else
			  wynik = tab[0];
			return wynik;
 }
}

/* funkcja wyznaczajaca zwyciezce*/
int kto_wygral(int tab[2][5])
{
 int wynik=0,tmp,i,zwroc;
 for (i = 0; i<2; i++)
 {
  tmp = rozkoduj(tab[i]);
  if (tmp>wynik)
  {
	wynik=tmp;
	zwroc=i;
  }
 }
 return zwroc;
}

/* funkcja losuje 5 kart dla gracza na masterze*/
void losuj_karty(int tab[5])
{
 int i;
 for (i =0 ; i< 5 ; i++)
  tab[i] = losuj_karte();
}

/* funkcja losuje karte ktora nie byla wylosowana*/
int losuj_karte()
{
 int karta;
 time_t t;
 srand((unsigned)time(&t));
 /* losuj liczbe z przedzialu 0..51 dopoki liczba ta*/
 /* nie bedzie numerem karty nie rozdanejdo tej pory*/
 do
  karta = rand()%52;
 while (karty[karta]==1);
 /* karta juz rozdana*/
 karty[karta]=1;
 return karta;
}

/* wydrukuj na ekranie karty gracza*/
void wypisz_karty(int tab[5])
{
 int i;
 for (i=0; i<5; i++)
 {
  printf (" %d : ",i+1);
  switch (tab[i]/4)
  {
	case 12: printf(" A ");
				break;
	case 11: printf(" K ");
				break;
	case 10: printf(" D ");
				break;
	case 9:  printf(" J ");
				break;
	default: printf(" %d ",tab[i]/4+2);
  }
  switch (tab[i]%4)
  {
	case 0:printf(" trefl ");
			 break;
	case 1:printf(" karo ");
			 break;
	case 2:printf(" kier ");
			 break;
	case 3:printf(" pik ");
  }
  printf("\n");
 }
}

/* wymien karty graczowi na masterze*/
void wymien_na_master(int tab[5])
{
 char tmp;
 int ile,ktora,i;
 wypisz_karty(tab);
 do
 {
  printf("\n Ile kart chcesz wymienic : ");
  czyscbufor();
  scanf("%d",&ile);
 }
 while (ile <0 || ile>4);
 printf("\n");
 /*ktore ma wymienic*/
 for (i=0; i<ile; i++)
 {
  do
  {
	printf(" %d karta : ",i+1);
	czyscbufor();
	scanf("%d",&ktora);
  }
  while (ktora<0 || ktora>5);
	/* losuje nowej karty*/
	tab[ktora-1] = losuj_karte();
 }
 printf("\n");
 wypisz_karty(tab);
}

/* wyswietl statystyke na koniec gry*/
void wyswietl_wyniki(struct dane gracze[2])
{
 int i,winer,punkty=0;
 printf ("\n\n\n Wyniki gry po %d rozgrywkach : \n",liczba_partii);
 for (i=0; i<2; i++)
 {
  printf("  %s : %d partii wygranych\n",gracze[i].nazwisko,gracze[i].punkty);
  if (gracze[i].punkty>punkty)
  {
	punkty = gracze[i].punkty;
	winer = i;
  }
 }
}
