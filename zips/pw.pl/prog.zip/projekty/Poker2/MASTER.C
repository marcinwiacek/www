#include <stdio.h>
#include <termios.h>
#include <time.h>
#include <string.h>
#include "poker.h"

#define ilosc_graczy 2

int liczba_partii;
int karty[52];


/*wypisuje do pliku wszystkie karty z gry*/
int wypiszdoplikukarty(int karty[2][5])
{
 FILE* plik;
 int i,j;
 char pom;
 do
 {
  plik=fopen("./transfer","w");
	 if (plik==NULL)
		sleep(4);
 } while (plik==NULL);
 pom='m';
 fwrite(&pom,sizeof(char),1,plik);
	for (j=0;j<2;j++)
	 for (i=0;i<5;i++)
	fwrite(&(karty[j][i]),sizeof(int),1,plik);
 fclose(plik);
 return 0;
}


/*odczytuje zadanie wymiany kart i wymienia je - odp do pliku*/
int wymien_przez_plik(int tab[2][5])
{
 FILE* plik;
 int i;
 char tmp;
 int kar[6];

 do
 {
  do
  {
	plik=fopen("./transfer","r");
		  sleep(2);
			 if (plik==NULL)
					sleep(2);
  } while (plik==NULL);
  fread(&tmp,sizeof(char),1,plik);
	if (tmp!='s') fclose(plik);
	 sleep(2);
 } while (tmp!='s');
 for (i=0;i<6;i++)
	fread(&(kar[i]),sizeof(int),1,plik);
 fclose(plik);
 for (i=1;i<=kar[0];i++)
  tab[1][kar[i]-1]=losuj_karte();
 wypiszdoplikukarty(tab);
 return 0;
}

int przeslij_dane(struct dane gracze[2],int ile)
{
 FILE* plik;
 unsigned int i;
 char pom,tmp;

 i=ile;
 printf("\n ***Czekam na SLAVE...***\n");
 do
 {
  plik=fopen("./transfer","w");
	 if (plik==NULL)
		sleep(2);
 } while (plik==NULL);
 pom='m';
 fwrite(&pom,sizeof(char),1,plik);
 fwrite(&ile,sizeof(int),1,plik);
 fwrite(&(gracze[0]),sizeof(struct dane),1,plik);
 fwrite(&(gracze[1]),sizeof(struct dane),1,plik);
 fclose(plik);
 do
 {
  do
  {
	plik=fopen("./transfer","r");
	 sleep(2);
		if (plik==NULL)
		  sleep(2);
  } while (plik==NULL);
  fread(&tmp,sizeof(char),1,plik);
	 if (tmp!='s') fclose(plik);
		sleep(2);
 } while (tmp!='s');
 fclose(plik);
 return 0;
}



int main()
{
 int i,best,j;
 char tmp;
 int tab[2][5];
 struct dane gracze[2];
 char text[10];
 printf("\n\n>>>>>>>> POKER by Andrzej Malec <<<<<<<<\n\n");
 do
 {
  printf(" Ile partii rozgrywamy : ");
  scanf("%d",&liczba_partii);
 } while (liczba_partii<1);

 /* podaj nazwiska graczy*/
 for (i=0;i<ilosc_graczy;i++)
 {
  printf (" Podaj nazwe %d gracza : ",i+1);
  scanf ("%s",gracze[i].nazwisko);
  gracze[i].typ = 0;
  gracze[i].punkty = 0;
 }
 przeslij_dane(gracze,liczba_partii);

 /* wykonaj petle gry liczba_partii razy*/
 for (i=0; i<liczba_partii; i++)
 {
  scanf("%c",&tmp);
  /* wyzeruj tablice zajetych kart*/
  for (j=0; j<52; j++)
  karty[j] = 0;

  /* losuj karty dla kazdego z graczy*/
  for (j=0; j<2; j++)
	losuj_karty(tab[j]);
  wypiszdoplikukarty(tab);

  /* wymien karty*/
  wymien_na_master(tab[0]);
  printf("\nKolej na uzytkownika SLAVE...\n");
  wymien_przez_plik(tab);
  /* czekaj na koniec kolejki*/
  /* dopoki nie bedzie wcisniety dowolny klawisz*/
  printf(" \n\n Koniec kolejki. ");
  printf(" \n Nacisnij klawisz enter ... \n");
  czyscbufor();
  scanf("%c",&tmp);
  scanf("%c",&tmp);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");


 /* wyznaczanie wygranego*/
 best = kto_wygral(tab);
 /* wypisanie jego nazwy*/
 printf(" \n Zwyciezca jest %s .\n", gracze[best].nazwisko);
 printf("\n Jego karty : \n");
 wypisz_karty(tab[best]);
 gracze[best].punkty++;
 czyscbufor();
} /* punktacja w grze po liczba_partii partiach*/
 wyswietl_wyniki(gracze);
 return 0;
}



