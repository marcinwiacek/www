#include"projtype.cpp"

// --- PROTOTYPY GLOWNYCH FUNKCJI PROGRAMU ---

void Start(void);                  // Inicjacja systemu
void WyswietlMenu(void);           // Menu glowne

void NowaLista(void);              // Skasowanie aktualnych danych
void Konfiguracja(void);           // Wyswietlenie konfiguracji programu
void EdycjaKonfiguracji(void);     // Edycja konfiguracji
void Dopisanie(void);              // Dopisanie nowej deklaracji
void Usuniecie(void);              // Usuniecie wskazanej deklaracji
void Zmiana(void);                 // Zmiana deklaracji lub jej czesci
void Specjalnosci(void);           // Funkcje dotyczace listy specjalnosci
void Studenci(void);               // Wyswietlenie listy studentow
void InfoPodzial(void);            // Wyswietlenie aktualnego podzialu
void Podzial(void);                // Aktualizacja podzialu na specjalnosci
void Zapis(void);                  // Zapis danych do plikow tekstowych
void Wyjscie(void);                // Wyjscie z  programu, zapis danych

void Pomoc(char*);                 // Pomoc dla uzytkownika


// --- PROTOTYPY FUNKCJI DOTYCZACYCH LISTY SPECJALNOSCI ---

void DopiszSpec(spec_class*);          // Dopisanie jedej specjalnosci
void UsunSpec();                       // Usuniecie wszystkich spec.
long IloscSpec();                      // Ilosc specjalnosci w pamieci
void ZerujSpec();                      // Zerowanie przydzialow do spec.
void WstawDoSpec(dane_class*);         // Dopisanie przydzialu do spec.
void InfoSpec(spec_class*,int,FILE*);  // Informacje o spec.
void Usun1Spec(spec_class*);           // Usuniecie jednej spec.
void WyswietlSpec();                   // Wyswietlenie identyfikatorow spec.
spec_class* CzyIstniejeSpec(char*);    // Czy istnieje spec. o podanym
				       //                   identyfikatorze


// --- PROTOTYPY FUNKCJI DOTYCZACYCH LISTY STUDENTOW ---

void DopiszStud(dane_class*);          // Dopisanie jednego studenta
void UsunStud();                       // Usuniecie wszystkich studentow
void Usun1Stud(dane_class*);           // Usuniecie jednego studenta
long IloscStud();                      // Ilosc studentow w pamieci
void InfoStud(dane_class*,int,FILE*);  // Informacje o studencie
int  WprowadzStud(FILE*,dane_class*);  // Wczytanie danych o studencie
                                       //                          z pliku
dane_class* CzyIstniejeStud(dane_class*);
                                       // Czy istnieje poday student


// --- PROTOTYPY FUNKCJI DOTYCZACYCH DRZEWA PODZIALOW ---

void UsunDrzewo(drzewo_class*);        // Usuniecie drzewa z pamieci
void DopiszDoDrzewa(drzewo_class*,drzewo_class*);
                                       // Dopisanie studenta do drzewa
void WyswietlDrzewo(drzewo_class*);    // Wyswietlenie drzewa
void PrzydzielWgDrzewa(drzewo_class*); // Przydzielenie studentow do spec.
                                       //        wedlug posortowanego drzewa

// --- PROTOTYPY FUNKCJI POMOCNICZYCH ---

void fprintS(FILE*,char*,int);   // Zapis tekstu, przesuniecie kursora
                                 //              o podana liczbe znakow
void fspaces(FILE*,char,int);    // Zapis podanej liczby jednakowych znakow
int  pytanie(char*);             // Zadanie pytania '(T/N)'
int  porownP(char*,char*);       // Porowananie tekstu ze wzorcem
void nfgets(char*,int,FILE*);    // Odpowiednik gets, usuwa znak '\n'


// --- ZMIENNE GLOBALNE ---

config_class config;             // Dane o konfiguracji programu
spec_class   *spec=NULL;         // Wskaznik na liste specjalnosci
dane_class   *dane=NULL;         // ---''--- na liste danych o studentach
drzewo_class *drzewo=NULL;       // ---''--- na korzen drzewa podzialow

char         text[256];          // Bufor dla operacji wejscia


// *********************************************
// *-------------------------------------------*
// *--------- GLOWNE FUNKCJE PROGRAMU ---------*
// *-------------------------------------------*
// *********************************************

main()
{
  Start();
  WyswietlMenu();
  return 0;
}


// -------------------------
// --- Inicjacja systemu ---
// -------------------------

void Start()
{
  FILE       *plik;
  spec_class sp;
  dane_class st;
  int i;

  puts("\n\n\n\n\n\n\n");
  puts("\t******************************************************");
  puts("\t*                                                    *");
  puts("\t*                SYSTEM PREFERENCJI                  *");
  puts("\t*       PODZIAL STUDENTOW NA GRUPY SPECJALNOSCI      *");
  puts("\t*                                                    *");
  puts("\t*----------------------------------------------------*");
  puts("\t*    Miroslaw Brudnowski, Politechnika Warszawska    *");
  puts("\t*    Wydzial Elektorniki i Technik Informacyjnych    *");
  puts("\t******************************************************");

  config.WM=0.2;
  config.WS=0.3;
  config.WE=0.5;
  config.AUTO=NIE;
  config.HELP=TAK;

  if ((plik=fopen(DANE_POSREDNIE,"rb"))!=NULL)
  {
    fread(&config,sizeof(config_class),1,plik);
    for(i=0; i<config.ilspec; i++)
    {
      fread(&sp,sizeof(spec_class),1,plik);
      DopiszSpec(&sp);
    }
    for(i=0; i<config.ilstud; i++)
    {
      fread(&st,sizeof(dane_class),1,plik);
      DopiszStud(&st);
    }
    fclose(plik);
    Pomoc("START");
  }
  else
  {
    Pomoc("START");
    EdycjaKonfiguracji();
  }

  if (config.AUTO) Podzial(); else config.wazny=NIE;


}


// -------------------
// --- Menu glowne ---
// -------------------

void WyswietlMenu(void)
{
  char zn;
  do
  {
    Pomoc("MENU");

    puts("\n\n\n OPCJE PROGRAMU:");

    puts("  K - Konfiguracja/Statystyka");
    puts("  G - Grupy specjalnosci");
    puts("  D - Dopisanie deklaracji");
    if (dane!=NULL)
    {
      puts("  N - Nowa lista");
      puts("  U - Usuniecie deklaracji");
      puts("  Z - Zmiana deklaracji");
      puts("  S - Informacje o studentach");
      puts("  I - Zapis wynikow podzialu");
    }
    if (drzewo!=NULL && config.wazny)
      puts("  P - Aktualny podzial");
    if (config.AUTO==NIE && dane!=NULL)
      puts("  A - Aktualizacja podzialu");
    puts("  W - Wyjscie z programu");

    printf("--->");
    gets(text);
    zn=text[0] & 0xDF;

    switch(zn)
    {
      case 'K': Konfiguracja(); break;
      case 'D': Dopisanie(); break;
      case 'W': Wyjscie(); break;
      case 'G': Specjalnosci(); break;

      case 'N': if (dane!=NULL) NowaLista(); break;
      case 'U': if (dane!=NULL) Usuniecie(); break;
      case 'Z': if (dane!=NULL) Zmiana(); break;
      case 'S': if (dane!=NULL) Studenci(); break;
      case 'I': if (dane!=NULL) Zapis(); break;

      case 'P': if (drzewo!=NULL) InfoPodzial(); break;

      case 'A': if (config.AUTO==NIE && dane!=NULL) Podzial(); break;
    }
  }
  while(zn!='W');
}


// ------------------------------------
// --- Skasowanie aktualnych danych ---
// ------------------------------------

void NowaLista(void)
{
  Pomoc("NOWA_LISTA");

  puts("UWAGA: Wszystkie dane zostana usuniete!!!");
  if (!pytanie("              Czy jestes pewien?")) return;
  if  (pytanie("        Czy nagrac dane na dysk?")) Zapis();

  UsunStud();                  // Usuniecie listy studentow
  UsunSpec();                  // Usuniecie listy specjalnosci
  UsunDrzewo(drzewo);          // Usuniecie drzewa podzialow
  drzewo=NULL;
  remove(DANE_POSREDNIE);      // Usuniecie pliku danych posrednich

  if  (pytanie("Czy chcesz zmienic konfiguracje?")) EdycjaKonfiguracji();
}


// ------------------------------------------
// --- Wyswietlenie konfiguracji programu ---
// ------------------------------------------

void Konfiguracja()
{
  spec_class* sp;
  dane_class* st;
  int decyz;
  long dec[3]={0,0,0};
  long zas=0,zaj=0;        // ilosc: zasobow specjalnosci i zajetych miejsc
  long ils,npr=0,npd=0;    // ilosc: studentow, nie przydzielonych, bez decyzji
  float srm=0,srs=0,sre=0; // liczniki srednich

  Pomoc("KONFIGURACJA");

  sp=spec;
  while(sp!=NULL)         // zliczanie zasobow i przydzialow
  {
    zas+=sp->zasoby;
    zaj+=sp->ilosc;
    sp=  sp->nast;
  }

  ils=IloscStud();        // ilosc wszystkich studentow
  st=dane;
  while(st!=NULL)         // zliczanie srednich, decyzji
  {
    decyz=st->decyz;
    if (decyz<0) npr++;
    if (decyz==0) npd++;
    if (decyz>0) dec[decyz-1]++;
    srm+=st->PM;
    srs+=st->PS;
    sre+=st->PE;
    st=  st->nast;
  }

  puts("\n\nINFORMACJE O USTAWIENIACH:");
  printf("  - waga sredniej maturalnej:   %1.2f\n",config.WM);
  printf("  - waga sredniej studiow:      %1.2f\n",config.WS);
  printf("  - waga sredniej z egzaminu:   %1.2f\n",config.WE);
  printf("  - automatyczna aktualizacja:  ");
  if (config.AUTO)
    puts("TAK");
  else
    puts("NIE");
  printf("  - aktywny tryb pomocy:        ");
  if (config.HELP)
    puts("TAK");
  else
    puts("NIE");

  puts("\nINFORMACJE STATYSTYCZNE:");
  printf("  - ilosc specjalnosci:       %ld\n",IloscSpec());
  printf("  - zasoby specjalnosci:      %ld\n",zas);
  printf("  - ilosc zajetych miejsc:    %ld\n",zaj);
  puts("  - ilosc studentow na liscie:");
  printf("       - wszystkich           %ld\n",ils);
  printf("       - przyjetych           %ld\n",ils-npr-npd);
  printf("       - nie przyjetych:      %ld\n",npr);
  printf("       - nie podjeto decyzji: %ld\n",npd);
  puts("  - ilosc spelnionych deklaracji:");
  printf("       - pierwszych           %ld\n",dec[0]);
  printf("       - drugich              %ld\n",dec[1]);
  printf("       - trzecich             %ld\n",dec[2]);
  if (dane!=NULL)
  {
    puts("  - srednie ocen:");
    printf("       - maturalnych          %1.2f\n",srm/ils);
    printf("       - w toku studiow       %1.2f\n",srs/ils);
    printf("       - z egzaminu           %1.2f\n",sre/ils);
  }
  if (pytanie("  Zmienic konfiguracje?"))
    EdycjaKonfiguracji();
}


// ---------------------------
// --- Edycja konfiguracji ---
// ---------------------------

void EdycjaKonfiguracji(void)
{
  float sr;
  dane_class *st;

  Pomoc("EDYCJA_KONF");

  printf("Waga sredniej maturalnej (%1.2f): ",config.WM);
  gets(text);
  if (sscanf(text,"%f",&sr)==1) config.WM=sr;

  printf("   Waga sredniej studiow (%1.2f): ",config.WS);
  gets(text);
  if (sscanf(text,"%f",&sr)==1) config.WS=sr;

  printf("Waga sredniej z egzaminu (%1.2f): ",config.WE);
  gets(text);
  if (sscanf(text,"%f",&sr)==1) config.WE=sr;

  printf("  Automatyczna aktualizacja (%c): ",'T'*(config.AUTO==TAK)+'N'*(config.AUTO==NIE));
  gets(text);
  if ((text[0] & 0xDF)=='T') config.AUTO=TAK;
  if ((text[0] & 0xDF)=='N') config.AUTO=NIE;

  printf("        Aktywny tryb pomocy (%c): ",'T'*(config.HELP==TAK)+'N'*(config.HELP==NIE));
  gets(text);
  if ((text[0] & 0xDF)=='T') config.HELP=TAK;
  if ((text[0] & 0xDF)=='N') config.HELP=NIE;

  st=dane;
  while(st!=NULL)         // aktualizacja sumy punktow
  {
    st->suma=config.WM*st->PM+config.WS*st->PS+config.WE*st->PE;
    st=st->nast;
  }
  if (config.AUTO) Podzial(); else config.wazny=NIE;

}


// ----------------------------------
// --- Dopisanie nowej deklaracji ---
// ----------------------------------

void Dopisanie(void)
{
  dane_class stud;
  FILE       *plik=NULL;

  Pomoc("DOPISANIE");

  printf("     Podaj nazwe pliku: ");
  gets(text);
  if (text[0]!='\0')
  {
    plik=fopen(text,"rt");
    if (plik==NULL)
    {
      puts("Nie odnaleziono pliku!");
      return;
    }
  }

  while(WprowadzStud(plik,&stud))
  {
    DopiszStud(&stud);
    if (plik==NULL)
      if (pytanie("Zakonczyc wprowadzanie?")) break;
  }

  if (plik!=NULL) fclose(plik);
  if (config.AUTO) Podzial();
}

// --------------------------------------
// --- Usuniecie wskazanej deklaracji ---
// --------------------------------------

void Usuniecie(void)
{
  dane_class *st,*nast;
  int        ok=NIE;

  Pomoc("USUNIECIE");

  printf("Nazwisko (pierwsze litery * - studenci nieprzydzieleni): ");
  gets(text);
  if (text[0]=='\0') return;

  st=dane;
  while(st!=NULL)
  {
    nast=st->nast;
    if(porownP(text,st->nazwisko) || (text[0]=='*' && st->decyz<0))
    {
      ok=TAK;
      InfoStud(st,0,stdout);
      if (pytanie("Usunac?")) Usun1Stud(st);
    }
    st=nast;
  }
  if (!ok)
  {
    puts("Nie odnaleziono opisanego studenta!");
    pytanie(NULL);
  }
  else
    if (config.AUTO && dane!=NULL) Podzial(); else config.wazny=NIE;
}


// ----------------------------------------
// --- Zmiana deklaracji lub jej czesci ---
// ----------------------------------------

void Zmiana(void)
{
  long  nr;
  int   ok=NIE,i;
  float fl;
  dane_class* st;
  dane_class  stud;
  char buf[64];

  Pomoc("ZMIANA");

  printf("Nazwisko (pierwsze litery, * - studenci nieprzydzieleni): ");
  gets(text);
  if (text[0]=='\0') return;

  st=dane;
  while(st!=NULL)
  {
    if(porownP(text,st->nazwisko) || (text[0]=='*' && st->decyz<0))
    {
      ok=TAK;
      InfoStud(st,0,stdout);
      if (pytanie("    Zmienic?"))
      {
        stud=(*st);
	printf("          Nazwisko: ");
        gets(buf);
        if (buf[0]!='\0') strcpy(stud.nazwisko,buf);
	printf("              Imie: ");
        gets(buf);
        if (buf[0]!='\0') strcpy(stud.imie,buf);
	printf("  Srednia z matury: ");
        gets(buf);
        if (sscanf(buf,"%f",&fl)==1) stud.PM=fl;
	printf("   Srednia studiow: ");
        gets(buf);
        if (sscanf(buf,"%f",&fl)==1) stud.PS=fl;
	printf("Srednia z egzaminu: ");
        gets(buf);
        if (sscanf(buf,"%f",&fl)==1) stud.PE=fl;

        WyswietlSpec();
        for(i=0; i<3; i++)
        {
	  printf("      Deklaracja %d: ",i+1);
	  gets(buf);
	  if (buf[0]=='\0') continue;
          buf[3]='\0';
          strcpy(stud.SPEC[i],buf);
          if (CzyIstniejeSpec(buf)==NULL)
	    puts("UWAGA: Podanej specjalnosci nie ma na liscie!");
        }
        Usun1Stud(st);
        DopiszStud(&stud);
	config.wazny=NIE;
	if (config.AUTO) Podzial();
      }
    }
    st=st->nast;
  }
  if (!ok)
  {
    puts("Nie odnaleziono opisanego studenta!");
    pytanie(NULL);
  }
}


// --------------------------------------------
// --- Funkcje dotyczace listy specjalnosci ---
// --------------------------------------------

void Specjalnosci(void)
{
  spec_class spc;
  spec_class *sp=spec;
  FILE       *plik;
  int        i=0;
  long       zas;

  Pomoc("SPECJALNOSCI");

  while(sp!=NULL)
  {
    InfoSpec(sp,i++,stdout);
    sp=sp->nast;
  }
  if (i>16) pytanie(NULL);

  puts("\n  1 - Dodanie");
  puts("  2 - Odczyt z pliku");
  puts("  3 - Usuniecie");
  puts("  4 - Usuniecie wszystkich");
  puts("  5 - Zmiana danych");
  puts("  ENTER - Bez zmian");
  printf("--->");

  gets(text);
  switch(text[0])
  {
    case '1':
      do
      {
        do
        {
	  printf("Identyfikator (3 litery): ");
          gets(text);
          if (text[0]=='\0') break;
          if ((sp=CzyIstniejeSpec(text))!=NULL)
            if (pytanie("Ta specjalnosc juz istnieje. Zmienic?"))
              Usun1Spec(sp);
            else
              text[0]='\0';
        }
        while(strlen(text)!=3);
        if (text[0]=='\0') break;
        strcpy(spc.ident,text);
	printf("Pelna nazwa specjalnosci: ");
        gets(spc.nazwa);
        do
        {
	  printf(" Ilosc dostepnych miejsc: ");
          gets(text);
        }
	while(sscanf(text,"%ld",&spc.zasoby)!=1);
	DopiszSpec(&spc);
      }
      while(pytanie("Wprowadzic opis nastepnej?")==TAK);
      break;

    case '2':
      printf("Podaj nazwe pliku z opisem specjalnosci: ");
      gets(text);
      if((plik=fopen(text,"rt"))!=NULL)
      {
        while(fscanf(plik,"%s%ld ",spc.ident,&spc.zasoby)==2)
        {
          nfgets(spc.nazwa,DL_SPNM,plik);
          if ((sp=CzyIstniejeSpec(spc.ident))!=NULL)
          {
	    printf("Specjalnosc %s juz istnieje - aktualizacja danych\n",sp->ident);
            Usun1Spec(sp);
	  }
	  DopiszSpec(&spc);
	}
	fclose(plik);
	ZerujSpec();
      }
      else
	puts("NIE ODCZYTANO!");
      break;

    case '3':
      printf("Identyfikator (3 litery): ");
      gets(text);
      if ((sp=CzyIstniejeSpec(text))!=NULL)
      {
        Usun1Spec(sp);
	puts("Usunieto...");
      }
      else
	puts("Podana specjalnosc nie istnieje!");
      break;

    case '4':
      if (pytanie("Czy jestes pewien?"))
        UsunSpec();
      break;

    case '5':
      printf("Identyfikator (3 litery): ");
      gets(text);
      if ((sp=CzyIstniejeSpec(text))!=NULL)
      {
	printf("             Stara nazwa: %s\n",sp->nazwa);
	printf("              Nowa nazwa: ");
        gets(text);
        if (text[0]!='\0') strcpy(sp->nazwa,text);
	printf("             Zasoby (%ld): ");
        gets(text);
        if (sscanf(text,"%ld",&zas)==1) sp->zasoby=zas;
      }
      else
	puts("Podana specjalnosc nie istnieje!");
      break;
    default:
      return;
  }
  if (config.AUTO) Podzial(); else config.wazny=NIE;
}


// ------------------------------------
// --- Wyswietlenie listy studentow ---
// ------------------------------------

void Studenci(void)
{
  dane_class* st=dane;
  int i=0;
  int ok=NIE;

  Pomoc("STUDENCI");

  puts("  1 - Wyszukiwanie / Lista alfabetyczna");
  puts("  2 - Lista wedlug sumy punktow");
  puts("  3 - Studenci nie przydzieleni");
  printf("--->");
  gets(text);

  switch(text[0])
  {
    case '1':
      printf("Nazwisko (pierwsze litery): ");
      gets(text);

      while(st!=NULL)
      {
        if (porownP(text,st->nazwisko))
        {
          InfoStud(st,i++,NULL);
          ok=TAK;
        }
        st=st->nast;
      }
      break;

    case '2':
      ok=TAK;
      if (drzewo==NULL || config.wazny==NIE) Podzial();
      WyswietlDrzewo(drzewo);
      break;
    case '3':
      while(st!=NULL)
      {
	if (st->decyz<0)
        {
          InfoStud(st,i++,NULL);
          ok=TAK;
        }
        st=st->nast;
      }
  }
  if (!ok)
    puts("Nie odnaleziono opisanych studentow!");
  else
    pytanie(NULL);
}


// ----------------------------------------
// --- Wyswietlenie aktualnego podzialu ---
// ----------------------------------------

void InfoPodzial(void)
{
  spec_class *sp=spec;
  dane_class *st;
  long i;

  Pomoc("INFO_PODZIAL");

  if (config.wazny==NIE)
  {
    puts("Podzial nie jest aktualny.");
    puts("Zostaly usuniete lub zmienione dane o niektorych studentach");
    pytanie(NULL);
    return;
  }

  while(sp!=NULL)
  {
    if (sp->ilosc!=0)
    {
      InfoSpec(sp,0,stdout);
      fspaces(stdout,'=',63);
      for(i=0; i < sp->ilosc; i++)
      {
        st=sp->podz[i].wsk;
        if (i==0)
          InfoStud(st,0,stdout);
        else
          InfoStud(st,i+4,stdout);
      }
      pytanie(NULL);
    }
    sp=sp->nast;
  }

}


// ---------------------------------------------
// --- Aktualizacja podzialu na specjalnosci ---
// ---------------------------------------------

void Podzial(void)
{
  long i,j;
  dane_class *s1;
  dane_class *s2;
  dane_class *smax;
  dane_class *spom;
  drzewo_class *dr;

  Pomoc("PODZIAL");

  if (config.wazny)
  {
    puts("Podzial jest aktualny!");
    return;
  }

  printf("AKTUALIZACJA PODZIALU ... ");

  ZerujSpec();
  UsunDrzewo(drzewo);
  drzewo=NULL;

  s1=dane;
  while(s1!=NULL)
  {
    dr=(drzewo_class*)malloc(sizeof(drzewo_class));
    dr->dane=s1;
    dr->suma=s1->suma;
    dr->wiekszy=NULL;
    dr->mniejszy=NULL;
    if (drzewo==NULL)
      drzewo=dr;
    else
      DopiszDoDrzewa(drzewo,dr);
    s1=s1->nast;
  }

  PrzydzielWgDrzewa(drzewo);
  config.wazny=TAK;

  puts("O.K.");
}


// -----------------------------------------
// --- Zapis danych do plikow tekstowych ---
// -----------------------------------------

void Zapis(void)
{
  spec_class *sp;
  dane_class *st;
  FILE       *plik;
  long i;

  Pomoc("ZAPIS");

  printf("       Podaj nazwe pliku (DANE O STUDENTACH): ");
  gets(text);

  if((plik=fopen(text,"wt"))==NULL)
  {
    puts("NIE ZAPISANO!!!");
  }
  else
  {
    fprintf(plik,"\n\n\t\t\t ALFABETYCZNA LISTA STUDENTOW\n\t\t\t");
    fspaces(plik,'=',32);
    st=dane;
    while(st!=NULL)
    {
      if (st==dane)
	InfoStud(st,0,plik);
      else
        InfoStud(st,1,plik);
      st=st->nast;
    }
    fclose(plik);
  }

  printf("        Podaj nazwe pliku (PODZIAL NA GRUPY): ");
  gets(text);

  if ((plik=fopen(text,"wt"))==NULL)
  {
    puts("NIE ZAPISANO !!!");
  }
  else
  {
    fprintf(plik,"\n\n\t\t WYNIKI PODZIALU STUDENTOW NA GRUPY SPECJALNOSCI\n\t\t");
    fspaces(plik,'=',49);
    fprintf(plik,"\n\n\t\t\t LISTY GRUP SPECJALNOSCI\n\t\t\t");
    fspaces(plik,'-',25);
    sp=spec;
    while(sp!=NULL)
    {
      fputs("\n\n",plik);
      InfoSpec(sp,0,plik);
      fspaces(plik,'=',63);
      for(i=0; i < sp->ilosc; i++)
      {
	st=sp->podz[i].wsk;
	if (i==0)
	  InfoStud(st,0,plik);
	else
	  InfoStud(st,1,plik);
      }
      sp=(*sp).nast;
    }
    fclose(plik);
  }

  printf("Podaj nazwe pliku (STUDENCI NIEPRZYDZIELENI): ");
  gets(text);
  if ((plik=fopen(text,"wt"))==NULL)
  {
    puts("NIE ZAPISANO!!!");
  }
  else
  {
    fprintf(plik,"\n\n\t\t WYNIKI PODZIALU STUDENTOW NA GRUPY SPECJALNOSCI\n\t\t");
    fspaces(plik,'=',49);
    fprintf(plik,"\n\n\n\t\t STUDENCI NIE ZAKWALIFIKOWANI DO ZADNEJ Z GRUP\n\t\t");
    fspaces(plik,'-',47);
    fputs("\n",plik);
    i=0;
    st=dane;
    while(st!=NULL)
    {
      if (st->decyz<0)
      {
	InfoStud(st,i,plik);
	i=1;
      }
      st=st->nast;
    }
    fclose(plik);
  }

  printf("         Podaj nazwe pliku (LISTA WEJSCIOWA): ");
  gets(text);

  if ((plik=fopen(text,"wt"))==NULL)
  {
    puts("NIE ZAPISANO!!!");
  }
  else
  {
    st=dane;
    while(st!=NULL)
    {
      fprintf(plik,"%s ",st->nazwisko);
      fprintf(plik,"%s ",st->imie);
      fprintf(plik,"%1.2f ",st->PM);
      fprintf(plik,"%1.2f ",st->PS);
      fprintf(plik,"%1.2f ",st->PE);
      fprintf(plik,"%s ",st->SPEC[0]);
      fprintf(plik,"%s ",st->SPEC[1]);
      fprintf(plik,"%s\n",st->SPEC[2]);
      st=st->nast;
    }
  }
}


// -----------------------------------------
// --- Wyjscie z  programu, zapis danych ---
// -----------------------------------------

void Wyjscie(void)
{
  dane_class *st;
  spec_class *sp;
  FILE       *plik;

  Pomoc("WYJSCIE");

  if (dane!=NULL)
    if (pytanie("Czy zapisac dane do plikow tekstowych?")) Zapis();

  if ((plik=fopen(DANE_POSREDNIE,"wb"))!=NULL)
  {
    config.ilspec=IloscSpec();
    config.ilstud=IloscStud();
    fwrite(&config,sizeof(config_class),1,plik);
    sp=spec;
    while(sp!=NULL)
    {
      fwrite(sp,sizeof(spec_class),1,plik);
      sp=sp->nast;
    }
    st=dane;
    while(st!=NULL)
    {
      fwrite(st,sizeof(dane_class),1,plik);
      st=st->nast;
    }
    fclose(plik);
  }
}


// -----------------------------
// --- Pomoc dla uzytkownika ---
// -----------------------------

void Pomoc(char* id)
{
  FILE *plik=NULL;
  int  ok=NIE;

  if (!config.HELP) return;

  if (plik==NULL)
    plik=fopen(PLIK_POMOCY,"rt");

  if (plik==NULL)
  {
    puts("\nPLIK POMOCY NIE MOZE BYC ODCZYTANY\n");
    return;
  }

  fseek(plik,0,SEEK_SET);
  while(!feof(plik))
  {
    nfgets(text,256,plik);
    if (ok==TAK && text[0]=='#') break;
    if (ok) puts(text);
    if (porownP(id,text+1)) ok=TAK;
  }
  printf("Wcisnij dowolny klawisz ");
  gets(text);
}



// ***************************************************
// *-------------------------------------------------*
// *--------- FUNKCJE TABLICY SPECJALNOSCI ----------*
// *-------------------------------------------------*
// ***************************************************


// -------------------------------------
// --- Dopisanie jednej specjalnosci ---
// -------------------------------------

void DopiszSpec(spec_class* s)
{
  spec_class *sn;
  long dl=sizeof(spec_class)+s->zasoby*sizeof(spec_podzial);

  s->nast=NULL;
  s->ilosc=0;
  ((char*)&s->ident)[3]='\0';

  sn=(spec_class*)malloc(dl);
  (*sn)=*s;
  sn->nast=spec;
  spec=sn;
  sn->podz=(spec_podzial*)(sn+1);
}


// -----------------------------------------
// --- Usuniecie wszystkich specjalnosci ---
// -----------------------------------------

void UsunSpec(void)
{
  spec_class *sp,*s1;

  sp=spec;
  while(sp!=NULL)
  {
    s1=sp;
    sp=s1->nast;
    free(s1);
  }
  spec=NULL;
}


// ------------------------------------
// --- Ilosc specjalnosci w pamieci ---
// ------------------------------------

long IloscSpec()
{
  spec_class *sp;
  int ilosc=0;

  sp=spec;
  while(sp!=NULL)
  {
    sp=sp->nast;
    ilosc++;
  }
  return ilosc;
}


// ---------------------------------------------
// --- Zerowanie przydzialow do specjalnosci ---
// ---------------------------------------------

void ZerujSpec(void)
{
  spec_class *sp;
  sp=spec;
  while(sp!=NULL)
  {
    sp->ilosc=0;
    sp=sp->nast;
  }
}


// --------------------------------------------
// --- Dopisanie przydzialu do specjalnosci ---
// --------------------------------------------

void WstawDoSpec(dane_class *s)
{
  spec_class *sp;
  long i;

  for(i=0; i<3; i++)
  {
    sp=spec;
    while(sp!=NULL)
    {
      if (strcmp(sp->ident,s->SPEC[i])==0 && sp->ilosc < sp->zasoby)
      {
        sp->podz[sp->ilosc++].wsk=s;
        s->decyz=i+1;
        return;
      }
      sp=sp->nast;
    }
  }
  s->decyz=-1;
}


// ------------------------------------
// --- Informacje o specjalnosciach ---
// ------------------------------------

void InfoSpec(spec_class* sp,int i,FILE* plik)
{
  if (i%22==0)
  {
    fputs(" IDENT      Pelna nazwa specjalnosci             ZASOBY ZAJETE\n",plik);
    fspaces(plik,'=',63);
  }
  fprintf(plik,"  ");
  fprintS(plik,(char*)&(*sp).ident,6);
  fprintS(plik,sp->nazwa,DL_SPNM);
  fprintf(plik,"%6ld ",sp->zasoby);
  fprintf(plik,"%6ld\n",sp->ilosc);
}


// -------------------------------------
// --- Usuniecie jednej specjalnosci ---
// -------------------------------------

void Usun1Spec(spec_class *wsk)
{
  spec_class *sp;
  spec_class *sn;

  if (spec==wsk)
  {
    sp=spec->nast;
    free(spec);
    spec=sp;
  }
  else
  {
    sp=spec;
    do
    {
      sn=sp->nast;
      if (sn==wsk)
      {
	sp->nast=sn->nast;
        free(sn);
        break;
      }
      sp=sn;
    }
    while(sp!=NULL);
  }
}


// -------------------------------------------------
// --- Wyswietlenie identyfikatorow specjalnosci ---
// -------------------------------------------------

void WyswietlSpec()
{
  spec_class *sp=spec;

  if (spec==NULL) return;

  printf("DOSTEPNE SPECJALNOSCI:\n");
  while(sp!=NULL)
  {
    printf("%s\t",sp->ident);
    sp=sp->nast;
  }
  puts("");
}


// ----------------------------------------------------------
// --- Czy istnieje specjalnosc o podanym identyfikatorze ---
// ----------------------------------------------------------

spec_class* CzyIstniejeSpec(char *ident)
{
  spec_class *sp=spec;

  while(sp!=NULL && strcmp(sp->ident,ident)!=0)
    sp=sp->nast;

  if (sp!=NULL) return sp; else return NULL;
}




// ************************************************
// *----------------------------------------------*
// *--------- FUNKCJE TABLICY STUDENTOW ----------*
// *----------------------------------------------*
// ************************************************


// ----------------------------------
// --- Dopisanie jednego studenta ---
// ----------------------------------

void DopiszStud(dane_class *s)
{
  dane_class *sp1,*sp2,*sn,*pom;

  s->suma=config.WM*s->PM+config.WS*s->PS+config.WE*s->PE;

  s->nast=NULL;
  s->decyz=0;

  sn=(dane_class*)malloc(sizeof(dane_class));
  (*sn)=*s;

  sp1=dane;
  if (sp1==NULL)
  {
    dane=sn;
    return;
  }

  sp2=sp1->nast;
  if(sp2==NULL)
  {
    if(strcmp(sp1->nazwisko,sn->nazwisko)>0)
    {
      dane=sn;
      sn->nast=sp1;
    }
    else
      sp1->nast=sn;
    return;
  }

  if(strcmp(sp1->nazwisko,sn->nazwisko)>0)
  {
    dane=sn;
    sn->nast=sp1;
    return;
  }

  while(sp2!=NULL)
  {
    if (strcmp(sp2->nazwisko,sn->nazwisko)>0) break;
    sp1=sp2;
    sp2=sp2->nast;
  }
  sp1->nast=sn;
  sn->nast=sp2;

}


// --------------------------------------
// --- Usuniecie wszystkich studentow ---
// --------------------------------------

void UsunStud(void)
{
  dane_class *sp,*s1;

  sp=dane;
  while(sp!=NULL)
  {
    s1=sp;
    sp=s1->nast;
    free(s1);
  }
  dane=NULL;
}


// ----------------------------------
// --- Usuniecie jednego studenta ---
// ----------------------------------

void Usun1Stud(dane_class *wsk)
{
  dane_class *sp;
  dane_class *sn;

  if (dane==wsk)
  {
    free(dane);
    dane=wsk->nast;
  }
  else
  {
    sp=dane;
    do
    {
      sn=sp->nast;
      if (sn==wsk)
      {
        sp->nast=sn->nast;
        free(sn);
        break;
      }
      sp=sn;
    }
    while(sp!=NULL);
  }
}


// ---------------------------------
// --- Ilosc studentow w pamieci ---
// ---------------------------------

long IloscStud(void)
{
  dane_class *sp;
  int ilosc=0;

  sp=dane;
  while(sp!=NULL)
  {
    sp=sp->nast;
    ilosc++;
  }
  return ilosc;
}


// ------------------------------
// --- Informacje o studencie ---
// ------------------------------

void InfoStud(dane_class* s,int i,FILE *plik)
{
  int dec;

  if (plik==NULL) plik=stdout;

  if (i%22==0)
  {
    fputs(" NAZWISKO          IMIE           PM    PS    PE   SUMA  D1   D2   D3   DECYZ\n",plik);
    fspaces(plik,'=',78);
  }
  fprintf(plik," ");
  fprintS(plik,(*s).nazwisko,DL_NAZW);
  fprintS(plik,(*s).imie,    DL_IMIE);
  fprintf(plik,"%1.2f  ",(*s).PM);
  fprintf(plik,"%1.2f  ",(*s).PS);
  fprintf(plik,"%1.2f  ",(*s).PE);
  fprintf(plik,"%1.2f  ",(*s).suma);
  fprintS(plik,(char*)&(*s).SPEC[0],5);
  fprintS(plik,(char*)&(*s).SPEC[1],5);
  fprintS(plik,(char*)&(*s).SPEC[2],4);

  dec=(*s).decyz;
  if (dec<0) fputs(" !NPR!\n",plik);
  if (dec==0) fputs("  ---\n",plik);
  if (dec>0) fprintf(plik,"  %s\n",&(*s).SPEC[dec-1]);

  if (i%22==21) pytanie(NULL);
}


// --------------------------------------------
// --- Wczytanie danych o studencie z pliku ---
// --------------------------------------------

int WprowadzStud(FILE* plik,dane_class* s)
{
  int i;
  int key=0;
  int ok=TAK;
  float pm,ps,pe;
  dane_class *st;

  if (plik==NULL)
  {
    plik=stdin;
    key=1;
  }

  if (key)
  {
    printf("              Nazwisko: ");
    gets(s->nazwisko);
  }
  else
    fscanf(plik,"%s",s->nazwisko);
  if (s->nazwisko[0]=='\0')
  {
    puts("NIE WPROWADZONO!");
    return NIE;
  }
  if (key)
  {
    printf("                  Imie: ");
    gets(s->imie);
  }
  else
    fscanf(plik,"%s",s->imie);

  if ((st=CzyIstniejeStud(s))!=NULL)
  {
    puts("Student o podanym imieniu i nazwisku jest juz w bazie danych!");
    InfoStud(st,0,NULL);
    if (key) pytanie(NULL);
    if (!pytanie(" Wprowadzic?"))
    {
      if (!key) fgets(text,256,plik);
      return NIE;
    }
  }

  if (key)
  {
    do
    {
      printf("     Srednia maturalna: ");
      gets(text);
    }
    while(sscanf(text,"%f",&pm)!=1);
    do
    {
      printf("       Srednia studiow: ");
      gets(text);
    }
    while(sscanf(text,"%f",&ps)!=1);
    do
    {
      printf("    Srednia z egzaminu: ");
      gets(text);
    }
    while(sscanf(text,"%f",&pe)!=1);
  }
  else
  {
    fscanf(plik,"%f",&pm);
    fscanf(plik,"%f",&ps);
    fscanf(plik,"%f",&pe);
  }
  s->PM=pm;
  s->PS=ps;
  s->PE=pe;
  if (key) WyswietlSpec();

  for(i=0; i<3; i++)
  {
    if (key)
    {
      do
      {
	printf("Deklaracja %d (3 znaki): ",i+1);
	gets(text);
      }
      while (strlen(text)!=3);
    }
    else
    {
      if (fscanf(plik,"%s",text)!=1)
	ok=NIE;
      else
	text[3]='\0';
    }
    strcpy(s->SPEC[i],text);
    if (key && CzyIstniejeSpec(text)==NIE)
      puts("UWAGA: Podana specjalnosc nie istnieje!");
  }

  return ok;
}


// ----------------------------------
// --- Czy istnieje poday student ---
// ----------------------------------

dane_class* CzyIstniejeStud(dane_class* stud)
{
  dane_class *st=dane;
  int        ok=NIE;

  while(st!=NULL)
  {
    if (strcmp(stud->nazwisko,st->nazwisko)==0)
      if (strcmp(stud->imie,st->imie)==0) {ok=TAK; break; }
    st=st->nast;
  }
  if (ok) return st; else return NULL;
}


// ************************************************
// *----------------------------------------------*
// *--------- FUNKCJE TABLICY STUDENTOW ----------*
// *----------------------------------------------*
// ************************************************


// ----------------------------------
// --- Usuniecie drzewa z pamieci ---
// ----------------------------------

void UsunDrzewo(drzewo_class* dr)
{
  if (dr!=NULL)
  {
    UsunDrzewo(dr->wiekszy);
    UsunDrzewo(dr->mniejszy);
    free(dr);
  }
}


// ------------------------------------
// --- Dopisanie studenta do drzewa ---
// ------------------------------------

void DopiszDoDrzewa(drzewo_class* dr,drzewo_class* st)
{
  if (st->suma >= dr->suma)
    if (dr->wiekszy==NULL)
      dr->wiekszy=st;
    else
      DopiszDoDrzewa(dr->wiekszy,st);
  else
    if (dr->mniejszy==NULL)
      dr->mniejszy=st;
    else
      DopiszDoDrzewa(dr->mniejszy,st);
}


// ---------------------------
// --- Wyswietlenie drzewa ---
// ---------------------------

void WyswietlDrzewo(drzewo_class* dr)
{
  static int i;
  if (dr==drzewo) i=0;
  if (dr->wiekszy!=NULL)
    WyswietlDrzewo(dr->wiekszy);
  InfoStud(dr->dane,i++,NULL);
  if (dr->mniejszy!=NULL)
    WyswietlDrzewo(dr->mniejszy);
}


// ------------------------------------------------------------
// --- Przydzielenie studneta do specjalnosci wedlug drzewa ---
// ------------------------------------------------------------

void PrzydzielWgDrzewa(drzewo_class* dr)
{
  if (dr->wiekszy!=NULL)
    PrzydzielWgDrzewa(dr->wiekszy);
  WstawDoSpec(dr->dane);
  if (dr->mniejszy!=NULL)
    PrzydzielWgDrzewa(dr->mniejszy);
}



// *****************************************
// *---------------------------------------*
// *--------- FUNKCJE POMOCNICZE ----------*
// *---------------------------------------*
// *****************************************


// -----------------------------------------------------------------
// --- Zapis tekstu, przesuniecie kursora o podana liczbe znakow ---
// -----------------------------------------------------------------

void fprintS(FILE* plik,char* str,int zn)
{
  for (int i=0; str[i]!='\0'; i++)
    putc(str[i],plik);
  for (; i<zn ;i++)
    putc(' ',plik);
}


// -----------------------------------------------
// --- Zapis podanej liczby jednakowych znakow ---
// -----------------------------------------------

void fspaces(FILE* plik,char zn,int il)
{
  for(; il>0; il--) putc(zn,plik);
  putc('\n',plik);
}


// -------------------------------
// --- Zadanie pytania '(T/N)' ---
// -------------------------------

int pytanie(char* txt)
{
  char znaki[64];

  if (txt!=NULL)
  {
    printf("%s (T/N):",txt);
  }
  gets(znaki);
  if (znaki[0]=='t' || znaki[0]=='T')
    return 1;
  else
    return 0;
}


// -------------------------------------
// --- Porowananie tekstu ze wzorcem ---
// -------------------------------------

int porownP(char* txt1,char* txt2)
{
  int i;

  for(i=0; txt1[i]!='\0' && (txt1[i] & 0xDF)==(txt2[i] & 0xDF); i++);
  if (txt1[i]=='\0') return 1; else return 0;
}


// -----------------------------------------
// --- Odpowiednik gets, usuwa znak '\n' ---
// -----------------------------------------

void nfgets(char *txt,int il,FILE *plik)
{
  int i;
  fgets(txt,il,plik);
  for(i=0; txt[i]!=10 && txt[i]!=12 && txt[i]!=0; i++);
  txt[i]='\0';
}

