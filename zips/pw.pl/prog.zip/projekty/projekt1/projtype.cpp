#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>

#define MAXFLOAT 1.0e6
#define DANE_CONFIG "config.txt"
#define DANE_POSREDNIE "prog_dat.dat"
#define PLIK_POMOCY "help.doc"

#define DL_NAZW 18
#define DL_IMIE 14
#define DL_SPNM 40

#define TAK 1
#define NIE 0


struct config_class // konfiguracja programu
{
  float WM;
  float WS;
  float WE;
  int   AUTO;
  int   HELP;
  int   wazny;
  long  ilspec;
  long  ilstud;
};


struct dane_class    // dane studenta
{
  dane_class* nast;
  char  nazwisko[DL_NAZW];
  char  imie[DL_IMIE];
  float PM;
  float PS;
  float PE;
  float suma;
  char  SPEC[3][4];
  int   decyz;
};

struct spec_podzial // podzial specjalnosci
{
  dane_class *wsk;      // - numer studenta
};

struct spec_class   // informacje o specjalnosci
{
  spec_class   *nast;
  spec_podzial *podz;   // - tablica podzialow
  char ident[4];        // - identyfikator
  char nazwa[DL_SPNM];  // - pelna nazwa
  long zasoby;          // - ilosc miejsc
  long ilosc;           // - ilosc miejsc zajetych
  float minsuma;        // - minmalna suma punktow
};

struct drzewo_class
{
  float         suma;
  dane_class*   dane;
  drzewo_class* wiekszy;
  drzewo_class* mniejszy;
};

