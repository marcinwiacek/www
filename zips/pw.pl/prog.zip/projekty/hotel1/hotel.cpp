#include "lista.h"
#include "hotel.h"
#include <fstream.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

#define TV 5.0			//ceny za dodatkowe wyposazenie
#define WC 5.0
#define GODZ 20.0
#define OSOBA 100.0
#define RADIO 5.0
#define TELEFON 10.0
#define PRYSZNIC 10.0


void blad ( int number, char* s = "" )
{
	char *error[] =
	{
		"Niewlasciwy plik danych",
		"Niewlasciwe wywolanie programu",
		"Nie mozna otworzyc pliku wejsciowego",
		"Nie ma takiego pokoju",
		"Nie ma takiej osoby",
		"Ten pokoj jest zajety lub zarezerwowany",
		"Nie mozna otworzyc pliku wyjsciowego"
	};

	cerr << '\n' << "BLAD!!! " << error[number] << ' ' << s << " ...\n";
	getchar();

	//exit ( 1 );
}

/* Funkcja odczytujaca kolejne linie z pliku tekstowego (wej) i wpisujaca je
 do tablcy. Funkcja pomija puste linie i linie komentarza zaczynajace sie "#" */
char *czytaj ( istream& plik )
{
	char tab[80];
	while ( 1 )
	{
		ws ( plik );
		plik.getline ( tab, 80 );
		if ( ( tab[0] == '#') || ( tab[0] == '\0') )
			continue;
		/*char *temp = tab;
		int i = 0, j = 0;
		while ( temp[i++] != '\0')
		{
			if ( isspace ( temp[i-1] ) )
				continue;
			tab[j++] = temp[i-1];
		}
		tab[j] = '\0';*/
		return tab;
	}
}


//###############################################################################



guest :: guest ( istream& plik )
{
	char tab[80];
	int i = 0;

	while ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "}" ) )
	{
		switch ( i++ )
		{
			case 0:
				imie = new char[81];
				strcpy ( imie, tab );
				break;
			case 1:
				nazwisko = new char[81];
				strcpy ( nazwisko, tab );
				break;
			case 2:
				adres = new char[81];
				strcpy ( adres, tab );
				break;
			case 3:
				int num;
				num = atol ( tab );
				num_pok = num;
				break;
			case 4:
				czas = atol ( tab );
				break;
		}
	}
}

void guest :: wykaz()
{
	cout << '\n' << imie << " " << nazwisko << "\tADRES: " << adres << '\n';
	cout << "Pokoj " << num_pok << "\tCzas pobytu [h]: " << czas << '\n';
}



//###################################################################################


room :: room ( istream& plik )
{
	char tab[80];
	int dan[9];

	strcpy ( tab, czytaj ( plik ) );
	if ( !strcmp ( tab, "}" ) )
		blad ( 1, "room" );

	char *p = tab;
	int i = 0;
	while ( *p )
		dan[i++] = strtol ( p, &p, 10 );
	dan[i] = '\0';
	wyposaz.number = dan[0];
	wyposaz.osob = dan[1];
	wyposaz.tv = dan[2];
	wyposaz.radio = dan[3];
	wyposaz.phone = dan[4];
	wyposaz.shower = dan[5];
	wyposaz.wc = dan[6];
	wyposaz.busy = dan[7];

}

void room :: wykaz()
{
	cout << wyposaz.number << "\t" << wyposaz.osob << "\t   " <<
		wyposaz.tv << '\t' << wyposaz.radio << '\t' << wyposaz.phone <<
		'\t' << wyposaz.shower << '\t' << wyposaz.wc << "    " <<
		wyposaz.busy << '\n';
}

//##################################################################################


floor :: floor ( istream& plik )
{
	char tab[80];

	licz_pok = 0;
	while ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "}" ) )
	{
		pokoje.add ( new tdowiazanie < room > ( plik ) );
		licz_pok++;

	}
}

void floor :: wykaz( int n )
{
	tdowiazanie < room > *temp;

	cout << "\nPOKOJ  LICZ_OSOB  TV  RADIO   TELEFON  PRYSZNIC    WC   BUSY\n";
	if ( n == 0 )
		for ( temp = pokoje.first; temp != NULL; temp = temp -> next )
			temp -> element.wykaz();
	else
	{
		for ( temp = pokoje.first; temp -> element.wyposaz.number != n; temp = temp -> next );
		temp -> element.wykaz();
	}



}



//###############################################################################

hotel :: hotel ( istream& plik )
{	
	char tab[80];

	licz_piet = 0;
	strcpy ( tab, "" );
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "hotel" ) )
		blad ( 0 );
	strcpy ( tab, czytaj ( plik ) );
	nazwa = new char[ strlen( tab ) + 1];
	strcpy ( nazwa, tab );

	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "{" ) )
		blad ( 0 );
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "floors" ) )
		blad ( 0 );
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "{" ) )
		blad ( 0 );
	while ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "}" ) )
	{
		if ( strcmp ( tab, "{" ) )
			blad ( 0 );
		pietra.add ( new tdowiazanie < floor > ( plik ) );
		licz_piet++;
	}
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "guests" ) )
		blad ( 0 );
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "{" ) )
		blad ( 0 );
	while ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "}" ) )
	{
		if ( strcmp ( tab, "{" ) )
			blad ( 0 );
		goscie.add ( new tdowiazanie < guest > ( plik ) );
	}
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "reservations" ) )
		blad ( 0 );
	if ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "{" ) )
		blad ( 0 );
	while ( strcmp ( strcpy ( tab, czytaj ( plik ) ), "}" ) )
	{
		if ( strcmp ( tab, "{" ) )
			blad ( 0 );
		rezer.add ( new tdowiazanie < reser > ( plik ) );
	}

}

void hotel :: wez_naz()
{
	cout << "\tHotel " << nazwa << '\n';
}

void hotel :: wez_piet ( int n )
{
	tdowiazanie < floor > *temp;
	int k = 1;
	if ( n == 0 )
	{
		cout << "Pietro\t" << "Liczba pokoi\t" << "Numery pokoi\n";
		for ( temp = pietra.first; temp != NULL; temp = temp -> next )
			cout << k++ << "\t\t" << temp -> element.licz_pok << '\t' <<
				temp -> element.pokoje.first -> element.wyposaz.number <<
				" - " <<  temp -> element.pokoje.last -> element.wyposaz.number
				<< '\n';
	}
	else
	{
		temp = pietra.first;
		for ( int j = 1; j < n; j++ )
			temp = temp -> next;
		temp -> element.wykaz ( 0 );

/*		for ( int i = 1; i < n; i++ )
			temp = temp -> next;
		cout << "Na pietrze " << n << " znajduja sie pokoje " <<
			temp -> element.pokoje.first -> element.wyposaz.number <<
			" - " <<  temp -> element.pokoje.last -> element.wyposaz.number
			<< "\n\n";
*/	}
}

void hotel :: wez_pok ( int n )
{
	tdowiazanie < floor > *temp;
	for ( temp = pietra.first; temp != NULL; temp = temp -> next )
		if ( ( temp -> element.pokoje.first -> element.wyposaz.number <= n )
		&& ( temp -> element.pokoje.last -> element.wyposaz.number >= n ) )
		{	temp -> element.wykaz ( n );
			break;
		}
	if ( temp == NULL )
		blad ( 3 );
}

void hotel :: wolne()
{
	tdowiazanie < floor > *temp1;
	tdowiazanie < room > *temp2;
	struct room :: stuff *t;

	cout << "\nPOKOJ  LICZ_OSOB  TV  RADIO   PHONE  SHOWER    WC   BUSY\n";
	for ( temp1 = pietra.first; temp1 != NULL; temp1 = temp1 -> next )
		for( temp2 = temp1 -> element.pokoje.first; temp2 != NULL; temp2 = temp2 -> next )
		{
			t = &( temp2 -> element.wyposaz );
			if (t -> busy == 0 ) 
				temp2 -> element.wykaz();
		}

}


void hotel :: wez_gos_rez ( char x )
{
	if ( x == 'g' )
	{
		tdowiazanie < guest > *temp;
		cout << '\n' << "LISTA GOSCI:";
		for ( temp = goscie.first; temp != NULL; temp = temp -> next )
			temp -> element.wykaz();
	}
	else if ( x == 'r' )
			{
				tdowiazanie < reser > *temp;
				cout << '\n' << "LISTA REZERWACJI:";
				for ( temp = rezer.first; temp != NULL; temp = temp -> next )
					temp -> element.wykaz();
			}
}

//#############	   REZERWACJA      ######################
void hotel :: rez_add()
{
	/*cout << "Podaj nastepujace dane:\n" << "Imie\n" << "Nazwisko\n" <<
		"Adres\n" << "Numer pokoju\n" << "Czas pobytu\n" << "Zakoncz znakiem '}'\n\n";
	rezer.add ( new tdowiazanie < reser > ( cin ) );*/

	char wait, *i, *n, *a;
	int l = 0, num, czas, out = 0;

	cout << "\nPodaj imie: ";
	i = new char[20];
	cin >> i;
	cout << "\nPodaj nazwisko: ";
	n = new char[20];
	cin >> n;
	cout << "\nPodaj adres: ";
	a = new char[40];
	cin >> a;
	cout << "\nPodaj numer pokoju: ";
	cin >> num;
	cout << "\nPodaj czas pobytu: ";
	cin >> czas;

	tdowiazanie < floor > *temp1;
	tdowiazanie < room > *temp2;
	struct room :: stuff *t;
	for ( temp1 = pietra.first; temp1 != NULL; temp1 = temp1 -> next )
		for( temp2 = temp1 -> element.pokoje.first; temp2 != NULL; temp2 = temp2 -> next )
		{
			t = &( temp2 -> element.wyposaz );
			if (t -> number == num) 
				if( t -> busy == 1)
				{	
					cout << "\nPokoj jest juz zajety lub zarezerwowany\n";
					out = 1;
					getchar();
					//cin >> wait;
					break;
				}
				else
				{	
					t -> busy = 1;
					rezer.add ( new tdowiazanie < reser > ());
					tdowiazanie < reser > *temp3;
					for ( temp3 = rezer.first; temp3 != NULL; temp3 = temp3 -> next )
						if ( temp3 -> element.num_pok == -1 )
						{	
							class reser *t = &( temp3->element );
							t->imie = new char[81];
							strcpy ( t->imie, i );
							t->nazwisko = new char[81];
							strcpy ( t->nazwisko, n );
							t->adres = new char[81];
							strcpy ( t->adres, a );
							t->num_pok = num;
							t->czas = czas;
						}
					out = 1;
					break;
				}
			if ( out ==1 )
				break;
		}
	if ( out == 0 )
	{
		cout << "\nNie ma takiego pokoju\n";
		getchar();
		//cin >> wait;
	}
}

//######################        ODWOLANIE   REZERWACJI      ##################
void hotel :: rez_rem()
{
	char *i, *n;
	int l = 0;

	cout << "\nPodaj imie: ";
	i = new char[20];
	cin >> i;
	cout << "\nPodaj nazwisko: ";
	n = new char[20];
	cin >> n;
	//cout << "\nPodaj adres: ";
	//a = new char[40];
	//cin >> a;

	tdowiazanie < reser > *temp;
	for ( temp = rezer.first; temp != NULL; temp = temp -> next, l++ )
		if ( !strcmp ( temp -> element.imie, i )
		&& !strcmp ( temp -> element.nazwisko, n ) )
		//&& !strcmp ( temp -> element.adres, a ) )
		{
			int num = temp -> element.num_pok;
			tdowiazanie < floor > *temp1;
			tdowiazanie < room > *temp2;
			struct room :: stuff *t;
			for ( temp1 = pietra.first; temp1 != NULL; temp1 = temp1 -> next )
				for( temp2 = temp1 -> element.pokoje.first; temp2 != NULL; temp2 = temp2 -> next )
				{
					t = &( temp2 -> element.wyposaz );
					if ( t -> number == num )
						t -> busy = 0;
				}
			rezer.remove ( l );
			break;
		}
	if ( temp == NULL )
		blad ( 4 );
}

//#############        REJESTRACJA       #########################
void hotel :: rejestr()
{
	/*cout << "Podaj nastepujace dane:\n" << "Imie\n" << "Nazwisko\n" <<
		"Adres\n" << "Numer pokoju\n" << "Czas pobytu\n" << "Zakoncz znakiem '}'\n\n";
	goscie.add ( new tdowiazanie < guest > ( cin ) );*/

	char wait, *i, *n, *a;
	int l = 0, num, czas, out = 0;

	cout << "\nPodaj imie: ";
	i = new char[20];
	cin >> i;
	cout << "\nPodaj nazwisko: ";
	n = new char[20];
	cin >> n;
	cout << "\nPodaj adres: ";
	a = new char[40];
	cin >> a;
	cout << "\nPodaj numer pokoju: ";
	cin >> num;
	cout << "\nPodaj czas pobytu: ";
	cin >> czas;

	tdowiazanie < floor > *temp1;
	tdowiazanie < room > *temp2;
	struct room :: stuff *t;
	for ( temp1 = pietra.first; temp1 != NULL; temp1 = temp1 -> next )
		for( temp2 = temp1 -> element.pokoje.first; temp2 != NULL; temp2 = temp2 -> next )
		{
			t = &( temp2 -> element.wyposaz );
			if (t -> number == num) 
				if( t -> busy == 1)
				{	
					cout << "\nPokoj jest juz zajety lub zarezerwowany\n";
					out = 1;
					getchar();
					//cin >> wait;
					break;
				}
				else
				{	
					t -> busy = 1;
					goscie.add ( new tdowiazanie < guest > ());
					tdowiazanie < guest > *temp3;
					for ( temp3 = goscie.first; temp3 != NULL; temp3 = temp3 -> next )
						if ( temp3 -> element.num_pok == -1 )
						{	
							class guest *t = &( temp3->element );
							t->imie = new char[81];
							strcpy ( t->imie, i );
							t->nazwisko = new char[81];
							strcpy ( t->nazwisko, n );
							t->adres = new char[81];
							strcpy ( t->adres, a );
							t->num_pok = num;
							t->czas = czas;
						}
					out = 1;
					break;
				}
			if ( out ==1 )
				break;
		}
	if ( out == 0 )
	{
		cout << "\nNie ma takiego pokoju\n";
		getchar();
		//cin >> wait;
	}
}

//#######################     WYKWATEROWANIE         ###################
void hotel :: wykwat()
{
	char *i, *n;
	int l = 0;

	cout << "\nPodaj imie: ";
	i = new char[20];
	cin >> i;
	cout << "\nPodaj nazwisko: ";
	n = new char[20];
	cin >> n;
	//cout << "\nPodaj adres: ";
	//a = new char[40];
	//cin >> a;

	tdowiazanie < guest > *temp;
	for ( temp = goscie.first; temp != NULL; temp = temp -> next, l++ )
		if ( !strcmp ( temp -> element.imie, i )
		&& !strcmp ( temp -> element.nazwisko, n ) )
		//&& !strcmp ( temp -> element.adres, a ) )
		{
			int num = temp -> element.num_pok;
			tdowiazanie < floor > *temp1;
			tdowiazanie < room > *temp2;
			struct room :: stuff *t;
			for ( temp1 = pietra.first; temp1 != NULL; temp1 = temp1 -> next )
				for( temp2 = temp1 -> element.pokoje.first; temp2 != NULL; temp2 = temp2 -> next )
				{
					t = &( temp2 -> element.wyposaz );
					if ( t -> number == num )
						t -> busy = 0;
				}
			double rach;
			rach = OSOBA*t->osob+TV*t->tv+RADIO*t->radio+TELEFON*t->phone+
				PRYSZNIC*t->shower+WC*t->wc;
			cout << "\nRachunek wynosi " << rach << " zlotych\n";
			goscie.remove ( l );
			break;
		}
	if ( temp == NULL )
		blad ( 4 );
}

//##################################
//###  Zapis danych do pliku     ###
//##################################
void hotel :: koniec()
{
	ofstream plik ( "dane1.txt" );
	if ( !plik )
		blad ( 6 );

	plik << "hotel\n" << nazwa << '\n' << "{\n" << "floors\n" << "{\n";
	tdowiazanie < floor > *temp;
	for ( temp = pietra.first; temp != NULL; temp = temp -> next )
	{
		plik << "{\n" << "%\n";
		tdowiazanie < room > *temp1 = ( temp -> element.pokoje.first );
		while ( temp1 != NULL )
		{
			plik << temp1 -> element.wyposaz.number << ' ';
			plik << temp1 -> element.wyposaz.osob << ' ';
			plik << temp1 -> element.wyposaz.tv << ' ';
			plik << temp1 -> element.wyposaz.radio << ' ';
			plik << temp1 -> element.wyposaz.phone << ' ';
			plik << temp1 -> element.wyposaz.shower << ' ';
			plik << temp1 -> element.wyposaz.wc << ' ';
			plik << temp1 -> element.wyposaz.busy << '\n';
			if ( temp1 -> next != NULL )
				plik << "%\n";
			temp1 = temp1 -> next;
		}
		plik << "}\n";
	}
	plik << "}\n";

	plik << "guests\n" << "{\n";
	tdowiazanie < guest > *tmp;
	for ( tmp = goscie.first; tmp != NULL; tmp = tmp -> next )
	{
		plik << "{\n";
		plik << tmp -> element.imie << '\n';
		plik << tmp -> element.nazwisko << '\n';
		plik << tmp -> element.adres << '\n';
		plik << tmp -> element.num_pok << '\n';
		plik << tmp -> element.czas << '\n';
		plik << "}\n";
	}
	plik << "}\n";

	plik << "reservations\n" << "{\n";
	tdowiazanie < reser > *tmp1;
	for ( tmp1 = rezer.first; tmp1 != NULL; tmp1 = tmp1 -> next )
	{
		plik << "{\n";
		plik << tmp1 -> element.imie << '\n';
		plik << tmp1 -> element.nazwisko << '\n';
		plik << tmp1 -> element.adres << '\n';
		plik << tmp1 -> element.num_pok << '\n';
		plik << tmp1 -> element.czas  << '\n';
		plik << "}\n";
	}
	plik << "}\n";

	plik << "}\n";
	plik.close();
}

hotel :: ~hotel()
{
	delete nazwa;
}

