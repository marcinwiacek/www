#ifndef LISTA_H
#define LISTA_H
#include <fstream.h>


template < class T >
class tdowiazanie
{
public:
	tdowiazanie < T >* next;
	T element;

	tdowiazanie () : element () { next = NULL; };
	tdowiazanie ( istream& plik ) : element ( plik )
	{ next = NULL; };
};



template < class T >
class tlista
{
public:
	tdowiazanie < T > *first;
	tdowiazanie < T > *last;

	tlista ( void ) { first = last = NULL; };
	void add ( tdowiazanie < T >* );
	void remove ( int );
	~tlista();
};

template < class T >
void tlista < T > :: add ( tdowiazanie < T >* element )
{
	if ( last != NULL )
		last -> next = element;
	else
		first = element;

	last = element;
}


template < class T >
void tlista < T > :: remove ( int lp )
{
	if ( lp == 0 )
	{
		tdowiazanie < T > *temp = first;
		first = temp -> next;
		delete temp;
	}
	else
	{
		tdowiazanie < T > *poprz = first, *aktu;
		for ( int i = 0; i < lp-1; i++ )
			poprz = poprz -> next;
		aktu = poprz->next;
		poprz -> next = aktu -> next;
		delete aktu;
	}
};

template < class T >
tlista < T > :: ~tlista ()
{
	tdowiazanie < T > *temp;

	for ( temp = first; temp != NULL; temp = first )
	{
		first = temp -> next;
		delete temp;
	}
}

#endif
