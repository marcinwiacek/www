#include "hotel.h"
#include "lista.h"
#include <stdlib.h>

int main( int argc, char* argv[] )
{
	char *menu[] =
	{
		"  MENU:",
		"1. Lista gosci.",
		"2. Lista rezerwacji.",
		"3. Rejestracja gosci.",
		"4. Wykwaterowanie.",
		"5. Rezerwacja pokoju.",
		"6. Odwolanie rezerwacji pokoju.",
		"7. Informacja o hotelu.",
		"8. Informacja o wolnych pokojach.",
		"0. Wyjscie z programu.",
		"",
		"Wybierz operacje: "
	};
	int a;
	char wybor, stop, esc = '1';
	char *d = "\nPress 'Enter' to continue...\n";
	
	if ( (argc != 1) && (argc != 2) )
	{
		cout << "\nBLAD!!! Niewlasciwe wywolanie programu.\n";
		exit ( 1 );
	}
	ifstream plik ( ( argc > 1 ) ? argv[1] : "dane.txt" );

	hotel nowy ( plik );
	plik.close();

	while ( 1 )
	{
		esc = '1';
		system ( "clear" );
		for ( int i = 0; i < 12; i++ )
			cout << menu[i] << '\n';
		cin >> wybor;
		switch ( wybor )
		{
			case '0':
				nowy.koniec();
				system ( "clear" );
				cout << "Dobranoc\n";
				exit ( 1 );
			case '1':
				nowy.wez_gos_rez ( 'g' );
				cout << d;
				getchar();getchar();
				//cin >> stop;
				break;
			case '2':
				nowy.wez_gos_rez ( 'r' );
				cout << d;
				getchar();getchar();
				//cin >> stop;
				break;
			case '3':
				nowy.rejestr();
				break;
			case '4':
				nowy.wykwat();
				cout << d;
				getchar();getchar();
				//cin >> stop;
				break;
			case '5':
				nowy.rez_add();
				break;
			case '6':
				nowy.rez_rem();
				break;
			case '7':
				while ( esc )
				{
					system ( "clear" );
					nowy.wez_naz();
					nowy.wez_piet();
					cout << "Podaj numer pietra [ 0 - wyjscie ]: ";
					cin >> a;
					if ( a == 0 )
						esc = '\0';
					else if ( a < nowy.licz_piet + 1 )
					{
						system ( "clear" );
						nowy.wez_piet ( a );
						cout << d;
						getchar();
						//cin >> stop;
					}	
				};
				break;
			case '8':
				//cout << "Podaj numer pokoju: ";
				//cin >> a;
				//nowy.wez_pok ( a );
				nowy.wolne();
				cout << d;
				getchar();getchar();
				//cin >> stop;
				break;
		}
	}
	return 0;
}
