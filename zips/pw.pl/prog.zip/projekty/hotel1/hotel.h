#ifndef HOTEL_H
#define HOTEL_H
#include "lista.h"
#include <fstream.h>


class wej_wyj
{
public:
	void blad ( int, char* );
	char *czytaj ( istream& );
};


class guest
{
	char *imie;
	char *nazwisko;
	char *adres;
	int num_pok;
	int czas;

public:
	guest (){ num_pok = -1; };
	guest ( istream& );
	void wykaz();
	friend class floor;
	friend class hotel;
};


class reser : public guest
{
public:
	reser() : guest(){};
	reser ( istream& plik ) : guest ( plik ){};
};


class room
{
	struct stuff
	{
		unsigned int number 	:16;
		unsigned int osob 	: 3;
		unsigned int tv		: 1;
		unsigned int radio	: 1;
		unsigned int phone	: 1;
		unsigned int shower	: 1;
		unsigned int wc		: 1;
		unsigned int busy	: 1;
	} wyposaz;
public:
	room() {};
	room ( istream& );
	void wykaz();
	friend class floor;
	friend class hotel;
};


class floor
{
	int licz_pok;
	tlista < room > pokoje;

	public:
	floor(){};
	floor ( istream& );
	void wykaz( int );
	friend class hotel;
};


class hotel
{
	char* nazwa;
	tlista < floor > pietra;
	tlista < guest > goscie;
	tlista < reser > rezer;

	public:
	int licz_piet;
	hotel(){};
	hotel ( istream& );
	void wez_naz();
	void wez_piet ( int  = 0 );
	void wez_pok ( int );
	void wez_gos_rez ( char );
	void rez_add();
	void rez_rem();
	void rejestr();
	void wykwat();
	void koniec();
	void wolne();
	~hotel();
	friend class tlista <floor>;
	friend class tlista <guest>;
	friend class tlista <reser>;
};


#endif
