#include <stdio.h>
#define LENGTH 10;

long int file_size(FILE *plik);
int get_line(char *poczatek,char *gdzie);

char *zrodlo,*cel;
char nazwy[150][10];
unsigned offsety[150];

void main(void)
{
FILE *plik;
long int index=0;
long int rozmiar;
int ile=0,dlug;
char linia[1000],*adres;
int cel_index=0,ostatni;


plik=fopen("help.txt","rb");
if (plik==NULL) 
   {
   printf("Nie moge znalezc pliku \"help.txt\"\n");
   exit(1);
   }
rozmiar=file_size(plik);
zrodlo=(char *)malloc(rozmiar);
cel   =(char *)malloc(rozmiar);
if (zrodlo==NULL||cel==NULL)
   {
   printf("Brak pamieci do realizacji zadania\n");
   exit(1);
   }
fread(zrodlo,rozmiar,1,plik);
fclose(plik);

while(index<=rozmiar)
{
index+=get_line(zrodlo+index,linia);
adres=strstr(linia,"_HELP_");
if (adres!=NULL) 
   {
   adres+=6;
   strcpy(nazwy[ile],adres);
   dlug=strlen(adres)-2;
   nazwy[ile][dlug]=0;
   offsety[ile]=cel_index;
   ile++;
   }
else
   {
   strcpy(cel+(int)cel_index,linia);
   ostatni=cel_index;
   cel_index+=strlen(linia);
   }
}

plik=fopen("help.dat","wb");
fwrite(&ile,sizeof(int),1,plik);
for (dlug=0;dlug<ile;dlug++)
{
fwrite(&nazwy[dlug],sizeof(nazwy[0]),1,plik);
fwrite(&offsety[dlug],sizeof(offsety[0]),1,plik);
}
fwrite(cel,sizeof(char),(int)ostatni,plik);
fclose(plik);
free(zrodlo);
free(cel);
printf("Operacja zakonczona sukcesem\n");
}

long int file_size(FILE *plik)
{
long int rozmiar;
fseek(plik,0,2);
rozmiar=ftell(plik);
fseek(plik,0,0);
return(rozmiar);
}

int get_line(char *poczatek,char *gdzie)
{
char znak;
int licznik=0;

do
  {
  znak=*(poczatek+licznik);
  *(gdzie+licznik)=znak;
  licznik++;
  }
while(znak!=10);
if (*(poczatek+licznik)==13) {*(gdzie+licznik)=13;}
*(gdzie+licznik)=0;
return(licznik);
}