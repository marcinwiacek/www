#include <stdio.h>
#include <alloc.h>
#include <mem.h>
#include <math.h>
#include <stdlib.h>
#include "funkcje.c"
#include "fun1.c"
#include "wartosc.c"
#include "polec.c"


void main(void)
{
LINIA linia;

printf("\nAby uzyskac informacje o programie wpisz : \"help demo\" lub \"help\" \n");
printf("\n\n\n---------------------------------COMPLEX---------------------------------\n");
printf("-------------------------Kalkulator liczb zespolonych--------------------\n\n\n");

prepare_help();
prepare_stale();


do
{
printf(">");
gets(linia);
strupr(linia);
lewe_prawe(linia,linia+strlen(linia)-1);
if (!strlen(linia)) continue;
if (!strcmp(linia,"QUIT")||!strcmp(linia,"EXIT")||!strcmp(linia,"BYE")) break;
wiersz_polecen(linia);
}
while(TRUE);
printf("God bye!\n");
}