LICZBA     wartosc              (char *poczatek,char *koniec);
void       wyswietl  		(LICZBA liczba);
//void       strupr    		(char *ciag);
void       usun_spacje          (char linia[]);

char      *jego_nawias          (char *poczatek,char *koniec);
char      *nastepne_dzialanie   (char *poczatek,char *koniec);
char      *jego_dzialanie       (char *poczatek,char *koniec,char dzialanie);
char      *nawias               (char *poczatek,char *koniec);

int       jest_stala            (char *poczatek,char *koniec); 
int       jest_funkcja          (char *poczatek,char *koniec);
int       jest_nazwa_funkcji    (char *poczatek,char *koniec);  
int       jest_zmienna          (char *poczatek,char *koniec);
char      jest_liczba           (char *poczatek,char *koniec);

LICZBA    wartosc_stalej        (int index); 
LICZBA    wartosc_zmiennej      (int index);   
LICZBA    wartosc_liczby        (char *poczatek,char *koniec); 
LICZBA    wartosc_funkcji       (char *poczatek,char *koniec,int index);  
void      prepare_stale         (void);
int       analiza               (char *poczatek,char *koniec); 
int       utworz_zmienna        (char *poczatek,char *koniec); 
void      wyswietl_zmienna      (int index);
unsigned long int  CORELEFT              (void);
void prepare_help(void);
void help(char *poczatek,char *koniec); 
void lewe_prawe(char *poczatek,char *koniec); 
int  jest_help (char *nazwa);
void wyswietl_pomoc(int index);
long int file_size(FILE *plik);

void       wyswietl  (LICZBA liczba)
{
if (!(((liczba.rez*20000)>=1)||((liczba.rez*20000)<=-1))) liczba.rez=0;
printf("       ans = %3.4f",liczba.rez);
if (((liczba.imz*20000)>=1)||((liczba.imz*20000)<=-1))
   {
   printf("%+3.4fj", liczba.imz);
   }
printf("\n");
}

//void       strupr    (char *ciag)
//{
//char *licznik;
//for (licznik=ciag;licznik<ciag+strlen(ciag);licznik++)
//    if (*licznik>='a'&&*licznik<='z') *licznik+='A'-'a';
//}

char      *nawias       (char *poczatek,char *koniec)
{
char *licznik;
for (licznik=poczatek;licznik<=koniec;licznik++)
    if (*licznik=='(') return(licznik);
return(NULL);
}

char       *jego_nawias   (char *poczatek,char *koniec)
{
char *licznik;
int otwierajace=0,zamykajace=0,tyle_samo=FALSE;
for (licznik=poczatek;licznik<=koniec;licznik++)
    {
    if (*licznik=='(') otwierajace++;
    if (*licznik==')') zamykajace++;
    if (otwierajace==zamykajace)
       {
       tyle_samo=TRUE;
       break;
       }
    }
    if (tyle_samo) return(licznik); 
    else return(NULL);
}

void usun_spacje(char linia[])
{
unsigned a,b=0;
for (a=0;a<strlen(linia);a++)
if (!isspace(linia[a])) linia[b++]=linia[a];
linia[b]=0;
}

char      *nastepne_dzialanie   (char *poczatek,char *koniec)
{
char *licznik;

licznik=poczatek;
while (licznik<=koniec)
      {
      if (*licznik=='(')
	 licznik=jego_nawias(licznik,koniec);
      if (licznik<koniec)
	 {
	 if (*licznik=='^'||*licznik=='/'||*licznik=='*'||
	     *licznik=='+'||*licznik=='-')
	    return(licznik);
	 }
      licznik++;
      }
return(NULL);
}

char      *jego_dzialanie       (char *poczatek,char *koniec,char dzialanie)
{
char *licznik;

licznik=poczatek;
while (licznik!=koniec)
      {
      licznik=nastepne_dzialanie(licznik,koniec);
      if (licznik==NULL) return (NULL);
      switch (dzialanie)
	     {
	     case '+':case '-':case 0:
	     if (*licznik=='+'||*licznik=='-') return(licznik);
	     licznik++;
	     break;
	     case '/':case '*':
	     if (*licznik=='*'||*licznik=='/') return(licznik);
	     licznik++;
	     break;
	     case '^':
	     if (*licznik=='^') return(licznik);
	     licznik++;
	     break;
	     }
      }
return(NULL);
}

int      jest_stala            (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int ile_funkcji,licz;

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
ile_funkcji=sizeof(stale)/sizeof(stale[0]);
for (licz=0;licz<ile_funkcji;licz++)
    if (!strcmp(nazwa,stale[licz].nazwa)) return(licz+1);
return(0);
}

int      jest_funkcja          (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik,*kon1;
int ile_funkcji,licz;

kon1=nawias(poczatek,koniec);
if (koniec!=jego_nawias(kon1,koniec)) return (0);
for (licznik=poczatek;licznik<kon1;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
ile_funkcji=sizeof(funkcje)/sizeof(funkcje[0]);
for (licz=0;licz<ile_funkcji;licz++)
    if (!strcmp(nazwa,funkcje[licz].nazwa)) return(licz+1);
return(0);
}

char      jest_liczba           (char *poczatek,char *koniec)
{
char *licznik,kropki=0;
if (poczatek==koniec&&*poczatek=='.') return(FALSE);
for (licznik=poczatek;licznik<=koniec;licznik++)
    {
    if (*licznik=='.') kropki++;
    else if (!isdigit(*licznik)) return(FALSE);
    }
if (kropki>1) return(FALSE);
return(TRUE);
}

int      jest_zmienna          (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int licz;

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
for (licz=0;licz<ilosc_zmiennych;licz++)
    if (!strcmp(nazwa,zmienne[licz].nazwa)) return(licz+1);
return(0);
}

LICZBA    wartosc_stalej        (int index)
{
return(stale[index].wartosc);
}

LICZBA    wartosc_zmiennej      (int index)
{
return(zmienne[index].wartosc);
}

LICZBA    wartosc_liczby        (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
LICZBA liczba;

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
liczba.rez=atof(nazwa);
liczba.imz=0;
return(liczba);
}

LICZBA    wartosc_funkcji       (char *poczatek,char *koniec,int index)
{
LICZBA liczba;
poczatek=nawias(poczatek,koniec);
liczba=funkcje[index].adres_funkcji(wartosc(poczatek,koniec));
return(liczba);
}

void      prepare_stale         (void)
{
stale[1].wartosc.rez=exp(1);
stale[2].wartosc.rez=acos(-1);
}

int       utworz_zmienna        (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int index;
LICZBA liczba={0,0};

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
   zmienne=(ZMIENNA *)realloc(zmienne,sizeof(ZMIENNA)*(ilosc_zmiennych+1));
   if (zmienne==NULL) return(0);
   
index=ilosc_zmiennych;
strcpy(zmienne[index].nazwa,nazwa);
zmienne[index].wartosc=liczba;
ilosc_zmiennych++;
return(ilosc_zmiennych);
}

void      wyswietl_zmienna      (int index)
{
LICZBA liczba;
liczba=zmienne[index].wartosc;
if (!(((liczba.rez*20000)>=1)||((liczba.rez*20000)<=-1))) liczba.rez=0;
printf("%10s = %3.4f",zmienne[index].nazwa,liczba.rez);
if (((liczba.imz*20000)>=1)||((liczba.imz*20000)<=-1))
   {
   printf("%+3.4fj", liczba.imz);
   }
printf("\n");
}

unsigned long int  CORELEFT              (void)
{
char *adres;
unsigned long int ile=0,licz=200000;
do
{
adres=malloc(ile+licz);
if (adres==NULL) licz/=2;
      ile+=licz;
      free(adres);
}
while (licz);
free(adres);
return(ile);
}

int       analiza               (char *poczatek,char *koniec)
{
LINIA linia;
int licznik,kon,dlugosc;
int n_lewe=0,n_prawe=0,blad;

for (licznik=0;licznik<=koniec-poczatek;licznik++)
    linia[licznik]=*(poczatek+licznik);
linia[licznik]=0;
dlugosc=strlen(linia);
for (licznik=0;licznik<dlugosc;licznik++)
    {
    if (linia[licznik]=='(') n_lewe++;
    if (linia[licznik]==')') n_prawe++;
    }
if (n_lewe!=n_prawe)
   {
   if (n_lewe>n_prawe) printf("Brak nawiasu zamykajacego   !!!\n");
   if (n_lewe<n_prawe) printf("Brak nawiasu otwierajacego  !!!\n");
   return(1);
   }
for (licznik=0;licznik<dlugosc;)
    {
    switch(linia[licznik])
    {
    case '(':
	 while(linia[licznik]=='(') licznik++;
	 if (licznik==dlugosc) return(0);
	 if (linia[licznik]=='*'||linia[licznik]=='/'||linia[licznik]=='^')
	    {
	    printf("Nie mozna uzywac dzialan /*^ bezposrednio \n");
	    printf("za nawiasem otwierajacym : %s\n",&linia[licznik]);
	    return(1);
	    }
	 if (linia[licznik]==')')
	    {
	    printf("Pomiedzy nawiasami musi wystepowac wyrazenie : %s\n",&linia[licznik]);
	    return(1);
	    }
	 continue;
    case ')': 
	 if (linia[licznik-1]=='*'||linia[licznik-1]=='/'||
	     linia[licznik-1]=='^'||linia[licznik-1]=='+'||
	     linia[licznik-1]=='-')
	     {
	     printf("Przed nawiasem zamykajacym nie moze wystepowac \n");
	     printf("jedno z dzialan +-^/* : %s\n",&linia[licznik-1]);
	     return(1);
	     }
	 while(linia[licznik]==')') licznik++;
	 if (licznik==dlugosc) return(0);
	 if (linia[licznik]!='*'&&linia[licznik]!='/'&&linia[licznik]!='^'
	     &&linia[licznik]!='+'&&linia[licznik]!='-')
	     {
	     printf("Za nawiasem zamykajacym musi wystepowac \n");
	     printf("jedno z dzialan +-^/* : %s\n",&linia[licznik]);
	     return(1);
	     }
	 continue;
    case '^': case '*': case '/': case '+': case '-':
	 if (licznik==dlugosc-1)
	    {
	    printf("Wyrazenie nie moze konczyc sie znakiem +-/^*\n");
	    return(1);
	    }
	 if (linia[licznik+1]=='^'||linia[licznik+1]=='/'||
	     linia[licznik+1]=='+'||linia[licznik+1]=='*'||
	     linia[licznik+1]=='-')
	    {
	    printf("Po znaku dzialania nie moze wystepowac nastepne \n");
	    printf("dzialanie %s \n",&linia[licznik]);
	    return(1);
	    }
	 licznik++;
	 continue;
    default :
	 if (licznik==0) 
	    if (linia[0]=='*'||linia[0]=='/'||linia[0]=='^')
	       {
	       printf("Wyrazenie nie moze zaczynac sie od \n");
	       printf("dzialan /*^ : %s\n",linia);
	       return(1);
	       }
	 if (linia[dlugosc-1]=='.')
	    {
	    printf("Po znaku kropka musi wystepowac czesc ulamkowa !\n");
	    return(1);
	    }
	 if (isdigit(linia[licznik])||linia[licznik]=='.')
	    {
	    kon=licznik+1;
	    while (linia[kon]!='+'&&linia[kon]!='-'&&linia[kon]!='*'&&
		   linia[kon]!='/'&&linia[kon]!='^'&&kon<dlugosc&&
		   linia[kon]!=')')
	    kon++;
	    if (!jest_liczba(&linia[licznik],&linia[kon]-1))
	       {
	       printf("Zly format wprowadzonej liczby : %s\n",&linia[licznik]);
	       return(1);
	       }
	    licznik=kon;
	    continue;
	    }
	 kon=licznik+1;
	 while (linia[kon]!='+'&&linia[kon]!='-'&&linia[kon]!='*'&&
		linia[kon]!='/'&&linia[kon]!='^'&&kon<dlugosc&&
		linia[kon]!=')'&&linia[kon]!='(')
	 kon++;
	 if (linia[kon]=='(')
	    {
	    if (!jest_nazwa_funkcji(&linia[licznik],&linia[kon]-1))
	       {
	       printf("Nie znam takiej funkcji : %s\n",&linia[licznik]);
	       return(1);
	       }
	    licznik=kon;
	    continue;
	    }	
	 blad=0;
	 if (jest_stala  (&linia[licznik],&linia[kon]-1)) blad=1;
	 if (jest_zmienna(&linia[licznik],&linia[kon]-1)) blad=1;
	 if (!blad)
	    {
	    printf("Nieznana zmienna,stala lub polecenie : %s \n",&linia[licznik]);
	    return(1);
	    }     
	 else 
	    {
	    licznik=kon;
	    continue;
	    }
    }}
return(0);
}

int       jest_nazwa_funkcji    (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int ile_funkcji,licz;

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
ile_funkcji=sizeof(funkcje)/sizeof(funkcje[0]);
for (licz=0;licz<ile_funkcji;licz++)
    if (!strcmp(nazwa,funkcje[licz].nazwa)) return(licz+1);
return(0);
}

void prepare_help(void)
{
FILE *plik;
int poprawny;
plik=fopen("help.dat","rb");
if (plik==NULL) 
   {
   printf("Nie moge znalezc pliku \"help.dat\".\nPolecenie \"help\" nie jest dostepne\n");
   return;
   }
fread(&ilosc_opisow,sizeof(unsigned),1,plik);
if (ilosc_opisow<=0) 
   {
   printf("Bledna struktura pliku \"help.dat\"\n");
   return;
   }
help_dane=(struct help_dd *)malloc(ilosc_opisow*sizeof(struct help_dd));
if (help_dane==NULL)
   {
   printf("Brak wolnej pamieci.Help jest nieosiagalny\n");
   return;
   }
poprawny=fread(help_dane,ilosc_opisow*sizeof(struct help_dd),1,plik);
if (poprawny!=1) 
   {
   printf("Bledna struktura pliku \"help.dat\"\n");
   return;
   }
fclose(plik);
stan=TRUE;
return;
}

void help(char *poczatek,char *koniec)
{
char linia[LINE_LENGTH+1];
int licznik,dlugosc,index;

if (!stan) 
   {
   printf("Help jest nieosiagalny");
   return;
   }
for(licznik=0;licznik<=koniec-poczatek;licznik++)
   linia[licznik]=*(poczatek+licznik);
   linia[licznik]=0;
dlugosc=strlen(linia);
if (dlugosc>10)
   {
   printf("Brak pomocy na temat : \"%s\" \n",linia+licznik);
   return;
   }
index=jest_help(linia);
if (index==0)
   {
   printf("Brak pomocy na temat : \"%s\" \n",linia);
   return;
   }
wyswietl_pomoc(index-1);
}

void lewe_prawe(char *poczatek,char *koniec)
{
char *pocz,*kon;
int licznik;
pocz=poczatek;kon=koniec;
while (isspace(*pocz)) pocz++;
while (isspace(*kon))  kon--;
for (licznik=0;licznik<=kon-pocz;licznik++)
    *(poczatek+licznik)=*(pocz+licznik);
    *(poczatek+licznik)=0;
}

int  jest_help (char *nazwa)
{
int licznik;

for (licznik=0;licznik<ilosc_opisow;licznik++)
    if (!strcmp(help_dane[licznik].nazwa,nazwa))
       return(licznik+1);
return(0);
}

void wyswietl_pomoc(int index)
{
int dlugosc,offset;
FILE *plik;
char *wskaznik;

plik=fopen("help.dat","rb");
if (plik==NULL)
   {
   printf("Nie moge znalezc pliku \"help.dat\".\nPolecenie \"help\" nie jest dostepne\n");
   return;
   }
if (index!=ilosc_opisow-1)
   {
   dlugosc=help_dane[index+1].dlugosc-help_dane[index].dlugosc;
   offset=help_dane[index].dlugosc
   +sizeof(unsigned)+ilosc_opisow*sizeof(struct help_dd);
   }
else
   {   
   dlugosc=file_size(plik)-help_dane[index].dlugosc-
   sizeof(unsigned)-ilosc_opisow*sizeof(struct help_dd);
   }
offset=help_dane[index].dlugosc
+sizeof(unsigned)+ilosc_opisow*sizeof(struct help_dd);
   
wskaznik=(char *)malloc(dlugosc+1);
if (wskaznik==NULL)
   {
   printf("Brak wolnej pamieci.Help jest nieosiagalny\n");
   fclose(plik);
   return;
   }
fseek(plik,offset,0);
fread(wskaznik,dlugosc,1,plik);
wskaznik[dlugosc]=0;
printf("%s",wskaznik);
free(wskaznik);
fclose(plik);
}

long int file_size(FILE *plik)
{
long int rozmiar;
fseek(plik,0,2);
rozmiar=ftell(plik);
fseek(plik,0,0);
return(rozmiar);
}






