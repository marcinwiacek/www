#define LINE_LENGTH 200
#define TRUE        1
#define FALSE       0
#define FUNKCJA_LENGTH   6
#define ZMIENNA_LENGTH   10
#define POLECENIE_LENGTH 10

typedef struct
	{
	float rez;
	float imz;
	}
	LICZBA;

typedef char  LINIA [LINE_LENGTH];

typedef struct 
	{
	char nazwa[ZMIENNA_LENGTH+1];
	LICZBA wartosc;
	}
	ZMIENNA;

ZMIENNA *zmienne=NULL;

ZMIENNA stale[]=
	{
	{"ANS",{0,0}},
	{"E", {2.718281828,0}},
	{"PI",{3.141592654,0}},
	{"J", {0          ,1}},
	};

typedef struct 
	{
	char nazwa[FUNKCJA_LENGTH+1];
	LICZBA (*adres_funkcji)(LICZBA) ;
	}
	FUNKCJA;

unsigned   ilosc_zmiennych=0;
unsigned ilosc_opisow,stan=FALSE;
struct help_dd
      {
      char nazwa[10];
      unsigned dlugosc;
      }
      *help_dane;

LICZBA suma     (LICZBA liczba1,LICZBA liczba2);
LICZBA roznica  (LICZBA liczba1,LICZBA liczba2);
LICZBA iloczyn  (LICZBA liczba1,LICZBA liczba2);
LICZBA iloraz   (LICZBA liczba1,LICZBA liczba2);
LICZBA potega   (LICZBA liczba1,LICZBA liczba2);

LICZBA SIN (LICZBA liczba);
LICZBA COS (LICZBA liczba);
LICZBA LG  (LICZBA liczba);
LICZBA LN  (LICZBA liczba);
LICZBA EXP (LICZBA liczba);
LICZBA TG  (LICZBA liczba);
LICZBA TAN (LICZBA liczba);
LICZBA CTG (LICZBA liczba);
LICZBA LOG (LICZBA liczba);
LICZBA ARG (LICZBA liczba);
LICZBA ABS (LICZBA liczba);
LICZBA REAL (LICZBA liczba);
LICZBA IMAG (LICZBA liczba);
LICZBA SQRT (LICZBA liczba);
LICZBA SINH (LICZBA liczba);
LICZBA COSH (LICZBA liczba);
LICZBA TANH (LICZBA liczba);
LICZBA TGH  (LICZBA liczba);
LICZBA CTGH (LICZBA liczba);
LICZBA ASIN (LICZBA liczba);
LICZBA ACOS (LICZBA liczba);
LICZBA ATAN (LICZBA liczba);
LICZBA ACTG (LICZBA liczba);
LICZBA ARSH (LICZBA liczba);
LICZBA ARCH (LICZBA liczba);
LICZBA ARTH (LICZBA liczba);
LICZBA ARCTH (LICZBA liczba);
LICZBA CONJ (LICZBA liczba);



FUNKCJA funkcje[]=
   {
     {"SIN",&SIN},
     {"COS",&COS},
     {"TG" ,&TG},
     {"CTG",&CTG},
     {"TAN",&TAN},
     {"LOG",&LOG},
     {"LG",&LG},
     {"EXP",&EXP},
     {"LN",&LN},
     {"ASIN",&ASIN},
     {"ACOS",&ACOS},
     {"ATAN",&ATAN},
     {"ATG", &ATAN},
     {"ACTG",&ACTG},
     {"SINH",&SINH},
     {"COSH",&COSH},
     {"TGH", &TGH},
     {"TANH",&TGH},
     {"CTGH",&CTGH},
     {"SQRT",&SQRT},
     {"ABS", &ABS},	    /*modol */
     {"REAL",&REAL},
     {"IMAG",&IMAG},
     {"ARG", &ARG},	     /*kat*/
     {"ARSH",&ARSH},
     {"ARCH",&ARCH},
     {"ARTH",&ARTH},
     {"ARCTH",&ARCTH},
     {"ASINH",&ARSH },
     {"ACOSH",&ARCH },
     {"ATANH",&ARTH },
     {"ATGH", &ARTH },
     {"ACTGH",&ARCTH},
     {"CONJ",&CONJ},
     };

LICZBA suma     (LICZBA liczba1,LICZBA liczba2)
{
LICZBA liczba;
liczba.rez=liczba1.rez+liczba2.rez;
liczba.imz=liczba1.imz+liczba2.imz;
return(liczba);
}

LICZBA roznica  (LICZBA liczba1,LICZBA liczba2)
{
LICZBA liczba;
liczba.rez=liczba1.rez-liczba2.rez;
liczba.imz=liczba1.imz-liczba2.imz;
return(liczba);
}

LICZBA iloczyn  (LICZBA liczba1,LICZBA liczba2)
{
LICZBA liczba;
liczba.rez=liczba1.rez*liczba2.rez-liczba1.imz*liczba2.imz;
liczba.imz=liczba1.rez*liczba2.imz+liczba1.imz*liczba2.rez;
return(liczba);
}

LICZBA iloraz   (LICZBA liczba1,LICZBA liczba2)
{
LICZBA liczba;
float mianownik;
mianownik=liczba2.rez*liczba2.rez+liczba2.imz*liczba2.imz;
if (mianownik!=0)
   {
   liczba.rez=( liczba1.rez*liczba2.rez+liczba1.imz*liczba2.imz)/mianownik;
   liczba.imz=(-liczba1.rez*liczba2.imz+liczba1.imz*liczba2.rez)/mianownik;
   return(liczba);
   }
printf("Proba dzielenia przez 0!!!\nOtrzymany wynik nie odzwierciedla rzeczywistosci!!!\n");
return(liczba);
}

LICZBA potega   (LICZBA liczba1,LICZBA liczba2)
{
if (liczba1.rez==0&&liczba1.imz==0&&liczba2.rez==0&&liczba2.imz==0)
   {
   printf("Symbol nieoznaczony 0^0.Wynik nie odzwierciedla rzeczywistosci\n");
   liczba1.rez=1;
   return(liczba1);
   }
if (liczba1.rez==0&&liczba1.imz==0)
   return(liczba1);
return(EXP(iloczyn(liczba2,LN(liczba1))));
}



LICZBA EXP(LICZBA liczba)
{
LICZBA liczba1;
liczba1.rez=cos(liczba.imz)*exp(liczba.rez);
liczba1.imz=sin(liczba.imz)*exp(liczba.rez);
return(liczba1);
}

LICZBA LN (LICZBA liczba)
{
LICZBA liczba1;
liczba1=ARG(liczba);
liczba1.imz=liczba1.rez;
if (liczba.rez!=0||liczba.imz!=0)
liczba1.rez=log(sqrt(liczba.rez*liczba.rez+liczba.imz*liczba.imz));
else {printf("Uzyta funkcja korzysta z logarytmu z 0!!!\nOtrzymany wynik nie odzwierciedla rzeczywistosci!!!\n");}
return(liczba1);
}

LICZBA SIN(LICZBA liczba)
{
LICZBA liczba1;
liczba1.rez=sin(liczba.rez)*cosh(liczba.imz);
liczba1.imz=cos(liczba.rez)*sinh(liczba.imz);
return(liczba1);
}

LICZBA COS(LICZBA liczba)
{
LICZBA liczba1;
liczba1.rez= cos(liczba.rez)*cosh(liczba.imz);
liczba1.imz=-sin(liczba.rez)*sinh(liczba.imz);
return(liczba1);
}

LICZBA LG  (LICZBA liczba)
{
LICZBA liczba1;
liczba1.rez=log(10);
liczba1.imz=0;
liczba1=iloraz(LN(liczba),liczba1);
return(liczba1);
}

LICZBA LOG  (LICZBA liczba)
{
return(LG(liczba));
}

LICZBA  TAN (LICZBA liczba)
{
return(iloraz(SIN(liczba),COS(liczba)));
}

LICZBA  TG (LICZBA liczba)
{
return(TAN(liczba));
}

LICZBA  CTG (LICZBA liczba)
{
LICZBA liczba1;
if (liczba.rez!=0||liczba.imz!=0)
return(iloraz(COS(liczba),SIN(liczba))); 
printf("Proba obliczenia ctg(0)!!!\nOtrzymany wynik nie odzwierciedla rzeczywistosci\n");
return(liczba1);
}

LICZBA  ARG (LICZBA liczba)
{
LICZBA liczba1;
if (liczba.rez!=0) liczba1.rez=atan(liczba.imz/liczba.rez);
   else 
       {
       (liczba1.rez=stale[2].wartosc.rez/2);
       if (liczba.imz<0) liczba1.rez=-liczba1.rez ;
       }
if (liczba.rez<0&&liczba.imz<0) liczba1.rez-=stale[2].wartosc.rez;
if (liczba.rez<0&&liczba.imz>=0) liczba1.rez+=stale[2].wartosc.rez;
liczba1.imz=0;
return(liczba1);
}

LICZBA  ABS (LICZBA liczba)
{
LICZBA liczba1;
liczba1.rez=sqrt(liczba.rez*liczba.rez+liczba.imz*liczba.imz);
liczba1.imz=0;
return(liczba1);
}

LICZBA  IMAG (LICZBA liczba)
{
liczba.rez=liczba.imz;
liczba.imz=0;
return(liczba);
}

LICZBA  REAL (LICZBA liczba)
{
liczba.imz=0;
return(liczba);
}

LICZBA  SQRT (LICZBA liczba)
{
LICZBA liczba1={0.5,0};
return(potega(liczba,liczba1));
}

LICZBA SINH (LICZBA liczba)
{
LICZBA liczba1,liczba2={0,1};
liczba1=SIN(iloczyn(liczba,liczba2));
liczba2.imz=-liczba2.imz;
liczba1=iloczyn(liczba1,liczba2);
return(liczba1);
}

LICZBA COSH (LICZBA liczba)
{
LICZBA liczba1,liczba2={0,1};
liczba1=COS(iloczyn(liczba,liczba2));
return(liczba1);
}

LICZBA TGH (LICZBA liczba)
{
return(iloraz(SINH(liczba),COSH(liczba)));
}

LICZBA CTGH (LICZBA liczba)
{
return(iloraz(COSH(liczba),SINH(liczba)));
}

LICZBA ASIN (LICZBA liczba)
{
LICZBA liczba1,liczba2={0,1},liczba3={1,0},liczba4={2,0};
liczba1=SQRT(roznica(liczba3,potega(liczba,liczba4)));
liczba1=suma(liczba1,iloczyn(liczba,liczba2));
liczba1=LN(liczba1);
liczba1=iloczyn(liczba1,liczba2);
liczba2.imz=0;
liczba1=roznica(liczba2,liczba1);
return(liczba1);
}

LICZBA ACOS (LICZBA liczba)
{
LICZBA liczba1,liczba2={0,1},liczba3={-1,0},liczba4={2,0};
liczba1=SQRT(suma(potega(liczba,liczba4),liczba3));
liczba1=suma(liczba,liczba1);
liczba1=LN(liczba1);
liczba1=iloczyn(liczba1,liczba2);
liczba2.imz=0;
liczba1=roznica(liczba2,liczba1);
return(liczba1);
}

LICZBA ATAN (LICZBA liczba)
{
LICZBA liczba1,licz,mian,liczba2={0,-0.5},liczba3={0,1},liczba4={1,0};
licz=suma   (liczba4,iloczyn(liczba,liczba3));
mian=roznica(liczba4,iloczyn(liczba,liczba3));
liczba1=LN(iloraz(licz,mian));
liczba1=iloczyn(liczba2,liczba1);
return(liczba1);
}

LICZBA ACTG (LICZBA liczba)
{
LICZBA liczba1,licz,mian,liczba2={0,-0.5},liczba3={0,1},liczba4={1,0};
mian=suma   (liczba4,iloczyn(liczba,liczba3));
licz=roznica(iloczyn(liczba,liczba3),liczba4);
liczba1=LN(iloraz(licz,mian));
liczba1=iloczyn(liczba2,liczba1);
return(liczba1);
}

LICZBA ARSH (LICZBA liczba)
{
LICZBA liczba1,liczba2={1,0},liczba3={2,0};
if (liczba.rez<0) 
   {
   liczba.rez=-liczba.rez;
   liczba.imz=-liczba.imz;
   liczba1=ARSH(liczba);
   liczba.rez=-liczba.rez;
   liczba.imz=-liczba.imz;
   }
liczba1=SQRT(suma(liczba2,potega(liczba,liczba3)));
liczba1=suma(liczba,liczba1);
liczba1=LN(liczba1);
return(liczba1);
}

LICZBA ARCH (LICZBA liczba)
{
LICZBA liczba1,liczba2={1,0},liczba3={2,0};
liczba1=SQRT(roznica(potega(liczba,liczba3),liczba2));
liczba1=suma(liczba,liczba1);
liczba1=LN(liczba1);
return(liczba1);
}

LICZBA ARTH (LICZBA liczba)
{
LICZBA liczba1,liczba2={0.5,0},liczba3={1,0};
liczba1=iloraz(suma(liczba3,liczba),roznica(liczba3,liczba));
liczba1=iloczyn(liczba2,LN(liczba1));
return(liczba1);
}

LICZBA ARCTH (LICZBA liczba)
{
LICZBA liczba1;
liczba1=ARTH(liczba);
if (liczba1.imz>0) liczba1.imz-=stale[2].wartosc.rez/2;
else
if (liczba1.imz<0) liczba1.imz+=stale[2].wartosc.rez/2;
return(liczba1);
}

LICZBA CONJ (LICZBA liczba)
{
liczba.imz=-liczba.imz;
return(liczba);
}