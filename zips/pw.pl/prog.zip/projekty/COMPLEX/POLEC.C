typedef struct
	{
	char nazwa_polecenia[POLECENIE_LENGTH+1];
	void (*adres_polecenia)(char *poczatek,char *koniec);
	}
	POLECENIE;

void    TRYG   (char *poczatek,char *koniec);
void    WYKL   (char *poczatek,char *koniec);
void    SAVE   (char *poczatek,char *koniec);
void    RUN    (char *poczatek,char *koniec);
void    HELP   (char *poczatek,char *koniec);
void    PIERW  (char *poczatek,char *koniec);
void    FREE   (char *poczatek,char *koniec);
void    SHOW   (char *poczatek,char *koniec);
void    FREEALL(char *poczatek,char *koniec);
void    SHOWALL(char *poczatek,char *koniec);
void    MEMORY (char *poczatek,char *koniec);
void    CZESC  (char *poczatek,char *koniec);
void    FUCK   (char *poczatek,char *koniec);


int     czy_jest_poleceniem (char *poczatek,char *koniec);
void    wiersz_polecen      (char *poczatek);
int     jest_dobra_nazwa    (char *poczatek,char *koniec); 

POLECENIE polecenia[]=
	{
	{"TRYG",       &TRYG   },
	{"WYKL",       &WYKL   },
	{"SAVE",       &SAVE   },
	{"RUN",        &RUN    },
	{"HELP",       &HELP   },
	{"PIERW",      &PIERW  },
	{"FREE",       &FREE   },
	{"FREEALL",    &FREEALL},
	{"SHOW",       &SHOW   },
	{"SHOWALL",    &SHOWALL},
	{"MEMORY",     &MEMORY},
	{"CZESC",      &CZESC},
	{"HI",         &CZESC},
	{"HELLO",      &CZESC},
	{"HEY",        &CZESC},
	{"FUCK",       &FUCK},
	};

void    TRYG   (char *poczatek,char *koniec)
{
LICZBA liczba;
float modol,alfa;
if (poczatek>koniec)
   {
   printf("Brak parametrow !\n");
   return;
   } 
if (analiza(poczatek,koniec)) return;
liczba=wartosc(poczatek,koniec);
modol=ABS(liczba).rez;
alfa=ARG(liczba).rez;
if (!(((liczba.rez*20000)>=1)||((liczba.rez*20000)<=-1))) liczba.rez=0;
printf("%1.4f",liczba.rez);
if (((liczba.imz*20000)>=1)||((liczba.imz*20000)<=-1))
   {
   printf("%+1.4fj = ", liczba.imz);
   }
printf(" = %1.4f*[cos(%1.4f)+j*sin(%1.4f)]\n",modol,alfa,alfa);
}

void    WYKL   (char *poczatek,char *koniec)
{
LICZBA liczba;
float modol,argument;
if (poczatek>koniec)
   {
   printf("Brak parametrow !\n");
   return;
   } 
if (analiza(poczatek,koniec)) return;
liczba=wartosc(poczatek,koniec);
modol=ABS(liczba).rez;
argument=ARG(liczba).rez;
if (!(((liczba.rez*20000)>=1)||((liczba.rez*20000)<=-1))) liczba.rez=0;
printf("%3.4f",liczba.rez);
if (((liczba.imz*20000)>=1)||((liczba.imz*20000)<=-1))
   {
   printf("%+3.4fj ", liczba.imz);
   }
printf(" = %1.4f*e^(%1.4f*j)\n",modol,argument);
}

void    SAVE   (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik,*ostatni;
FILE *plik;
int index;
LICZBA liczba;

if (poczatek>koniec)
   {
   printf("Brak parametrow w uzyciu polecenia SAVE !\n");
   return;
   }
licznik=poczatek;
while (*licznik!=','&&licznik<=koniec) nazwa[licznik-poczatek]=*licznik++;
nazwa[licznik-poczatek]=0;
if (licznik>=koniec)
   {
   printf("Brak zmiennych do zapisywania !\n");
   return;
   }
licznik++;
ostatni=licznik;
plik=fopen(nazwa,"a+t");
if (plik==NULL)
   {
   printf("Blad podczas otwierania pliku %s !\n",nazwa);
   return;
   }
do
  {
  while (*licznik!=',') 
	{
	nazwa[licznik-ostatni]=*licznik;
	licznik++;
	if (licznik>koniec) break;
	}
  nazwa[licznik-ostatni]=0;
  index=jest_zmienna(ostatni,licznik-1);
  if (!index)
     {
     printf("Jedna z podanych zmiennych nie istnieje : %s\n",ostatni);
     fclose(plik);
     return;
     };
  index--;
  liczba=zmienne[index].wartosc;
  fprintf(plik,"\n%s=%f%+f*j;\n",nazwa,liczba.rez,liczba.imz);
  licznik++;
  ostatni=licznik;
  }
while (licznik<=koniec);
fclose(plik);
}

void    RUN    (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
FILE *plik;

if (poczatek>koniec)
   {
   printf("Brak parametrow !\n");
   return;
   }
for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
plik=fopen(nazwa,"rt");
if (plik==NULL) 
   {
   printf("Plik %s nie istnieje!!!\n",poczatek);
   return;
   }
while (fgets(nazwa,LINE_LENGTH,plik)!=NULL)
      {
      if (nazwa[strlen(nazwa)-1]==10) nazwa[strlen(nazwa)-1]=0;
      strupr(nazwa);
      lewe_prawe(nazwa,nazwa+strlen(nazwa)-1);
      if (!strlen(nazwa)) continue;
      wiersz_polecen(nazwa);
      }
fclose(plik);
}

void    HELP   (char *poczatek,char *koniec)
{
char linia[][10]={"polecenia","funkcje"};
if (koniec<=poczatek)
   {
   help(linia[0],linia[0]+strlen(linia[0])-1);
   printf("Nacisnij ENTER : ");gets(linia[0]);
   help(linia[1],linia[1]+strlen(linia[1])-1);
   } 
else help(poczatek,koniec);
}

void    PIERW  (char *poczatek,char *koniec)
{
char *licznik=0;
LICZBA liczba;
float modol,alfa,kat;
int stopien,k;

if (poczatek>koniec)
   {
   printf("Brak parametrow !\n");
   return;
   }
licznik=poczatek;
while (licznik<koniec&&*licznik!=',') licznik++;
if (licznik<=poczatek||licznik==koniec)
   {
   printf("Blad w parametrach programu : %s\n",licznik);
   return;
   }
if (analiza(licznik+1,koniec)) return;
if (!jest_liczba(poczatek,licznik-1)) 
   {
   printf("Nieprawidlowy parametr : stopien pierwiastka\n");
   return;
   }
liczba=wartosc(licznik+1,koniec);
modol=wartosc(poczatek,licznik-1).rez;
stopien=floor(modol);
modol=ABS(liczba).rez;
alfa=ARG(liczba).rez;
if (stopien>20) 
   {
   printf("Oblicza pierwiastki max.20 stopnia\n");
   return;
   }
if (stopien<2)
   {
   printf("Stopien musi byc wiekszy od 1\n");
   return;
   }
if (liczba.rez==0&&liczba.imz==0)
   {
   printf("Nie mozna obliczac pierwiastkow z 0 !\n");
   return;
   }
modol=log(modol)/stopien;
modol=exp(modol);
printf("Pierwiastki %d stopnia z ",stopien);
if (!(((liczba.rez*20000)>=1)||((liczba.rez*20000)<=-1))) liczba.rez=0;
printf("%3.4f",liczba.rez);
if (((liczba.imz*20000)>=1)||((liczba.imz*20000)<=-1))
   {
   printf("%+3.4fj ", liczba.imz);
   }
printf("\n");
for (k=0;k<stopien;k++)
    {
    kat=(alfa+2*k*acos(-1))/stopien;
    printf("Z%2d = %1.4f*[cos(%1.4f)+j*sin(%1.4f)] = ",k,modol,kat,kat);
    printf("%1.4f*[%1.4f %+1.4f*j]\n",modol,cos(kat),sin(kat));
    }
}

void    FREE   (char *poczatek,char *koniec)
{
LINIA linia="FREE";
char *licznik,*ostatni;
int index;

if (!ilosc_zmiennych) 
   {
   printf("Brak zmiennych w pamieci !\n");
   return;
   } 
if (koniec<poczatek)
   {
   printf("Nieprawidlowe uzycie funkcji FREE !\n");
   help(linia,linia+strlen(linia)-1);
   return;
   }
licznik=poczatek;
ostatni=licznik;
do
  {
  while (*licznik!=',') 
	{
	licznik++;
	if (licznik>koniec) break;
	}
  index=jest_zmienna(ostatni,licznik-1);
  if (!index)
     {
     printf("Jedna z podanych zmiennych nie istnieje : %s\n",ostatni);
     return;
     };
  if (index==ilosc_zmiennych)
     {
     zmienne=(ZMIENNA *)realloc(zmienne,sizeof(ZMIENNA)*(ilosc_zmiennych-1));
     ilosc_zmiennych--;
     }
  else
     {
     zmienne[index-1].wartosc.rez=zmienne[ilosc_zmiennych-1].wartosc.rez;
     zmienne[index-1].wartosc.imz=zmienne[ilosc_zmiennych-1].wartosc.imz;
     strcpy(&zmienne[index-1].nazwa,&zmienne[ilosc_zmiennych-1].nazwa);
     zmienne=(ZMIENNA *)realloc(zmienne,sizeof(ZMIENNA)*(ilosc_zmiennych-1));
     ilosc_zmiennych--;
     }
  licznik++;
  ostatni=licznik;
  }
while (licznik<=koniec);
}


void    SHOW   (char *poczatek,char *koniec)
{
LINIA linia="SHOW";
char *licznik,*ostatni;
int index;

if (!ilosc_zmiennych) 
   {
   printf("Brak zmiennych w pamieci !\n");
   return;
   } 
if (koniec<poczatek)
   {
   printf("Nieprawidlowe uzycie funkcji SHOW !\n");
   help(linia,linia+strlen(linia)-1);
   return;
   }
licznik=poczatek;
ostatni=licznik;
do
  {
  while (*licznik!=',') 
	{
	licznik++;
	if (licznik>koniec) break;
	}
  index=jest_zmienna(ostatni,licznik-1);
  if (!index)
     {
     printf("Jedna z podanych zmiennych nie istnieje : %s\n",ostatni);
     return;
     }
  wyswietl_zmienna(index-1);
  licznik++;
  ostatni=licznik;
  }
while (licznik<=koniec);
}

void    FREEALL(char *poczatek,char *koniec)
{
poczatek=koniec;koniec=poczatek;
ilosc_zmiennych=0;
free(zmienne);
}

void    FUCK  (char *poczatek,char *koniec)
{
static int ile=0;
char teksty[][30]=
     {
     {"Dlaczego tak mnie traktujesz"},
     {"Nie badz taki"},
     {"I nawzajem"},
     {"Bo poskarze mamie"},
     {"Wal na ryj"},
     {"Idz sie wyspowiadac"},
     {"Mam Cie dosc"},
     };

poczatek=koniec;koniec=poczatek;
ile%=(sizeof(teksty)/sizeof(teksty[0]));
printf("%s\n",teksty[ile]);
ile++;
}


void    CZESC  (char *poczatek,char *koniec)
{
char teksty[][30]=
     {
     {"Ja tez Cie witam"},
     {"Buzka"},
     {"Siemano"},
     {"Czesc glabie"},
     {"Daj grabe"},
     {"Przybij piatke"},
     {"Czolko"},
     {"Mam dosc powitan"},
     {"Howgh"},
     {"Skoncz bo sie zapetle"},
     };
static int ile=0;

poczatek=koniec;koniec=poczatek;
ile%=(sizeof(teksty)/sizeof(teksty[0]));
printf("%s\n",teksty[ile]);
ile++;
}

void    SHOWALL(char *poczatek,char *koniec)
{
char temp[50];
unsigned licznik;
licznik=poczatek-koniec;
for (licznik=0;licznik<ilosc_zmiennych;licznik++)
    {
    wyswietl_zmienna(licznik);
    if (licznik%23==22) 
       {
       printf("Nacisnij Enter : ");
       gets(temp);
       }
    }
}

void    MEMORY (char *poczatek,char *koniec)
{
poczatek=koniec;koniec=poczatek;
printf("Ilosc wolnej pamieci : %lu\n",(unsigned long)coreleft());
}

int     czy_jest_poleceniem(char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int ile_polecen,licz;
for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
ile_polecen=sizeof(polecenia)/sizeof(polecenia[0]);
for (licz=0;licz<ile_polecen;licz++)
    if (!strcmp(nazwa,polecenia[licz].nazwa_polecenia)) 
       return(licz+1);
return(0);
}

void wiersz_polecen(char *linia)
{
int licznik,index,blad;
int        wyswietlanie=1,przypisanie=0;

for (licznik=0;licznik<strlen(linia);licznik++)
    if (isspace(linia[licznik])) 
       {
       licznik--;
       break;
       }
if ((index=czy_jest_poleceniem(linia,linia+licznik))!=0)
   {
      usun_spacje(linia+licznik+1);
      polecenia[index-1].adres_polecenia(linia+licznik+1,
                                         linia+strlen(linia)-1);
      return;
   }
usun_spacje(linia);
if (linia[strlen(linia)-1]==';')
   {
   wyswietlanie=0;
   linia[strlen(linia)-1]=0;
   }
else wyswietlanie=1;
for (licznik=0;licznik<strlen(linia);licznik++)
    if (linia[licznik]=='=') break;
if (licznik!=strlen(linia))
{
if (licznik==strlen(linia)-1)
   {
   printf("Nie moge wykonac takiej operacji!\n");
   return;
   }
if (licznik>10)
   {
   printf("Nazwa zmiennej nie moze przekraczac 10 znakow!\n");
   return;
   }
if (!isalpha(linia[0]))
   {
   printf("Nazwa zmiennej musi zaczynac sie od litery!\n");
   return;
   }
for (index=0;index<licznik;index++)
   if (!isalnum(linia[index]))
      {
      printf("Nazwa zmiennej moze sie skladac tylko z liter i cyfr!\n");
      return;
      }
przypisanie=1;
}; 
if (przypisanie)
   {
   index=jest_zmienna(linia,linia+licznik-1);
   if (!index)
      {
      if (jest_dobra_nazwa(linia,linia+licznik-1))
	 index=utworz_zmienna(linia,linia+licznik-1);
      else
	 {
	 printf("Niedozwolona nazwa zmiennej : %s\n",linia);
	 return;
	 }
      }
   if (!index)
      {
      printf("Brak wolnej pamieci na otworzenie zmiennej!\n");
      return;
      } 
   blad=analiza(linia+licznik+1,linia+strlen(linia)-1);
   if (blad) return;
   zmienne[index-1].wartosc=wartosc(linia+licznik+1,linia+strlen(linia)-1);
   if (wyswietlanie)
      wyswietl_zmienna(index-1);
   return;
   }
blad=analiza(linia,linia+strlen(linia-1));
if (blad) return;
stale[0].wartosc=wartosc(linia,linia+strlen(linia)-1);
if (wyswietlanie)
   {
   wyswietl(stale[0].wartosc);
   }
}

int     jest_dobra_nazwa    (char *poczatek,char *koniec)
{
char nazwa[LINE_LENGTH+1];
char *licznik;
int ile_polecen,ile_stalych,ile_funkcji,licz;

for (licznik=poczatek;licznik<=koniec;licznik++)
    nazwa[licznik-poczatek]=*licznik;
nazwa[licznik-poczatek]=0;
ile_polecen=sizeof(polecenia)/sizeof(polecenia[0]);
ile_stalych=sizeof(stale)/sizeof(stale[0]);
ile_funkcji=sizeof(funkcje)/sizeof(funkcje[0]);
for (licz=0;licz<ile_polecen;licz++)
    if (!strcmp(nazwa,polecenia[licz].nazwa_polecenia)) 
       return(0);
for (licz=0;licz<ile_stalych;licz++)
    if (!strcmp(nazwa,stale[licz].nazwa)) 
       return(0);
for (licz=0;licz<ile_funkcji;licz++)
    if (!strcmp(nazwa,funkcje[licz].nazwa)) 
       return(0);
return(1);
}

