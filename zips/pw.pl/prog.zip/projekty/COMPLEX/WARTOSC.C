LICZBA wartosc(char *poczatek,char *koniec)
{
char *nastepne;
LICZBA liczba={0,0};
int index;

if ((index=jest_stala(poczatek,koniec))!=0)
   return(wartosc_stalej(index-1));
if ((index=jest_zmienna(poczatek,koniec))!=0)
   return(wartosc_zmiennej(index-1));
if (jest_liczba(poczatek,koniec))
   return(wartosc_liczby(poczatek,koniec));
if ((index=jest_funkcja(poczatek,koniec))!=0)
   return(wartosc_funkcji(poczatek,koniec,index-1));

if (*poczatek=='(')
   if (jego_nawias(poczatek,koniec)==koniec)
       return(wartosc(poczatek+1,koniec-1));

nastepne=jego_dzialanie(poczatek,koniec,0);
if (nastepne!=NULL)
   {
   while(jego_dzialanie(nastepne+1,koniec,0)!=NULL)
	nastepne=jego_dzialanie(nastepne+1,koniec,0);
   switch(*nastepne)
	 {
	 case '+':
	      return(suma(wartosc(poczatek,nastepne-1),
			  wartosc(nastepne+1,koniec)));
	 case '-':
	      return(roznica(wartosc(poczatek,nastepne-1),
			     wartosc(nastepne+1,koniec)));
	 }
   }
nastepne=jego_dzialanie(poczatek,koniec,'*');
if (nastepne!=NULL)
   {
   while(jego_dzialanie(nastepne+1,koniec,'*')!=NULL)
	 nastepne=jego_dzialanie(nastepne+1,koniec,'*');
      switch(*nastepne)
	 {
	 case '*':
	      return(iloczyn(wartosc(poczatek,nastepne-1),
			     wartosc(nastepne+1,koniec)));
	 case '/':
	      return(iloraz(wartosc(poczatek,nastepne-1),
			     wartosc(nastepne+1,koniec)));
	 }
   }
nastepne=jego_dzialanie(poczatek,koniec,'^');
if (nastepne!=NULL)
   {
   while(jego_dzialanie(nastepne+1,koniec,'^')!=NULL)
	nastepne=jego_dzialanie(nastepne+1,koniec,'^');
   return(potega(wartosc(poczatek,nastepne-1),
		 wartosc(nastepne+1,koniec)));
   }
return(liczba);
}
