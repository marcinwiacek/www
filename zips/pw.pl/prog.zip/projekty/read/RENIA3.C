#include <stdio.h>

main()
{
int a,c,d;
char b,nzw_pliku[15];
FILE *plik;

printf("\n\n\tProjekt nr 3");
printf("\n\tautor : Renata Wojtaszek\n");
do
 {
c=1;
printf("\nPodaj nazwe pliku do sekwencyjnego odczytu : ");
scanf("%s",nzw_pliku);
if ((plik=fopen(nzw_pliku,"r"))==NULL)
	fprintf(stderr,"Nie moge otworzyc pliku : %s\n",nzw_pliku);
else
	{
	while ((b=getc(plik))!=EOF)
		{
		if (b=='\n')
			{
			printf("%cRekord nr %d\nENTER - nastepny,w - wyjscie\n",b,c);
			if ((d=getchar())=='w')
				break;
			c++;
			}
		else
			printf("%c",b);
		}		
	}
printf("Jeszcze raz (t/n)? :");
d=getchar();
 }
while (d=='t');
}
