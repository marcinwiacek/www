#include <stdio.h>
#include <alloc.h>


struct droga
{ //Struktura do przechowywanie informacji o drodze
	unsigned int miasto;    //Numer miasta, do ktorego biegnie droga
	float dlugosc;          //Dlugosc drogi
	struct droga *nastepna; //Wskaznik na nastepny element listy
};

struct miasto
{ //Struktura do przechowywania informacji o miescie
	unsigned int numer;   //Numer miasta
	char juz_byl;
	struct droga *drogi;
	struct miasto *nastepne; //Wskaznik na nastepny element listy
};

struct trasa
{ //Struktura do przechowywania informacji o elemencie trasy
	unsigned int miasto;      //Numer miasta przez ktore biegnie droga
	struct trasa *nastepne;    //Wskaznik na nastepny element listy
};

struct miasto *miasta;     //Wskaznik na poczatek list miast
struct trasa *najkrotsza;  //Wskaznik na poczatek listy zawierajacej najkrotsza trase
float dlug_najkrot;        //Dlugosc najkrotszej trasy


struct miasto *Znajdz_miasto(unsigned int nr)
//Funkcja zwraca wskaznik na miasto o numerze nr, jesli nie ma takiego miasta
//to tworzy je (jesli funkcja zwroci NULL, to zabraklo pamieci)
{
	struct miasto *wynik; //Wskaznik na szukane miasto
	struct miasto *wsk1,*wsk2; //Wskazniki robocze
	struct miasto *wsk3;       //Nowo utworzone miasto

	wsk2=NULL;
	wynik=NULL;
	wsk1=miasta;
	while ((wsk1!=NULL) && (wynik==NULL))
	{ //Szukaj miasta w liscie miast
		if (nr==wsk1->numer)
			wynik=wsk1;
		wsk2=wsk1;
		wsk1=wsk1->nastepne;
	}
	if (wynik==NULL)
	{ //Jesli nie ma mista to utworz je
		wsk3=calloc(1,sizeof(struct miasto));
		if (wsk3==NULL)
		{
			printf("Brak pamieci !\n");
			return NULL;
		}
		wsk3->numer=nr;
		wsk3->drogi=NULL;
		wsk3->juz_byl=0;
		wsk3->nastepne=NULL;
		if (miasta==NULL)
			miasta=wsk3;
		else
			wsk2->nastepne=wsk3;
		wynik=wsk3;
	}
	return wynik;
}

int Dodaj_droge(unsigned int nr1,unsigned int nr2,float odl)
//Dodaje droge z miasta nr1 do miasta nr2 o dlugosci odl
{
	struct droga *wsk1; //Roboczy wskaznik
	struct droga *wsk2; //Wskaznik na nowo utworzony element
	struct miasto *miasto1;

	wsk2=calloc(1,sizeof(struct droga)); //Tworz nowy element listy
	if (wsk2==NULL)
	{
		printf("Brak pamieci !\n");
		return 1;
	}
	wsk2->miasto=nr2;
	wsk2->dlugosc=odl;
	wsk2->nastepna=NULL;
	miasto1=Znajdz_miasto(nr1);
	if (miasto1==NULL)
		return 1;
	if (miasto1->drogi==NULL)
		miasto1->drogi=wsk2;
	else
	{
		wsk1=miasto1->drogi;
		while (wsk1->nastepna!=NULL)
			wsk1=wsk1->nastepna;
		wsk1->nastepna=wsk2;
	}
	return 0;
}

void Usun_trase(struct trasa **tr)
//Usuwa liste elementow trasa wskazywana przez tr z pamieci
{
	struct trasa *wsk1,*wsk2;

	wsk1=*tr;
	while (wsk1!=NULL)
	{
		wsk2=wsk1->nastepne;
		free(wsk1);
		wsk1=wsk2;
	}
	(*tr)=NULL;
}

int Dodaj_do_trasy(struct trasa **tr,unsigned int nr)
//Dodaje do listy elementow trasa wskazywanej przez tr element o numerze nr
{
	struct trasa *wsk1,*wsk2;

	wsk2=calloc(1,sizeof(struct trasa));
	if (wsk2==NULL)
	{
		printf("Brak pamieci !\n");
		return 1;
	}
	wsk2->miasto=nr;
	wsk2->nastepne=NULL;
	if (*tr==NULL)
		(*tr)=wsk2;
	else
	{
		wsk1=*tr;
		while (wsk1->nastepne!=NULL)
			wsk1=wsk1->nastepne;
		wsk1->nastepne=wsk2;
	}
	return 0;
}
int Szukanie (struct trasa *przebyta,float dlugosc,unsigned int obecne)
//Funkcja rekurencyjna do szukania
//przebyta - lista miast, przez ktore prowadzi obecna sciezka
//dlugosc - dlugosc obecnej sciezki
//obecne - miasto, w ktorym sie aktualnie znajduje
{
	struct trasa *wsk1,*wsk2;
	struct droga *dr1;
	struct miasto *mias1;
	char byly_wszystkie;

	mias1=miasta;
	byly_wszystkie=1;
	while (mias1!=NULL)
	{
		if (mias1->juz_byl==0)
			byly_wszystkie=0;
		mias1=mias1->nastepne;
	}
	if (byly_wszystkie)
	{ //Jesli juz przeszedl wszystkie miasta, to zapamietaj trase jako najkrotsza
		Usun_trase(&najkrotsza);
		if (przebyta!=NULL)
		{
			wsk1=przebyta;
			while (wsk1!=NULL)
			{
				if (Dodaj_do_trasy(&najkrotsza,wsk1->miasto))
					return 1;
				wsk1=wsk1->nastepne;
			}
		}
		dlug_najkrot=dlugosc;
	}
	else
	{
		mias1=Znajdz_miasto(obecne);
		dr1=mias1->drogi;
		while (dr1!=NULL)
		{ // Powtorz dla wszystkich drog wychodzacych z miasta
			if ((dlugosc+dr1->dlugosc<dlug_najkrot) || (dlug_najkrot==-1))
			{ //Jesli dlugosc sciezki nie bedzie wieksza od najkrotszej
				//dotychczas znalezionej
				mias1=Znajdz_miasto(dr1->miasto);
				if (mias1->juz_byl==0)
				{ //Jesli nie byj jeszcze w tym miescie
					if (Dodaj_do_trasy(&przebyta,dr1->miasto))
						return 1;
					mias1->juz_byl=1;//Wydluz trase o miasto do ktorego biegnie droga
					//i odwolaj sie do siebie z tym miastem
					if (Szukanie (przebyta,dlugosc+dr1->dlugosc,dr1->miasto))
						return 1;
					mias1->juz_byl=0;
					wsk1=przebyta;
					while (wsk1->nastepne!=NULL)
					{  //Usun miasto dodane do trasy
						wsk2=wsk1;
						wsk1=wsk1->nastepne;
					}
					free(wsk2->nastepne);
					wsk2->nastepne=NULL;
				}
			}
			dr1=dr1->nastepna;
		}
	}
	return 0;
}

int Znajdz_najkrotsza_droge (void)
//Funkcja przy uzyciu funkcji szukaj odnajduje najkrotsza trase
{
	struct trasa *przebyta=NULL;
	struct miasto *mias1;

	Usun_trase (&najkrotsza);
	dlug_najkrot=-1;
	mias1=miasta;
	while (mias1!=NULL)
	{ //Powtorz zaczynajac od kazdego z miast
		mias1->juz_byl=1;
		if (Dodaj_do_trasy(&przebyta,mias1->numer))
			return 1;
		if (Szukanie (przebyta,0,mias1->numer))
		{
			Usun_trase(&najkrotsza);
			Usun_trase (&przebyta);
			return 1;
		};
		mias1->juz_byl=0;
		Usun_trase (&przebyta);
		mias1=mias1->nastepne;
	}
	return 0;
}
int Wczytaj_z_pliku (char *nazwa_pliku)
//Wczytuje dane z pliku i przy uzyciu funkcji dodaj droge zapisuje je do pamieci
{
	FILE *f; //Wskaznik na plik
	unsigned int nr1,nr2;
	float odl;

	f=fopen(nazwa_pliku,"rt");
	if (f!=NULL)
	{
		while (fscanf(f,"%d %d %f",&nr1,&nr2,&odl)==3)
		{
			if ((Dodaj_droge(nr1,nr2,odl)) || (Dodaj_droge(nr2,nr1,odl)))
			{
				fclose(f);
				return 1;
			};
		}
		if (!feof(f))
		{
			printf ("Blad odczytu z dysku !\n");
			fclose (f);
			return 1;
		}
		fclose (f);
	}
	else
	{
		printf("Nie moge otworzyc pliku\n");
		return 1;
	}
	return 0;
};
int Zapisz_do_pliku (char *nazwa_pliku)
//Zapisuje najkrotsza droge do pliku
{
	FILE *f;
	struct trasa *wsk1;
	int blad=0;

	f=fopen(nazwa_pliku,"wt");
	if (f!=NULL)
	{
		if (najkrotsza!=NULL)
		{
			if (fprintf(f,"dlugosc=%g\n",dlug_najkrot)==EOF)
				blad=1;
			wsk1=najkrotsza;
			while ((wsk1!=NULL) && (!blad))
			{
				if (wsk1->nastepne!=NULL)
				{
					if (fprintf(f,"%u -> ",wsk1->miasto)==EOF)
						blad=1;
				}
				else
				{
					if (fprintf(f,"%u\n",wsk1->miasto)==EOF)
						blad=1;
				}
				wsk1=wsk1->nastepne;
			}
			if (blad)
			{
				printf("Blad zapisu na dysk\n");
				fclose(f);
				return 1;
			}
		}
		fclose (f);
	}
	else
	{
		printf("Nie moge utworzyc pliku\n");
		return 1;
	}
	return 0;
};
void main (void)
{
	char nazwa1[20];
	char nazwa2[20];

	najkrotsza=NULL;
	miasta=NULL;
	printf("Podaj nazwe pliku wejsciowego:");
	gets(nazwa1);
	printf("Podaj nazwe pliku wyjsciowego:");
	gets(nazwa2);
	if (!Wczytaj_z_pliku(nazwa1))
	{
		if (!Znajdz_najkrotsza_droge())
		{
			Zapisz_do_pliku(nazwa2);
		}
	}
}