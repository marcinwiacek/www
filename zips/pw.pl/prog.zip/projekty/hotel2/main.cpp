#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <fstream.h>
#include "struct.h"
#include "obsluga.h"

/********************************** main ************************************/
int main()
{
 ifstream set_htl("setup.htl");
 ifstream goscie_htl("goscie.htl");
 lista<pokoj>  hotel;
 lista<gosc> rejestr;
 lista<gosc> rezerwa;
 char wybor;

 clrscr();

 czytaj_hotel(hotel,set_htl);
 set_htl.close();
 //czytaj_gosci(rejestr,rezerwa,hotel,goscie_htl);
 //goscie_htl.close();
 czytaj(rejestr,hotel,'z');
 czytaj(rezerwa,hotel,'r');

 do
 {
  clrscr();
  cout << "1) Lista gosci\n";
  cout << "2) Lista rezerwacji\n";
  cout << "3) Rejestracja gosci\n";
  cout << "4) Wykwaterowanie\n";
  cout << "5) Rezerwacja pokoju\n";
  cout << "6) Odwolanie pokoju\n";
  cout << "7) Uklad pokoi w hotelu\n";
  cout << "8) Kategorie pokoi i ich ceny\n";
  cout << "9) Konfiguracja hotelu\n";
  cout << "k) Wyjscie z programu\n\n";
  cout << "Twoj wybor :";
  cin >> wybor;
   switch (wybor)
	{
	  case '1':
		 cout << rejestr;
		 getchar();
		 break;
	  case '2':
		 cout << rezerwa;
		 getchar();
		 break;
	  case '3':
		 dostaw(rejestr,hotel,'z');
		 break;
	  case '4':
		 usun(rejestr,hotel,'z');
		 getchar();
		 break;
	  case '5':
		 dostaw(rezerwa,hotel,'r');
		 break;
	  case '6':
		 usun(rezerwa,hotel,'r');
		 getchar();
		 break;
	  case '7':
		 cout << hotel;
		 getchar();
		 break;
	  case '8':
                 info();
		 getchar();
		 break;
	  case '9':
                 konfiguracja();
		 break;
	  default:break;
	}
  }
  while (wybor!='k');
zapisz(rejestr,rezerwa);
exit(1);
return 1;
}