#include <iostream.h>
#include <fstream.h>

char * getstr(ifstream &f,int n=1);
void czytaj_hotel(lista<pokoj> &hotel,ifstream &p_ptr);
int czytaj(lista<gosc> &lista,lista<pokoj> &hotel,char znak);
void dostaw(lista<gosc> &lista,lista<pokoj> &hotel,char znak);
void zapisz(lista<gosc> &rejestr,lista<gosc> &rezerwa);
float cena(pokoj *pkj,gosc *gsc);
void usun(lista<gosc> &lista,lista<pokoj> &hotel,char znak);
long potega (int podst,int wykl);
void konfiguracja();
void info();
