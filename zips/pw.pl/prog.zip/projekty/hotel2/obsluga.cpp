#include <iostream.h>
#include <string.h>
#include <fstream.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include "struct.h"
/******************************** obsluga **********************************/

char * getstr(ifstream &f,int n=1)
{
 char tab[80],*tablica=0,zn;
 int i=0;

 for (int m=0;m<n;m++)
   {
     f.get(zn);
     while (isspace(zn)!=0)
       {
	f.get(zn);
       }
     while (isspace(zn)==0)
       {
	if (zn==EOF) return "";
	tab[i]=zn;
	i++;
	f.get(zn);
       }
     tab[i]='\0';
     tablica=new char(strlen(tab)+1);
     strcpy(tablica,tab);
   }
 return tablica;
}

void czytaj_hotel(lista<pokoj> &hotel,ifstream &p_ptr)
{
 char pom[80];
 int nr_pietra=0;
 int ilosc_pokoi;
 int licznik=0;

 strcpy(pom,getstr(p_ptr));
 while(strcmp(pom,"pietro:")!=0)
 strcpy(pom,getstr(p_ptr));

 while(strcmp(pom,"koniec")!=0)
 {
  if (strcmp(pom,"pietro:")==0)
    {
     nr_pietra=atoi(getstr(p_ptr));
     getstr(p_ptr);
    }
  ilosc_pokoi=atoi(getstr(p_ptr));
  getstr(p_ptr);
  strcpy(pom,getstr(p_ptr));
  for (int x=1;x<=ilosc_pokoi;x++)
  hotel.dolacz(pokoj(nr_pietra,++licznik,pom,'p'));
  strcpy(pom,getstr(p_ptr));
 }
}

int czytaj(lista<gosc> &lista,lista<pokoj> &hotel,char znak)
{
 char imie[80];
 ifstream p_ptr("goscie.htl");
 char nazwisko[80];
 char pom[80];
 char *typ[]={"rejestracja","rezerwacja"};
 char *komunikat=" nie zostal wpisany na liste !\n";
 int nr_pkj;
 int indeks;
 float czas;
 pokoj *pkj_ptr;

  if (znak=='z') indeks=0;
  else if (znak=='r') indeks=1;

  strcpy(pom,getstr(p_ptr));
  while(strcmp(pom,typ[indeks])!=0)
  {
   if (strcmp(pom,"")==0) {p_ptr.close();return 0;}
   strcpy(pom,getstr(p_ptr));
  }

  strcpy(pom,getstr(p_ptr));
  while (strcmp(pom,"koniec")!=0)
  {
   nr_pkj=atoi(pom);
   czas=atof(getstr(p_ptr));
   pkj_ptr=hotel.szukaj(pokoj(-1,nr_pkj,""));
   strcpy(imie,getstr(p_ptr));
   strcpy(nazwisko,getstr(p_ptr));
   if (pkj_ptr==NULL)
   {
    cout << "\nBlad danych ! :" << imie  << " " << nazwisko << komunikat;
    getchar();
   }
   else
   {
    pkj_ptr->stan=znak;
    lista.dolacz(gosc(imie,nazwisko,pkj_ptr,czas));
   }
   strcpy(pom,getstr(p_ptr));
  }
 p_ptr.close();
 return 1;
}

void dostaw(lista<gosc> &lista,lista<pokoj> &hotel,char znak)
{
 char imie[80];
 char nazwisko[80];
 char *komunikat="Pokoj niedostepny !\n";
 int nr_pkj;
 int nr_ptr;
 float czas;
 pokoj *pkj_ptr;

 cout << "Podaj nr pokoju:";
 cin >> nr_pkj;
 pkj_ptr=hotel.szukaj(pokoj(-1,nr_pkj,""));
 if (pkj_ptr!=NULL)
 {
  cout << "Podaj imie     :";
  cin >> imie;
  cout << "Podaj nazwisko :";
  cin >> nazwisko;
  cout << "Podaj czas pobytu:";
  cin >> czas;
  pkj_ptr->stan=znak;
  lista.dolacz(gosc(imie,nazwisko,pkj_ptr,czas));
 }
 else cout << komunikat;
}

void zapisz(lista<gosc> &rejestr,lista<gosc> &rezerwa)
{
 char *typ[]={"rejestracja","rezerwacja"};
 rejestr.ogon=rejestr.glowa;
 rezerwa.ogon=rezerwa.glowa;
 lista<gosc> *pomoc;
 pomoc=&rejestr;

 ofstream plik("goscie.htl");
 for(int i=0;i<2;i++)
 {
  plik << typ[i] << endl;
  while (pomoc->ogon!=NULL)
  {
   plik << pomoc->ogon->element.pkj_ptr->nr_pkj << " ";
   plik << pomoc->ogon->element.czas << " ";
   plik << pomoc->ogon->element.imie << " ";
   plik << pomoc->ogon->element.nazwisko << endl;
   pomoc->ogon=pomoc->ogon->nast;
  }
  plik << "koniec" << endl;
  pomoc=&rezerwa;
 }
 plik << endl;
 plik.close();
}

float cena(pokoj *pkj,gosc *gsc)
{
 ifstream plik("setup.htl");
 char pom[80];
 char string[80];

 while (strcmp(strcpy(pom,getstr(plik)),"pietro:")!=0)
 {
  if (strcmp(pom,"kategoria:")==0)
   {
    if (strcmp(strcpy(pom,getstr(plik)),pkj->kat)==0)
     {
      getstr(plik);
      return (gsc->czas)*(atof(getstr(plik)));
     }
   }
 }
 return 0;
}

void usun(lista<gosc> &lista,lista<pokoj> &hotel,char znak)
{
 char imie[80];
 char nazwisko[80];
 char *komunikat=" nie zajmuje pokoju ";
 int nr_pkj;
 float czas;
 pokoj *pkj_ptr=NULL;
 gosc *gosc_ptr=NULL;

  cout << "Podaj imie     :";
  cin >> imie;
  cout << "Podaj nazwisko :";
  cin >> nazwisko;
  cout << "Podaj nr pokoju:";
  cin >> nr_pkj;
  pkj_ptr=hotel.szukaj(pokoj(-1,nr_pkj,"",znak));
  if (pkj_ptr!=NULL)
   {
    gosc_ptr=lista.szukaj(gosc(imie,nazwisko,pkj_ptr,czas));
    if (znak=='z')
     if (gosc_ptr!=NULL)
      cout << "Naleznosc dla hotelu : " << cena(pkj_ptr,gosc_ptr);

    lista.usun(gosc(imie,nazwisko,pkj_ptr,czas));
    pkj_ptr->stan='p';
    pkj_ptr=0;
    gosc_ptr=0;
   }
  else cout << " Osoba " << imie << " " << nazwisko
	    << komunikat << nr_pkj << endl;
}


long potega (int podst,int wykl)
{
 long iloczyn=1;
 for (int i=1; i<=wykl ; i++)
  iloczyn=iloczyn*podst;
 return iloczyn;
}

void konfiguracja()
{
 int l_kat;
 int l_ptr;
 int l_pkj;
 float cena;
 char string[80];
 ofstream plik("setup2.htl");

 cout << "Podaj liczbe kategorii :";
 cin >> l_kat;
 char str[80][80];

 for (int i=0;i<l_kat;i++)
 {
  cout << "Podaj nazwe kategorii: ";
  cin >> str[i];
  plik << "kategoria: " << str[i] << endl;
  cout << "Podaj cene: ";
  cin  >> cena;
  plik << "cena: " << cena << " ";
  cout << "Podaj opis kategorii w [ ] :";
  cin >> string;
  cin >> string;
  while (strcmp(string,"]")!=0)
  {
   plik << string << " ";
   cin >> string;
  }
  plik << endl;
 }

 cout << "Podaj ilosc pieter :" ;
 cin >> l_ptr;

 for (i=1;i<=l_ptr;i++)
 {
  cout << "pietro: " << i << endl;
  plik << endl << "pietro: " << i << endl;
  for (int n=0;n<l_kat;n++)
   {
    cout << "Podaj ilosc pokoii kat. " << str[n] << " : ";
    cin >> l_pkj;
    if (l_pkj>0) plik << "ilosc: " << l_pkj << " kat: " << str[n] << endl;
   }
 }

 plik << endl <<"koniec" << endl;
 plik.close();
}

void info()
{
 ifstream plik("setup.htl");
 char pom[80];

 while (strcmp(strcpy(pom,getstr(plik)),"pietro:")!=0)
 {
  if (strcmp(pom,"kategoria:")==0)
   {
    cout << endl << pom << " " << getstr(plik) << endl;
   }
  else cout << pom << " ";
 }
}
