#include <iostream.h>
#include <string.h>
#include "struct.h"
/******************************* struct pokoj *******************************/

pokoj::pokoj (int n_pr,int n_pk,char * k,char s)
{
 nr_ptr=n_pr;
 nr_pkj=n_pk;
 strcpy((kat=new char [strlen(k)+1]),k);
 stan=s;
}

pokoj::pokoj (pokoj & p)
{
 nr_ptr=p.nr_ptr;
 nr_pkj=p.nr_pkj;
 strcpy((kat=new char [strlen(p.kat)+1]),p.kat);
 stan=p.stan;
}

pokoj pokoj::operator = (pokoj &p)
{
 nr_ptr=p.nr_ptr;
 nr_pkj=p.nr_pkj;
 if (kat) delete [] kat;
 strcpy((kat=new char [strlen(p.kat)+1]),p.kat);
 stan=p.stan;
 return *this;
}

pokoj::~pokoj()
{
 delete [] kat;
}

ostream & operator << (ostream & cel,pokoj & p)
{
 cel << p.nr_ptr << " " ;
 cel << p.nr_pkj << " " ;
 cel << p.kat << " " ;
 cel << p.stan << " \t" ;
 return cel;
}

int pokoj::operator == (pokoj p)
{
  if (nr_pkj==p.nr_pkj)
   if (stan==p.stan)
    return 1;
  return 0;
}

/****************************** struct gosc *********************************/

gosc::gosc (char *im,char *na,pokoj *pk,float cz)
{
 strcpy((imie=new char[strlen(im)+1]),im);
 strcpy((nazwisko=new char[strlen(na)+1]),na);
 pkj_ptr=pk;
 czas=cz;
}

gosc::gosc (gosc & g)
{
 strcpy((imie=new char[strlen(g.imie)+1]),g.imie);
 strcpy((nazwisko=new char[strlen(g.nazwisko)+1]),g.nazwisko);
 pkj_ptr=g.pkj_ptr;
 czas=g.czas;
}

gosc gosc::operator = (gosc &g)
{
 delete [] imie;
 delete [] nazwisko;
 strcpy(imie=new char[strlen(g.imie)+1],g.imie);
 strcpy(nazwisko=new char[strlen(g.nazwisko)+1],g.nazwisko);
 pkj_ptr=g.pkj_ptr;
 czas=g.czas;
 return *this;
}

gosc::~gosc()
{
 delete [] imie;
 delete [] nazwisko;
}

ostream & operator << (ostream & cel,gosc & g)
{
 cel << "\nImie : "     << g.imie              << "\n";
 cel << "Nazwisko : "   << g.nazwisko          << "\n";
 cel << "Nr. pokoju : " << g.pkj_ptr->nr_pkj   << "\n";
 cel << "Nr. pietra : " << g.pkj_ptr->nr_ptr   << "\n";
 cel << "Czas : "       << g.czas              << "\n";
 return cel;
}

int gosc::operator == (gosc g)
{
 if (strcmp(imie,g.imie)==0)
  if (strcmp(nazwisko,g.nazwisko)==0)
   if (pkj_ptr==g.pkj_ptr)
    return 1;
 return 0;
}
