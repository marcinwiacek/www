#include <iostream.h>

struct pokoj
{
 int nr_ptr;
 int nr_pkj;
 char *kat;
 char stan;
 pokoj (int n_pr,int n_pk,char * k,char s='p');
 pokoj (pokoj & p);
 pokoj () {nr_ptr=-1;nr_pkj=-1;stan='p';strcpy((kat=new char[1]),"");}
 ~pokoj ();
 int operator == (pokoj p);
 pokoj operator = (pokoj &p);
 friend ostream & operator << (ostream & cel,pokoj & p);
};

struct gosc
{
 char *imie;
 char *nazwisko;
 pokoj * pkj_ptr;
 float czas;
 gosc (char *im,char *na,pokoj *pkj_ptr,float cz=0);
 gosc () {czas=-1;strcpy((imie=new char[1]),"");
	  strcpy((nazwisko=new char[1]),"");pkj_ptr=0;}
 gosc (gosc &g);
 ~gosc ();
 int operator == (gosc g);
 gosc operator = (gosc &g);
 friend ostream & operator << (ostream & cel,gosc & g);
};

/******************************* wzorzec listy ******************************/
template <class T>
class lista
{
 public:

 struct el_listy
 {
  T element;
  el_listy *nast;
 } *glowa,*ogon;

 lista() {glowa=ogon=NULL;}
 lista(lista &);
 ~lista();
 void dolacz(T element);
 int usun(T element);
 T * szukaj(T element);
 friend ostream& operator << (ostream &cel,lista<T> &l);
};

template <class T> lista<T>::lista(lista<T> &ref_li)
{
 glowa=ogon=0;
 el_listy *pomoc=ref_li.glowa;

 while (pomoc!=0)
 {
  dolacz(pomoc->element);
  pomoc=pomoc->nast;
 }
}

template <class T> void lista<T>::~lista()
{
 while (glowa->nast!=NULL)
 {
  delete glowa;
  glowa=glowa->nast;
 }
}

template <class T> void lista<T>::dolacz(T element)
{
 el_listy *pomoc=new el_listy;
 pomoc->nast=0;
 pomoc->element=element;

 if (glowa==0) {glowa=ogon=pomoc;}
 else
    {
     ogon->nast=pomoc;
     ogon=ogon->nast;
    }
}

template <class T> int lista<T>::usun(T element)
{
 el_listy *poprzedni=glowa;
 el_listy *nastepny=poprzedni->nast;
 if (glowa->element==element)
  {
   glowa=glowa->nast;
   delete poprzedni;
   return 1;
  }
 else
 while (nastepny!=0)
  {
   if (nastepny->element==element)
   {
    poprzedni->nast=nastepny->nast;
    if (poprzedni->nast==0) ogon=poprzedni;
    delete nastepny;
    return 1;
   }
   nastepny=nastepny->nast;
   poprzedni=poprzedni->nast;
  }
 return 0;
}

template <class T> T * lista<T>::szukaj(T element)
{
 el_listy *pomoc=glowa;

 while(pomoc!=NULL)
  {
   if (pomoc->element==element) return &pomoc->element;
   pomoc=pomoc->nast;
  }
 return NULL;
}

template <class T> ostream & operator << (ostream & cel,lista<T> &l)
{
 l.ogon=l.glowa;
 if (l.ogon!=0)
 {
 while (l.ogon->nast!=NULL)
 {
  cout << l.ogon->element;
  l.ogon=l.ogon->nast;
 }
 cout << l.ogon->element;
 }
 else cout << "Lista jest pusta !\n";
 return cel;
}
