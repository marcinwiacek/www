#include "run.h"

void sortuj_karty(struct karta *reka)
{
 int a,c,d;
 struct karta b;
 
 for(d=0;d!=5;d++) 
 for(a=0;a!=5;a++)
      for (c=(a+1);c!=5;c++)
          if (reka[a].figura>reka[c].figura) 
	      {
	       b=reka[a];
	       reka[a]=reka[c];
	       reka[c]=b;
	       break;
	      };    
}

void losowanie(struct karta *gracz,struct karta *talia,int ktora)
{
 int l;
 
 do l=rand() % 23;
 while (talia[l].figura==0);
 
 gracz[ktora]=talia[l];
 talia[l].figura=0;
}

void wymiana_kart(struct karta *reka,struct karta *talia,int wartosc)
{
 int x;
 
 if (wartosc<300) {
		   for(x=0;x!=5;x++) losowanie(reka,talia,x);
		   return; 
                  }
		  
 if (wartosc<600) for(x=0;x!=5;x++) if (wymien[x]==1) losowanie(reka,talia,x);
}

