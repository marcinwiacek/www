

int czy_strit(struct karta *reka);
int czy_kolor(struct karta *reka);
int czy_kareta(struct karta *reka);
int czy_para(struct karta *reka,int nr_1,int nr_2);
int czy_trojka_full(struct karta *reka);
int sprawdzanie(struct karta *reka);

