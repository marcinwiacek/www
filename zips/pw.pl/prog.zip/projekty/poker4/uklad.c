#include "run.h"
#include "stdlib.h"

const char *figura_c[] = {"9\0","10\0","Walet\0","Dama\0","Krol\0","As\0"};
const char *kolor_c[] = {"Kier\0","Karo\0","Trefl\0","Pik\0"};

void wyswietl_karty(struct karta *reka)
{          
 int x;
 
 for (x=0;x!=5;x++) printf("%d. %s-%s\n",x+1,figura_c[reka[x].figura-1],kolor_c[reka[x].kolor-1]);
 return;
}

void uklad_kart(int wartosc)
{ 
 div_t temp,temp1;
 const char *strit[] = {"Maly Strit\0","Duzy Strit\0"};
 const char *poker[] = {"Maly Poker\0","Duzy Poker\0"};
 
 temp=div(wartosc,100);
 --temp.rem;
  
 switch (temp.quot) {
  case 0 : {
            printf("Kolor najstarszej karty : %s\n",kolor_c[temp.rem]);
 	    break;
 	   }
  case 3 : {
            printf("Para : %s\n",figura_c[temp.rem]);
	    break;
           }
  case 4 : {
            temp=div(temp.rem,10);
	    --temp.quot;
            printf("Dwie Pary : %s/%s\n",figura_c[temp.quot],figura_c[temp.rem]);
	    break;
	   }    
  case 5 : {
            printf("Trojka : %s\n",figura_c[temp.rem]);
	    break;
           }
  case 6 : {
            temp=div(temp.rem,10);
	    --temp.quot;
	    printf("%s\n",strit[temp.quot]);
	    break;
           }
  case 7 : {
            printf("Kolor : %s\n",kolor_c[temp.rem]);
	    break;
           }
  case 8 : {
            printf("Full : %s\n",figura_c[temp.rem]);
	    break;
	   }    
  case 9 : {
            printf("Kareta : %s\n",figura_c[temp.rem]);
	    break;
	   }
  default : {
             temp=div(temp.quot,100);
	     temp.quot=temp.rem/10;
	     printf("%s\n",poker[--temp.quot]);
	     break;
	    }  
  }		  
}
