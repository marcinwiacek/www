
void sortuj_karty(struct karta *reka);
void losowanie(struct karta *gracz,struct karta *talia,int ktora);
void wymiana_kart(struct karta *reka,struct karta *talia,int wartosc);

