extern struct karta {
        int figura;
        int kolor; };  
extern struct karta talia_p[];
extern int wymien[];


