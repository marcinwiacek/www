#include <stdio.h>
#include <time.h>
#include "run.h"
#include "karty.h"
#include "spr.h"
#include "uklad.h"

extern struct karta talia_p[] = {1,1, 2,1, 3,1, 4,1, 5,1, 6,1,
                                 1,2, 2,2, 3,2, 4,2, 5,2, 6,2,                         
                                 1,3, 2,3, 3,3, 4,3, 5,3, 6,3,                       
                                 1,4, 2,4, 3,4, 4,4, 5,4, 6,4};
extern int wymien[] = {0,0,0,0,0};

void tryb_dodatkowy()
{
int x,y,l,l1,wartosc_1;
struct karta gracz_1[4];

system("clear");
printf("Tryb dodatkowy\n");
printf("---------------\n\n");
printf("Oznaczenia kart: 1-dziewiatka, 2-dziesiatka, 3-Walet, 4-Dama, 5-Krol, 6-As\n");
printf("Oznaczenia kolorow: 1-Kier, 2-Karo, 3-Trefl, 4-Pik\n");
for (x=0;x<5;x++) {
	            printf("\nKarta nr. %d\n",x+1);
		    
		    do {
			do { 
			    printf("Figura: ");
			    scanf("%d",&l);
			   } while (l<1 || l>6);
			do {
			    printf("Kolor: ");
			    scanf("%d",&l1);
			   } while (l1<1 || l1>4);
			for(y=0;y!=24;y++)
			    if ((talia_p[y].figura==l) && (talia_p[y].kolor==l1))
				{
			         talia_p[y].kolor=talia_p[y].figura=0;
			         y=0;
			         break;
				}
			if (y!=0) printf("Ta karta juz byla ! wprowadz jeszcze raz !\n");  
		       } while (y!=0); 
		      
		       gracz_1[x].figura=l;
		       gracz_1[x].kolor=l1;  
		  }
		  
sortuj_karty(&gracz_1[0]);
system("clear");
printf("Twoje karty to:\n");
wyswietl_karty(&gracz_1[0]);
	     
wartosc_1=sprawdzanie(&gracz_1[0]);
for (x=0;x!=5;x++) if (wymien[x]==1)
   {                                       
    printf("\nNumery kart ktore powinienes wymienic to: ");
    for (y=0;y!=5;y++) if (wymien[y]==1) printf("%d ",y+1);
    printf("\n");
    break;
   }
if (x==5) 
   {
    printf("\nNic nie powinienes wymienic, twoj uklad kart to - ");
    uklad_kart(wartosc_1);
   }	                
printf("\n");    
}

void tryb_zwykly()
{
 static char *kto[] = {"Punkt dla mnie\0","Punkt dla Ciebie\0"};
 int x,l,m_punkty;
 int punkty_1=0,punkty_2=0;
 int rozdanie = 0;
 int wartosc_1=0,wartosc_2=0;
 char znak;
 struct karta gracz_1[5];
 struct karta gracz_1_s[5];
 struct karta gracz_2[5];
 struct karta talia[24];
 time_t tt;
 
 time(&tt);
 srand(tt);   /*incjalizacja generatora liczb losowych*/
  
 system("clear");	
 printf("Podaj ilosc punktow: ");
 scanf("%d",&m_punkty);
 
 while ((punkty_1!=m_punkty) && (punkty_2!=m_punkty))
 {
 for(x=0;x!=24;x++) talia[x]=talia_p[x]; /*reset*/
 for(x=0;x!=5;x++) wymien[x]=0; 
 ++rozdanie;

 system("clear");
 printf("Wynik %d:%d\n",punkty_1,punkty_2);
 printf("-----------\n");
	
 for(x=0;x!=5;x++)
 losowanie(&gracz_1[0],&talia[0],x); /*dla kompa*/
 for(x=0;x!=5;x++) losowanie(&gracz_2[0],&talia[0],x);
 /*dla gracza*/
 
 sortuj_karty(&gracz_1[0]); 
 sortuj_karty(&gracz_2[0]);

 for(x=0;x!=5;x++) gracz_1_s[x]=gracz_1[x];  /*zapamietanie kart przed wymiana*/
 		
 printf("Partia nr: %d\n",rozdanie);
 printf("-------------\n\n");
 printf("Twoje karty: \n\n");
 
 wyswietl_karty(&gracz_2[0]); 
 printf("\nKtore karty wymieniasz ? (ENTER - koniec) :\n");
            
 x=0;
 fflush(stdin);
 while ((znak!=10) && (x!=5))
    {
     znak=getchar();
     fflush(stdin);
     if (znak>48 && znak<54) wymien[znak-49]=1;  
     ++x;
    }
 
 wymiana_kart(&gracz_2[0],&talia[0],500); /*wymiana i sprawdzenie dla gracza*/
 sortuj_karty(&gracz_2[0]);
 wartosc_2=sprawdzanie(&gracz_2[0]);
 
 wartosc_1=sprawdzanie(&gracz_1[0]);      /*wymiana i sprawdzanie kompa*/
 wymiana_kart(&gracz_1[0],&talia[0],wartosc_1);
 sortuj_karty(&gracz_1[0]);
 wartosc_1=sprawdzanie(&gracz_1[0]);
 
 system("clear");
 l=0;
 if (wartosc_1==wartosc_2) {         /*dodatkow porownanie dla remisu*/
                            for(x=0;x!=5;x++)
			      { 
			       if (gracz_1[x].figura>gracz_2[x].figura) 
			 	     {
				      ++punkty_1;
				      --x; /*zeby if(x=4) nie bylo gdy roznia sie wlasnie na 4 pozycji*/
				      break;
				     }
			       if (gracz_1[x].figura<gracz_2[x].figura)
			             {
				      ++punkty_2;
				      l=1;
				      --x;
				      break;
				     } 
			      }	      
			    if(x=4) 
				{
				 if(gracz_1[4].kolor>gracz_2[4].kolor) 
				    ++punkty_1;
				 else
				    {
				     ++punkty_2;
				     l=1;
				    }  
				 }    
                           }
 
 if (wartosc_1>wartosc_2) ++punkty_1;
 if (wartosc_1<wartosc_2) {
                           ++punkty_2;
			   l=1;
			  } 
 
 printf(kto[l]); /*ogloszenie kto wygral*/
 printf("             Wynik %d:%d",punkty_1,punkty_2);
 printf("          Nacisnij dowolny klawisz ...\n");
 printf("Twoje karty po wymianie: \n");
 wyswietl_karty(&gracz_2[0]);
 uklad_kart(wartosc_2);
 
 printf("\nMoje karty przed wymiana: \n");
 wyswietl_karty(&gracz_1_s[0]);
 
 printf("\nMoje karty po wymianie: \n");
 wyswietl_karty(&gracz_1[0]);
 uklad_kart(wartosc_1);

 fflush(stdin);
 getchar();           /*czekaj na klawisz*/
 znak=0;
 }
 
 system("clear");
 if (m_punkty==punkty_1) printf("Wygralem !!!\n\n");
 else printf("Wygrales !!!\n\n");
			   
 printf("Ilosc rozegranych partii: %d\n",rozdanie);
 printf("Ilosc partii wygranych przez Ciebie: %d\n",punkty_2);
 printf("Ilosc partii wygranych przeze mnie : %d\n\n",punkty_1); 
}

main (int argc, char *argv[])
{ 
 if (argc==2) tryb_dodatkowy();
 else tryb_zwykly();
}
