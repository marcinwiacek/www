

void wyswietl_karty(struct karta *reka);
void uklad_kart(int wartosc);
