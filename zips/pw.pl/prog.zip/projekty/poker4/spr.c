#include "run.h"

int czy_strit(struct karta *reka)  /*zwraca 0 - nie strit lub wartosc strita*/ 
{
 int temp;
  if ((reka[0].figura==1) && (reka[1].figura==2) && (reka[2].figura==3) &&
     (reka[3].figura==4) && (reka[4].figura==5)) 
         {
	  temp=610+reka[4].kolor;
	  return temp;
	 }
 if ((reka[0].figura==2) && (reka[1].figura==3) && (reka[2].figura==4) &&
     (reka[3].figura==5) && (reka[4].figura==6))
         {
	  temp=620+reka[4].kolor;
	  return temp;
	 }
 return 0;  
}

int czy_kolor(struct karta *reka) /*zwraca 0 - nie kolor lub wartosc koloru*/
{
 int temp=0;
 
 if ((reka[0].kolor==reka[1].kolor) && (reka[1].kolor==reka[2].kolor) &&
     (reka[2].kolor==reka[3].kolor) && (reka[3].kolor==reka[4].kolor))
	  temp=700+reka[0].kolor;
 return temp;
}

int czy_kareta(struct karta *reka) /*zwraca 0 - nie kareta lub wartosc karety*/
{
 int temp=0;
 
 if (((reka[0].figura==reka[1].figura) && (reka[1].figura==reka[2].figura) &&
      (reka[2].figura==reka[3].figura)) ||
     ((reka[1].figura==reka[2].figura) && (reka[2].figura==reka[3].figura) &&
      (reka[3].figura==reka[4].figura))) temp=900+reka[2].figura;
 return temp;
}

int czy_para(struct karta *reka,int nr_1,int nr_2) /* zwraca 0 - nie para lub wartosc pary*/
{
 int temp=0;
 if (reka[nr_1].figura==reka[nr_2].figura) 
     {
      temp=300+reka[nr_1].figura;
      wymien[nr_1]=wymien[nr_2]=0;
     }					    
 
 return temp;
}

int czy_trojka_full(struct karta *reka) /*zwraca 0 -nie trojka lub wartosc trojki lub fulla*/
{
 int temp=0;
 if ((reka[0].figura==reka[1].figura) && (reka[1].figura==reka[2].figura)) 
     {
      temp=500+reka[0].figura;
      if (czy_para(reka,3,4)) temp=800+reka[0].figura;
      else wymien[3]=wymien[4]=1;
     } 
 if ((reka[2].figura==reka[3].figura) && (reka[3].figura==reka[4].figura))
     {
      temp=500+reka[2].figura;
      if (czy_para(reka,0,1)) temp=800+reka[2].figura;
      else wymien[0]=wymien[1]=1;
     } 
 if ((reka[1].figura==reka[2].figura) && (reka[2].figura==reka[3].figura))
     {
      temp=500+reka[1].figura;
      wymien[0]=wymien[4]=1;
     }  	 
 return temp;
}

int sprawdzanie(struct karta *reka)
{
 int temp=0,temp1=0,x;
 if ((reka[0].figura!=reka[1].figura) && (reka[1].figura!=reka[2].figura) &&
     (reka[2].figura!=reka[3].figura) && (reka[3].figura!=reka[4].figura))
         {
	  if(temp=czy_strit(reka)) {
	                            if(czy_kolor(reka)) temp=(temp*100);
				    return temp;
				   }
	  if(temp=czy_kolor(reka)) return temp;
	  for (temp=0;temp!=5;temp++) wymien[temp]=1; /*nic ... wszystko do wymiany*/
	  return reka[4].kolor;
	 }
 if((temp=czy_kareta(reka))==0) {
				 if((temp=czy_trojka_full(reka))==0)
				  {
				   for(x=0;x!=5;x++) wymien[x]=1;
				   if(temp1=czy_para(reka,0,1))
				    { 
				     if((temp=czy_para(reka,2,3))==0)
				          if((temp=czy_para(reka,3,4))==0)
				            return temp1; 
				     return (400+(10*reka[3].figura)+reka[1].figura);       
				    }
				   if(temp1=czy_para(reka,1,2))
				    { 
				     if((temp=czy_para(reka,3,4))==0)
				      return temp1; 
				     return (400+(10*reka[3].figura)+reka[1].figura); 
				    }
				   if((temp1=czy_para(reka,2,3)) || 	 
				      (temp1=czy_para(reka,3,4))) 
				        return temp1;
				   return 0;	 
				  }
				  return temp;    	    
				 }  					  
 return temp;
}

