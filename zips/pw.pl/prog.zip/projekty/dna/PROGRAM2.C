/* "Badanie lancuchow DNA"  projekt:Konrad Stefanski 2P16 */
#include<stdio.h>

/* deklaracja zmiennych globalnych oraz tablic */
 char a[1000],b[1000],c[1000],d[1000];
 int at,cg,gc,ta,e,k,l,m,p,q,r,w,x,y,z,pomoc;

/* deklaracja funkcjii revdna() badajacej lancuch DNA */
void revdna(int z)
/* sprawdzanie wystepowania polaczen */
 {
 ta=0;cg=0;r=0;

/* przepisanie tablicy a[] do c[] */
 p=0;
 do
   { c[p]=a[p]; p=p+1; }
 while(a[p]!='\0');
 c[p]='\0';

/* przepisanie tablicy b[] do d[] */
 q=0;
 do
   { d[q]=b[q]; q=q+1; }
   while(b[q]!='\0');
   d[q]='\0';

/* przesuwanie elementow tablicy c[] w lewo o wartosc z */
   w=l-z;x=0;
   do
     { c[x]=c[x+z]; x=x+1; }
   while(a[x]!='\0');

/* przesuwanie elementow tablicy d[] w prawo o warosc w */
   y=0;
   do
   { d[y]=d[y+w]; y=y+1; }
   while(d[y]!='\0');

/* sprawdzanie wystepowania polaczen dla kazdego kroku zawiniecia */
   do
     {
     if((c[r]=='a')&&(d[r]=='t'))
       { at=at+1;ta=ta+1; }
     if((c[r]=='t')&&(d[r]=='a'))
       { at=at+1;ta=ta+1; }
     if((c[r]=='g')&&(d[r]=='c'))
       { gc=gc+1;cg=cg+1; }
     if((c[r]=='c')&&(d[r]=='g'))
       { gc=gc+1;cg=cg+1; }
     r=r+1;
     }
   while((c[r]!='\0')||(d[r]!='\0'));
   z=z+1;

/* prezentacja wynikow dla kazdego kroku zawiniecia */
  printf("\n%s\n",c); printf("%s\n",d);
  if((ta>0)||(cg>0))
  printf(" Wykryto polaczenia: a-t:%d g-c:%d \n\n",ta,cg);

/* sprawdzanie warunku z!=l ,jesli nie jest spelniony to funkcja revdna()
   wywola rekurencyjnie sama siebie z parametrem z                        */
 if (z!=l) revdna(z);
 }

/*      program glowny      */
 main()
 {
/* nadawanie wartosci poczatkowych zmiennym */
 do
 {
 at=0;cg=0;gc=0;ta=0;l=-1;k=-1;p=0;q=0;r=0;w=0;x=0;y=0;z=1;

/* poczatek wykonywania programu */
 printf("\n\n   BADANIE LANCUCHA DNA  \n");
 printf("  projekt: Konrad Stefanski 2P16   \n\n");
 printf("  W lancuchach DNA wystepuja cztery kwasy: \n");
 printf("  adynina,tymina,guanina,cytozyna.\n");
 printf("  Podczas wpisywania lancucha\n");
 printf("  podawaj tylko pierwsze litery z nazw kwasow\n");
 printf("  a wiec: (a), (t), (g) lub (c) .\n\n");
 printf("Wpisz lancuch DNA :");
 scanf("%s",a); /* wpisywanie lancucha do tablicy a[] */

/* obliczanie ilosci znakow we wpisanym lancuchu */
   e=0;
  while((a[e]=='a')||(a[e]=='t')||(a[e]=='c')||(a[e]=='g'))
   { e=e+1; }
  do
  l=l+1;
  while(a[l]!='\0');
  m=l;

/* przepisanie tablicy a[] do tablicy b[] w odwrotnej kolejnosci */
  do
  {
  --m;++k; b[k]=a[m];
  }
  while(m!=0);
  b[l]='\0';
/* sprawdzanie poprawnosci wpisanego lancucha */
  if(e<l)
  { printf("\a\n\n WPISALES NIEODPOWIEDNIE ZNAKI !!! \n");pomoc=0; }
  else
   {
   pomoc=1;
   revdna(z); /* wywolanie funkcji revdna() z parametrem zaleznym od zmiennej z */

/* prezentacja wyniku koncowego */
   printf("\n%s\n",b);
   printf(" W sumie wykryto :\n");
   printf(" %d polaczen adynina-tymina i %d polaczen guanina-cytozyna.  \n",at,gc);
   }
 }
 while(pomoc!=1);
 }
