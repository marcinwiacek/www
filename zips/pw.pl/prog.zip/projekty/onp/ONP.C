/* onp.c: deficja funkcji onp () przeksztalcajacej wyrazenie do odwrotnej
   notacji polskiej oraz pomocniczych funkcji uzywanych do jej
   implementacji */

#include <stdio.h>
#include "symbol.h"

/* onp (void): zamienia wyrazenie z wejscia na ONP
   Zwraca: 0 jesli wyrazenie poprawne albo -1 jesli wystapi blad
   Efekty uboczne: czyta ze standardowego wejscia wyrazenie arytmetyczne
                   zawierajace liczby calkowite, litery (zmienne),
                   operatory +,-,*,/ i nawiasy oraz zapisuje na standardowe
                   wyjscie rownowazne wyrazenie w ONP
   Implementacja: metoda rekurencyjnie zstepujaca realizowana przez
                  pomocnicze funkcje wyrazenie (), skladnik () i czynnik () */
int onp (void)
{
  struct Symbol sym;
  return wyrazenie (pobierz_symbol (&sym));
}


/* wyrazenie (sym): zamienia wyrazenie na ONP
   Argumenty:
     sym --- wskaznik na aktualny symbol wejsciowy
   Zwraca: -1 jesli wystapi blad i 0 w przeciwnym przypadku
   Efekty uboczne: czyta kolejne symbole wejsciowe i po rozpoznaniu
                   wyrazenia zapisuje je na wyjscie w ONP
   Implementacja: rozpoznaje wyrazenie zgodnie ze skladnia
                  ['+' | '-'] <skladnik> {('+' | '-') <skladnik>} */
int wyrazenie (struct Symbol *sym)
{
  char z = '\0'; /* poczatkowy znak */
  if (sym->rodzaj == OPADD)
  {
    z = sym->znak;
    pobierz_symbol (sym);
  }

  if (skladnik (sym) == -1) /* zamien na ONP pierwszy skladnik wyrazenia */
    return -1;
  if (z)
    printf ("%c ", z); /* zapisz poczatkowy znak */
  while (sym->rodzaj == OPADD)
  {
    char op = sym->znak;
    pobierz_symbol (sym);
    if (skladnik (sym) == -1) /* zamien na ONP kolejny skladnik wyrazenia */
      return -1;
    printf ("%c ",  op); /* zapisz operator */
  }
  return 0;
}


/* skladnik (sym): zamienia skladnik na ONP
   Argumenty:
     sym --- wskaznik na aktualny symbol wejsciowy
   Zwraca: -1 jesli wystapi blad i 0 w przeciwnym przypadku
   Efekty uboczne: czyta kolejne symbole wejsciowe i po rozpoznaniu
                   skladnika zapisuje go na wyjscie w ONP
   Implementacja: rozpoznaje skladnik zgodnie ze skladnia
                  <czynnik> {('*' | '/') <czynnik>} */
int skladnik (struct Symbol *sym)
{
  if (czynnik (sym) == -1) /* zamien na ONP pierwszy czynnik skladnika */
    return -1;
  while (sym->rodzaj == OPMULT)
  {
    char op = sym->znak;
    pobierz_symbol (sym);
    if (czynnik (sym) == -1) /* zamien na ONP kolejny czynnik skladnika */
      return -1;
    printf ("%c ", op); /* zapisz operator */
  }
  return 0;
}


/* czynnik (sym): zamienia czynnik na ONP
   Argumenty:
     sym --- wskaznik na aktualny symbol wejsciowy
   Zwraca: -1 jesli wystapi blad i 0 w przeciwnym przypadku
   Efekty uboczne: czyta kolejne symbole wejsciowe i po rozpoznaniu
                   czynnika zapisuje go na wyjscie w ONP
   Implementacja: rozpoznaje czynnik zgodnie ze skladnia
                  "zmienna" | <"liczba" | '(' <wyrazenie> ')' */
int czynnik (struct Symbol *sym)
{
  switch (sym->rodzaj)
  {
  case LICZBA:
    printf ("%d ", sym->liczba);
    pobierz_symbol (sym);
    break;
    
  case ZMIENNA:
    printf ("%c ", sym->znak);
    pobierz_symbol (sym);
    break;

  case LNAWIAS:
    pobierz_symbol (sym); /* pomin lewy nawias */
    if (wyrazenie (sym) == -1)
      return -1;
    if (sym->rodzaj != PNAWIAS)
      return -1;
    pobierz_symbol (sym); /* pomin prawy nawias */
    break;

  default:
    return -1;
  }
  return 0;
}
