/* main.c: definicja funkcji main () */

#include <stdio.h>
#include "onp.h"

int main ()
{
  printf ("Niepoprawne wyrazenie konczy dzialanie\n");
  while (onp () != -1)
    putchar ('\n');
  
  fprintf (stderr, "Bledne wyrazenie\n");
  return 0;
}
