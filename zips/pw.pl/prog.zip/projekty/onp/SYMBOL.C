#include <stdio.h>
#include <ctype.h>
#include "symbol.h"

/* pobierz_symbol (sym): pobiera z wejscia nastepny symbol
   Argumenty:
     sym --- wskaznik na strukture opisujaca symbol
   Zwraca: sym
   Efekty uboczne: po pominieciu odstepow czyta ze standardowego
                   wejscia maksymalny ciag znakow, ktory moze byc
                   interpretowany jako symbol (ale nie dalej niz do konca
                   wiersza) i wypelnia odpowiednio pola struktury
                   wskazywanej przez sym */
struct Symbol *pobierz_symbol (struct Symbol *sym)
{
  int c;
  while (isspace (c = getchar ()) && c != '\n') /* stop jesli nowa linia */
    ;

  sym->znak = c;
  if (isalpha (c)) /* litera to zmienna */
  {
    sym->rodzaj = ZMIENNA;
    sym->znak = c;
  }
  else if (isdigit (c)) /* cyfra rozpoczyna liczbe */
  {
    sym->rodzaj = LICZBA;
    ungetc (c, stdin); /* cofnij na wejscie pierwsza cyfre */
    scanf ("%d", &sym->liczba);
  }
  else if (c == '+' || c == '-')
    sym->rodzaj = OPADD;
  else if (c == '*' || c == '/')
    sym->rodzaj = OPMULT;
  else if (c == '(')
    sym->rodzaj = LNAWIAS;
  else if (c == ')')
    sym->rodzaj = PNAWIAS;
  else
    sym->rodzaj = NIEZNANY;

  return sym;
}
