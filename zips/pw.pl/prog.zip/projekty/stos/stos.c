#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>

#define INT 0
#define FLOAT 1
#define CHAR 2
#define STRING 3

#define LENGTH 100
#define LENGTH2 20
#define NAME 20

typedef union 
{
 int calk;
 float rzecz;
 char znak;
 char lanc[LENGTH];
} unia;

typedef struct znacznik_wezla
{
 struct znacznik_wezla *nastepny;
 unia dana;
 int rodzaj;
} wezel;

wezel *na_stos(unia dana_, int rodzaj_, wezel *szczyt_)
{
 wezel *wezel_=(wezel *)malloc(sizeof *szczyt_);
 wezel_->dana=dana_;
 wezel_->rodzaj=rodzaj_;
 wezel_->nastepny=szczyt_;
 return wezel_;
}

wezel *ze_stosu(unia *dana_,int *rodzaj_, wezel *szczyt_)
{
 if (szczyt_)
 { 
  wezel *wezel_=szczyt_->nastepny;
  *dana_=szczyt_->dana;
  *rodzaj_=szczyt_->rodzaj;
  free(szczyt_);
  return wezel_;
 }
 else return NULL;
}

wezel *szczyt=NULL;

int na_stos_()
{
 int wyjscie=1,l=8;
 char tmp[LENGTH2],*ok;
 double tmpd;
 unia dana;
 clear();
 do 
 { 
  (l<24) ? (l++) : ({clear(); l=8;});  
  mvprintw(1,2,"Odloz na stos:");
  mvprintw(3,3,"1 - liczbe calkowita");
  mvprintw(4,3,"2 - liczbe rzeczywista");
  mvprintw(5,3,"3 - pojedynczy znak ");
  mvprintw(6,3,"4 - lancuch znakow");
  mvprintw(8,1,"powrot - podwojny Esc");
  noecho();
  switch (getch())
  {
   case '1': 
     mvprintw(l,1,"wprowadz liczbe calkowita do odlozenia na stos: "); 
     echo(); 
     mvscanw(l,50,"%s",tmp); 
     dana.calk=(int)strtol(tmp,&ok,10); 
     if (ok[0]!=0) mvprintw(++l,1,"wprowadzono bledne dane!"); 
     else szczyt=na_stos(dana,INT,szczyt); 
     break;
   case '2': 
     mvprintw(l,1,"wprowadz liczbe rzeczywista do odlozenia na stos: "); 
     echo(); 
     mvscanw(l,52,"%s",tmp);
     dana.rzecz=(float)strtod(tmp,&ok); 
     if (ok[0]!=0) mvprintw(++l,1,"wprowadzono bledne dane!"); 
     else
     szczyt=na_stos(dana,FLOAT,szczyt); 
     break;
   case '3': 
     mvprintw(l,1,"wprowadz znak do odlozenia na stos: "); 
     echo(); 
     dana.znak=getch(); 
     szczyt=na_stos(dana,CHAR,szczyt); 
     break;
   case '4':
     mvprintw(l,1,"wprowadz lancuch do odlozenia na stos: "); 
     echo();
     mvscanw(++l,1,"%s",dana.lanc); 
     szczyt=na_stos(dana,STRING,szczyt); 
     break;
   case  27: 
     if (getch()==27) wyjscie=0;
  }
 }
 while (wyjscie);
}

int wyswietl()
{
 wezel *szczyt_=szczyt;
 unia dana;
 int typ,l=2;
 clear();
 mvprintw(1,2,"Zawartosc stosu:");
 do 
 {
  (l<20) ? (l++) : ({mvprintw(l+2,1,"dowolny klawisz - dalej"); getch(); clear(); l=2;});  
  if (szczyt_)
  { 
   wezel *_wezel_=szczyt_->nastepny;
   dana=szczyt_->dana;
   typ=szczyt_->rodzaj;
   szczyt_=_wezel_;
   switch (typ)
   {
    case INT: mvprintw(l,2," l. calk.:  %i",dana.calk); break;
    case FLOAT: mvprintw(l,2,"l. rzecz.:  %f",dana.rzecz); break;
    case CHAR: mvprintw(l,2,"     znak:  %c",dana.znak); break;
    case STRING: mvprintw(l,2,"  lancuch:  %s",dana.lanc); break;
   }              
  }
  else if (!(szczyt)) mvprintw(l,2,"stos jest pusty");
 }
 while (szczyt_);
 mvprintw(l+3,3,"nacisnij cos");
 getch();
}

int ze_stosu_(int tryb)
{
 int wyjscie=1,typ,l=7;
 unia dana;
 if (!(tryb))
 {
  clear();
  do 
  {
   (l<24) ? (l++) : ({clear(); l=7;}); 
   mvprintw(1,2,"Menu:");
   mvprintw(3,3,"1 - usun z wierzchu");
   mvprintw(4,3,"2 - usun caly stos");  
   mvprintw(6,1,"powrot - podwojny Esc");
   noecho();
   switch (getch())
   {
    case '1':
      if (!(szczyt)) mvprintw(l,1,"stos jest pusty");
      else 
      {
       szczyt=ze_stosu(&dana,&typ,szczyt);
       switch (typ)
       {
        case INT: mvprintw(l,1,"zdjeto ze stosu liczbe calkowita: %i",dana.calk); break;
        case FLOAT: mvprintw(l,1,"zdjeto ze stosu liczbe rzeczywista: %f",dana.rzecz); break;
        case CHAR: mvprintw(l,1,"zdjeto ze stosu znak: %c",dana.znak); break;
        case STRING: mvprintw(l,1,"zdjeto ze stosu lancuch: %s",dana.lanc); break;
       }              
      }; 
      break;
    case '2': 
      while (szczyt) szczyt=ze_stosu(&dana,&typ,szczyt);      
      mvprintw(l,1,"usunieto stos"); 
      break;
    case  27: if (getch()==27) wyjscie=0;
   }
  }
  while (wyjscie);
 } 
 else while (szczyt) szczyt=ze_stosu(&dana,&typ,szczyt);
}

int zapisz(int tryb)
{
 char nazwa[NAME];
 FILE *plik;
 wezel *szczyt_=szczyt;
 unia dana;
 int typ,wyjscie=1,wy2; 
 if (!(tryb))
 {
  do 
  {
   wy2=1;
   clear();
   mvprintw(1,1,"podaj nazwe pliku:");
   echo();
   mvscanw(2,1,"%s",nazwa);
   if (fopen(nazwa,"r"))
   {
    mvprintw(3,1,"podany plik istnieje!");
    mvprintw(4,1,"1 - utworzyc plik od nowa");
    mvprintw(5,1,"2 - dodac do pliku");
    mvprintw(6,1,"3 - podac nowy plik");
    mvprintw(8,1,"anulowanie zapisu - podwojny Esc");
    do 
     switch (getch())
     {
      case '1':
        plik=fopen(nazwa,"w");
        wy2=0;
        wyjscie=0;
        break;
      case '2':
        plik=fopen(nazwa,"a");
        wy2=0;
        wyjscie=0;
        break;
      case '3':
        wy2=0;
        break;
      case  27: 
        if (getch()==27) return;
     }
    while (wy2);
   }
   else 
   {
    plik=fopen(nazwa,"w"); 
    wyjscie=0;
   }  
  }
  while (wyjscie); 
 }
 else plik=fopen("tmp","w");
 while (szczyt_)
 { 
  wezel *_wezel_=szczyt_->nastepny;
  dana=szczyt_->dana;
  typ=szczyt_->rodzaj;
  szczyt_=_wezel_;
  switch(typ)
  {
   case INT: fprintf(plik,"%i %i\n",INT,dana.calk); break;
   case FLOAT: fprintf(plik,"%i %f\n",FLOAT,dana.rzecz); break;
   case CHAR: fprintf(plik,"%i %c\n",CHAR,dana.znak); break;
   case STRING: fprintf(plik,"%i %s\n",STRING,dana.lanc); break;
  }               
 } 
 fclose(plik);
}

int odczytaj(int tryb)
{
 char nazwa[20];
 FILE *plik;
 wezel *szczyt_=szczyt;
 unia dana;
 int typ,wyjscie=1,wy2=1; 
 if (!(tryb))
 {
  do 
  { 
   clear();
   mvprintw(1,1,"podaj nazwe pliku:");
   echo();
   mvscanw(2,1,"%s",nazwa);
   if (!(plik=fopen(nazwa,"r")))
   {
    mvprintw(3,1,"podany plik nie istnieje!");
    mvprintw(4,1,"1 - podaj plik ponownie");
    mvprintw(6,1,"anulowanie odczytu - podwojny Esc");
    do 
     switch(getch())
     {
      case '1': wy2=0; break;
      case  27: if (getch()==27) return;
     }
    while (wy2);
    wy2=1; 
   }
   else wy2=0;
  }
  while (wy2);
 }
 else plik=fopen("tmp","r");
 while ((typ=getc(plik))!=EOF)  
  switch(typ)
  {
   case '0': fscanf(plik,"%d\n",&dana.calk); szczyt=na_stos(dana,INT,szczyt); break;  
   case '1': fscanf(plik,"%f\n",&dana.rzecz); szczyt=na_stos(dana,FLOAT,szczyt); break;
   case '2': getc(plik); dana.znak=getc(plik); szczyt=na_stos(dana,CHAR,szczyt); break;
   case '3': fscanf(plik,"%s\n",dana.lanc); szczyt=na_stos(dana,STRING,szczyt); break;
  } 
 if (tryb) remove("tmp"); 
 fclose(plik);
}

int menu()
{
 int wyjscie=1,wy2=1;
 initscr();
 do 
 {
  clear(); 
  mvprintw(1,2,"Menu:\n\n   1 - odkladanie na stos\n   2 - wyswietlanie zawartosci stosu\n");
  mvprintw(5,1,"  3 - zdejmowanie ze stosu\n   4 - zapis stosu do pliku\n");
  mvprintw(7,1,"  5 - odczyt stosu z pliku\n\n wyjscie z programu - podwojny Esc\n\n");
  noecho();  
  switch (getch())
  {
   case '1': na_stos_(); break; 
   case '2': wyswietl(); break;
   case '3': ze_stosu_(0); break;
   case '4': zapisz(0); break;
   case '5': if (szczyt)
             {
              clear();
              mvprintw(1,1,"stos nie jest pusty!");
              mvprintw(2,1,"usunac poprzednia zawartosc stosu? (t/n)");
              do 
               switch (getch())
               {
                case 't':
                case 'T':
                  ze_stosu_(1);
                  wy2=0;
                  odczytaj(0);
                  break;
                case 'n':
                case 'N':
                  zapisz(1);
                  ze_stosu_(1);
                  odczytaj(0);
                  odczytaj(1);
                  wy2=0;
               }
              while (wy2); 
             }
             else odczytaj(0);
             zapisz(1);
             ze_stosu_(1);
             odczytaj(1);
             break;
   case  27: if (getch()==27) wyjscie=0;
  }
 }
 while (wyjscie);
 endwin();
}

int main()
{
 menu();
}