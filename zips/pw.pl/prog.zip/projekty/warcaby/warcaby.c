#include<stdio.h>
#include<conio.h>

enum czyt {SUKCES, FIASKO};

struct pole
{
 char color;   /* color - kolor pola */
 char pionek;  /* 1-pionek pierwszego gracza, 2-pionek drugiego gracza */
					/* 3-damka pierwszego gracza, 4-damka drugiego gracza */
};             /* 0-brak pionka */

enum czyt plik(struct pole[8][8],char g);
int spr1 (struct pole[8][8],int,int,char);
int spr2 (struct pole[8][8],int,int,char);
int spr3 (struct pole[8][8],int,int);

main(void)
 {
  int i,j,w,k,lewo=0,prawo=0,biciep=0,biciel=0,lewo1=0,prawo1=0,lewo2=0;
  int w1,k1,w2,k2,w3,k3,w4,k4,brak=0,pole=0,pole1=0;
  int x,y,brak1=0;
  char g,d,gd,dd;		/* zmienne gracza */
  struct pole plansza[8][8];


clrscr();
printf("##############################################################\n");
printf("\tPROGRAM PRZEWIDUJACY NASTEPNY RUCH W WARCABACH.\n");
printf("\nKtorym graczem chcesz byc (1 czy 2)?: ");
scanf("%c",&g);

if(g<'1' || g>'2')
  printf("Nie ma takiego gracza! (ma byc: 1 lub 2)");
else {

if(plik(plansza,g)==FIASKO) return 1;

printf("##############################################################");
printf("\n***plansza***");
printf("\n\t  ABCDEFGH ");
printf("\n	 ����������\n");

printf("\t");
for(i=0;i<8;i++)
 {
	printf("%d%c",i+1,176);

  for(j=0;j<8;j++) {
	printf("%c",(plansza[i][j].pionek=='1')? 'X' : ((plansza[i][j].pionek=='2')? 'Y'
	  : ((plansza[i][j].pionek=='3')? 'D' : ((plansza[i][j].pionek=='4')? 'E':((plansza[i][j].color=='b')? 946: 32)))));
						  }
	printf("%c ",176);
	printf("\n\t");
 }
printf("\r  	 ����������\n");


 /* ######### Badanie gry ############# */
 for(i=0;i<8;i++)
  {
	for(j=0;j<8;j++)
		{
		 pole=spr3(plansza,i,j);
		  if(pole)
			{
			 pole1=pole1+pole;
			 printf("\nPionek %c%d stoi na polu bialym.",j+65,i+1);
			}
		}
  }

  if (pole1!=0) printf("\n\n\t\a ZLE ROZSTAWIENIE PIONKOW NA PLANSZY !!!");
  else {

 if (g=='1')  d='2';
 else  d='1';

 if (g=='1')
  {
	 gd='3';                 /*zmienne do damek*/
	 dd='4';
  }
 else { gd='4'; dd='3'; }


for(k=0;k<8;k++)
{
  for(w=0;w<8;w++)
	  if(spr2(plansza,w,k,g)==0) ++brak1;
}


for(k=0;k<8;k++)
{
  for(w=0;w<8;w++)
  {
  if (spr1(plansza,w,k,g))
	{
		lewo=spr2(plansza,++w,++k,d);
		lewo1=spr2(plansza,w,k,g);
		prawo=spr2(plansza,w,k-=2,d);
		prawo1=spr2(plansza,w,k,g);



	 if(prawo==1 && prawo1==0)        // <<<<<<=====czy jest na prawo pionek
	  {
		biciep=spr2(plansza,w+1,k-1,d) || spr2(plansza,w+1,k-1,g);
			if (biciep==0 || prawo==0)
			  {
				 ++brak;
				 printf("\n>>>>> pionek %c%d <<<<<",k+66,w);
				 printf("\n BICIE w PRAWO (pionka %c%d)",k+65,w+1);
					prawo=spr2(plansza,w+2,k-2,d);
					lewo2=spr2(plansza,w+2,k,d);
					biciep=spr2(plansza,w+3,k-3,d) || spr2(plansza,w+3,k-3,g);
					biciel=spr2(plansza,w+3,k+1,d) || spr2(plansza,w+3,k+1,g);

						if ((biciep==0&&prawo==1)||(biciel==0&&lewo2==1))
							printf("  -  podwojne");
			  }
	  }

	 if(lewo==1 && lewo1==0)         // <<<<<<=====czy jest na lewo pionek
	  {
		biciel=spr2(plansza,w+1,k+3,d) || spr2(plansza,w+1,k+3,g);
		 if (biciel==0||lewo==0)
			  {
					++brak;
					printf("\n>>>>> pionek %c%d <<<<<",k+66,w);
					printf("\n BICE w LEWO (pionka %c%d)",k+67,w+1);
					prawo=spr2(plansza,w+2,k+2,d);
					lewo1=spr2(plansza,w+2,k+4,d);
					biciep=spr2(plansza,w+3,k+1,d) || spr2(plansza,w+3,k+1,g);
					biciel=spr2(plansza,w+3,k+5,d) || spr2(plansza,w+3,k+5,g);
						if ((biciep==0&&prawo==1)||(biciel==0&&lewo1==1))
							printf("  -  podwojne");
			  }
	  }
	  w-=1;       /*porzadkowanie zmiennych*/
	  k+=1;

	} } }
	/* ###### BICIA DAMKI  ############ */

for(k=0;k<8;k++)
 {
  for(w=0;w<8;w++)
	{

  if (spr1(plansza,w,k,gd))			// <<<<<<=====czy istnieje damka
	{
		w1=w2=y=w;
		k1=k2=x=k;

	 do
	  {
			lewo=spr2(plansza,++w1,++k1,dd)||spr2(plansza,w1,k1,gd);
			{
				biciel=spr2(plansza,w1,k1,dd);
				lewo1=spr2(plansza,w1+1,k1+1,dd)||spr2(plansza,w1+1,k1+1,gd);
					if (lewo1==0 && biciel==1)
					 {
						++brak;
						printf("\n>>>>> damka %c%d >>>>>",x+65,y+1);
						printf(" BICIE w LEWO (pionka %c%d)",k1+65,w1+1);
					 }
			  }

	  } while(lewo==0);

	 do
	  {
		prawo=spr2(plansza,++w2,--k2,dd)||spr2(plansza,w2,k2,gd);
			 {
				  biciep=spr2(plansza,w2,k2,dd);
				  prawo1=spr2(plansza,w2+1,k2-1,dd)||spr2(plansza,w2+1,k2-1,gd);
						if (prawo1==0 && biciep==1)
						 {
							++brak;
							printf("\n>>>>> damka %c%d >>>>>",y+65,x+1);
							printf(" BICIE w PRAWO (pionka %c%d)",k2+65,w2+1);
						 }
			 }
	  } while(prawo==0);


	  w3=w4=w; k3=k4=k;

		 do
		  {
			lewo=spr2(plansza,--w3,++k3,dd)||spr2(plansza,w3,k3,gd);
				{
					biciel=spr2(plansza,w3,k3,dd);
					lewo1=spr2(plansza,w3-1,k3+1,dd)||spr2(plansza,w3-1,k3+1,gd);
						if (lewo1==0 && biciel==1)
						 {
							++brak;
							printf("\n>>>>> damka %c%d >>>>>",y+65,x+1);
							printf(" BICIE do tylu w LEWO (pionka %c%d)",k3+65,w3+1);
						 }
				}

		  } while(lewo==0);

		 do
		  {
			prawo=spr2(plansza,--w4,--k4,dd)||spr2(plansza,w4,k4,gd);

			 if (prawo==1)
				{
				  biciep=spr2(plansza,w4,k4,dd);
				  prawo1=spr2(plansza,w4-1,k4-1,dd)||spr2(plansza,w4-1,k4-1,gd);
					 if (prawo1==0 && biciep==1)
					  {
						 ++brak;
						 printf("\n>>>>> damka %c%d >>>>>",y+65,x+1);
						 printf(" BICIE do tylu w PRAWO (pionka %c%d)",k4+65,w4+1);
					  }
				}

		  } while(prawo==0);

	 }
	} }

if(brak==0)		/*szukanie ruchow*/
 {

for(k=0;k<8;k++)
{
  for(w=0;w<8;w++)
  {
  if (spr1(plansza,w,k,g))
	{
		++brak;
		lewo=spr2(plansza,++w,++k,d);
		lewo1=spr2(plansza,w,k,g);
		prawo=spr2(plansza,w,k-=2,d);
		prawo1=spr2(plansza,w,k,g);

	if (prawo==0 && prawo1==0)
		printf("\n >>> ruch w prawo pionkiem %c%d na %c%d",k+66,w,k+65,w+1);

	  if (lewo==0 && lewo1==0)
		  printf("\n >>> ruch w lewo pionkiem %c%d na %c%d",k+66,w,k+67,w+1);	  //bylo w %d k+2

	  w-=1;
	  k+=1;

	 }

  if (spr1(plansza,w,k,gd))
	{
	++brak;

	 w1=w2=w3=w4=y=w;
	 k1=k2=k3=k4=x=k;

		 do
		  {
			lewo=spr2(plansza,++w1,++k1,dd)||spr2(plansza,w1,k1,gd);
			  if (lewo==0)
				 printf("\n >>> ruch damki %c%d w lewo na  %c%d",x+65,y+1,k1+65,w1+1);
		  } while(lewo==0);

		 do
		  {
			prawo=spr2(plansza,++w2,--k2,dd)||spr2(plansza,w2,k2,gd);

			 if (prawo==0)
				printf("\n >>> ruch damki %c%d w prawo na %c%d",x+65,y+1,k2+65,w2+1);
		  } while(prawo==0);


		 do
		  {
			lewo=spr2(plansza,--w3,++k3,dd)||spr2(plansza,w3,k3,gd);
			  if (lewo==0)
					printf("\n >>> ruch damki %c%d do tylu w lewo na %c%d",x+65,y+1,k3+65,w3+1);
		  } while(lewo==0);

		 do
		  {
			prawo=spr2(plansza,--w4,--k4,dd)||spr2(plansza,w4,k4,gd);

			 if (prawo==0)
				printf("\n >>> ruch damki %c%d do tylu w prawo na %c%d",x+65,y+1,k4+65,w4+1);
		  } while(prawo==0);

 }
}
} }

if(brak==0&&(g=='1'||g=='2'))  printf("\nNie ma pionkow na planszy.");
//if(brak1!=0&&brak==0)&&(g=='1'||g=='2'))  printf("\nBRAK RUCHOW.");
 } }
getchar();getchar();
return 0;
}
/* Funkcja czytaj�ca z pliku */
enum czyt plik (struct pole plansza[8][8],char g)
{
	FILE *fptr;
	char filename[]="c:\\app\\plansza.txt";
	int reval = SUKCES;
	int i,j=0,k=0,w;
	char c;
	char tab[8][8];

 if((fptr = fopen(filename, "r")) == 0) {
		printf("Nie moge otworzyc pliku %s.\n", filename);
		reval=FIASKO;
 } else {
	if(g=='1'){
	i=0;j=0;
	while(fscanf(fptr,"%c",&c)!=EOF){
	 if(c!='\n') plansza[i][j++].pionek=c;
	 if(j==8){j=0;i++;};
	}
	for(i=0;i<8;i++){
	 for(j=0;j<8;j++){
	  plansza[i][j].color=(i%2)?((!(j%2)) ?'b':'c'):((!(j%2)) ?'c':'b');
	 }
	}

 } else {
	 if(g=='2') {
	i=0;j=0;
	while(fscanf(fptr,"%c",&c)!=EOF){
	 if(c!='\n') tab[i][j++]=c;
	 if(j==8){j=0;i++;};
	}
	for(i=0,k=7;i<8;i++,k--){
	 for(j=0,w=7;j<8;j++,w--){
	  plansza[i][j].color=(i%2)?((!(j%2)) ?'b':'c'):((!(j%2)) ?'c':'b');
	  plansza[i][j].pionek=tab[k][w];
	}
	}
	} else (g=0);
  }
 }
	return reval;
}

/* Funkcja sprawdzajaca czy na polu znajduje sie moj pionek*/
spr1 (struct pole p[8][8],int w,int k,char g)

{
 if((w>=0 && w<=7) && (k>=0 && k<=7))
  if(p[w][k].pionek==g) return 1; else return 0;
 else return -1;
}

/* Funkcja sprawdzajaca czy na polu znajduje sie moj pionek lub damka */
spr2 (struct pole p[8][8],int w,int k,char g)

{
 char gd;

 if (g=='3') gd='1';
 else
  {
	if (g=='4') gd='2';
	else
	 {
	  if (g=='1')  gd='3';
	  else gd='4';
	 }
  }
 if((w>=0 && w<=7) && (k>=0 && k<=7))

  if(p[w][k].pionek==g || p[w][k].pionek==gd) return 1; else return 0;
 else return -1;
}

/* Funkcja sprawdzajaca czy pole jest zajete */
spr3 (struct pole p[8][8],int i,int j)

{
 int a,c;

 if((i>=0 && i<=7) && (j>=0 && j<=7)) {

  a=((p[i][j].pionek=='1')||(p[i][j].pionek=='3'));
  c=((p[i][j].pionek=='2')||(p[i][j].pionek=='4'));

	if((a==1||c==1)&&(p[i][j].color=='b'))	return 1; else return 0;
	}

  else return -1;
}




