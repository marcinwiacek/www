//int (*porownaj)(const void *a,const void *b);
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "poker.h"

// nr kart to liczba  z przedzialu  0.. 51 w kolejnosci jak nizej
// 0 - 2 trefl, 1 - 2 karo, 2, - 2 kier ....
extern int karty[52];           // stan kart jesli 1 to dana karta jest juz rozdana
extern int ryzyko,liczba_partii;        // zmienne globalne dotyczace partii

// funkcja porownujaca do qsorta
int porownaj(const void *a,const void *b)
  {
 if (*(int*)(a)>*(int*)(b))
  return 1;
 if (*(int*)(a)==*(int*)(b))
  return 0;
        return -1;
  }

// funkcja zwracajaca specyficzny kod odpowiedniego ukladu
// Okreslenie wyzszosci ukladu odbywa se przez zwykle porownanie kodow
int rozkoduj(int tab[5])
  {
      int karta,i,wynik;
      int poker = 1, strit = 1,kolor = 1;
      int index = 0;
      int powtorki[4];
      // sortowanie tablicy danych
      qsort(tab,5,sizeof(int),&porownaj);
      karta = tab[0];
      // sprawdzanie czy istnieje strit lub poker
      for (i=1; i<5; i++)
        {
            if (tab[i]/4 != karta+1 && poker)
                poker = 0;
            if (tab[i]/4 != karta/4+1)
                {
                    strit = 0;
                    karta++;
                    break;
                }
        }
      // jesli poker to kod najwyzszy
      if (poker)
        {
           wynik = 9000 + tab[4];
           return wynik;
        }
      // jesli strit to czy duzy , czy maly
      if (strit)
        {
            if (tab[4]/4 == 12)
                wynik = 5000 + tab[4];
            else
                wynik = 4000 + tab[4];
            return wynik;
        }
      // inicjacja tablicy powtorek
      // tablica powtorek jest co najwyzej 3 elementowa
      for (i = 1; i<5; i++)
         if (tab[i-1]/4 == tab[i]/4)
           {
               powtorki[index] = tab[i];        // zawsze karta o wiekszym kolorze
               index++;
           }
       // w zaleznosci od liczby powtorek
       switch (index)
         {
             case 3:
                         // jesli trzy powtorki identycznych figur to kareta
                         if (powtorki[0]/4 == powtorki[1]/4 && powtorki[1]/4== powtorki[2]/4)
                           {
                               wynik = 7000 + powtorki[0];
                               return wynik;
                           }
                         // w pozostalym przypadku full
                         wynik = 6000 + powtorki[1];
                         return wynik;
             case 2:
                         // jesli obydwie powtroki identycznych figur to trojka
                         if (powtorki[0]/4 == powtorki[1]/4)
                           {
                               wynik = 3000 + powtorki[1];
                               return wynik;
                           }
                         // w przeciwnym wypadku dwie pary
                         // jesli jedna para starszych figur to oddpowiednio zinterpretuj
                         // do wyniku wpisz 2000 plus najwysza karte pierwszej pary
                         // (pomnozona aby miala jak najwiekszy wplyw potem drugierj pary
                         if (powtorki[0]/4 > powtorki[1]/4)
                               wynik = 2000 + 13*4*powtorki[0]/4 +4*powtorki[1]/4 + powtorki[0]%4;
                         else
                               wynik = 2000 + 13*4*powtorki[1]/4 +4*powtorki[0]/4 + powtorki[1]%4;
                         return wynik;
             case 1:
                         // jesli jedna powtorka to para
                         wynik = 1000 + powtorki[0];
                         return wynik;
             default:
                         // jesli brak powtorek
                         kolor = 1;
                         for (i=1; i<5; i++)
                                if (tab[i]%4 != tab[i-1]%4)
                                        {
                                            kolor = 0;
                                            break;
                                        }
                         // jesli kolor
                         if (kolor)
                                wynik = 8000 + tab[i]%4;
                         else
                                wynik = tab[0];
                         return wynik;
         }
  }

// funkcja wyznaczajaca zwyciezce
int kto_wygral(int tab[4][5])
  {
      int wynik=0,tmp,i,zwroc;
      // w petli sprawdza kod kazdego ukladu i wyznacza najwiekszy
      for (i = 0; i<4; i++)
        {
            tmp = rozkoduj(tab[i]);
            if (tmp>wynik)
              {
                  wynik = tmp;
                  zwroc=i;
              }
        }
      return zwroc;
  }

// funkcja losuje 5 kart dla jednego gracza
void losuj_karty(int tab[5])
  {
      int i;
      for (i =0 ; i< 5 ; i++)
         tab[i] = losuj_karte();
  }

// funkcja losuje karte ktora nie byla wylosowana
int losuj_karte()
  {
      int karta;
      time_t t;
      // ustawianie zarodka generatora liczb losowych
      srand((unsigned)time(&t));
      // losuj liczbe z przedzialu 0..51 dopoki liczba ta
      // nie bedzie numerem karty rozdanej
      do
         karta = rand()%52;
      while (karty[karta]==1);
      // zaznacz ze karta juz rozdana
      karty[karta]=1;
      return karta;
  }

// funkcja wymienia karty graczowi wirtualnemu
// ustala optymalny krok przy okresleniu ryzyka
void wymien_komputer(int tab[5])
  {
      int i,stan,trzy_kolory=0,kolor;
      int kolory[5];
      int zmienna = 0,zmienna2;
      // rozkoduj uklad
      stan = rozkoduj(tab);
      // sprawdza sklad kolorow w ukladzie
      for (i = 0; i < 5; i++)
            kolory[tab[i]%4]++;
      // jesli ktorys kolor pojawi sie wiecej niz 3 - krotnie
      // ale nie 5- krotnie to wymieniaj do koloru
      for (i = 0; i < 4; i++)
            if (kolory[i]>=3 && kolory[i]!= 5)
                {
                        trzy_kolory =1;
                        kolor = i;
                }
      // wymieniaj do koloru
      if (trzy_kolory && ryzyko)
        {
                for (i= 0; i< 5; i++)
                        if (tab[i]%5 != kolor)
                                tab[i] = losuj_karte();
                return;
        }
      // jesli kolor lub wyzej
      if (stan>=7000) return;
      // jesli full to mozna ryzykownie wymienic pare
      if (stan>=6000)
        if (ryzyko)
                {
                    zmienna = (stan-6000) /4;
                    for (i = 0; i<5; i++)
                        if (tab[i]/4 != zmienna)
                                tab[i] = losuj_karte();
                    return;
                }
      // duzy strit - nie warto nic robic
      if (stan>=5000) return;
      // maly strit - wymienic najnizsza karte
      if (stan>=4000)
        if (ryzyko)
                tab[0] = losuj_karte();
      // trojka - wymien 2 pozostale karty
      if (stan>=3000)
        {
            zmienna = (stan - 3000)/4;
            for (i=0 ; i<5; i++)
                if (tab[i]/4 != zmienna)
                        tab[i] = losuj_karte();
            return;
        }
      // pary dwie - jeli ryzyko to wymien mlodsza pare i karte wolna
      // jesli nie ryzykant to tylko jedna karte
      if (stan>=2000)
        {
                // musze rozkodowac pare starsza
                zmienna = (stan - 2000)/(13*4);
                if (ryzyko)
                        {
                            for (i=0 ; i<5; i++)
                                if (tab[i]/4 != zmienna)
                                        tab[i] = losuj_karte();
                            return;
                        }
                // musze jakos rozkodowac najmlodsza pare
                zmienna2 = ((stan - 2000)/4)%13;
                for (i=0 ; i<5; i++)
                        if (tab[i]/4 != zmienna && tab[i]/4 != zmienna2)
                                tab[i] = losuj_karte();
                return;
        }
      // para wymien 3 karty
      if (stan>=1000)
        {
            zmienna = (stan - 1000)/4;
            for (i=0 ; i<5; i++)
                if (tab[i]/4 != zmienna)
                        tab[i] = losuj_karte();
            return;
        }
      // nic - wymien cztery karty najnizsze
      for (i=0; i<4; i++)
        tab[i] = losuj_karte();
  }

// wypisz na ekran karty gracza
void wypisz_karty(int tab[5])
  {
      int i;
      for (i=0; i<5; i++)
        {
            printf (" %d : ",i+1);
            switch (tab[i]/4)
                {
                    case 12:
                        printf(" A ");
                        break;
                    case 11:
                        printf(" K ");
                        break;
                    case 10:
                        printf(" D ");
                        break;
                    case 9:
                        printf(" J ");
                        break;
                    default:
                        printf(" %d ",tab[i]/4+2);
                }
            switch (tab[i]%4)
                {
                    case 0:
                        printf(" trefl ");
                        break;
                    case 1:
                        printf(" karo ");
                        break;
                    case 2:
                        printf(" kier ");
                        break;
                    case 3:
                        printf(" pik ");
                }
            printf("\n");
        }
  }

// wymien karty graczowi rzeczywistemu
void wymien_czlowiek(int tab[5])
  {
      char tmp;
      int ile,ktora,i;
      // wypisz wszystkie karty
      wypisz_karty(tab);
      // zapytaj ile chcesz wymienic
      do
        {
              printf("\n Ile kart chcesz wymienic : ");
              fflush(stdin);
              scanf("%d",&ile);
        }
      while (ile <0 || ile>4);
      printf("\n");
      // pytaj ktore ma wymienic
      for (i=0; i<ile; i++)
        {
            do
                {
                    printf(" %d karta : ",i+1);
                    fflush(stdin);
                    scanf("%d",&ktora);
                }
            while (ktora<0 || ktora>5);
            // losuje nowa karte w miejsce starej
            tab[ktora-1] = losuj_karte();
        }
      printf("\n");
      // wypisuje nowy uklad kart
      wypisz_karty(tab);
  }

// wyswietl wyniki na ekranie
void wyswietl_wyniki(struct dane gracze[4])
  {
      int i,winer,punkty=0;
      printf ("\n\n\n Statystyka po %d rozgrywkach : \n",liczba_partii);
      for (i=0; i<4; i++)
        {
            printf("  %s : %d partii wygranych\n",gracze[i].nazwisko,gracze[i].punkty);
            if (gracze[i].punkty>punkty)
                {
                    punkty = gracze[i].punkty;
                    winer = i;
                }
        }
  }
