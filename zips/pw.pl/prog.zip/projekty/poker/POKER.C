#include "poker.h"
// dane o graczach i partii
int ilosc_graczy,ryzyko,liczba_partii;
int karty[52];


main()
  {
      int i,best,j;
      char tmp;
      int tab[4][5];
      struct dane gracze[4];
      // intro
      printf("\n\n                      POKER\n\n");
      // pytanie o ilosc graczy - ludzi, ryzyko komputerow, liczbe partii
      do
        {
                printf(" Ilu graczy (ludzi) : ");
                scanf("%d",&ilosc_graczy);
        }
      while (ilosc_graczy<0 || ilosc_graczy>4);
      do
        {
              printf(" Czy gracze komputerowi sa ryzykowni (t/n) : ");
              fflush(stdin);
              scanf(" %c", &tmp);
        }
      while (tmp!='t' && tmp!='n');
      if (tmp == 't')
         ryzyko =1;
      else
         ryzyko =0;
      do
        {
              printf(" Do ilu partii gramy : ");
              scanf("%d",&liczba_partii);
        }
      while (liczba_partii<1);
      // podaj nazwiska graczy - ludzi
      for (i=0; i<ilosc_graczy; i++)
         {
             printf (" Podaj nazwisko %d gracza : ",i+1);
             scanf ("%s",gracze[i].nazwisko);
             gracze[i].typ = 0;
             gracze[i].punkty = 0;
         }
      // podaj nazwiska graczy - komputerow
      for (; i < 4; i++)
         {
             printf (" Podaj nazwisko %d komputera : ",i-ilosc_graczy+1);
             scanf (" %s",gracze[i].nazwisko);
             gracze[i].typ = 1;
             gracze[i].punkty = 0;
         }
      // wykonaj petle liczba partii razy
      // bedzie tylez partii
      for (i=0; i<liczba_partii; i++)
         {
                scanf("%c",&tmp);
             // zeruj tablice zajetych kart
                for (j=0; j<52; j++)
                        karty[j] = 0;
                // losuj karty dla kazdego z graczy
                for (j=0; j<4; j++)
                       losuj_karty(tab[j]);
                // dokonaj wymiany kart przez kazdego z graczy
                for (j=0; j<4; j++)
                        {
										  printf("\n\n Gracz %d : %s\n\n",j+1,gracze[j].nazwisko);
										  // jesli gracz czlowiek to czekaj poki
										  //podejdzie do komputera
										  // i ukryj poprzednie wyniki
										  if (gracze[j].typ == 0)
													 {
																printf(" \n Nacisnij enter... \n");
																fflush(stdin);
																scanf("%c",&tmp);

printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
																printf("\n\n Gracz %d : %s\n\n",j+1,gracze[j].nazwisko);
													 }
										  // wymien karty
										  if (gracze[j].typ)
													 wymien_komputer(tab[j]);
										  else
													 wymien_czlowiek(tab[j]);
										  // czekaj na koniec kolejki
										  // dopoki nie bedzie dowolnego klawisza
										  printf(" \n\n Koniec kolejki. ");
										  printf(" \n Nacisnij enter ... \n");
										  fflush(stdin);
										  scanf("%c",&tmp);
										  scanf("%c",&tmp);

printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
								}
					 // wyznaczanie wygranego
					 best = kto_wygral(tab);
					 // wypisanie jego nazwiska
					 printf(" \n Wygral %s .\n", gracze[best].nazwisko);
					 printf("\n Jego uklad : \n");
					 wypisz_karty(tab[best]);
					 gracze[best].punkty++;
					 fflush(stdin);
			}
		// punktacja po liczba_partii partiach
		wyswietl_wyniki(gracze);
		return 0;
  }