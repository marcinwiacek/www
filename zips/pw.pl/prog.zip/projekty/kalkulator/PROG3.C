/* kompilacja cc -o prog3 prog3.c -lcurses -lm */
#define UNIX

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<malloc.h>

#ifdef UNIX
 #include<curses.h>
#else
 #include<conio.h>
#endif

struct dat{
double argument;
char   operacja;
struct dat *poprz;
};

double mem=0;
int ech_pop=0;

void intro();
void kalkulator();
void outro();
struct dat* clear_tree(struct dat*);
void wyswietl(struct dat*);
void screen(char*);
struct dat* pobierz_op(struct dat*);
void echo_klaw(char);
double to_scr(char*,double,int,int,int);
int szukaj_naw(struct dat*);
void poziom_naw(struct dat*);
int priorytet(struct dat*);
struct dat* licz(struct dat*);

void main(){

#ifdef UNIX
 initscr();
 cbreak();
 noecho();
#endif
  
  intro();
  kalkulator();
  outro();

#ifdef UNIX
 endwin();
 exit(0);
#endif
}

void kalkulator(){
  struct dat *tree;
  tree=NULL;
  do{
    tree=clear_tree(tree);
    do{
      wyswietl(tree);
      tree=pobierz_op(tree);
      while ((tree->poprz!=NULL)&&(priorytet(tree)>=priorytet(tree->poprz))){
        tree=licz(tree);};
    }while((tree->operacja!='R')&&(tree->operacja!='K'));
  }while(tree->operacja!='K');
  clear_tree(tree);
}

void wyswietl(struct dat *dana){
char buf[20];
  if (dana==NULL)
    buf[0]='0',buf[1]=0;
  else
    if (dana->operacja=='E')
      sprintf(buf,"%s","ERROR!");
    else{
      if ((dana->argument>1E5)||(dana->argument<1E-5))
        sprintf(buf,"% .9e",dana->argument);
      else sprintf(buf,"% .9f",dana->argument),buf[11]=0;};
  screen(buf);
}

struct dat* pobierz_op(struct dat *prev){
  struct dat *dana;
  int op=0,znak_l=0,znak_w=0,wykl=0,krop=0,n=0,m=0,koniec=1;
  double tmp=0;
  char klaw,buf[20]="";
  if ((prev==NULL)||((prev->operacja!=')')&&(prev->operacja!='='))){
    if ((prev!=NULL)&&(prev->operacja=='E'))
      prev=clear_tree(prev);
      dana=(struct dat*)malloc(sizeof (struct dat));
      dana->poprz=prev;}
  else{
    dana=prev;
    op=1;
    tmp=dana->argument;
    if (prev->operacja==')'){
      dana=prev->poprz;
      dana->argument=prev->argument;
      dana->operacja='=';
      free(prev);};};
  do{
  fflush(stdin);

#ifdef UNIX
  klaw=getch();
#else
  klaw=(char)(getch()&0xff);
#endif
  
  echo_klaw(klaw);
    switch(klaw){
      case 'r': ;
      case 'R': ;
      case 'k': ;
      case 'K': dana->operacja=klaw&0xdf;
                koniec=0;
                break;
      case '\n':
      case '=': if (szukaj_naw(dana)>0) {screen("Niedomkniete nawiasy!"); break;};
                if ((n==0)&&(op==0)) break;
                dana->operacja='=';
                koniec=0;
                break;
      case ')': if ((szukaj_naw(dana)==0)||((n==0)&&(op==0))) break;
                dana->operacja=')';
                koniec=0;
                break;
      case '+': ;
      case '-': ;
      case '*': ;
      case '/': ;
      case '^': if ((n==0)&&(op==0)) break;
                dana->operacja=klaw;
                koniec=0;
                break;
      case '(': if (szukaj_naw(dana)>18) break;
                dana->operacja='(';
                prev=dana;
                dana=(struct dat*)malloc(sizeof (struct dat));
                dana->poprz=prev,m=1;
                break;
      case 's': ;
      case 'S': tmp=sin((tmp*2*3.141592654)/360),m=2;
                break;
      case 'c': ;
      case 'C': tmp=cos((tmp*2*3.141592654)/360),m=2;
                break;
      case 't': ;
      case 'T': if (tmp=fmod(tmp,180),tmp==90) { dana->operacja='E'; koniec=0; break;};
                tmp=tan((tmp*2*3.141592654)/360),m=2;
                break;
      case 'l': ;
      case 'L': if ((tmp<=0)||(tmp>1E36)) {dana->operacja='E'; koniec=0; break;};
                tmp=log(tmp),m=2;
                break;
      case 'g': ;
      case 'G': if ((tmp<=0)||(tmp>1E36)) {dana->operacja='E'; koniec=0; break;};
                tmp=log10(tmp),m=2;
                break;
      case 'w': ;
      case 'W': mem=tmp;
                break;
      case 'm': ;
      case 'M': tmp=mem,m=2;
                break;
      case '\\':if (wykl==0) znak_l=!znak_l;
                else         znak_w=!znak_w;
                if (op==1) tmp=0;
                op=0;
                tmp=to_scr(buf,tmp,znak_l,znak_w,op);
                break;
      case '.': if ((op==1)||(krop==1)||(n==0)) break;
                krop=1;
                buf[n++]='.';
                buf[n]=0;
                tmp=to_scr(buf,tmp,znak_l,znak_w,op);
                break;
      case 'e': ;
      case 'E': if ((op==1)||(wykl!=0)||(n==0)) break;
                wykl=n;
                buf[n++]='E';
                buf[n]=0;
                tmp=to_scr(buf,tmp,znak_l,znak_w,op);
                break;
      case '\b':if ((op==1)||(n==0)) break;
                if (buf[--n]=='E') wykl=0,znak_w=0;
                if (buf[n]=='.') krop=0;
                if (n==0) znak_l=0;
                buf[n]=0;
                tmp=to_scr(buf,tmp,znak_l,znak_w,op);
                break;
      case '1': ;
      case '2': ;
      case '3': ;
      case '4': ;
      case '5': ;
      case '6': ;
      case '7': ;
      case '8': ;
      case '9': ;
      case '0': if (((n>9)&&(krop==1)&&(wykl==0))||((n>8)&&(krop==0)&&(wykl==0))||((wykl!=0)&&(n-wykl>2))) break;
                if (op==1) tmp=0;
                op=0;
                buf[n++]=klaw;
                buf[n]=0;
                tmp=to_scr(buf,tmp,znak_l,znak_w,op);};
    if (m>0){
      if (m==1){
        tmp=0;
        op=0;
        poziom_naw(dana);
        };
      if (m==2){
        op=1;
        tmp=to_scr(buf,tmp,znak_l,znak_w,op);};
      n=0;
      m=0;
      znak_l=0;
      znak_w=0;
      wykl=0;
      krop=0;};
  }while(koniec);
  dana->argument=tmp;
  return dana;
}

double to_scr(char *buf_l,double liczba,int znak_mant,int znak_wykl,int mode){
char bufor[20]="";
int n=0,m=0;
float l;
  if (mode==0){
    if (znak_mant==1) bufor[m++]='-',bufor[m]=0;
    while(*(buf_l+n)!=0){
      if (*(buf_l+n)=='E'){
        bufor[m++]='E';
        n++;
          if (znak_wykl==1) bufor[m++]='-';};
      if (*(buf_l+n)!=0)
        bufor[m++]=*(buf_l+n++);
      bufor[m]=0;};
    sscanf(bufor,"%e",&l),liczba=(float)l;
  }else
    if ((liczba>1E5)||(liczba<1E-5))
      sprintf(bufor,"% .9e",liczba);
    else sprintf(bufor,"% .9f",liczba),bufor[11]=0;
  screen(bufor);
  return liczba;
}

int priorytet(struct dat *dana){
  switch(dana->operacja){
    case '^': return 1;
    case '/': return 2;
    case '*': return 2;
    case '+': return 3;
    case '-': return 3;
    case ')': return 4;
    case '=': return 5;
    case '(': return 6;};
  return 0;
}

struct dat* licz(struct dat *aktual){
  struct dat *poprzed;
  poprzed=aktual->poprz;
  switch(poprzed->operacja){
    case '^' : poprzed->argument=pow(poprzed->argument,aktual->argument);
               break;
    case '*' : poprzed->argument=poprzed->argument*aktual->argument;
               break;
    case '/' : if (aktual->argument==0) {aktual->operacja='E';return aktual;};
               poprzed->argument=poprzed->argument/aktual->argument;
               break;
    case '+' : poprzed->argument=poprzed->argument+aktual->argument;
               break;
    case '-' : poprzed->argument=poprzed->argument-aktual->argument;};
  poprzed->operacja=aktual->operacja;
  free(aktual);
  return poprzed;
}

struct dat* clear_tree(struct dat *curr){
  struct dat *prev;
  while(curr!=NULL){
    prev=curr->poprz;
    free(curr);
    curr=prev;};
  return curr;
}

int szukaj_naw(struct dat *curr){
int n=0;
  while(curr!=0){
    if (curr->operacja=='(') n++;
    curr=curr->poprz;};
  return n;
}

void poziom_naw(struct dat *dana){
char buf[20];
int n,m;
  m=szukaj_naw(dana);
  for (n=0;n<m;n++) buf[n]='(';
  buf[n]=0;
  screen(buf);
}

void screen(char *buf){
int x=32,y=5,w=24;

#ifdef UNIX
 move(y-1,(x-w-1));
 printw("%*s",w,buf);
 refresh();
#else
 gotoxy(x-w,y);
 printf("%*s",w,buf);
#endif
}

void echo_klaw(char klaw){
int m;
struct {char kl;int x;int y;char napis[7];}dane[31]={
       {'0',4,14,"0"},
       {'1',4,12,"1"},
       {'2',9,12,"2"},
       {'3',14,12,"3"},
       {'4',4,10,"4"},
       {'5',9,10,"5"},
       {'6',14,10,"6"},
       {'7',4,8,"7"},
       {'8',9,8,"8"},
       {'9',14,8,"9"},
       {'.',9,14,"."},
       {'\\',13,14,"+\\-"},
       {'+',19,8,"+"},
       {'-',19,10,"-"},
       {'*',19,12,"*"},
       {'/',19,14,"/"},
       {'=',24,8,"="},
       {'E',24,10,"E"},
       {'(',24,12,"("},
       {')',24,14,")"},
       {'S',29,8,"sin"},
       {'C',29,10,"cos"},
       {'T',29,12,"tan"},
       {'^',35,8,"^"},
       {'L',34,10,"ln"},
       {'G',34,12,"log"},
       {'\b',31,14,"bs<-"},
       {'K',4,16,"koniec"},
       {'M',14,16,"memr"},
       {'W',22,16,"memw"},
       {'R',30,16,"clear"}};
#ifdef UNIX
move(dane[ech_pop].y-1,dane[ech_pop].x-1);
printw(" %s ",dane[ech_pop].napis);
refresh();
#else
gotoxy(dane[ech_pop].x,dane[ech_pop].y);
printf(" %s ",dane[ech_pop].napis);
#endif

if (klaw=='\n') klaw='=';
if ((klaw>0x60)&&(klaw<0x7b)) klaw=klaw&0xdf;
for (m=0;m<31;m++)
  if (klaw==dane[m].kl){
    ech_pop=m;

#ifdef UNIX
    move(dane[ech_pop].y-1,dane[ech_pop].x-1);
    printw("<%s>",dane[ech_pop].napis);
    refresh();};
#else
    gotoxy(dane[ech_pop].x,dane[ech_pop].y);
    printf("<%s>",dane[ech_pop].napis);};
#endif
}

void outro(){

#ifdef UNIX
clear();
printw("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printw("                                                                  (C)1997\n\n");
printw("Do zobaczenia!\n");
refresh();
#else
clrscr();
printf("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printf("                                                                  (C)1997\n\n");
printf("Do zobaczenia!\n");
#endif
}

void intro(){

#ifdef UNIX
clear();
printw("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printw("                                                                  (C)1997\n\n");
printw("Program ten to proba implementacji naukowego kalkulatora kieszonkowego na\n");
printw("komputerze dlatego tez sposob jego obslugi jest zblizony do obslugi\n");
printw("zwyklego kalkulatora. Cyfry jak i podstawowe operacje sa wywolywane\n");
printw("poprzez naciskanie odpowednich klawiszy tj. 0-9,+,-,*,//,^. Program\n");
printw("pozwala na wprowadzanie danych w notacji zmiennopozycyjnej tj. mantysy\n");
printw("czyli ulamka dziesietnego ze znakiem, litery \"E\" oraz dwucyfrowego\n");
printw("wykladnika ze znakiem. Uzyskanie kropki i litery \"E\" sprowadza sie\n");
printw("do ich nacisniecia na klawiaturze. Zmiany znaku dokonuje sie poprzez\n");
printw("naciskanie klawisza \" \\ \" i tak podczas edycji ulamka zmienia sie znak\n");
printw("ulamka a podczas edycji wykladnika zmienia sie znak wykladnika. Nie mozna\n");
printw("zmienic znaku wyniku operacji! Przed zatwierdzeniem danej czyli przed\n");
printw("wybraniem operacji matematycznej wprowadzana liczbe mozna edytowac\n");
printw("kasujac ostatni wprowadzony znak klawiszem <backspace>. Nie mozna edyto-\n");
printw("wac wyniku operacji! Program pozwala rowniez na zastosowanie nawiasow ().\n");
printw("Operacje trygonometryczne i logarytmy uzyskuje sie poprzez nacisniecie\n");
printw("liter podkreslonych w nazwach funkcji widocznych na pulpicie kalkulatora.\n");
printw("Wynik wprowadzonego ciagu operacji otrzymuje sie po nacisnieciu klawisza\n");
printw("\"=\" lub <ENTER>.\n\nNacisnij cos...");
refresh();
getch();
clear();
printw("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printw("                                                                  (C)1997\n\n");
printw("Program dysponuje takze pamiecia do ktorej mozna zapisywac aktualnie wprowa-\n");
printw("dzana dana lub wynik operacji (po nacisnieci litery \"w\"),lub odczytac\n");
printw("(klawiszem \"m\") jako aktualna dana. W kazdej chwili mozna wyczyscic pole\n");
printw("edycji i pamiec wszystkich poprzednich dzialan naciskajac klawisz \"r\".\n");
printw("Wyjscie z programu po nacisnieciu klawisza \"k\".\n\nMilej zabawy!\n\nNacisnij cos...");
refresh();
getch();
clear();
printw(" --------------------------------------  \n");
printw("|        Kalkulator naukowy GZ1        | \n");
printw("|                                      | \n");
printw("|      --------------------------      | \n");
printw("|     |                          |     | \n");
printw("|      --------------------------      | \n");
printw("|                                      | \n");
printw("|   7    8    9    +    =    sin   ^   | \n");
printw("|                            ~         | \n");
printw("|   4    5    6    -    E    cos  ln   | \n");
printw("|                            ~    ~    | \n");
printw("|   1    2    3    *    (    tan  log  | \n");
printw("|                            ~      ~  | \n");
printw("|   0    .   +\\-   /    )      bs<-    | \n");
printw("|             ~                        | \n");
printw("|   koniec    memr    memw    clear    | \n");
printw("|   ~         ~          ~        ~    | \n");
printw("|                                      | \n");
printw("|      Grzegorz Zablocki/2P16  (C)1997 | \n");
printw(" --------------------------------------  \n");
refresh();
#else
clrscr();
printf("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printf("                                                                  (C)1997\n\n");
printf("Program ten to proba implementacji naukowego kalkulatora kieszonkowego na\n");
printf("komputerze dlatego tez sposob jego obslugi jest zblizony do obslugi\n");
printf("zwyklego kalkulatora. Cyfry jak i podstawowe operacje sa wywolywane\n");
printf("poprzez naciskanie odpowednich klawiszy tj. 0-9,+,-,*,//,^. Program\n");
printf("pozwala na wprowadzanie danych w notacji zmiennopozycyjnej tj. mantysy\n");
printf("czyli ulamka dziesietnego ze znakiem, litery \"E\" oraz dwucyfrowego\n");
printf("wykladnika ze znakiem. Uzyskanie kropki i litery \"E\" sprowadza sie\n");
printf("do ich nacisniecia na klawiaturze. Zmiany znaku dokonuje sie poprzez\n");
printf("naciskanie klawisza \" \\ \" i tak podczas edycji ulamka zmienia sie znak\n");
printf("ulamka a podczas edycji wykladnika zmienia sie znak wykladnika. Nie mozna\n");
printf("zmienic znaku wyniku operacji! Przed zatwierdzeniem danej czyli przed\n");
printf("wybraniem operacji matematycznej wprowadzana liczbe mozna edytowac\n");
printf("kasujac ostatni wprowadzony znak klawiszem <backspace>. Nie mozna edyto-\n");
printf("wac wyniku operacji! Program pozwala rowniez na zastosowanie nawiasow ().\n");
printf("Operacje trygonometryczne i logarytmy uzyskuje sie poprzez nacisniecie\n");
printf("liter podkreslonych w nazwach funkcji widocznych na pulpicie kalkulatora.\n");
printf("Wynik wprowadzonego ciagu operacji otrzymuje sie po nacisnieciu klawisza\n");
printf("\"=\" lub <ENTER>.\n\nNacisnij cos...");
getch();
clrscr();
printf("\"Program kalkulatora naukowego\"                 by Grzegorz Zablocki/2P16\n");
printf("                                                                  (C)1997\n\n");
printf("Program dysponuje takze pamiecia do ktorej mozna zapisywac aktualnie wprowa-\n");
printf("dzana dana lub wynik operacji (po nacisnieci litery \"w\"),lub odczytac\n");
printf("(klawiszem \"m\") jako aktualna dana. W kazdej chwili mozna wyczyscic pole\n");
printf("edycji i pamiec wszystkich poprzednich dzialan naciskajac klawisz \"r\".\n");
printf("Wyjscie z programu po nacisnieciu klawisza \"k\".\n\nMilej zabawy!\n\nNacisnij cos...");
getch();
clrscr();
printf(" --------------------------------------  \n");
printf("|        Kalkulator naukowy GZ1        | \n");
printf("|                                      | \n");
printf("|      --------------------------      | \n");
printf("|     |                          |     | \n");
printf("|      --------------------------      | \n");
printf("|                                      | \n");
printf("|   7    8    9    +    =    sin   ^   | \n");
printf("|                            ~         | \n");
printf("|   4    5    6    -    E    cos  ln   | \n");
printf("|                            ~    ~    | \n");
printf("|   1    2    3    *    (    tan  log  | \n");
printf("|                            ~      ~  | \n");
printf("|   0    .   +\\-   /    )      bs<-    | \n");
printf("|             ~                        | \n");
printf("|   koniec    memr    memw    clear    | \n");
printf("|   ~         ~          ~        ~    | \n");
printf("|                                      | \n");
printf("|      Grzegorz Zablocki/2P16  (C)1997 | \n");
printf(" --------------------------------------  \n");
#endif
}


