/*atan2.c*/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double result;
   double x = 90.0, y = 45.0;

   result = atan2(y, x);
   printf("Arcus tangens x/y=%lf wynosi %lf\n", (y / x), result);
   return 0;
}