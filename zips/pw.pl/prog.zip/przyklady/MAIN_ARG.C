/* main_arg.c*/

#include <stdio.h>

void main( int argc, char *argv[] )
   {
   int j;

   printf("\nLiczba argumentow = %d\n", argc);
   for(j=0; j<argc; j++)
      printf("Argumentem numer %d jest  %s\n", j, argv[j] );
   }