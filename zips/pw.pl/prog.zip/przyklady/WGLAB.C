/* wglab.c */

#include <stdio.h>
#define  n 7

void zwiedzaj(int G[n][n], int Z[n], int i)
{
int k;

Z[i]=1;
printf("Badam wierzcholek %d\n",i);
for(k=0;k<n;k++)
  if(G[i][k]!=0)
		if(Z[k]==0) zwiedzaj(G,Z,k);
}

void szukaj(int G[n][n], int Z[n])
{
int i;
for(i=0;i<n;i++) Z[i]=0;
for(i=0;i<n;i++)
	if(Z[i]==0) zwiedzaj(G,Z,i);
}



void main()
{
int i,j, G[n][n], Z[n];

for(i=0;i<n;i++)
  for(j=0;j<n;j++)
	 G[i][j]=0;

G[0][1]=1;G[0][2]=1;G[0][3]=1;
G[1][2]=1;G[2][3]=1;G[1][4]=1;G[3][5]=1;G[4][6]=1;
szukaj(G,Z);
}



