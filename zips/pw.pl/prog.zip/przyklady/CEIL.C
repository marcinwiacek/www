/*ceil.c*/

#include <math.h>
#include <stdio.h>

int main(void)
{
   double number = 123.54;
   double down, up;

   down = floor(number);
   up = ceil(number);

   printf("Dana wejsciowa    %5.2lf\n", number);
   printf("Liczba zaokraglona do dolu  %5.2lf\n", down);
   printf("Liczba zaokraglona do gory  %5.2lf\n", up);

   return 0;
}