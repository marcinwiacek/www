/* mainpro.c*/

#include <stdio.h>
int funkcja(void);

int a, b;           /*zmienne glogalne */

void main(void)
   {
   int wynik;

   printf("Podaj dwie liczby: ");
   scanf("%d%d", &a, &b);
   wynik = funkcja();
   printf("Suma kwadratow liczb wynosi %d.\n", wynik);
   }