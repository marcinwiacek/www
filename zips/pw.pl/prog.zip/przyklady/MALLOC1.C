/* malloc1.c*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
   char *wsk_znakowy;

   if ((wsk_znakowy =(char *)malloc(10)) == NULL)
   {
      printf("Brak pamieci\n");
      exit(1);
   }
   strcpy(wsk_znakowy, "Hello");
   printf("Tekst: %s\n", wsk_znakowy);
   free(wsk_znakowy);
   return 0;
}