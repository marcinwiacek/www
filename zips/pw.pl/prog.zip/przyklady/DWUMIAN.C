/* dwumian_n.c*/

#include <stdio.h>

long int silnia(int n); /*prototyp funkcji*/

void main()
{
	int k,n,ZLE=1;
	long int dwu_n=0;
	while (ZLE)
		{
		printf("\nProgram obliczajacy wartosc dwumianu Newtona");
		printf("\nPodaj n=");
		scanf("%d",&n);
		printf("\nPodaj k=");
		scanf("%d",&k);
		if (n>=0 && k>=0 && n>=k) ZLE=0;
		}
	dwu_n=silnia(n)/(silnia(k)*silnia(n-k));/*wyolanie funkcji*/
	printf("\nWartosc dwumianu wunosi:%ld\n",dwu_n);

}

long int silnia(int n)/*definicja funkcji*/
{
int i;
long int wynik=1;
if (n==0) return 1;
for (i=1;i<=n;i++)
	wynik*=i;
return wynik;
}
