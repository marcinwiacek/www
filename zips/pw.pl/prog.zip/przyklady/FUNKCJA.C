/* funkcja.c*/

int funkcja(void)
   {
   extern int a, b;      /* deklaracja zmiennych globalnych*/

   return( a*a + b*b );
   }