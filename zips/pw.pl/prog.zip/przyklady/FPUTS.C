/* fputs.c */

#include <stdio.h>
#include <string.h>

void main(void)
   {
   FILE *wsk_plik;
   char linia[40];

   wsk_plik = fopen("linie.txt", "w");
   while(strlen( gets(linia) ) > 0)
      {
      fputs(linia, wsk_plik);
      fputs("\n", wsk_plik);
      }
   fclose(wsk_plik);
   }