/* program znajdujacy zadany element w tablicy trojwymiarowej*/

#include <stdio.h>
#define X 3
#define Y 3
#define Z 3

void main()
{
	int macierz[X][Y][Z]={  { {  10,  13,   8 },
				  {  99, 200, 300 },
				  { -89, -78,  49 }, },
				{ {   1,   2,   3 },
				  { -10, -20, -30 },
				  { -40, -50, -60 }, },
				{ {  10,  20,  30 },
				  {  40,  60,  70 },
				  {  50,  80,  90 }, }, };
	int x,y,z,szukany,JEST=0;


	printf("\nPodaj element szukany ");
	scanf("%d",&szukany);
	for (x=0;x<X;x++)
	    for(y=0;y<Y;y++)
		for(z=0;z<Z;z++)
			if (macierz[x][y][z]==szukany)
				{
				JEST=1;
				goto znaleziony;
				}
	znaleziony: if (JEST)
			printf("\nZnaleziony element ma wspolrzedne x=%d, y=%d, z=%d",x,y,z);
		    else
			printf("\n Nie znaleziono ");

}