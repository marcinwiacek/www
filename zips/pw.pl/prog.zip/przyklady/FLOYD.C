/*floyd.c*/

#include <stdio.h>
#define min(a,b) ((a)<(b)?(a):(b))
#define n 6

int G[n][n],R[n][n],D[n][n];

void init(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
   for(j=0;j<n;j++)
		g[i][j]=10000; /* nieskonczonosc*/
}

void inicjuj_Route(int g[n][n],int R[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		if (g[i][j]!=0) R[i][j]=j;
}


void zeruj(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		g[i][j]=0;
}

void floyd(int g[n][n],int R[n][n])
{
int i,j,k;

for(k=0;k<n;k++)
  for(i=0;i<n;i++)
    for(j=0;j<n;j++)
    if(g[i][j]>g[i][k]+g[k][j])
      {
      g[i][j]=min( g[i][j], g[i][k]+g[k][j]);
      R[i][j]=k;
      }
}


void main()
{
int i,j,k;
zeruj(R);
zeruj(G);
init(D);
D[0][0]=0;D[1][1]=0;D[2][2]=0;D[3][3]=0;D[4][4]=0;D[5][5]=0;
D[0][3]=30;D[0][1]=10;D[1][2]=15;D[1][4]=40;D[2][3]=5;
D[2][4]=20;D[4][5]=20;D[4][6]=10;D[5][6]=5;D[6][3]=25;
G[0][3]=30;G[0][1]=10;G[1][2]=15;G[1][4]=40;G[2][3]=5;
G[2][4]=20;G[4][5]=20;G[4][6]=10;G[5][6]=5;G[6][3]=25;
inicjuj_Route(G,R);
floyd(D,R);
for(i=0;i<n;i++)
   for(j=0;j<n;j++)
     {
     if(G[i][j]==10000) printf("%d <--> %d drogi nie ma\n", i, j);
     else
     {
     if(i!=j)
       {
	printf("%d <--> %d = %d\n", i,j,G[i][j]);
	if(R[i][j]!=0)
		{
		printf("%d \t",i);
		k=i;
		while(k!=j)
			{
			k=R[k][j];
			printf("%d \t",k);
			}
		}
	 }
     }
     }



}



