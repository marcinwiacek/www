/*strspn.c*/
#include <stdio.h>
#include <string.h>
#include <alloc.h>

int main(void)
{
   char *string1 = "1234567890";
   char *string2 = "123DC8";
   int length;

   length = strspn(string1, string2);
   printf("Wspolna czesc az do pozycji  %d\n", length);
   return 0;
}