/*strncmp.c*/

#include <string.h>
#include <stdio.h>

int  main(void)

{
   char *buf1 = "aaabbb", *buf2 = "bbbccc", *buf3 = "ccc";
   int wynik;

   wynik = strncmp(buf2,buf1,3);
   if (wynik > 0)
      printf("buf2 > buf1\n");
   else
      printf("buf2 < buf1\n");

   wynik = strncmp(buf2,buf3,3);
   if (wynik > 0)
      printf("buf2 > buf3\n");
   else
      printf("buf2 < buf3\n");

   return(0);
}