/*asin.c*/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double result;
   double x = 0.5;

   result = asin(x);
   printf("Arc sinus liczby %f wynosi  %lf\n", x, result);
   return(0);
}