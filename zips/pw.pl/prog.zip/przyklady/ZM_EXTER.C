/*zm_ extern.c*/

#include <stdio.h>

void parzysta_nieparzysta(void);
void ujemna(void);

int klawisz;                       /* zmienna zewnetrzna (external variable)*/

void main(void)
   {
   printf("\nNacisnij klawisz: ");
   scanf("%d", &klawisz);
   parzysta_nieparzysta();
   ujemna();
   }


void parzysta_nieparzysta(void)
   {
   if ( klawisz % 2 )
      printf("Nieparzysta.\n");
   else
      printf("Parzysta.\n");
   }


void ujemna(void)
   {
   if ( klawisz < 0 )
      printf("Liczba ujemna.\n");
   else
      printf("Liczba dodatnia.\n");
   }
