
/*program zliczajacy dodatnie elementy  tablicy */

#include <stdio.h>


void main()
{
	int i,licznik=0,tablica[]={1,2,-23,76,-67,-100,457,765,54,11};


	for (i=0;i<10;i++)
		{
		if (tablica[i]<0)
			continue;
		licznik++;
		}
	printf("\nElementow wiekszych i rownych zeru jest %d",licznik);

}



1
CONTINUE.C


