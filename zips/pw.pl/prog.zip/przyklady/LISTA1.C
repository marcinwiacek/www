/* lista1.c*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1

void dodaj_nowy(void);
void wyswietl_liste(void);
void usun(void);
void zwolnienie_pamieci(void);

struct element
   {
   char informacja[30];
   struct element *nastepny;
   };

struct element *pierwszy = NULL;

void main(void)
   {
   char ch;

   while(TRUE)
      {
      printf("\n Nacisnij:'d'- wprowadzenie nowego elementu");
      printf("\n\t  'w' wyswietlenie wszystkich elementow");
      printf("\n\t  'u' usuniecie elementu,");
      printf("\n\t  'q' wyjscie ");
      ch = getc(stdin);
      fflush(stdin);
      switch(ch)
	 {
	 case 'd':
	    dodaj_nowy(); break;
	 case 'w':
	    wyswietl_liste(); break;
	 case 'u':
	    usun(); break;
	 case 'q':
	    zwolnienie_pamieci(); break;
	 default:
	    puts("\nBledna dana wejsciowa");
	 }
      }
   }



void dodaj_nowy(void)
   {
   struct element *nowy;
   nowy =  malloc( sizeof(struct element) );
   if(nowy==NULL)
      {
      printf("Blad alokacji pamieci ");
      return;
      }
   nowy->nastepny = pierwszy;
   pierwszy = nowy;
   printf("\nPodaj informacje: ");
   gets(nowy->informacja);
   }


void wyswietl_liste(void)
   {
   struct element *tutaj;
   if (pierwszy == NULL )
      {
      printf("\nPusta lista.\n");
      return;
      }
   tutaj = pierwszy;
   do
      {
      printf("\ninformacja: %s\n", tutaj->informacja );
      tutaj = tutaj->nastepny;
      }
   while(tutaj != NULL);
   }



void usun(void)
   {
   struct element *tutaj;
   struct element *poprzedni;
   char info_do_usuniecia[30];
   if (pierwszy == NULL)
      {
      printf("\nPusta lista.\n");
      return;
      }
   printf("\nWprowadz informacje do usuniecia: ");
   gets(info_do_usuniecia);
   tutaj = pierwszy;
   do
      {
      if( strcmp(tutaj->informacja, info_do_usuniecia)==0 )
	 {
	 if(tutaj==pierwszy)
	    pierwszy = tutaj->nastepny;
	 else
	    poprzedni->nastepny = tutaj->nastepny;
	 free(tutaj);
	 return;
	 }
      poprzedni = tutaj;
      tutaj = tutaj->nastepny;
      }
   while(tutaj != NULL);
   printf("Informacja nie znajduje sie na liscie\n");
   }


void zwolnienie_pamieci(void)
   {
   struct element *tutaj, *zwolnij;

   if (pierwszy == NULL )
      exit(0);
   tutaj = pierwszy;
   do
      {
      zwolnij = tutaj;
      tutaj = tutaj->nastepny;
      free(zwolnij);
      }
   while(tutaj != NULL);
   exit(0);
   }