/*strcat.c*/

#include <string.h>
#include <stdio.h>

int main(void)
{
   char destination[25];
   char *b = " ", *p = "Programowanie", *c = "C";

   strcpy(destination, p);
   strcat(destination, b);
   strcat(destination, c);

   printf("%s\n", destination);
   return 0;
}