/* double2.ctab_2wym.c*/

#include <stdio.h>
#define ROWS 4
#define COLS 5

void main(void)
   {
   int tablica[ROWS][COLS] =
	      {  { 13, 15, 17, 19, 21 },
		 { 20, 22, 24, 26, 28 },
		 { 31, 33, 35, 37, 39 },
		 { 40, 42, 44, 46, 48 }  };
   int j, k;

   for(j=0; j<ROWS; j++)
      {
      for (k=0; k<COLS; k++)
	 printf("%d ", *(*(tablica+j)+k) );
      printf("\n");
      }
   }
