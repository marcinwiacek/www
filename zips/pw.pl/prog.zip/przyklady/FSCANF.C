/* fscanf.c*/

#include <stdio.h>

void main(void)
   {
   FILE *wsk_plik;
   char osoba[40];
   int wzrost;
   float waga;

   wsk_plik = fopen("osoba.txt", "r");
   fscanf(wsk_plik, "%s %d %f", osoba, &wzrost, &waga);
   printf("%s %03d %.2f\n", osoba, wzrost, waga);
   fclose(wsk_plik);

   }