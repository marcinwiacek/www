/* wsk_str.c*/

#include <stdio.h>

void main(void)
   {
   struct przyklad
      {
      int numer;
      char znak;
      };
   struct przyklad str;
   struct przyklad *wsk;

   wsk = &str;
   wsk->numer = 10;
   wsk->znak = 'X';
   printf("\nwsk->numer=%d", wsk->numer );
   printf("\nwsk->znak=%c\n",  wsk->znak );
   }
