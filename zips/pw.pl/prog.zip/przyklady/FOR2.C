/*program sumujacy poszczegolne elementy tablicy*/
#include <stdio.h>

void main()
{
	int i,suma=0,tablica[10];
	for (i=0;i<10;i++)
		{
		 printf("Wprowadz wartosc komorki %i=",i);
		 scanf("%i",&tablica[i]);
		 suma+=tablica[i];
		 }
       printf("Suma elementow wynosi= %d",suma);

}