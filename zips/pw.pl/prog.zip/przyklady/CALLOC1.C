/*calloc1.c*/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   char *wsk_znakowy = NULL;

   wsk_znakowy =(char *)calloc(10, sizeof(char));
   strcpy(wsk_znakowy, "Hello");
   printf("Tekst: %s\n", wsk_znakowy);
   free(wsk_znakowy);
   return 0;
}
