/* fopen.c*/

#include <stdio.h>


void main(void)
   {
   FILE *wsk_plik;
   char znak;

   wsk_plik = fopen("text.txt","w");
   while( (znak=getchar()) != '0' )
      putc(znak,wsk_plik);
   fclose(wsk_plik);
   }