#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student{
char imie[15];
char nazwisko[20];
struct student *nast;
};

void sortuj(struct student *root,struct student **t_im,struct student **t_naz)
{
 struct student *pomoc,*aktual;
 int i=0,j,k;
 char *najm;

for (aktual=root;aktual!=NULL;aktual=aktual->nast)
 {
  t_im[i]=aktual;
  t_naz[i]=aktual;
  i++;
 }

 for(j=0;j<i;j++)
  {
	najm=t_im[j]->imie;
	 for(k=j;k<i;k++)
	 {
	  if (strcmp(t_im[k]->imie,najm)<=0)
		{
		  najm=t_im[k]->imie;
		  pomoc=t_im[j];
		  t_im[j]=t_im[k];
		  t_im[k]=pomoc;
		}
	 }
  }
 for(j=0;j<i;j++)
 {
	najm=t_naz[j]->nazwisko;
	for(k=j;k<i;k++)
	{
	  if(strcmp(t_naz[k]->nazwisko,najm)<=0)
		{
		  najm=t_naz[k]->nazwisko;
		  pomoc=t_naz[j];
		  t_naz[j]=t_naz[k];
		  t_naz[k]=pomoc;
		}
	}
 }

}

void main()
{
 struct student *osoba,*korzen,*pomoc;
 struct student **tab_imie,**tab_nazw;
 int licz=1,i,koniec=0;

 korzen=NULL;
 printf(" * konczy wprowadzanie\n");

 do{
 osoba=(struct student *)malloc(sizeof(struct student));
 if (osoba!=NULL)
  {
 printf("Wprowadz imie studenta :\n");
 gets(osoba->imie);
 if (osoba->imie[0]=='*')
  {
	koniec=1;
	break;
  }
 printf("Wprowadz nazwisko studenta :\n");
 gets(osoba->nazwisko);
	if (korzen==NULL)
	 {
	  korzen=osoba;
	  korzen->nast=NULL;
	 }
  else
	{
	 osoba->nast=korzen;
	 korzen=osoba;
	}

  }
  else
	  printf("nie ma pami�ci na wykonanie programu !\n");


 }
 while(!koniec);
 tab_imie=(struct student **)malloc(sizeof(struct student));
 tab_nazw=(struct student **)malloc(sizeof(struct student));
 osoba=korzen;
 printf("Przed sortowaniem :\n");
 while(osoba!=NULL)
  {
	printf("Osoba nr : %d\n",licz);
	printf("Imie : %s\n" ,osoba->imie);
	printf("Nazwisko : %s\n",osoba->nazwisko);
	osoba=osoba->nast;
	licz++;
  }
 sortuj(korzen,tab_imie,tab_nazw);
 licz--;

 printf("Po sortowaniu wg imion :\n");
 for(i=0;i<licz;i++)
 {
  printf("Imie : %s\n",tab_imie[i]->imie);
  printf("Nazwisko : %s\n",tab_imie[i]->nazwisko);
 }
	getchar();

 printf("Po posortowaniu wg nazwisk :\n");
 for(i=0;i<licz;i++)
 {
  printf("Imie : %s\n",tab_nazw[i]->imie);
  printf("Nazwisko : %s\n",tab_nazw[i]->nazwisko);
 }
  getchar();

 for(osoba=korzen;osoba!=NULL;osoba=osoba->nast)
 {
	pomoc=osoba->nast;
	free(osoba);
 }
 free(tab_imie);
 free(tab_nazw);
}