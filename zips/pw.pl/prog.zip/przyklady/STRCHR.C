  /*strchr.c*/

 #include <string.h>
 #include <stdio.h>

int main(void)
 {
    char string[25];
    char c = 'l',*ptr;

    strcpy(string, "Dowolny ciag znakow");
    ptr = strchr(string, c);
    if (ptr)
       printf("Znak %c jest na pozycji: %d\n", c, ptr-string);
    else
       printf("The character was not found\n");
    return 0;
 }