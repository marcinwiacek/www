/*strlen.c */

#include <stdio.h>
#include <string.h>

int main(void)
{
   char *string = "Wyklad z Prog";

   printf("%d\n", strlen(string));
   return 0;
}