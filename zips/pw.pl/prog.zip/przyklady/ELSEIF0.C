/*kalkulator arytmetyczny*/

#include <stdio.h>

void main()
{
	float numer1,numer2;
	char operator,koniec='t';
	while (koniec!='n')
		{
		printf("\nPodaj liczbe1, operator+,-,*,/, liczbe2\n");
		scanf("%f %c %f",&numer1,&operator,&numer2);
		if (operator=='+')
			printf(" = %f.0", numer1+numer2);
		else if (operator == '-')
			printf(" = %f.0", numer1-numer2);
		else if (operator == '*')
			printf(" = %f.0", numer1*numer2);
		else if (operator == '/')
			printf(" = %f.0", numer1/numer2);
		else
		       printf("\n Bledny operator\n" );
		printf("\nPowtorne obliczenia [t/n] ");
		koniec=getch();
		}
}