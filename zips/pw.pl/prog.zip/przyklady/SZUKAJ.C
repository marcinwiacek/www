/*szukaj*/

#include <stdio.h>
#define n 5

int min(int a,int  b);
void init(int g[n][n]);
void zeruj(int g[n][n]);
void floyd(int g[n][n]);

int graf[n][n];

void main()
{
int i,j;

init(graf);
graf[0][1]=10;
graf[0][3]=15;
graf[1][3]=8;
graf[2][1]=32;
graf[3][2]=31;
graf[4][1]=44;
floyd(graf);
for(i=0;i<n;i++)
   for(j=0;j<n;j++)
     {
     if(graf[i][j]==10000) printf("%d <--> %d drogi nie ma\n",i, j);
     else
     if(i!=j) printf("%d <--> %d droga wynosi %d\n" ,i,j ,graf[i][j]);
     }
}

int min(int a,int  b)
{
if(a<b) return a;else return b;
}

void init(int g[n][n])
{
int i,j;
for(i=0;i<n;i++)
   for(j=0;j<n;j++)
		g[i][j]=10000;
}

void zeruj(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		g[i][j]=0;
}

void floyd(int g[n][n])
{
int i,j,k;

for(k=0;k<n;k++)
  for(i=0;i<n;i++)
    for(j=0;j<n;j++)
      g[i][j]=min( g[i][j], g[i][k]+g[k][j]);
}
