/* osoby.c */
#include <stdio.h>

void main(void)
   {
   struct osoby                /* deklaracja struktury*/
      {
      char nazwisko [30];
      int numer;
      };
   struct osoby pan1,pan2;        /* definicja zmiennych*/
   char numerstr[81];               /* wczytanie numeru*/

   printf("\nPan 1.\nNazwisko: ");
   gets(pan1.nazwisko);
   printf("Podaj numer (5 znakow): ");
   gets(numerstr);
   pan1.numer = atoi(numerstr);

   printf("\nPan 2.\nNazwisko: ");
   gets(pan2.nazwisko);
   printf("Podaj numer (5 znakow): ");
   gets(numerstr);
   pan2.numer = atoi(numerstr);

   printf("\nLista osob:\n" );
   printf("   Nazwisko: %s\n", pan1.nazwisko);
   printf("   Numer: %05d\n", pan1.numer);
   printf("   Nazwisko: %s\n", pan2.nazwisko);
   printf("   Numer: %05d\n", pan2.numer);
   }
