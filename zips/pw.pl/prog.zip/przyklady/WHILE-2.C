/* program wyswietla kod ASCI dla wprowadzonego znaku */

#include <stdio.h>

void main()
	{
	char znak='a';
	while (znak != 'k' )   /* Nacisniecie klawisza k konczy program */
		{
		printf("Nacisnij dowolny klawisz: ");
		znak=getch();
		printf("\nKod ASCI dla znaku %c wynosi %d\n", znak,znak);
		}
	 }