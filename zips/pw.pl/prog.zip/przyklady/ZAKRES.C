
#include <stdio.h>
#include <limits.h>
#include <float.h>


void main()
{
	printf("Rozmiary typow calkowitych\n");
	printf("Ilosc bitow w char %d\n",CHAR_BIT);
	printf("Maksymalna wartosc  char %d\n",CHAR_MAX);
	printf("Minimalnalna wartosc  char %d\n",CHAR_MIN);
	printf("Maksymalna wartosc  int %d\n",INT_MAX);
	printf("Minimalnalna wartosc  int %d\n",INT_MIN);
	printf("Maksymalna wartosc long int %ld\n",LONG_MAX);
	printf("Minimalnalna wartosc long int %ld\n",LONG_MIN);
	printf("Maksymalna wartosc signed char %d\n",SCHAR_MAX);
	printf("Minimalnalna wartosc  signed char %d\n",SCHAR_MIN);
	printf("Maksymalna wartosc short %d\n",SHRT_MAX);
	printf("Minimalnalna wartosc  short %d\n",SHRT_MIN);
	printf("Maksymalna wartosc unsigned char %hd\n",UCHAR_MAX);
	printf("Maksymalna wartosc unsigned int %u\n",UINT_MAX);
	printf("Maksymalna wartosc unsigned long %lu\n",ULONG_MAX);
	printf("Maksymalna wartosc unsigned short %u\n",USHRT_MAX);
	printf("Podstawa reprezentacji wykladnika potegi %d\n", FLT_RADIX);
	printf("Rodzaj zaokraglenia przy dodawaniu zmniennopozycyjnym %d\n", FLT_ROUNDS);
	printf("Liczba cyfr dziesietnych precyzji %d\n", FLT_DIG);
	printf("Najmniejsza liczba x taka ze x+1.0 !=1.0 %e\n", FLT_EPSILON);
	printf("Liczba liczb podstawy w mantysie % d\n", FLT_MANT_DIG);
	printf("Maksymalna liczba zmiennopozycyjna % e\n", FLT_MAX);
	printf("Minimalna liczba zmiennopozycyjna % e\n", FLT_MIN);
	printf("Liczba cyfr dziesietnych podwojnej precyzji %d\n", DBL_DIG);
	printf("Najmniejsza liczba double x taka ze x+1.0 !=1.0 %el\n", DBL_EPSILON);
	printf("Maksymalna liczba zmiennopozycyjna typu double %le\n", DBL_MAX);
	printf("Minimalna liczba zmiennopozycyjna typu double %le\n",DBL_MIN);
}
