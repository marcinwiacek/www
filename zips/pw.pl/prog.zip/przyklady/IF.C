/* program sprawdzajacy czy liczba jest ujemna*/

#include <stdio.h>

void main()
{
	float x=0;

	printf("\nWprowadz dowolna liczbe X= ");
	scanf("%f",&x);
	if (x >= 0)
		printf ("\nLiczba X wieksza lub rowna zero\n");
	else
		printf ("\nLiczba X mniejsza od zera\n");
}
