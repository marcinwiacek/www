/* unia.c*/

#include <stdio.h>

void main(void)
   {
   union intflo         /* declaracja unii*/
      {
      int intnum;       /*    liczba typu integer */
      float fltnum;     /*    liczba typu float */
      } unia;           /* definicja zmiennej 'unia' */

   printf("sizeof(union inflo)=%d\n", sizeof(union intflo) );
   unia.intnum = 734;
   printf("unia.intnum=%d\n", unia.intnum );
   unia.fltnum = 867.43;
   printf("unia.fltnum=%.2f\n", unia.fltnum );
   }
