/*strerror.c*/

#include <stdio.h>
#include <errno.h>

int main(void)
{
   char *buffer;
   int n=2;
   buffer = strerror(n);
   printf("Error nr %d: %s\n",n, buffer);
   return 0;
}