/* sort_z_fun.c*/

#include <stdio.h>
#define MAX 20

void sort(int[], int);

void main(void)
   {
   int tablica[MAX];
   int index = 0;
   int dex;

   printf("\nWprowadz liczby, 0 konczy\n");
   do
      {
      printf("Wprowadz liczbe: ");
      scanf("%d", tablica+index);
      }
   while ( *(tablica+index++) != 0 );
   sort(tablica,--index);
   for (dex=0; dex<index; dex++)
      printf("%d\n", *(tablica+dex));
   }


void sort(int tablica[], int index)
   {
   int k, i, temp;

   for (k=0; k<index-1; k++)
      for (i=k+1; i<index; i++)
	 if (*(tablica+k) > *(tablica+i))
	    {
	    temp = *(tablica+i);
	    *(tablica+i) = *(tablica+k);
	    *(tablica+k) = temp;
	    }
   }
