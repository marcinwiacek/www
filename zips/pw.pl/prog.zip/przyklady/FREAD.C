/* fread.c*/

#include <stdio.h>

struct przyklad
{
  int liczba;
  char znak;
};

int main(void)
{
   FILE *wsk_plik;
   struct przyklad s;

   if ((wsk_plik = fopen("TEST.txt", "r")) == NULL)
   {
      fprintf(stderr, "Nie moge otworzyc pliku.\n");
      return 1;
   }
   while (fread(&s, sizeof(s), 1, wsk_plik)==1)
	{
	printf("\nLiczba: %d\n", s.liczba);
	printf("\nZnak: %c\n", s.znak);
	}
   fclose(wsk_plik);
   return 0;
}