/* i_tabws.c*/

#include <stdio.h>
#include <string.h>
#define MAX 5

void main(void)
   {
   int index;
   int jest=0;
   char nazwa[40];
   char *lista[MAX] =       /*tablica wskaznikow do stringow*/
	       {  "Polonez",
		  "Fiat",
		  "Ford",
		  "Daewoo",
		  "Opel"     };

   printf("Wprowadz szukana nazwe: ");
      gets(nazwa);
   for (index=0; index<MAX; index++)
      if( strcmp(lista[index],nazwa)==0 )
	 {
	 jest = 1;
	 break;
	 }
   if ( jest == 1 )
	 printf("Znaleziono w spisie.\n");
   else
      printf("Brak danych!\n");
   }
