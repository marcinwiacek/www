/* fw_tab.c */

#include <stdio.h>
#include <stdlib.h>

int tablica[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

void main(void)
   {
   FILE *wsk_plik;

   if( (wsk_plik=fopen("tablica.txt","w"))==NULL )
      {
      printf("Nie moge otworzyc pliku\n");
      exit(1);
      }
   fwrite(tablica, sizeof(tablica), 1, wsk_plik);
   fclose(wsk_plik);
   }
