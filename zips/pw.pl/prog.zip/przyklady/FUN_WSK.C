/* fun_wsk.c*/

#include <stdio.h>

int funkcja(int, int);

void main(void)
   {
   int wynik;
   int (*fun_wsk)(int, int);

   fun_wsk = funkcja;
   wynik = (*fun_wsk)(2, 2);
   printf("\nwynik=%d\n", wynik);
   }

int funkcja(int a1, int a2)
   {
   return(a1 + a2);
   }
