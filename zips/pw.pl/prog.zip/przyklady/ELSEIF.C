/*program wyszukujacy wykorzystujacy algorytm bisekcji*/

#include <stdio.h>
#define ROZMIAR 10

void main()
{
	/*tablica posortowana od wartosci najwiekszych do najmniejszych*/
	int tablica[]={1000,900,800,700,600,500,400,300,200,100};
	int dol=0,srodek,gora=ROZMIAR-1;
	int x; /*szukana wartosc*/

	printf("W prowadz wartosc szukana x=");
	scanf("%d",&x);
	while(dol<=gora)
		{
		srodek=(dol+gora)/2;
		if (x<tablica[srodek])
			dol=srodek+1;
		else if (x>tablica[srodek])
			gora=srodek-1;
		else
		{
		printf("\n X znajduje sie na %i pozycji\n",srodek);
		break;
		}
		}

}
