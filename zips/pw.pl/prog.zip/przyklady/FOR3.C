/*program sortujacy Shell-sort*/

#include <stdio.h>
#define ROZMIAR 10

void main()
{
	int i,j;/* zmienne sterujace przebiegiem petli*/
	int odstep,temp;
	int tablica[ROZMIAR];

	for (i=0;i<ROZMIAR;i++)
		{
		 printf("Wprowadz wartosc komorki %i=",i);
		 scanf("%i",&tablica[i]);
		 }
	for (odstep=ROZMIAR/2;odstep>0;odstep/=2)
		for (i=odstep; i<ROZMIAR; i++)
			for (j=i-odstep;j>=0 && tablica[j]>tablica[j+odstep]; j-=odstep)
			  {
			   temp=tablica[j];
			   tablica[j]=tablica[j+odstep];
			   tablica[j+odstep]=temp;
			  }
	for (i=0;i<ROZMIAR;i++) printf("Wartosc komorki %i=%i\n",i, tablica[i]);


}