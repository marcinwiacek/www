/* zamiana.c*/
#include <stdio.h>

void zamiana1(int,int);
void zamiana2(int *,int *);

void main()
{
	int a,b;
	int *wsk_a, *wsk_b;

	printf("\nPodaj wartosc a =");
	scanf("%d",&a);
	printf("\nPodaj wartosc b =");
	scanf("%d",&b);
	wsk_a=&a;
	wsk_b=&b;
	zamiana1(a,b);
	printf("\nWartosc a wynosi %d, wartosc b wynosi %d",a,b);
	zamiana2(wsk_a,wsk_b);
	printf("\nWartosc a wynosi %d, wartosc b wynosi %d\n",a,b);
}

void zamiana1(int a,int b)
{
	int temp;

	temp=a;
	a=b;
	b=temp;
}

void zamiana2(int *wa,int *wb)
{
	int temp;
	temp=*wa;
	*wa=*wb;
	*wb=temp;
}
 
