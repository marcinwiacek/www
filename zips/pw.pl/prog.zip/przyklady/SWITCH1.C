/* program zliczajacy ilosc wystapien poszczegolnych cyfr w ciagu znakow*/
#include <stdio.h>
#define ROZMIAR1 200
#define ROZMIAR2 10

void main()
{
	char ciag[ROZMIAR1];/*tablica znakowa*/
	int i,j=0,licznik[ROZMIAR2];

	printf("Podaj ciag znakow do analizy\n");
	scanf("%s",ciag);
	for (i=0;i<ROZMIAR2;licznik[i++]=0);
	while (ciag[j]!='\0')
		{
		switch (ciag[j])
			{
			case '0':
				licznik[0]++;
				break;
			case '1':
				licznik[1]++;
				break;
			case '2':
				licznik[2]++;
				break;
			case '3':
				licznik[3]++;
				break;
			case '4':
				licznik[4]++;
				break;
			case '5':
				licznik[5]++;
				break;
			case '6':
				licznik[6]++;
				break;
			case '7':
				licznik[7]++;
				break;
			case '8':
				licznik[8]++;
				break;
			case '9':
				licznik[9]++;
				break;
			default:;
			}
		j++;
		}
	for(i=0;i<ROZMIAR2;i++)
		printf("\nLiczba wystapien %d wynosi %d",i,licznik[i]);
}