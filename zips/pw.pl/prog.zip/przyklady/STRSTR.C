/*strstr.c*/

#include <stdio.h>
#include <string.h>

int main(void)
{
   char *str1 = "Wyklad z Prog", *str2 = "rog", *ptr;

   ptr = strstr(str1, str2);
   printf("Podciag na pozycji : %d\n", ptr-str1);
   return 0;
}