/*zm_stati.c*/

#include <stdio.h>

int fun(void);

void main(void)
   {
   int j;

   for(j=0; j<10; j++)
      printf("\nWywolanie funkcji numer: %d\n ", fun() );
   }

int fun(void)
   {
   static int k;

   return(++k);
   }
