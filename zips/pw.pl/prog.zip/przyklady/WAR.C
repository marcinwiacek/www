/* war*/

#include <stdio.h>
#define n 5

int G[n][n];

void zeruj(int g[n][n]);
void warshall(int g[n][n]);
void wypisz(int g[n][n],int numer);

void main()
{
int i,j;
zeruj(G);

G[0][1]=1;
G[0][3]=1;
G[1][3]=1;
G[2][1]=1;
G[3][2]=1;
G[4][1]=1;

wypisz(G,1);
warshall(G);
wypisz(G,2);
}

void warshall(int g[n][n])
{
int x,y,z;

for(x=0;x<n;x++)
  for(y=0;y<n;y++)
    for(z=0;z<n;z++)
       if(g[y][z]==0) g[y][z]=g[y][x]*g[x][z];
}

void wypisz(int g[n][n],int numer)
{
int i,j;

if (numer==1)
	printf("To jest tablica przed wykonaniem algorytmu J_W\n");
else
	printf("To jest tablica po wykonanu algorytmu J_W\n");

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
    {
     printf("%d   ",g[i][j]);
     if(j==n-1) printf("\n");
    }

}
void zeruj(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		g[i][j]=0;
}
