/*modf.c*/

#include <math.h>
#include <stdio.h>

int main(void)
{
   double fraction, integer;
   double number = 100000.567;

   fraction = modf(number, &integer);
   printf("LIczba: %lf czesc calkowita %lf i ulamkowa %lf\n",
	  number, integer, fraction);
   return 0;
}