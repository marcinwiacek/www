/*sortowanie babelkowe */

#include <stdio.h>
#define ROZMIAR 10

void main()
{
	int i,j,temp,tablica[ROZMIAR];
	for (i=0;i<ROZMIAR;i++)
		{
		printf("\n Podaj liczbe: ");
		scanf("%d",&tablica[i]);
		}
	/*sortowanie*/
	for (i=0; i<ROZMIAR;i++)
		for(j=i+1;j<ROZMIAR;j++)
			if(tablica[i] > tablica[j])
				{
				temp=tablica[i];
				tablica[i]=tablica[j];
				tablica[j]=temp;
				}
       /*tablica posortowana*/
       for (i=0;i<ROZMIAR;i++)
		printf("%d\n",tablica[i]);


}