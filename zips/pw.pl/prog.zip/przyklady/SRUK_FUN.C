/* strfun_w.c*/


#include <stdio.h>

#include <stdlib.h>             /* for atof()*/
#define TRUE 1

struct personel
   {
   char nazwisko[30];
   int numer;
   float wzrost;
   };

void nowy(int n, struct personel *wsk_osoba);
void wypisz(int n, struct personel tablica_osob[]);

void main(void)
   {
   struct personel tablica_osob[50];  /* tablica 50 osob*/
   struct personel *wsk_osoba;
   int n = 0;
   char ch;

   while( TRUE )
      {
      printf("\nNacisnij 'n' zeby wprowadzic nowa osobe,");
      printf("\n	 'w' aby wyswietlic wszystkie osoby,");
      printf("\n	 'k' aby zakonczyc: ");
      ch = getchar();
      switch (ch)
	 {
	 case 'n':
	    wsk_osoba = &tablica_osob[n];
	    nowy(n, wsk_osoba );
	    n++;
	    break;
	 case 'w':
	    wypisz(n, tablica_osob);
	    break;
	 case 'k':
	    exit(0);
	 default:
	    printf("\nZly klawisz");
	 }
      }
   }



void nowy(int num, struct personel *ptrag)
   {
   char string[81];

   printf("\nDana %d.\nWprowadz nazwisko : ", num+1);
   gets(ptrag->nazwisko);
   printf("Wproadz numer (3 cyfry): ");
   gets(string);
   ptrag->numer = atoi(string);
   printf("Wproadz wzrost w centymetrach : ");
   gets(string);
   ptrag->wzrost = atof(string);
   }



void wypisz(int num, struct personel tablica_osob[])
   {
   int j;
   if (num < 1)
      printf("\nBrak danych.\n");
   for (j=0; j < num; j++)
      {
      printf("\nOsoba nr. %d\n", j+1);
      printf("  Nazwisko: %s\n", tablica_osob[j].nazwisko);
      printf("  Numer: %03d\n", tablica_osob[j].numer);
      printf("  Wzrost: %4.2f\n", tablica_osob[j].wzrost);
      }
   }
