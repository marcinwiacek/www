/*program zamieniajacy liczbe int na postac znakowa */

#include <stdio.h>
#define ROZMIAR 100

void main()
{
	char znak,znaki[ROZMIAR];
	int i=0,liczba,dzielnik;

	printf("Podaj liczbe do zamiany X= ");
	scanf("%d",&liczba);
	if (liczba<0 ) /*zapamietanie znaku liczby*/
		{
		znak='-';
		liczba=-liczba;
		znaki[i++]=znak;
		}

	for (dzielnik=1; (liczba / (dzielnik*10)) >= 1;dzielnik*=10);
	do
		{
		znaki[i++]=liczba/dzielnik+'0';
		liczba%=dzielnik;
		dzielnik/=10;
		}
	while (dzielnik >= 1 );
	znaki[i]='\0';
	printf("\nPostac znakowa %s",znaki);

}