 /*strcmp.c*/

 #include <string.h>
 #include <stdio.h>

int main(void)
 {
    char *buf1 = "aaa", *buf2 = "bbb";
    int wynik;

    wynik = strcmp(buf2, buf1);
    if (wynik > 0)
       printf("buf2 wieksze niz buf1\n");
    else
       printf("buf2 mniejszeniz buf1\n");
  return 0;
 }