/* reallo1.c*/

#include <stdio.h>
#include <stdlib.h>

#define PRZYROST 10

void main(void)
   {
   int *wskaznik = NULL;
   int n = 0;
   int liczba_bajtow = 0;
   int j;

   printf("\n");
   do
      {
      if(n*sizeof(int) >= liczba_bajtow)
	 {
	 wskaznik = realloc(wskaznik, PRZYROST);
	 if(wskaznik==NULL)
	    { printf("\nNiemozna realokowac pamieci"); exit(1); }
	 liczba_bajtow += PRZYROST;
	 printf("Liczba zaalokowanych bajtow = %d\n", liczba_bajtow );
	 }
      printf("Wprowadz liczbe: ");
      scanf( "%d", &wskaznik[n] );
      }
   while(wskaznik[n++] != 0);

   for(j=0; j<n-1; j++)
      printf("%7d ", wskaznik[j]);
   free(wskaznik);
   }