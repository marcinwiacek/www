/* fgets.c */

#include <stdio.h>

void main(void)
   {
   FILE *wsk_plik;
   char linia[40];

   wsk_plik = fopen("linie.txt", "r");
   while( fgets(linia, 80, wsk_plik) != NULL )
      printf("%s", linia);
   fclose(wsk_plik);
   }