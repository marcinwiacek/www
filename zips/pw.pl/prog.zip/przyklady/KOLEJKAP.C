/*kolejkap.c */

#include <stdio.h>
#include <stdlib.h>
#define ROZMIAR_KOLEJKI 12

void wstaw(int x);
int  obsluz();
void DoGory();
void NaDol();
void pisz();

int *sterta,L;

void main()
{
	int i, x,t[12]={37,41,26,14,19,99,23,17,12,20,25,42};

	sterta=(int *)malloc(ROZMIAR_KOLEJKI*sizeof(int));
	for(i=1;i<=12;i++) wstaw(t[i-1]);
	printf("Nowa sterta:\n");
	pisz();
	obsluz();
	printf("sterta po 1-krotnej obsludze:\n");
	pisz();
	obsluz();
	printf("sterta po 2-krotnej obsludze:\n");
	pisz();
	obsluz();
	printf("sterta po 3-krotnej obsludze:\n");
	pisz();
}

void DoGory()
{
	int temp=sterta[L];
	int n=L;

	while((n!=1)&&(sterta[n/2]<=temp))
		{
		sterta[n]=sterta[n/2];
		n=n/2;
		}
	sterta[n]=temp;
}



void wstaw(int x)
{
	sterta[++L]=x;
	DoGory();
}

void NaDol()
{
	int temp,i=1;
	while(1)
		{
		int p=2*i;    	 /* lewy potomek wezla "i"=p, prawy=p+1*/
		if(p>L)break;
		if(p+1<=L)             /* prawy potomek niekoniecznie musi istniec */
		if(sterta[p]<sterta[p+1]) p++; /*przesuwamy sie do nastepnego*/
		if(sterta[i]>=sterta[p]) break;
		temp=sterta[p];
		sterta[p]=sterta[i];
		sterta[i]=temp;
		i=p;
		}
}

int obsluz()
{
	int x=sterta[1];

	sterta[1]=sterta[L--];
	NaDol();
	return x;
}

void pisz()
{
	int j, i=1;

	while(i<=L)
		{
		for(j=i;(j<=L)&&(j<2*i);j++)
		printf("%d,", sterta[j]);
		i*=2;
		printf("\n");
		}
}
