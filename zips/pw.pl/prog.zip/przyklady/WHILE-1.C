/* program wypisuje 10 pierwszych liczb*/

#include <stdio.h>

void main()
	{
	int liczba=0;

	while (++liczba <= 10 )
		{
		printf("\nLiczba %d\n", liczba);
		}
	 }