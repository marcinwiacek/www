/*strrchr.c*/

#include <string.h>
#include <stdio.h>

int main(void)
{
   char string[25];
   char *ptr, c = 'c';

   strcpy(string, "Dowolny ciag znaczkow");
   ptr = strrchr(string, c);
   if (ptr)
      printf("Ostatnie %c jest na pozycji: %d\n", c, ptr-string);
   else
      printf("The character was not found\n");
   return 0;
}