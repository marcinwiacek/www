/* kompozy.c*/

#include <stdio.h>
#define n 5 /* graf o 5 wierzcholkach*/

int G1[n][n],G2[n][n],G3[n][n];

void zeruj(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		g[i][j]=0;
}

void kompozycja(int g1[n][n],int g2[n][n],int g3[n][n])
{
int x,y,z;
for(x=0;x<n;x++)
  for(y=0;y<n;y++)
  {
  z=0;
  while(1)
    {
    if(z==n) break;
    if( (g1[x][z]==1)&&(g2[z][y]==1))
	    {
	     g3[x][y]=1;
	     break;
	    }
    z++;
   }
  }
}


void wypisz(int g[n][n],int numer)
{
int i,j;
printf("To jest tablica:%d\n", numer);
for(i=0;i<n;i++)
	for(j=0;j<n;j++)
    {
     printf("%d   ",g[i][j]);
     if(j==n-1) printf("\n");
    }
}

void main()
{
zeruj(G1);
zeruj(G2);
zeruj(G3);

G1[1][0]=1;
G1[0][2]=1;
G1[3][2]=1;
G1[1][3]=1;
G1[4][3]=1;
G1[1][4]=1;

G2[4][0]=1;
G2[0][1]=1;
G2[2][1]=1;
G2[4][2]=1;
G2[1][3]=1;
G2[3][3]=1;

wypisz(G1,1);
wypisz(G2,2);
kompozycja(G1,G2,G3);
wypisz(G3,3)
}


