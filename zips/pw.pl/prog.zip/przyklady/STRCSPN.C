/*strcspn.c*/

 #include <stdio.h>
 #include <string.h>
 #include <alloc.h>

int main(void)
 {
    char *string1 = "1234567890";
    char *string2 = "747DC8";
    int length;

    length = strcspn(string1, string2);
    printf("Rozne znaki az do pozycji: %d\n", length);

    return 0;
 }