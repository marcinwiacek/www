/* odczyt.c*/

#include <stdio.h>

void main(void)
   {
   FILE *wsk_plik;
   int znak;

   wsk_plik = fopen("text.txt","r");
   while( (znak=getc(wsk_plik)) != EOF )
      printf("%c", znak);
   fclose(wsk_plik);
   }