/*bsearch.c*/

#include <stdlib.h>
#include <stdio.h>

#define NELEMS(arr) (sizeof(arr) / sizeof(arr[0]))

int numarray[] = {123, 145, 512, 627, 800, 933};

int numeric (const int *p1, const int *p2)
{
   return(*p1 - *p2);
}

int lookup(int key)
{
   int *itemptr;

   itemptr = bsearch (&key, numarray, NELEMS(numarray),
   sizeof(int), (int(*)(const void *,const void *))numeric);
   return (itemptr != NULL);
}

int main(void)
{
   if (lookup(512))
      printf("512 znaleziono.\n");
   else
      printf("512 nie znalezino.\n");

   return 0;
}
