/* tablica.c*/

#include <stdio.h>

void main(void)
   {
   int numer[] = { 92, 81, 70, 69, 58 };
   int licznik;

   printf("\n");
   for (licznik=0; licznik<5; licznik++)
      printf("\n%d", *(numer+licznik) );
   }
