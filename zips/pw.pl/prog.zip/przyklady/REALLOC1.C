/*  realloc1.c */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
   char *wsk_znakowy;


   wsk_znakowy =(char *)malloc(10);
   strcpy(wsk_znakowy, "Hello");
   printf("tekst %s\n  zaalokowany pod adresem  %p\n", wsk_znakowy, wsk_znakowy);
   wsk_znakowy =(char *)realloc(wsk_znakowy, 20);
   printf("Tekst %s\n  pod nowym adresem  %p\n", wsk_znakowy, wsk_znakowy);
   free(wsk_znakowy);
   return 0;
}