/* sortuj_p.c*/

#include <stdio.h>
#include <string.h>

#define MAXN 30                /* maksymalna liczba lini*/
#define MAXL 81                /* maksymalna dlugosc tekstu*/

void main(void)
   {
   char tekst[MAXN][MAXL];    /*tablica znakowa*/
   char *wskazniki[MAXN];     /* tablica wskaznikow do char */
   char *temp;
   int liczba = 0;            /* liczba wprowadzonych linii*/
   int i, k;                  /* indeksy*/
   
   printf("\n");
   while ( liczba < MAXN )      /* pobierz tekst*/
      {
      printf("tekst %d: ", liczba+1);
      gets(tekst[liczba]);
      if ( strlen(tekst[liczba])==0 )
	 break;                   /* brak danych*/
      wskazniki[liczba++] = tekst[liczba];
      }

   /* sortowanie wskaznikow */

   for (k=0; k<liczba-1; k++)   /* dla kazdego stringu*/
      for (i=k+1; i<liczba; i++) /* znajdz najmniejszy*/
	 if ( strcmp(wskazniki[k],wskazniki[i]) > 0 )  /* porownanie*/
	    {
	    temp = wskazniki[i];
	    wskazniki[i] = wskazniki[k];
	    wskazniki[k] = temp;
	    }

   printf("\nPosortowany tekst : \n");
   for (k=0; k<liczba; k++)
      printf("tekst %d: %s\n", k+1, wskazniki[k]);
   }
