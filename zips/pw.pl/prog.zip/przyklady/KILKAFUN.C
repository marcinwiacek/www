/* kilkaFun.c*/

#include <stdio.h>
int sumsqr(int, int);
int sqr(int);
int sum(int, int);

void main(void)
   {
   int num1, num2;

   printf("\nWprowadz dwie liczby : ");
   scanf("%d %d", &num1, &num2);
   printf("Suma kwadratow liczb wynosi %d\n", sumsqr(num1,num2) );
   }



int sumsqr(int j,int k)
   {
   return( sum( sqr(j), sqr(k) ) );
   }



int sqr(int z)
   {
   return(z * z);
   }


int sum(int x, int y)
   {
   return(x + y);
   }

