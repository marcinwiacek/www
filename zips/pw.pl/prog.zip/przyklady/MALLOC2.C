/* malloc2.c*/

#include <stdlib.h>

void main(void)
   {
   unsigned liczba_int = 20000;
   unsigned liczba_bajtow_pam;

   int *wskaznik;
   unsigned j;

   liczba_bajtow_pam = liczba_int * sizeof(int);
   wskaznik =(int *)malloc(liczba_bajtow_pam);
   for(j=0; j<liczba_int; j++)
     *(wskaznik+j) = j;
   free(wskaznik);
   }