/* wszerz.c*/

#include <stdio.h>
#include "kolejka.h"
#define n 7

void szukaj(int G[n][n],int Z[n],int i)
{
int s,k;

wstaw(i);

while(!pusta())
 {
 obsluz(&s);
 Z[s]=1;
 printf("Wyjmuje z kolejki wezel nr. %d\n",s);

 for(k=0;k<n;k++)
	if(G[s][k]!=0)
			if(Z[k]==0)
			 {
			 Z[k]=1;
			 wstaw(k);
			 printf("Wstawiam do kolejki wierzcholek nr. %d\n",k);
			 }
 }
}

int main()
{
int i,j, G[n][n], Z[n];

for(i=0;i<n;i++)
  for(j=0;j<n;j++)
	 G[i][j]=0;

G[0][1]=1;G[0][2]=1;G[0][3]=1;
G[1][2]=1;G[2][3]=1;G[1][4]=1;G[3][5]=1;G[4][6]=1;
for(i=0;i<n;i++) Z[i]=0;
szukaj(G,Z,0);
}



