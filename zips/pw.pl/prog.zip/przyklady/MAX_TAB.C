/* max_tab.c*/

#include <stdio.h>
#define MAX 20

int max(int[], int);

void main(void)
   {
   int tablica[MAX];
   int index = 0;
   int num;

   printf("\nWprowadz liczby, 0 konczy\n");
   do
      {
      printf("Wproadz liczbe: ");
      scanf("%d", &tablica[index]);
      }
   while ( tablica[index++] != 0 );
   num = max(tablica,index-1);
   printf("Najwieksza liczba jest %d\n", num);
   }



int max(int tablica[], int index)
   {
   int i, max;
   max = tablica[0];
   for (i=1; i<index; i++)
      if ( max < tablica[i] )
	 max = tablica[i];
   return(max);
   }
