/*szukaj_d*/

#include <stdio.h>
#define n 5

int graf[n][n];

void zeruj(int g[n][n]);
void droga(int x, int y, int g[n][n]);
void wypisz(int g[n][n],int numer);

void main()
{
int i,j;

zeruj(graf);

graf[0][1]=1;
graf[0][3]=1;
graf[1][3]=1;
graf[2][1]=1;
graf[3][2]=1;
graf[4][1]=1;

wypisz(graf,1);
for(i=0;i<n;i++)
   for(j=0;j<n;j++)
    {
     printf("Doga od wierzcholka \"%d:\" do \"%d\":\n",i,j);
     droga(i,j,graf);
    }
}



void zeruj(int g[n][n])
{
int i,j;

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		g[i][j]=0;
}


void droga(int x, int y, int g[n][n])
{
int k;

if(g[x][y]!=0)
	 {
	 printf("%d \t",x);
	 k=x;
	 while(k!=y)
	      {
	      k=g[k][y];
	      printf("%d \t",k);
	      }
	 }
printf("\n");
}

void wypisz(int g[n][n],int numer)

{
int i,j;

if (numer==1)
	printf("To jest tablica przed wykonaniem algorytmu J_W\n");
else
	printf("To jest tablica po wykonanu algorytmu J_W\n");

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
		{
		printf("%d   ",g[i][j]);
		if(j==n-1) printf("\n");
		}
}

