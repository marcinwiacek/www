/*wy_ar.c*/

#include <stdlib.h>
#include "stos.h"

void wypisz(struct wyrazenie *w);
int poprawne(struct wyrazenie *w);
double oblicz(struct wyrazenie *w);

struct  dane
{
	double wartosc;
	char operator;
};

void main()
{

	struct dane t[9]={{2,'0'},{3,'0'},{0,'+'},{7,'0'},{9,'0'},{0,'*'},{0,'+'},{12.5,'0'},{0,'*'}};
	struct wyrazenie *x,*l1,*p1;
	int i;

	for(i=0;i<9;i++)
		{
		x=(struct wyrazenie *)malloc(sizeof(struct wyrazenie));
		if((t[i].operator=='*')||(t[i].operator=='+')||(t[i].operator=='-')||(t[i].operator=='/')||(t[i].operator==':'))
			x->operator =t[i].operator;
			else
			{
			x->wartosc=t[i].wartosc;x->operator='0';
			}
		x->lewy =NULL;
		x->prawy=NULL;
		if((t[i].operator=='*')||(t[i].operator=='+')||(t[i].operator=='-')||(t[i].operator=='/')||(t[i].operator==':'))
			{
			pop(&l1);
			pop(&p1);
			x->lewy =l1;
			x->prawy=p1;
			}
		push(x);
		}
wypisz(x);
printf("= %0.1f \n" ,oblicz(x));
}


void wypisz(struct wyrazenie *w)
{
	if(w->operator=='0')
		printf("%0.1f",w->wartosc);
	else
		{
		printf("(");
		wypisz(w->lewy);
		printf("%c", w->operator);
		wypisz(w->prawy);
		printf(")");
		}
}

int poprawne(struct wyrazenie *w)
{
	if(w->operator=='0') return 1;
	switch (w->operator)
	  {
	  case '+':
	  case '-':
	  case '*':
	  case ':':
	  case '/': return (poprawne(w->lewy)*poprawne(w->prawy));
	  default : return (0);  /*blad*/
	  }

}

double oblicz(struct wyrazenie *w)
{
	if(poprawne(w))
		if (w->operator=='0') return (w->wartosc); /* pojedyncza wartosc*/
	 else
		switch (w->operator)
			{
			case '+':return oblicz(w->lewy)+oblicz(w->prawy);
			case '-':return oblicz(w->lewy)-oblicz(w->prawy);
			case '*':return oblicz(w->lewy)*oblicz(w->prawy);
			case ':':
			case '/':if(oblicz(w->prawy)!= 0)
					return (oblicz(w->lewy)/oblicz(w->prawy));
					else
						{
						printf ("\nDzielenie przez zero!\n");
						exit(-1);
						}
      }
    else printf("Blad skladni...!\n");
}
