/* fprintf.c */

#include <stdio.h>
#include <string.h>

void main(void)
   {
   FILE *wsk_plik;
   char osoba[40];
   int wzrost;
   float waga;

   wsk_plik = fopen("osoba.txt", "w");
   printf("Wprowadz Nazwisko, wzrost i wage: ");
   scanf("%s %d %f", osoba, &wzrost, &waga);
   fprintf(wsk_plik, "%s %d %f", osoba, wzrost, waga);
   fclose(wsk_plik);

   }