/*program wypisujacy zawartosc tablicy*/
#include <stdio.h>

void main()
{
	int i,tablica[10]={1,4,7,12,0,-3,1,45,100,999};

	for (i=0;i<10;i++) printf("Zawartosc komorki %i wynosi %i\n",i,tablica[i]);
}