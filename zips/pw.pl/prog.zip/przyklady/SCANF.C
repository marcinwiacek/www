/*przykladowe uzycia funkcji scanf*/

#include <stdio.h>

void main()
{
	int dzien;
	char  nazwa_miesiaca[30], znak;
	float x;
	printf("\nPodaj dowolny znak : ");
	scanf("%c",&znak);
	printf("\nPodaj numer dnia= ");
	scanf("%d",&dzien);
	printf("\nPodaj nazwe miesiaca: ");
	scanf("%s",nazwa_miesiaca);
	printf("\nZnak : %c",znak);
	printf("\nPodaj dowolna liczbe zmiennopozycyjna : ");
	scanf("%f",&x);
	printf("\nNumer dnia: %d",dzien);
	printf("\nNazwe miesiaca: %s",nazwa_miesiaca);
	printf("\nLiczba zmiennopozycyjna : %f\n",x);
}
