/* str_zag.c*/

#include <stdio.h>

struct personel
   {
   char nazwisko [30];
   int numer;
   };

struct zespol
   {
   struct personel boss;
   struct personel pracownik;
   };

struct zespol zespol1 =
   { { "Jasio", 1 },
     { "Zosia", 2 }  };

void main(void)
   {
   printf("\nboss:\n" );
   printf("   nazwisko: %s\n", zespol1.boss.nazwisko);
   printf("      numer: %03d\n", zespol1.boss.numer);
   printf("pracownik:\n" );
   printf("   nazwisko: %s\n", zespol1.pracownik.nazwisko);
   printf("      numer: %03d\n", zespol1.pracownik.numer);
   }
