/* zmienD_M.c*/
#include <stdio.h>

char zmienDM(void);

void main(void)
   {
   char znak;
   printf("\nWprowadz dowolna litere ");
   znak = zmienDM();
   printf("\nLitera po konwersji %c\n",znak);
   }


char zmienDM(void)
   {
   char znak;
   znak = getchar();
   if ( znak>64 && znak<91 )  /* sprawdzenie czy duza litera*/
      return(znak + 32);    /* konwersja na male*/
   else
      return (znak);
   }
