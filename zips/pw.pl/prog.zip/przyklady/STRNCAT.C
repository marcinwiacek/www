/*strncat.c*/

#include <string.h>
#include <stdio.h>

int main(void)
{
   char destination[25];
   char *source = " States";

   strcpy(destination, "United");
   strncat(destination, source, 7);
   printf("%s\n", destination);
   return 0;
}