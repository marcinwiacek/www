/*sortowanie babelkowe */

#include <stdio.h>
#define ROZMIAR 10

int main()
{
	int i,j,temp,tablica[ROZMIAR],w=1;
	for (i=0;i<ROZMIAR;i++)
		{
		printf("\n Podaj liczbe (%d): ",i+1);
		scanf("%d",&tablica[i]);
		}
	/*sortowanie*/
	while (w==1)
		{
		w=0;
		for(j=0;j+1<ROZMIAR;j++)
			if(tablica[j] > tablica[j+1])
				{
				temp=tablica[j];
				tablica[j]=tablica[j+1];
				tablica[j+1]=temp;
				w=1;
				}
		}
       /*tablica posortowana*/
       for (i=0;i<ROZMIAR;i++)
		printf("%d\n",tablica[i]);

return 0;
}