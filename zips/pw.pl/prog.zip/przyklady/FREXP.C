/*frexp.c*/

#include <math.h>
#include <stdio.h>

int main(void)
{
   double mantissa, number;
   int exponent;

   number = 8.0;
   mantissa = frexp(number, &exponent);

   printf("Liczba: %lf= ", number);
   printf("%lf razy 2 ", mantissa);
   printf("do potegi %d\n", exponent);

   return 0;
}