/*fifo.c*/

#include <stdio.h>
#include <stdlib.h>
#define MAX_FIFO 10

char *fifo[MAX_FIFO];
int glowa,ogon;

void wstaw( char *element);
int obsluz(char *w);
int pusta(void);

void main(void)
{

	char s[80];
	int i,res;
	printf("Wprowadz 4 elementy;\n");
	for(i=0; i<4;i++)
		wstaw(gets(s));
	while(!pusta())
	     {
	      res=obsluz(s);
	      printf("Obsluzony zostal klient:%s\n",s);

	    }
}


  void wstaw( char *element)
  {
	fifo[ogon++]=(char *)malloc(sizeof(element));
	strcpy(fifo[ogon-1],element);
	if (ogon >MAX_FIFO) ogon=0;
  }

int obsluz(char *w)
{
	if (glowa==ogon) return -1;
	strcpy(w,fifo[glowa++]);
	if (glowa> MAX_FIFO) glowa=0;
	return 1;
}

int pusta(void)
{
if (glowa==ogon)
	return 1;
else
	return 0;
}
