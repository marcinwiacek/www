#include <stdio.h>
#include <conio.h>

void main(void)
{

  int n=10, p=4, q=10, r;
  clrscr();
  r=n==(p=q);
  printf("A: n=%d p=%d q=%d r=%d\n",n,p,q,r);
  n=p=q=r=4;
  n+=p+=q;
  printf("B: n=%d p=%d q=%d\n",n,p,q);
  q=n<p?n++:p++;
  printf("C: n=%d p=%d q=%d\n",n,p,q);
  q=n>p?++n:++p;
  printf("D: n=%d p=%d q=%d\n",n,p,q);

  n=4;p=2;
  q=n++ >p ||p++!=3;
  printf("E: n=%d p=%d q=%d\n",n,p,q);

  n=4;p=2;
  q=n++<p||p++!=3;
  printf("F: n=%d p=%d q=%d\n",n,p,q);

  n=4;p=2;
  q=++n==3&& ++p==3;
  printf("G: n=%d p=%d q=%d\n",n,p,q);

  n=4;p=2;
  q=++n==6&&++p==3;
  printf("H: n=%d p=%d q=%d\n",n,p,q);
}
























