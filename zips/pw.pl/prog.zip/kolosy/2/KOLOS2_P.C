#include <stdio.h>
#include <conio.h>

char input[]="CREDOPOSOGERO1\1\11W\1PIJOKOSTRA1";
void main(void)
{

  int i,c;
  clrscr();
  for (i=2;(c=input[i])!='\0';i++){
  switch(c){
  case 'a': putchar('i');continue;
  case '1': break;
  case 1: while( (c=input[++i]) != '\1' && c!='\0');
 // continue;
  case 9: putchar('D');
  case 'O': case 'P' :continue;
  default:putchar(c);continue;
  }
  putchar(' ');
  }
  putchar('\n');
}