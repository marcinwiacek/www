#include<stdio.h>
#define A(x,y,z) y*i+3*x+z

void fun1(int*);
void fun2(float*);

void main(void)
{ float *wsk,arr[]={1.15e-3,3.14142,-2.145,-45.678,-376345e+2};
  int tab[]={3,2,1}, i=3, j=4;
  printf("\n Zestaw 1: \n %d, %d, %d\n",A(2,3-1,4)*2,A(2+3,4,5)/2,3*A(4,2,5)%2);
  wsk=&arr[0];
  printf("%9s:%3.f,%15.3e\n","ptr=arr",*wsk+j,*(wsk+j));
  fun1(tab);
  fun2(wsk++);
}

void fun1(int *tab)
{ int i=2,j;
  i=(j=tab[1])+1;
  ++tab[--j];
  tab[i++-1]-=--j;
  printf("Fun1: %2d,%-3d,%d: %-5d>%3d",--i,j+++1,*tab,tab[1],tab[2]);
}

void fun2(float *wsk)
{ int j,i=2;
  printf("\n Fun2:\n");
	 for(j=1;i+=j;j++)
		printf("%10s %1n %1s: %-5.f %2e\n","wsk=arr[",--i"]",+wsk+j,(*wsk+j)**(wsk+j));
}

