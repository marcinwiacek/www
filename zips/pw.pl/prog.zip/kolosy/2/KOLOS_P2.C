#include <stdio.h>
#include <conio.h>

char *c[]={"TROI","LABA","ZUCH","CYNK"};
char **cp[]={c+3,c+2,c+1,c};
char ***cpp=cp;

void main(void)
{
  clrscr();
  printf("%s",**++cpp+2);
  printf("%s",*--*++cpp+2);
  printf("%s",*cpp[-2]+2);
//  printf("%s",*--*++cpp+2);
  printf("%s",cpp[-1][-1]+3);
}