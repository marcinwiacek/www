
#include <stdio.h>
#include <stdlib.h>
#define ABS(a) (((a)>0)?(a):-(a))
#define CUBABS(a) ABS((a)*(a)*(a))

void main(int argc, char *argv[])
{
  int i,j,k=20;
  if (argc !=2)
  {
    printf("Zle wywolanie programu!\n");
    exit(1);
  }
  
  if (*argv[1] <'1' ||*argv[1] >'9')
  {
    printf("Zly argument programu!\n");
    exit(2);
  }
  
  else
  {
    sscanf(argv[1], "%d",&i);
    k%=i;
    printf("Wynik0: %d\n",k);
    if (i>9)
      i=9;
    for (j=1;j<=i;j++)
    {
      k+=CUBABS(-1)*(-1);
      printf("Wynik%1d:   %d\n",j,k);
    }
    printf("Wynik: %d\n",k);
  }
}
