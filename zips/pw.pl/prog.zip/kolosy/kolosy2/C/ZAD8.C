#include<stdio.h>
#include "defsd.h"

 struct s1{
	    char s[5];
	    int i;
            struct s1 *s1p;
	  };



void main(void)

{
  static struct s1 a[] ={
                      {"ZUBR",1,a+1},
                      {"DZIK",2,a+2},
		      {"WILK",3,a}
		     };
   struct s1 *p = a;
   int i;

   PRINT3(s,a[0].s,p->s,a[2].s1p->s);

	for(i = 0; i < 2; i++)
	  {
	   PR(d,--a[i].i);
	   PR(c,++a[i].s[3]);
           NL;
	  }
	 
  PRINT3(s,(p->s),a[(++p)->i].s,a[--(p->s1p->i)].s);

}