extern int i;

int reset(void)
  {
    return (i);
  }