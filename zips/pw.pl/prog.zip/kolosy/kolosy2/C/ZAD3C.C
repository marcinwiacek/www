static int i = 33;

int next(void)
  {
    return(i += 5);
  }

int last(void)

  {
   return (i -= 6);
  }

int new(int i)
  {
    static int j = 8;
    return (i = j += i);
  }

