#include<stdio.h>
#define NL printf("\n");
char *c[] = {
	     "PLOT",
	     "FOG",
	     "PUNCH",                       
             "BREAD"
	    };

char **cp[] = {c+3, c+2, c+1, c};
char ***cpp = cp;


void main(void)

{/*printf("%s",cp);  NL
 printf("%s",*cp);   NL
 printf("%s",*cpp);   NL
   */
 printf("%s",**++cpp + 4);
 printf("%s",*--*++cpp + 2);
 printf("%s",*cpp[-2] + 4);
 printf("%s",cpp[-1][-1] + 1);
 printf("\n");
}