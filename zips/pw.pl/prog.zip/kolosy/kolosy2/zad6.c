#include <stdio.h>
#include <string.h>

void rev(char *s, int i, int k);
void main()
{
  char *p="ala ma kota";
  int i=0,k;
  k=strlen(p)-1;
  rev(p,i,k);
  for (i=0;i<=k;);
    printf("%c",p[i++]);
  printf("\n");
}

void rev(char s[], int i, int k)
{
int c;
if (k<=i)
  return;
else
  {
  c=s[i];
  s[i++]=s[k];
  s[k--]=c;
  rev(s,i,k);
  }
}
