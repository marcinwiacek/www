#include "defs.h"
#include <stdio.h>

char *c[]={
"TRANS",
"CROSS",
"DUCHA",
"CYKL"};

char **cp[]={c+3,c+2,c+1,c};
char ***cpp=cp;

int main (void)
{
  printf("%s",**++cpp+3);
  printf("%s",*--*++cpp+3);
  printf("%s",*cpp[-2]+2);
  printf("%s",cpp[-1][-1]+2);
return(0);
}
