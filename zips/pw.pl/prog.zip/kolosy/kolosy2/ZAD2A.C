static int i=8;

int next (void)
{
  return ( i+=3 );
}

int last (void)
{
  return ( i-=1 );
}

int new (int i)
{
  static int j=5;
  return ( i=j+=i );
}