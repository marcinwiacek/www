#include<stdio.h>
#define NL printf("\n");
char *c[] = {
	     "KLOC",
	     "TARA",
	     "OPAR",                       
             "TREL"
	    };

char **cp[] = {c+3, c+2, c+1, c};
char ***cpp = cp;


void main(void)

{printf("%s",cp);  NL
 printf("%s",*cp);   NL
 printf("%s",*cpp);   NL
 
 printf("%s",**++cpp + 1);
 printf("%s",*--*++cpp + 3);
 printf("%s",*cpp[-2] + 2);
 printf("%s",cpp[-1][-1] + 3);
 printf("\n");
}