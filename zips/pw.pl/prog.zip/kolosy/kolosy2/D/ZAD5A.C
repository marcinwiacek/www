#include<stdio.h>
#include"defsd.h"


int next(void);
int last(void);
int new(int);
int reset(void);

int i = 4;

void main(void)

{
  auto int i,j;

  i = reset();

  for(j = 2; j <= 4; j++)
   {
     PRINT2(d,i,j);
     PRINT1(d,next());
     PRINT1(d,last());
     PRINT1(d,new(i+j));
   }
}

