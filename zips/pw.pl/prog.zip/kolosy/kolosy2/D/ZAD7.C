#include<stdio.h>

char input[] = "SUTE\11TAEMPAE1\1WT\1A\11AEDYTNA";

void main(void)

{
  int i,c;
  for(i = 2; (c = input[i]) != '\0'; i++)

   {
    switch (c)
      {
       case 'a' : putchar('i'); continue;
       case '1' : break;
       case 1   : while (( c = input[++i]) != '\1' && c != '\0');
		  continue;
       case 9   : putchar('L');
       case 'E' : case 'T' : continue;
       default  : putchar (c); continue;
      }
    putchar (' ');
   }
 putchar('\n');
}