#include <stdio.h>
char input[]="SUPEKWAPEDERAT1\1\11W\1PIECZEBYE";

void main(void)
{
   int i,c;
   for (i=2; (c=input[i]) != '\0'; i++) {
      switch (c) {
        case 'a': putchar('i'); continue;
        case '1': break;
        case 1:   while ( (c=input[++i]) != '\1'
                          && c != '\0');
        case 9:   putchar ('L');
        case 'E': case 'P': continue;
        default:  putchar (c); continue;
 }
        putchar (' ');
      }
      putchar('\n');
}
