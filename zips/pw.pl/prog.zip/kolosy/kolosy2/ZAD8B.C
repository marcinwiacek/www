#include <stdio.h>

#define PR(a) printf(#a "= %d\t", (int) (a))
#define PRINT(a) PR(a); putchar('\n')
#define PRINT2(a,b) PR (a); PRINT(b)
#define PRINT3(a,b,c) PR(a); PRINT2(b,c)

#define MAX(a,b) (a<b ? b:a)
#define TAB(c,i,oi,x) if(c=='\t') for (x=8-(i-oi-1)%8,oi=i;x;x--) putchar ('*')

int main(void)
{
  {
    int x=12, y=13;
    PRINT3( MAX(x++,y),x,y);
    PRINT3( MAX(x++,y),x,y);
  }
  {
    static char input[]="\tALA\tAS";
    char c;
    int i, oldi, temp;

    for (oldi=-1, i=0; (c=input[i])!='\0'; i++)
      if (c<' ') TAB (c,i,oldi,temp);
      else putchar(c);
    putchar('\n');
  }
return(0);
}
