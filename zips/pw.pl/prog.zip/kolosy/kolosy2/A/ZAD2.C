#include<stdio.h>
#include"defsd.h"

int reset(void);
int next(int);
int last(int);
int new(int);

int i = 3;

void main(void)

{
  auto int i,j;

  i = reset();

  for(j = 3; j <= 5; j++)
   {
     PRINT2(d,i,j);
     PRINT1(d,next(i));
     PRINT1(d,last(i));
     PRINT1(d,new(i+j));
   }
}

int reset(void)
  {
    return i--;
  }

int next(int j)
  {
    return(j-=++i);
  }

int last(int j)

  {
   static int i = 10;
   return (i+=--j);
  }

int new(int k)
  {
    auto int j = 10;
    return (i=j-=k);
  }

