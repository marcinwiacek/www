format long;
r13=20000;
r12=3300 ;
r15=82000;
r2=20000 ;
c1=0.00000002;
c2=c1   ;
f=logspace(0,5)
a1=r2/(r13+r2)
a2=r2/(r12+r2)
a3=r2/(r15+r2)
b=c1/(c1+c2)

w=2*pi.*f;
t1=r13*c1;
t2=r12*c1;
t3=r15*c1;

k1=a1.*(sqrt((1+((w.^2).*(t1.^2)))./((1+(w.^2).*(t1.^2).*(a1./b).^2))));
k2=a2.*(sqrt((1+((w.^2).*(t2.^2)))./((1+(w.^2).*(t2.^2).*(a2./b).^2))));
k3=a3.*(sqrt((1+((w.^2).*(t3.^2)))./((1+(w.^2).*(t3.^2).*(a3./b).^2))));

semilogx(f,k1,f,k2,f,k3)
xlabel('czestotliwosc')
ylabel('k')
text(11,0.88,'R=3.3k')
text(11,0.52,'R=20k')
text(11,0.23,'R=82k')
title('Charakterystyki amplitudowe ( zadanie 1 )')
grid on



%%k=((1+w*t1*j)/((1/a)+j*w*t1*(1/b)))
%%f1=angle(k1);
%%fi=(180/pi)*f1