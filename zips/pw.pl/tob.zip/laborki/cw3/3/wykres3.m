f=[400:50:14000];
f0=1.1427e+4;
Qr=3.3010;
Qc=2.8547;
v=f./f0-f0./f;

C=0.0000000097;
rl=220;
R=215;
E=0.4;
Rw=68;

Ur=(R)./(R+rl+j.*(2.*pi.*f.*L-1./(2.*pi.*f.*C)));
Ur2=(R)./(R+Rw+rl+j.*(2.*pi.*f.*L-1./(2.*pi.*f.*C)));

Ga=abs(Ur);
Gb=abs(Ur2);

G1=1./(sqrt(1+Qr.*Qr.*v.*v));
G2=1./(sqrt(1+Qc.*Qc.*v.*v));
hold on;
plot(f,Ga,'b');
plot(f,Gb,'k');
grid on;