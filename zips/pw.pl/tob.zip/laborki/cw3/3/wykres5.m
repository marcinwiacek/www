f=[400:50:14000];
C=0.0000000097;
R=215;
rl=220;
L=0.02;
psi=(-atan((2.*pi.*f.*L-1./(2.*pi.*f.*C))/(R+rl))).*180./pi;
plot(f,psi);
grid on;