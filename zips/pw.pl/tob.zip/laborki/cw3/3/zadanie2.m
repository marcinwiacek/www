Qr=3.3010;
Rw=68;
R=215;
rl=220;
f0=1.1427e+4;
Qc=(Qr)./(1+Rw./(R+rl))
Bc=f0./Qc