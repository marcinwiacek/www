fo=1.1427e+4;
rl=0;
Rw=0;
L=0.02;
E=0.4;
C=0.0000000097;
R=215;

Rc=rl+R;
ro=1./(2.*pi.*f0.*C);
Qr=ro./Rc

fLmax=f0./(sqrt(1-1./(2.*Qr.*Qr)))
fCmax=f0.*(sqrt(1-1./(2.*Qr.*Qr)))