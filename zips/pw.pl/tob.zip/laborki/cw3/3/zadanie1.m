L=0.02;
C=0.0000000097;
R=215;
rl=220;

f0=1./(2.*pi.*sqrt(C.*L))

Rc=rl+R

ro=(1)./(2.*pi.*f0.*C)

Qr=ro./Rc

Br=f0./Qr

deltaf=Br./2;

fd=f0-deltaf

fg=f0+deltaf