fo=9.3459e+3;
rl=0;
Rw=0;
L=0.02;
E=0.4;
C=0.0000000145;
R=140;

Rc=rl+R;
ro=1./(2.*pi.*f0.*C);
Qr=ro./Rc;

f=[400:50:15000];
v=f./f0-f0./f;

pierwiastek=sqrt(1+Qr.*Qr.*v.*v);

h=(Qr.*(f./f0))./(pierwiastek);
k=(Qr.*(f0./f))./(pierwiastek);

plot(f,h,'r');
hold on;
plot(f,k,'g');
grid on;
