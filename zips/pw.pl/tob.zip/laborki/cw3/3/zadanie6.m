E=0.4;
f=7500;
w=2.*pi.*f;
C=0.0000000145;
R=140;
L=0.02;
rl=220;

Uc=(E./(j.*w.*C))./(R+rl+j.*(w.*L-1./(w.*C)))
amplituda=abs(Uc)
kat=angle(Uc).*180./pi

Ul=(E.*(rl+j.*w.*L))./(R+rl+j.*(w.*L-1./(w.*C)))
amplituda=abs(Ul)
kat=angle(Ul).*180./pi

Ur=(R.*E)./(R+rl+j.*(w.*L-1./(w.*C)))
amplituda=abs(Ur)
kat=angle(Ur).*180./pi