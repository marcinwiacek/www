%Oblicza pierwiastki wielomianu

clear;
a=input('wspolczynnik a wielomianu drugiego stopnia ax^2+bx+c = ');
b=input('b = ');
c=input('c = ');
w=[real(a) real(b) real(c)];
r=roots(w);
disp('pierwiastki tego wielomianu :'),disp(r);
