%Oblicza przyprostokatna i katy na podstawie przeciwprostokatnych

c=input('Podaj przeciwprostokatna c = ');
a=input('Podaj przyprostokatna a = ');

b=sqrt(c^2 - a^2);

disp('b = '),disp(b);
disp('kat alfa (stopnie) = '),disp((asin(a/c)*180)/pi);
disp('kat beta (stopnie) = '),disp((asin(b/c)*180)/pi);