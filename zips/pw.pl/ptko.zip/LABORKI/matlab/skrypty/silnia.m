%Oblicza silnie

p=input('Podaj liczbe = ');

s=1;

for i=1:p,
  s=s*i;
end

disp(s);