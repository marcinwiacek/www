%pierwiastki n-tego stopnia z (-1); 

n=input('stopien = ');

v(1)=1; 
v(n+1)=1; 

for i=2:n 
  v(i)=0; 
end;

X=roots(v);
disp(X);