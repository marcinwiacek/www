
hold on; %wszystkie wykresy w jednym ukladzie

x=-10:0.05:0 
y=x.^2-x %normalna potega to .^
plot(x,y,'b'); %rysujemy - trzeci parameter okresla kolor lub czym rysowac kolejne punkty (np. kwadratami)

x2=0:0.05:pi
y2=sin(x2)
plot(x2,y2,'b');

x3=pi:0.05:10
y3=x3-pi
plot(x3,y3,'m');