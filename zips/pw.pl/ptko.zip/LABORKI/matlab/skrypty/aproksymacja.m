%Aproksymacja - przyblizanie - zastepowanie jednych wielkosci drugimi,
%wygodniejszymi z okreslonych wzgledow

x=1:8;
y=[1.45 1.95 2.43 3.02 3.53 4 4.4 5.1];
L=cov(x,y); M=cov(x);
a=L(1,2)/L(1,1)
b=mean(y)-a*mean(x)
y1=a*x+b;
plot(x,y,'o',x,y1),grid on
