%Macierze

A=[1,1;
   1,2];
disp(A); %wyswietl macierz

disp('Wyznacznik');disp(det(A));

if det(A)~=0 
  disp('Macierz odwrotna');disp(inv(A));
else 
  disp('Macierz odwrotna nie istnieje') 
end;

disp('Macierz transponowana');disp(A');

disp('Rzad macierzy');disp(rank(orth(A)));

disp('W kazdym wyrazie dodajemy 2');disp(A+2); %Podobnie mnozenie, odejmowanie, itd.

B=[1;1];

disp('Iloczyn macierzy');disp(A*B);
