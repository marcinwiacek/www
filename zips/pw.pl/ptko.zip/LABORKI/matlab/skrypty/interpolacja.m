%Interpolacja - znajdowanie funkcji przechodzacej przez zadane punkty
%(tzw. wezly interpolacji)

x=0:0.4:2;
y=exp(-0.5*x).*cos(5*x);
xx=0:0.05:2; 
metoda=['linear '; 'spline '; 'cubic  '];
for k=1:3
 subplot(3,1,k) 
 yy=interp1(x,y,xx,metoda(k,:));
 plot(x,y,'*',xx,yy,':',xx,...
 exp(-0.5*xx).*cos(5*xx)),grid on
 opis=['Metoda:' metoda(k,:)];
 title(opis)
end;
