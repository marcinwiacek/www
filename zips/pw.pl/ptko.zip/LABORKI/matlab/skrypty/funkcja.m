%Jak definiujemy funkcje

function y=funkcja(x) 
y=sin(x);