%Program rysuje funkcje
%y=sin(2x)+log(2x+2)

y='sin(2*x)+log(2*x+2)';
ezplot(y);
grid on
