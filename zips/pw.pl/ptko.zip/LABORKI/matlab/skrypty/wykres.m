%Wykres funkcji y=A*sin(x)+B

disp('wykres funkcji A*sin(x)+B');

n=input('krok = ');
start=input('start = ');
stop=input('stop = ');
A=input('wpolczynnik A = ');
B=input('wpolczynnik B = ');

x=start:n:stop;
y=A*sin(x)+B;

plot(x,y);