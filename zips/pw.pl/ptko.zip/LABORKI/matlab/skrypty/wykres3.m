
x=0:0.05:2*pi
y=sin(x)
y1=sin(x+1)
subplot(2,1,1)
plot(x,y,'b')
hold on %drugi wykres w tym samy ukladzie
plot(x,y1,'g')

text(3*pi/4,sin(3*pi/4),...  %rysowanie skrzalek z tekstem
'\leftarrowsin(x) = .707',...
'FontSize',12)

text(pi,sin(pi),'\leftarrowsin(x) = 0',... %rysowanie skrzalek z tekstem
'FontSize',12)

text(5*pi/4,sin(5*pi/4),'sin(x) = -.707\rightarrow',... %rysowanie skrzalek z tekstem
'HorizontalAlignment','right',...
'FontSize',12)

xlabel('etykieta osi x') %opis osi
ylabel('etykieta osi y') %opis osi
legend('f(x)=sin(x)', 'f(x)=sin(x+1)') %opis wykresu
grid on %wlacz siatke

subplot(2,1,2)
plot(x,y)
