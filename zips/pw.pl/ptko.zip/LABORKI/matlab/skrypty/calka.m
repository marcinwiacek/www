%calkowanie przy uzyciu funkcji i "tradycyjnie" sumowaniem

a=0; %granice calkowania
b=1;

%calkowanie przez sumowanie
c=0.0001; %krok - im mniejszy, tym dokladniej liczy
zo=0;
for i=a:c:b 
zo=zo+funkcja(i)*c;
end;
disp('Wartosc tradycyjnie ');disp(zo);

%calkowanie z funkcji
z=quad('funkcja',a,b); 
disp('Z funkcji');disp(z);