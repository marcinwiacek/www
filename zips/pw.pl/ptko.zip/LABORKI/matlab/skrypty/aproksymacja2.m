%Aproksymacja - przyblizanie - zastepowanie jednych wielkosci drugimi,
%wygodniejszymi z okreslonych wzgledow

x=1:5;
y=[5.5 43.1 128 290.7 498.4];
c=polyfit(x,y,3)
x2=1:0.1:5;
y2=polyval(c,x2);
y3=interp1(x,y,x2,'spline')
plot(x,y,'o',x2,y2,x2,y3,':');
grid on
