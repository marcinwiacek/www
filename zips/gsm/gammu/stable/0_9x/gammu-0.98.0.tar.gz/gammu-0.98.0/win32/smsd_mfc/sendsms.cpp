
#include "common.h"

#include <afxwin.h>
#include <afxext.h>
#include <afxcview.h>

#include "resource.h"
#include "sendsms.h"

CSendSMSDlg::CSendSMSDlg() : CDialog(CSendSMSDlg::IDD)
{
}

BEGIN_MESSAGE_MAP(CSendSMSDlg, CDialog)
END_MESSAGE_MAP()
