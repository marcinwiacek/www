#include <afxwin.h>
#include <afxext.h>
#include <afxcview.h>

#include "resource.h"

class CSendSMSDlg : public CDialog
{
public:
	CSendSMSDlg();
	enum {IDD = IDD_SENDSMS};
protected:
	DECLARE_MESSAGE_MAP()
};
