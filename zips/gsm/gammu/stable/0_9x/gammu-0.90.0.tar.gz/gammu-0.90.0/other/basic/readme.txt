GammuGUI by Luca Cassioli 2003
------------------------------

This program requires GAMMU program by Marcin Wiacek:
http://marcin-wiacek.fkn.pl/english/zips/download.html


Source files must be run using wxBasic version available at "Bleeding edge" section
of wxBasic web site (http://wxbasic.sourceforge.net)


Look at my page for latest version and pre-compiled windows/linux versions:
http://www.geocities.com/lcassioli/gammugui/



