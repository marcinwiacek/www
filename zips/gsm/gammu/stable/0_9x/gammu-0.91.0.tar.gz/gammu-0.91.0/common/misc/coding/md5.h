#ifndef __md5_h
#define __md5_h

void CalculateMD5(unsigned char *buffer, int length, unsigned char *checksum);

#endif
