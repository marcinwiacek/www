#ifndef ___MD5_H___
#define ___MD5_H___

void CalculateMD5(unsigned char *buffer, int length, unsigned char *checksum);

#endif
