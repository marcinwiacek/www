
#ifndef phone_nokia_dct3common_h
#define phone_nokia_dct3common_h

typedef struct {
	int 	Locations[4];
	int	CurrentLocation;
	int	ID;
} DCT3_WAPSettings_Locations;

#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
