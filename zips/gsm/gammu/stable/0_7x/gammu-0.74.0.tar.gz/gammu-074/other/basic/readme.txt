.WX file must be run using wxbasic 0.52 (http://prdownloads.sourceforge.net/wxbasic/wxbasic-0.52.zip)

.WXB file must be run using wxBasic available at "Bleeding edge" section (http://wxbasic.sourceforge.net)

Look at my page for latest version and pre-compiled windows/linux versions:
http://www.geocities.com/lcassioli/gammugui/
