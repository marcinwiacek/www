
void DCT4SetPhoneMenus	   (int argc, char *argv[]);
void DCT4tests		   (int argc, char *argv[]);
void DCT4SetVibraLevel	   (int argc, char *argv[]);
void DCT4ResetSecurityCode (int argc, char *argv[]);
void DCT4GetVoiceRecord	   (int argc, char *argv[]);
void DCT4Info		   (int argc, char *argv[]);

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
