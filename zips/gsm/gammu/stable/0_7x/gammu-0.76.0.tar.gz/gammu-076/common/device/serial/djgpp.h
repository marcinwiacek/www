
#ifdef DJGPP
#ifndef djgppserial_h
#define djgppserial_h

typedef struct {
    int hPhone;
} GSM_Device_SerialData;

#endif
#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
