
extern GSM_SMSDeaemonService SMSDFiles;
