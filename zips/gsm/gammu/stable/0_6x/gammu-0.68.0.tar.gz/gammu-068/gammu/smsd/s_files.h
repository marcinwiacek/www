
extern GSM_SMSDService SMSDFiles;
