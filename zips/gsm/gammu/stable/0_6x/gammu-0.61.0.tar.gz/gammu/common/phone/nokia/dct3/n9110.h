
#ifndef n9110_h
#define n9110_h

#ifndef GSM_USED_MBUS2
#  define GSM_USED_MBUS2
#endif

#endif
