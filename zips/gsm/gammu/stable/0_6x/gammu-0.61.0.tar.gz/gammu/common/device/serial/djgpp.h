
#ifdef DJGPP
#ifndef djgppserial_h
#define djgppserial_h

typedef struct {
    int hPhone;
} GSM_Device_SerialData;

#endif
#endif
