
#ifndef alcatel_h
#define alcatel_h

#include "../../gsmcomon.h"

#ifndef GSM_USED_AT
#  define GSM_USED_AT
#endif

typedef struct {
	int	i;
} GSM_Phone_ALCATELData;

#endif
