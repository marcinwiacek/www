
void decodesniff	(int argc, char *argv[]);
void decodebinarydump	(int argc, char *argv[]);
