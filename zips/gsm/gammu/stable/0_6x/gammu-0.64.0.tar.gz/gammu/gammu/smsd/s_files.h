
extern GSM_SMSDaemonService SMSDFiles;
