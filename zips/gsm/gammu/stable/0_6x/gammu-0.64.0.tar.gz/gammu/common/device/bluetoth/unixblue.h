
#ifndef DJGPP
#ifndef WIN32
#ifndef unixbluetooth_h
#define unixbluetooth_h

typedef struct {
    int hPhone;
} GSM_Device_BlueToothData;

#endif
#endif
#endif
