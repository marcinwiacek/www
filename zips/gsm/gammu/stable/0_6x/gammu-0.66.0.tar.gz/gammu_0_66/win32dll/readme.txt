This is an example, which show some possible methods of using Gammu
functions.

First compile DLL, copy it to directory with Delphi 6 project and then run
it. It will work with FBUS cable. You can see, how to install callbacks
for making few things: reading sms. You can see, how to send sms, etc.

Example can be used to build sms gateway for multiple phone for
sending/receiving sms.
