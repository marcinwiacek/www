
void DCT4SetPhoneMenus	   (int argc, char *argv[]);
void DCT4tests		   (int argc, char *argv[]);
void DCT4SetVibraLevel	   (int argc, char *argv[]);
void DCT4ResetSecurityCode (int argc, char *argv[]);
void DCT4GetVoiceRecord	   (int argc, char *argv[]);
