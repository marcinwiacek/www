/* (c) 2004 by Marcin Wiacek */

#ifndef n650_h
#define n650_h

typedef struct {
	int fake;
} GSM_Phone_N650Data;

#ifndef GSM_USED_MBUS2
#  define GSM_USED_MBUS2
#endif

#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
