Gammu README
------------
Q. What is this ?

A. This is package with different tools and drivers for Nokia and other mobile
   phones released under GNU GPL/LGPL license (see /copying file).

   It's created by Marcin Wiacek and other people and based on some experiences
   from Gnokii (www.gnokii.org) and MyGnokii (www.mwiacek.com) projects.

   Gammu (GNU All Mobile Management Utilities) was earlier (up to version 0.58)
   called MyGnokii2.

   NOTE: Name Gammu is not connected with Gammu from "Heretics of Dune" written
         by Frank Herbert
-------------------------------------------------------------------------------
Q. How to report bugs ?

A. http://www.gammu.org/bugs or use mailing list
-------------------------------------------------------------------------------
Q. Where can I find more informations ?

A. * docs/docs/english/gammu.htm and readme.htm
   * www.gammu.org (inside Wiki)
