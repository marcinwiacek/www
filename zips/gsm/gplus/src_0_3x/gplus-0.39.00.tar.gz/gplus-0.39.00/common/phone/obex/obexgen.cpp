/* (C) 2003 - 2008 by Marcin Wiacek www.mwiacek.com */

#include "../../protocol/gsmprot.h"
#include "obexgen.h"
#include "../../misc/xml/tinyxml.h"

GSM_Error GSM_Phone_OBEXGEN::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	AnsStruct 	AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

//Continue
if(Ans("\x90",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);
if(Ans("\x90",0x00,0x00,ID_AddFilePart+ID,&AS))return ReplyAddFilePart(msg,Debug,(unsigned char *)Struct);

//Success
if(Ans("\xA0",0x00,0x00,ID_GetIMEI+ID,&AS))return ReplyOpen(msg,Debug,(unsigned char *)Struct);
if(Ans("\xA0",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);
if(Ans("\xA0",0x00,0x00,ID_AddFilePart+ID,&AS))return ReplyAddFilePart(msg,Debug,(unsigned char *)Struct);

if(Ans("\xC4",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_Return_Error(GSM_ERR_FRAME_NOT_REQUESTED);
        return GSM_Return_Error(GSM_ERR_FRAME_TYPE_UNKNOWN);
}

void GSM_Phone_OBEXGEN::AddBlock(unsignedstring *Buffer, unsigned char ID, const unsigned char *AddBuffer, int AddLength)
{	
	Buffer->push_back(ID);
	Buffer->push_back((AddLength+3)/256);
	Buffer->push_back((AddLength+3)%256);
	if (AddLength != 0) Buffer->append(AddBuffer,AddLength);
}

GSM_Error GSM_Phone_OBEXGEN::ReplySetPath(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::SetPath(wchart *Path)
{	
	GSM_File 	File;
        GSM_Error       error;
	unsignedstring  Buffer,Type,req,Now;
	wchart		buf2;
	wchart 		name;
	int 		i=0;

	(*Debug)->Deb("Path '%s'\n",UnicodeToStringReturn(Path->data()));
	while (true) {
		req.clear();
		/* Flags */
		req.push_back(2); req.push_back(0x00);
		/* connection ID block */
		req.push_back(OBEX_HEAD_CONNECTION_ID);
		req.append(ConnectionID,4);
		/* Name block */
		AddBlock(&req, OBEX_HEAD_NAME, Now.data(), Now.size());
		(*Debug)->Deb("SENT: Set path %i\n",Now.size());
		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_SET_PATH+128, 10, ID_GetIMEI+ID, &req);
		if (error.Code != GSM_ERR_NONE) return error;

		if (Path->size()==i) return GSM_Return_Error(GSM_ERR_NONE);

		Now.clear();
		while (1) {
			if (Path->size()==i) break;
			if (Path->data()[i] == '\\') {
				i++;
				break;
			}
			Now.push_back(Path->data()[i]/256);
			Now.push_back(Path->data()[i]%256);
			i++;
		}

		if (Now.size()==0) return GSM_Return_Error(GSM_ERR_NONE);

		Now.push_back(0);
		Now.push_back(0);
	}
}

GSM_Error GSM_Phone_OBEXGEN::ReplyGetFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_File 	*File = (GSM_File *)S;
	unsigned int 		Pos=0;

	switch (msg->Type) {
		case OBEX_RESP_CONTINUE : (*Debug)->Deb("RECEIVED: Get file continue\n"); break;
		case OBEX_RESP_SUCCESS  : (*Debug)->Deb("RECEIVED: Get file last\n");     break;
		default   		: return GSM_Return_Error(GSM_ERR_UNKNOWN);
	}

	while(Pos < msg->Buffer.size()) {
		if (msg->Buffer.data()[Pos]==OBEX_HEAD_LENGTH) { //file size
			File->Info.Size = msg->Buffer.data()[Pos+1]*256*256*256+
					  msg->Buffer.data()[Pos+2]*256*256+
					  msg->Buffer.data()[Pos+3]*256+
					  msg->Buffer.data()[Pos+4];
			(*Debug)->Deb("  size\n");
			Pos+=5;
			continue;
		}
		switch (msg->Buffer.data()[Pos]) {
		case OBEX_HEAD_NAME: 
			(*Debug)->Deb("  name\n"); 
			break;
		case OBEX_HEAD_TYPE:
			(*Debug)->Deb("  type\n");
			break;			
		case OBEX_HEAD_TIME_ISO:
			(*Debug)->Deb("  datetime\n");
			break;			
		case OBEX_HEAD_BODY: //file content
		case OBEX_HEAD_BODY_END: //last file content
			(*Debug)->Deb("  content\n");
			File->Buffer.append((const unsigned char *)msg->Buffer.data()+Pos+3,msg->Buffer.data()[Pos+1]*256+msg->Buffer.data()[Pos+2]-3);
			break;
		default:
		        return GSM_Return_Error(GSM_ERR_UNKNOWN);
			break;
		}
		Pos+=msg->Buffer.data()[Pos+1]*256+msg->Buffer.data()[Pos+2];
	}
	switch (msg->Type) {
		case OBEX_RESP_CONTINUE: return GSM_Return_Error(GSM_ERR_NONE);		
		case OBEX_RESP_SUCCESS: return GSM_Return_Error(GSM_ERR_EMPTY);
	}
	return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

GSM_Error GSM_Phone_OBEXGEN::GetFile(GSM_File *File, unsignedstring Type)
{
	GSM_Error 	error;
	unsignedstring  Buffer,req;
	wchart		buf2;
	unsigned int		i;

	(*Debug)->Deb("'%s'\n",UnicodeToStringReturn(File->Info.ID.data()));
	if (File->Buffer.size() == 0x00) {
		if (File->Info.ID.size()!=0) {
			i = File->Info.ID.size()-1;
			while (1) {
				if (File->Info.ID.data()[i] == '\\') break;
				if (i==0) return GSM_Return_Error(GSM_ERR_UNKNOWN);
				i--;
			}
			buf2.clear();
			buf2.append(File->Info.ID.data(),i+1);
		}
		error = SetPath(&buf2);
		if (error.Code != GSM_ERR_NONE) return error;

		/* Name block */
		if (File->Info.ID.size()!=0) {
			buf2.clear();
			buf2.append(File->Info.ID.data()+i+1,File->Info.ID.size()-i-1);
			for (i=0;i<buf2.size();i++) {
				Buffer.push_back(buf2.data()[i]/256);
				Buffer.push_back(buf2.data()[i]%256);
			}
			if (buf2.size()!=0) {
				Buffer.push_back(0); Buffer.push_back(0);
			}
		}
		AddBlock(&req, OBEX_HEAD_NAME, Buffer.data(),Buffer.size());
		File->Info.Name.clear();
		File->Info.Name.append(buf2);
		/* Type block */
		AddBlock(&req, OBEX_HEAD_TYPE, Type.data(), Type.size());

		(*Debug)->Deb("SENT: Get file start\n");
	} else {
		(*Debug)->Deb("SENT: Get file continue\n");
	}

	/* connection ID block */
	req.push_back(OBEX_HEAD_CONNECTION_ID);
	req.append(ConnectionID,4);

	error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_GET+128, 10, ID_GetFilePart+ID, File);
	if (error.Code == GSM_ERR_NONE && File->Buffer.size() == 0x00) {
		req.clear();
		/* connection ID block */
		req.push_back(OBEX_HEAD_CONNECTION_ID);
		req.append(ConnectionID,4);

		(*Debug)->Deb("SENT: Get file continue\n");
		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_GET+128, 10, ID_GetFilePart+ID, File);
	}
	return error;
}

GSM_Error GSM_Phone_OBEXGEN::ReplyAddFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::AddFilePart(GSM_File *File, int *Pos)
{
	GSM_Error 	error;
	unsignedstring  Buffer,req;
	wchart		buf2;
	unsigned int	i,j;
	char		Buff[200];

	(*Debug)->Deb("'%s'\n",UnicodeToStringReturn(File->Info.ID.data()));

	j = 2000;
	if (File->Info.Size - *Pos < 2000) j = File->Info.Size - *Pos;

	if (*Pos == 0) {
		if (File->Info.ID.size()!=0) {
			i = File->Info.ID.size()-1;
			while (1) {
				if (File->Info.ID.data()[i] == '\\') break;
				if (i==0) return GSM_Return_Error(GSM_ERR_UNKNOWN);
				i--;
			}
			buf2.clear();
			buf2.append(File->Info.ID.data(),i+1);
		}
		(*Debug)->Deb("'%s'\n",UnicodeToStringReturn(buf2.data()));
		error = SetPath(&buf2);
		if (error.Code != GSM_ERR_NONE) return error;

		/* Name block */
	        Buffer.clear();
		if (File->Info.Name.size()!=0) {
			for (i=0;i<File->Info.Name.size();i++) {
				Buffer.push_back(File->Info.Name.data()[i]/256);
				Buffer.push_back(File->Info.Name.data()[i]%256);
			}
			if (Buffer.size()!=0) {
				Buffer.push_back(0); Buffer.push_back(0);
			}
		}
		AddBlock(&req, OBEX_HEAD_NAME, Buffer.data(),Buffer.size());

		File->Info.ID.append(File->Info.Name);

		/* Type block */
//		if (Type.size()!=0) {
//			AddBlock((char *)req, &Current, OBEX_HEAD_TYPE, (char *)Type.data(), Type.size());
//		}

		if (File->Info.ModificationDateTimeAvailable) {
			SaveVCalendarDateTime(&File->Info.ModificationDateTime, Buff);
			Buffer.clear();
			Buffer.append((unsigned char *)Buff,strlen(Buff));
			Buffer.push_back('Z');
			AddBlock(&req, OBEX_HEAD_TIME_ISO, Buffer.data(),Buffer.size());
		}

		/* File length */
		req.push_back(OBEX_HEAD_LENGTH);
		req.push_back(File->Info.Size / (256*256*256));
		req.push_back(File->Info.Size / (256*256));
		req.push_back(File->Info.Size / 256);
		req.push_back(File->Info.Size % 256);
	}

	/* connection ID block */
	req.push_back(OBEX_HEAD_CONNECTION_ID);
	req.append(ConnectionID,4);

	if (*Pos + j == File->Info.Size) {
		(*Debug)->Deb("SENT: Add file last\n");

		/* data */
		AddBlock(&req, OBEX_HEAD_BODY_END, File->Buffer.data()+(*Pos),j);
		*Pos += j;

		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_PUT+128, 10, ID_AddFilePart+ID, File);
		if (error.Code != GSM_ERR_NONE) return error;

		return GSM_Return_Error(GSM_ERR_EMPTY);
	} else {
		(*Debug)->Deb("SENT: Add file continue\n");
		/* data */
		AddBlock(&req, OBEX_HEAD_BODY, File->Buffer.data()+(*Pos),j);
		*Pos += j;
		return Write((unsigned char *)req.data(), req.size(), OBEX_OP_PUT, 10, ID_AddFilePart+ID, File);
	}
}

GSM_Error GSM_Phone_OBEXGEN::GetFilePart(GSM_File *File)
{
	unsignedstring Type;

	return GetFile(File, Type);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextRootFolderID(wchar_t *ID, GSM_MemoryType *MemType)
{
	FileFolderInfo 	FInfo;
	GSM_Error 	error;

	if (ID[0] == 0) {
		GetFolderInfoList(&RootFolder, TRUE);
		RootFolderSubEntry = NULL;
	}

	if (!RootFolder.GetNext(&RootFolderSubEntry)) return GSM_Return_Error(GSM_ERR_EMPTY);
	CopyUnicode(RootFolderSubEntry->Info.ID.data(),ID);
		(*Debug)->Deb("root name '%s'\n",UnicodeToStringReturn(RootFolderSubEntry->Info.Name.data()));

	*MemType = MEM_PHONE;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetFolderInfoList(GSM_FileFolderInfoList *FInfo, BOOLEAN Start)
{
	GSM_File 		File;
        GSM_Error       	error;
	unsignedstring  	Buffer,Type;
	wchart			buf2;
	FileFolderInfo 		*Info;
	wchart 			name,Name2;
	TiXmlDocument 		doc;
	TiXmlNode* 		node;
	TiXmlElement* 		todoElement;

	FInfo->ClearAll();

	File.Info.ID.append(FInfo->Info.ID);
	Type.append((unsigned char *)"x-obex/folder-listing",21);
	Type.push_back(0x00);
	while (1) {
		error = GetFile(&File, Type);
		if (error.Code != GSM_ERR_NONE && error.Code != GSM_ERR_EMPTY) return error;
		if (error.Code == GSM_ERR_EMPTY) break;
	}

	File.RemoveDTD();
	
	(*Debug)->Deb("%s\n",(char *)File.Buffer.data());

	doc.Parse((char *)File.Buffer.data());
	todoElement = doc.FirstChild("folder-listing")->ToElement();
	for (node = todoElement->FirstChild( "folder" );node;node = node->NextSibling( "folder")) {
		if (!node->ToElement()->Attribute("name")) continue;

		Info = new FileFolderInfo;

		Info->ReadOnly  	= FALSE;
		Info->Hidden    	= FALSE;
		Info->System    	= FALSE;
		Info->DRMForwardLock 	= FALSE;
		Info->Folder    	= TRUE;
		Info->ModificationDateTimeAvailable = FALSE;
		if (node->ToElement()->Attribute("modified")) {
			Info->ModificationDateTimeAvailable = ReadVCalendarDateTime(node->ToElement()->Attribute("modified"), &Info->ModificationDateTime);
		}
		Info->Name.append(StringToUnicodeReturn(node->ToElement()->Attribute("name")));
//		Info->Memory = MEM_PHONE;
//		if (node->ToElement()->Attribute("mem_type")) {
//			if (!strcmp(node->ToElement()->Attribute("mem_type"),"MMC")) {
//				Info->Memory = MEM_MEMORY_CARD;
//			}
//		}
		Name2.clear();
		Name2.append(FInfo->Info.ID);
		Name2.append(Info->Name);
		Name2.push_back('\\');
		Info->SetID(Name2.data());
		FInfo->AddSubEntry(Info);
	}
	for (node = todoElement->FirstChild( "file" );node;node = node->NextSibling( "file")) {
		if (!node->ToElement()->Attribute("name")) continue;

		Info = new FileFolderInfo;

		Info->ReadOnly  	= FALSE;
		Info->Hidden    	= FALSE;
		Info->System    	= FALSE;
		Info->DRMForwardLock 	= FALSE;
		Info->Folder    	= FALSE;
		Info->Size = 0;
		if (node->ToElement()->Attribute("size")) Info->Size = atoi(node->ToElement()->Attribute("size"));
		Info->ModificationDateTimeAvailable = FALSE;
		if (node->ToElement()->Attribute("modified")) {
			Info->ModificationDateTimeAvailable = ReadVCalendarDateTime(node->ToElement()->Attribute("modified"), &Info->ModificationDateTime);
		}
		Info->Name.append(StringToUnicodeReturn(node->ToElement()->Attribute("name")));
		Name2.clear();
		Name2.append(FInfo->Info.ID);
		Name2.append(Info->Name);
		Info->SetID(Name2.data());

		FInfo->AddSubEntry(Info);
	}

	FInfo->SubEntryFullData = TRUE;

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::ReplyOpen(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	unsigned int Pos=4;

	while(Pos < msg->Buffer.size()) {
		switch (msg->Buffer.data()[Pos]) {
		case OBEX_HEAD_CONNECTION_ID: // Connection ID
			memcpy(ConnectionID,msg->Buffer.data()+Pos+1,4);
			Pos+=5;
			break;
		case OBEX_HEAD_WHO: // Response to OBEX_HEAD_TARGET
			Pos+=19;
			break;
		default:
		        return GSM_Return_Error(GSM_ERR_UNKNOWN);
			break;
		}
	}

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::Open(char *FrameID)
{
	GSM_File 		File;
        GSM_Error       	error;
	unsignedstring  	req;
	wchart			buf2,name,Name2;
	unsigned char 		req2[200];

	req.push_back(0x10); // version 1.0
	req.push_back(0x00); // no flags
	req.push_back(0x04); req.push_back(0x00);// max size of packet = 4*256

	/* Folder Browsing Service UUID */
	req2[0] = 0xF9; req2[1] = 0xEC; req2[2] = 0x7B;
	req2[3] = 0xC4; req2[4] = 0x95; req2[5] = 0x3C;
	req2[6] = 0x11; req2[7] = 0xD2; req2[8] = 0x98;
	req2[9] = 0x4E; req2[10]= 0x52; req2[11]= 0x54;
	req2[12]= 0x00; req2[13]= 0xDC; req2[14]= 0x9E;
	req2[15]= 0x09;
	AddBlock(&req, OBEX_HEAD_TARGET, req2, 16);

	return Write((unsigned char *)req.data(), req.size(), OBEX_OP_CONNECT+128, 2, ID_GetIMEI+ID, &req);
}

GSM_Error GSM_Phone_OBEXGEN::ReadCapability()
{
	GSM_Error error;
	unsignedstring 		Type;

	if (Capability.Info.Size == -1) {
		Type.append((unsigned char *)"x-obex/capability",17);
		Type.push_back(0x00);
		while (1) {
			error = GetFile(&Capability, Type);
			if (error.Code == GSM_ERR_UNKNOWN) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
			if (error.Code != GSM_ERR_NONE && error.Code != GSM_ERR_EMPTY) return error;
			if (error.Code == GSM_ERR_EMPTY) break;
		}
		Capability.RemoveDTD();
	
		(*Debug)->Deb("%s\n",(char *)Capability.Buffer.data());
	}
        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetIMEI(unsigned char *IMEI)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = ReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	todoElement = doc.FirstChild("Capability")->FirstChild("General")->FirstChild("SN")->ToElement();
	sprintf((char *)IMEI,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetCodeNameModel(unsigned char *Model)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = ReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	todoElement = doc.FirstChild("Capability")->FirstChild("General")->FirstChild("Model")->ToElement();
	sprintf((char *)Model,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetFirmwareVersion(unsigned char *Firm)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = ReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	todoElement = doc.FirstChild("Capability")->FirstChild("General")->FirstChild("SW")->ToElement();
	sprintf((char *)Firm,"%s",todoElement->Attribute("Version"));

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetManufacturer(unsigned char *Manufacturer)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = ReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	todoElement = doc.FirstChild("Capability")->FirstChild("General")->FirstChild("Manufacturer")->ToElement();
	sprintf((char *)Manufacturer,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}
