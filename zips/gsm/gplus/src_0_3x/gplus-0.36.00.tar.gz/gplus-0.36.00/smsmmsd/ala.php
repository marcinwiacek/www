<?php
	$database = pg_connect("host=127.0.0.1 dbname=x user=x password=x");
	if (!$database) echo "error1";
	if (isset($_GET['fileid']) && isset($_GET['fileid2'])) {
		$sql="select content,type2 from daemon.\"inbox_decoded\" where id=".$_GET['fileid']." and seq_num=".$_GET['fileid2'];
		$result = pg_query($database,$sql);
		if (!$result) echo "error2";
		$result2 = pg_fetch_array($result);
		header("Content-type: ".$result2['type2']);

		if ($result2['type2']=="text/plain" ||
		    $result2['type2']=="text/x-vCard" ||
		    $result2['type2']=="text/x-vNote" ||
		    $result2['type2']=="text/x-vTodo" ||
		    $result2['type2']=="text/x-vImelody" ||
		    $result2['type2']=="text/x-vCalendar" ||
		    $result2['type2']=="application/smil") {
			echo $result2["content"];
			exit;
		}

		for ($i=0;$i<strlen($result2["content"]);$i++) {
			echo chr(intval($result2["content"][$i*2].$result2["content"][$i*2+1],16));
		}
		exit;
	}

	echo "<html><head>";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" >";
	echo "</head><body>";
	if(!$database) echo "error";

	echo "<form method=get>";
	echo "<select name=id>";
	$result = @pg_query($database,"select distinct id from daemon.\"inbox_decoded\"");
        while ($result2 = @pg_fetch_array($result)) {
		echo "<option";
		if (isset($_GET['id']) && $result2['id']==$_GET['id']) echo " selected";
		echo ">".$result2["id"]."</option>";
	}
	echo "</select><input type=submit value='display'></form><p>";

	if (!isset($_GET['id'])) exit;

	echo "<hr>";

	echo "attachments: ";
	$sql="select type,content,type2,id,seq_num from daemon.\"inbox_decoded\" where id=".$_GET['id']." order by seq_num";
	$result = pg_query($database,$sql);
        while ($result2 = pg_fetch_array($result)) {
		if (strstr($result2["type2"],"image/")) {
		} else if ($result2["type2"]=="text/plain") {
		} else {
			echo "<a href=ala.php?fileid=".$_GET['id']."&fileid2=".$result2['seq_num'].">attachment</a>";
		}
	}

	echo "<hr>";

	$sql="select type,content,type2,id,seq_num,bold,italic,underline,strikethrough,small,large from daemon.\"inbox_decoded\" where id=".$_GET['id']." order by seq_num";
	$result = pg_query($database,$sql);
        while ($result2 = pg_fetch_array($result)) {
		if (strstr($result2["type2"],"image/")) {
			echo "<img src=ala.php?fileid=".$_GET['id']."&fileid2=".$result2['seq_num'].">";
		} else if ($result2["type2"]=="text/plain") {
			if ($result2["bold"]=='t') echo "<b>";
			if ($result2["underline"]=='t') echo "<u>";
			echo $result2["content"];
			if ($result2["underline"]=='t') echo "</u>";
			if ($result2["bold"]=='t') echo "</b>";
		} else {
		}
	}

	echo "</body></html>";
?>
