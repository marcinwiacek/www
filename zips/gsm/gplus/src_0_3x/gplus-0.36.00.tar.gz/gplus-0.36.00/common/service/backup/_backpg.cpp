#ifdef POSTGRESQL

GSM_Error GSM_Backup::GetInboxFromPostgreSQL(PGconn *conn, BOOLEAN SMS, BOOLEAN MMS, BOOLEAN OnlyUnprocessed)
{
    	GSM_SMSMMSDecodedEntry      	DecodedEntry;
	unsignedstring 			ala,ala2;
	PGresult 			*result;
	int 				p,num;
	GSM_SMSEntry			*SMS2;
	GSM_SMSList			*Entry;
	GSM_MMSEntry			*Entry2;
	char				ala3[5000];

	if (SMS) {
		sprintf(ala3,"select TPDCS,TPStatus,TPUDL,TPVP,TPMR,TPPID,firstbyte,UserData,SMSCNumber,DateTime,SMSCTime,PhoneNumbers,id from daemon.\"inbox_sms\"");
		if (OnlyUnprocessed) sprintf(ala3+strlen(ala3)," where processed=false");
		result = PQexec (conn, ala3);

		num = PQntuples(result);
		for (p = 0; p < num; p++) {
			Entry = new GSM_SMSList;
			Entry-> Folder = 1;

			SMS2 = new GSM_SMSEntry;

			SMS2->TPDCS = atoi(PQgetvalue(result, p, 0));
			SMS2->TPStatus = atoi(PQgetvalue(result, p, 1));
			SMS2->TPUDL = atoi(PQgetvalue(result, p, 2));
			SMS2->TPVP = atoi(PQgetvalue(result, p, 3));
			SMS2->TPMR = atoi(PQgetvalue(result, p, 4));
			SMS2->TPPID = atoi(PQgetvalue(result, p, 5));
			SMS2->firstbyte = atoi(PQgetvalue(result, p, 6));
			HexBinToString((unsigned char *)PQgetvalue(result, p, 7), &SMS2->UserData);
			HexBinToString((unsigned char *)PQgetvalue(result, p, 8), &SMS2->SMSCNumber);

			ala.clear();
			HexBinToString((unsigned char *)PQgetvalue(result, p, 9), &ala);
			if (ala.size()==7) memcpy(SMS2->DateTime,ala.data(),7);

			ala.clear();
			HexBinToString((unsigned char *)PQgetvalue(result, p, 11), &ala);
			SMS2->PhoneNumbers.Add(ala.data(),ala.size());

			sprintf(ala3,"%s",(unsigned char *)PQgetvalue(result, p, 12));
			SMS2->ID.append(StringToUnicodeReturn(ala3),strlen(ala3));

			Entry->Add(SMS2);
			Add_SMS(Entry);
		}
	}
	if (MMS) {
		sprintf(ala3,"select id,content from daemon.\"inbox_mms\"");
		if (OnlyUnprocessed) sprintf(ala3+strlen(ala3)," where processed=false");
		result = PQexec (conn, ala3);

		num = PQntuples(result);
		for (p = 0; p < num; p++) {
			Entry2 = new GSM_MMSEntry;
			HexBinToString((unsigned char *)PQgetvalue(result, p, 1), &Entry2->File.Buffer);

			sprintf(ala3,"%s",(unsigned char *)PQgetvalue(result, p, 0));
			Entry2->File.Info.ID.append(StringToUnicodeReturn(ala3),strlen(ala3));

			Entry2->Folder = 2;
	
			Add_MMS(Entry2);
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

GSM_Error GSM_Backup::AddInboxToPostgreSQL(PGconn *conn, BOOLEAN SMS, BOOLEAN MMS)
{
	GSM_Backup_MMSEntry	*MMSEntry;
	GSM_Backup_SMSEntry	*SMSEntry;
	GSM_SMSListSubEntry	*SubEntry;
	int			Num=1,Seq=1,Part,i,NumbersNum;
	char			buff[500];
	GSM_SMSNumbersSubEntry  *Numbers;
	unsignedstring		query,dest;
	PGresult 		*result2;

	if (SMS) {
		SMSEntry = NULL;
		while (GetNext_SMS(&SMSEntry)) {
			SubEntry = NULL;
			Part = 1;
			while (SMSEntry->GetEntry()->GetNext(&SubEntry)) {
				if (SubEntry->GetSMS()->ID.size()!=0) continue;

				result2 = PQexec (conn, "select nextval('daemon.inbox_sms_id')");

				query.clear();
				query.append((unsigned char *)"insert into daemon.\"inbox_sms\" (id,TPDCS,TPStatus,TPUDL,TPVP,TPMR,TPPID,firstbyte,UserData,SMSCNumber,DateTime,SMSCTime,PhoneNumbers) values (");

				sprintf(buff,"%s,",PQgetvalue(result2, 0, 0));
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%s",PQgetvalue(result2, 0, 0));
				SubEntry->GetSMS()->ID.append(StringToUnicodeReturn(buff),strlen(buff));

				sprintf(buff,"%i,",SubEntry->GetSMS()->TPDCS);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,",SubEntry->GetSMS()->TPStatus);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,",SubEntry->GetSMS()->TPUDL);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,",SubEntry->GetSMS()->TPVP);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,",SubEntry->GetSMS()->TPMR);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,",SubEntry->GetSMS()->TPPID);
				query.append((unsigned char *)buff,strlen(buff));
				sprintf(buff,"%i,'",SubEntry->GetSMS()->firstbyte);
				query.append((unsigned char *)buff,strlen(buff));

				dest.clear();
				StringToHexBin(&SubEntry->GetSMS()->UserData,&dest);
				query.append(dest);

				sprintf(buff,"','");
				query.append((unsigned char *)buff,strlen(buff));

				dest.clear();
				StringToHexBin(&SubEntry->GetSMS()->SMSCNumber,&dest);
				query.append(dest);

				sprintf(buff,"','");
				query.append((unsigned char *)buff,strlen(buff));

				for (i=0;i<7;i++) {
					sprintf(buff+(i*2),"%02X",SubEntry->GetSMS()->DateTime[i]);
				}
				buff[i*2]=0;
				query.append((unsigned char *)buff,strlen(buff));

				sprintf(buff,"','");
				query.append((unsigned char *)buff,strlen(buff));

				for (i=0;i<7;i++) {
					sprintf(buff+(i*2),"%02X",SubEntry->GetSMS()->SMSCTime[i]);
				}
				buff[i*2]=0;
				query.append((unsigned char *)buff,strlen(buff));

				sprintf(buff,"',");
				query.append((unsigned char *)buff,strlen(buff));

				Numbers=NULL;
				NumbersNum=1;
				if (SubEntry->GetSMS()->PhoneNumbers.GetNext(&Numbers)) {
					sprintf(buff,"'");
					query.append((unsigned char *)buff,strlen(buff));

					dest.clear();
					StringToHexBin(&Numbers->PhoneNumber,&dest);
					query.append(dest);

					sprintf(buff,"'");
					query.append((unsigned char *)buff,strlen(buff));

					NumbersNum++;
				}
				if (NumbersNum==1) {
					sprintf(buff,"''");
					query.append((unsigned char *)buff,strlen(buff));

				}

				sprintf(buff,")");
				query.append((unsigned char *)buff,strlen(buff));

				PQexec(conn, (char *)query.data());	

				if (SubEntry->GetSMS()->SaveDateTimeAvailable) {
					sprintf(buff,"Saved = ");				
					SaveVCalendarDateTime(&SubEntry->GetSMS()->SaveDateTime,buff);
				}
			
				Part++;
				Num++;
			}
			Seq++;
		}
	}
	if (MMS) {
		MMSEntry = NULL;
		while (GetNext_MMS(&MMSEntry)) {
			if (MMSEntry->GetEntry()->File.Info.ID.size()!=0) continue;

			result2 = PQexec (conn, "select nextval('daemon.inbox_mms_id')");

			query.clear();
			query.append((unsigned char *)"insert into daemon.\"inbox_mms\" (id,content) values (");

			sprintf(buff,"%s,'",PQgetvalue(result2, 0, 0));
			query.append((unsigned char *)buff,strlen(buff));
			sprintf(buff,"%s",PQgetvalue(result2, 0, 0));
			MMSEntry->GetEntry()->File.Info.ID.append(StringToUnicodeReturn(buff),strlen(buff));

			dest.clear();
			StringToHexBin(&MMSEntry->GetEntry()->File.Buffer,&dest);
			query.append(dest);

			sprintf(buff,"')");
			query.append((unsigned char *)buff,strlen(buff));

			PQexec(conn, (char *)query.data());	
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

GSM_Error GSM_Backup::AddDecodedInboxToPostgreSQL(PGconn *conn, BOOLEAN SMS, BOOLEAN MMS)
{
	int				Num=1,Seq=1,p;
	unsignedstring			query,dest;
	GSM_Backup_SMSEntry 		*En;
	GSM_Backup_MMSEntry		*En2;
	GSM_Error 			error;
	GSM_SMSMMSDecodedEntry      	DecodedEntry;
	GSM_SMSMMSDecodedSubEntry       *DecodedSubEntry;
	PGresult 			*result2;
	unsignedstring 			ala,ala2;
	char 				buff2[200];
	BOOLEAN				Found = FALSE;
	GSM_SMSListSubEntry		*SubEntry;

	if (SMS) {
		En = NULL;
		while (GetNext_SMS(&En)) {
			if (!En->GetEntry()->Complete) continue;

		        error=DecodedEntry.ReadFromSMS(En->GetEntry());
			if (error.Code != GSM_ERR_NONE) continue;
	
			result2 = PQexec (conn, "select nextval('daemon.inbox_decoded_id')");
	
			p=1;
			DecodedSubEntry = NULL;
			while (DecodedEntry.GetNext(&DecodedSubEntry)) {
	        		switch (DecodedSubEntry->Type) {
			        case MSG_MMSSMS_File:
					ala.clear();
					ala.append((unsigned char *)"insert into daemon.\"inbox_decoded\" (type,id,seq_num,content,type2,filename,bold,italic,underline,strikethrough,small,large) values (");
	
					sprintf(buff2,"0,%s,%i,",PQgetvalue(result2, 0, 0),p);
					ala.append((unsigned char *)buff2,strlen(buff2));
	
				        if (!wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/plain")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vCard")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vNote")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vTodo")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vImelody")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vCalendar")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("application/smil"))) {
						sprintf(buff2,"'");
						ala.append((unsigned char *)buff2,strlen(buff2));
						if (DecodedSubEntry->File.Buffer.size()!=0) ala.append(DecodedSubEntry->File.Buffer);
						sprintf(buff2,"',");
						ala.append((unsigned char *)buff2,strlen(buff2));
					} else {
						sprintf(buff2,"'");
						ala.append((unsigned char *)buff2,strlen(buff2));
						ala2.clear();
						StringToHexBin(&DecodedSubEntry->File.Buffer,&ala2);
						ala.append(ala2);
						sprintf(buff2,"',");
						ala.append((unsigned char *)buff2,strlen(buff2));
					}
					sprintf(buff2,"'%s','',",UnicodeToStringReturn(DecodedSubEntry->Text.data()));
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false,");
					if (DecodedSubEntry->TextBold) sprintf(buff2,"true,");
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false,");
					if (DecodedSubEntry->TextItalic) sprintf(buff2,"true,");
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false,");
					if (DecodedSubEntry->TextUnderline) sprintf(buff2,"true,");
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false,");
					if (DecodedSubEntry->TextStrikethrough) sprintf(buff2,"true,");
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false,");
					if (DecodedSubEntry->TextSize==MSG_Text_Size_Small) sprintf(buff2,"true,");
					ala.append((unsigned char *)buff2,strlen(buff2));
					sprintf(buff2,"false)");
					if (DecodedSubEntry->TextSize==MSG_Text_Size_Large) sprintf(buff2,"true)");
					ala.append((unsigned char *)buff2,strlen(buff2));
					PQexec(conn, (char *)ala.data());
					break;
	        		}
				p++;
			}

			SubEntry = NULL;
			while (En->GetEntry()->GetNext(&SubEntry)) {
				sprintf(buff2,"update daemon.\"inbox_sms\" set processed=true where ID=%s",UnicodeToStringReturn(SubEntry->GetSMS()->ID.data()));
				result2 = PQexec (conn, buff2);
			}

		}
	}
	if (MMS) {
		En2 = NULL;
		while (GetNext_MMS(&En2)) {
			error=DecodedEntry.ReadFromMMS(&En2->GetEntry()->File);
			if (error.Code != GSM_ERR_NONE) continue;
	
			result2 = PQexec (conn, "select nextval('daemon.inbox_decoded_id')");
	
			p=1;
			DecodedSubEntry = NULL;
			while (DecodedEntry.GetNext(&DecodedSubEntry)) {
	        		switch (DecodedSubEntry->Type) {
			        case MSG_MMSSMS_File:
					ala.clear();
					ala.append((unsigned char *)"insert into daemon.\"inbox_decoded\" (type,id,seq_num,content,type2,filename) values (");
	
					sprintf(buff2,"0,%s,%i,",PQgetvalue(result2, 0, 0),p);
					ala.append((unsigned char *)buff2,strlen(buff2));
	
				        if (!wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/plain")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vCard")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vNote")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vTodo")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vImelody")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("text/x-vCalendar")) ||
				            !wcscmp(DecodedSubEntry->Text.data(),StringToUnicodeReturn("application/smil"))) {
						sprintf(buff2,"'");
						ala.append((unsigned char *)buff2,strlen(buff2));
						if (DecodedSubEntry->File.Buffer.size()!=0) ala.append(DecodedSubEntry->File.Buffer);
						sprintf(buff2,"',");
						ala.append((unsigned char *)buff2,strlen(buff2));
					} else {
						sprintf(buff2,"'");
						ala.append((unsigned char *)buff2,strlen(buff2));
						ala2.clear();
						StringToHexBin(&DecodedSubEntry->File.Buffer,&ala2);
						ala.append(ala2);
						sprintf(buff2,"',");
						ala.append((unsigned char *)buff2,strlen(buff2));
					}
					sprintf(buff2,"'%s','')",UnicodeToStringReturn(DecodedSubEntry->Text.data()));
					ala.append((unsigned char *)buff2,strlen(buff2));
					PQexec(conn, (char *)ala.data());
					break;
	        		}
				p++;
			}
			sprintf(buff2,"update daemon.\"inbox_mms\" set processed=true where id=%s",UnicodeToStringReturn(En2->GetEntry()->File.Info.ID.data()));
			result2 = PQexec (conn, buff2);
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

#endif
