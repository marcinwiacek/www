/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../../service/gsmmisc.h"
#include "../../../device/gsmdev.h"
#include "../../gsmphone.h"
#include "../ndct34.h"

class GSM_Protocol;
class GSM_Protocol_Message;

typedef struct {
        int                     NoteID;
        GSM_Calendar_Type       NoteType;
} GSM_Cal_Types;

#define Feat_Series40_30 "s40_30;"

class GSM_Phone_N6510:virtual public GSM_Phone
{
public:
        GSM_Phone_N6510(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("1100" ,      "RH-18"  ,  ""            ,"fbus", "nonote;"));	
		Info.push_back(GSM_Phone_Info("1100a",      "RH-38"  ,  ""            ,"fbus", "nonote;"));
		Info.push_back(GSM_Phone_Info("1100b",      "RH-36"  ,  ""            ,"fbus", "nonote;"));
//1200
//1208
//1650
		Info.push_back(GSM_Phone_Info("2610" ,      "RH-86"  ,  ""            ,"fbus", "nonote;"));
//2626
//2630
		Info.push_back(GSM_Phone_Info("2650" ,      "RH-53"  ,  ""            ,"fbus", "nonote;"));
//2660
//2670
        /*1*/   Info.push_back(GSM_Phone_Info("3100/3120",  "RH-19"  ,  ""            ,"fbus", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("3100b/3120b","RH-50"  ,  ""            ,"fbus", "nonote;"));
        	Info.push_back(GSM_Phone_Info("3105" ,      "RH-48"  ,  "Nokia 3105"  ,"fbus|irdaphonet", "nonote;"));
        	Info.push_back(GSM_Phone_Info("3108" ,      "RH-6"   ,  ""  		 ,"fbus", "nonote;"));
	/*3FP2*/Info.push_back(GSM_Phone_Info("3110",       "RM-237" ,  "Nokia 3110"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));//3110 Classic
        /*1*/   Info.push_back(GSM_Phone_Info("3200" ,      "RH-30"  ,  "Nokia 3200"  ,"fbus|irdaphonet", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("3200b",      "RH-31"  ,  "Nokia 3200"  ,"fbus|irdaphonet", "nonote;"));
       		Info.push_back(GSM_Phone_Info("3205" ,      "RH-11"  ,  "Nokia 3205"  ,"fbus|irdaphonet", "nonote;"));
        /*2*/   Info.push_back(GSM_Phone_Info("3220" ,      "RH-37"  ,  ""            ,"fbus", ""));
        /*2*/   Info.push_back(GSM_Phone_Info("3220b",      "RH-49"  ,  ""            ,"fbus", ""));
        /*1*/   Info.push_back(GSM_Phone_Info("3300" ,      "NEM-1"  ,  "Nokia 3300"  ,"fbus|irdaphonet", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("3300b",      "NEM-2"  ,  "Nokia 3300"  ,"fbus|irdaphonet", "nonote;"));
//3500 classic
        /*1*/   Info.push_back(GSM_Phone_Info("3510" ,      "NHM-8"  ,  ""            ,"fbus", "calendar35;filesystem1only;notodo;nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("3510i/3530", "RH-9"   ,  ""            ,"fbus", "calendar35;filesystem1only;notodo;nonote;"));
//3555 Classic
        	Info.push_back(GSM_Phone_Info("3589i",      "RH-44"  ,  ""            ,"fbus", "calendar35;filesystem1only;notodo;nonote;"));
        	Info.push_back(GSM_Phone_Info("3590" ,      "NPM-8"  ,  ""            ,"fbus", "calendar35;filesystem1only;notodo;nonote;"));
        	Info.push_back(GSM_Phone_Info("3595" ,      "NPM-10" ,  ""            ,"fbus", "calendar35;filesystem1only;notodo;nonote;"));
//5070
        /*1*/   Info.push_back(GSM_Phone_Info("5100" ,      "NPM-6"  ,  "Nokia 5100"  ,"fbus|irdaphonet|dku5fbus|dku5", "filesystem1only;nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("5100" ,      "NPM-6U" ,  "Nokia 5100"  ,"fbus|irdaphonet|dku5fbus|dku5", "filesystem1only;nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("5100" ,      "NPM-6X" ,  "Nokia 5100"  ,"fbus|irdaphonet|dku5fbus|dku5", "filesystem1only;nonote;"));
        /*2*/   Info.push_back(GSM_Phone_Info("5140" ,      "NPL-5"  ,  "Nokia 5140"  ,"fbus|irdaphonet", "nonote;"));
        /*2*/   Info.push_back(GSM_Phone_Info("5140b",      "NPL-4"  ,  "Nokia 5140"  ,"fbus|irdaphonet", "nonote;"));
        /*2*/   Info.push_back(GSM_Phone_Info("5140i",      "RM-104" ,  "Nokia 5140i" ,"fbus|irdaphonet", "nonote;"));
        /*3FP2*/Info.push_back(GSM_Phone_Info("5200",       "RM-174" ,  "Nokia 5200"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP2*/Info.push_back(GSM_Phone_Info("5300",       "RM-146" ,  "Nokia 5300"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP2*/Info.push_back(GSM_Phone_Info("5300b",      "RM-147" ,  "Nokia 5300"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
//5310 Xpress Music
        /*2*/   Info.push_back(GSM_Phone_Info("6020" ,      "RM-30"  ,  "Nokia 6020"  ,"fbus|irdaphonet", ""));
        /*2*/   Info.push_back(GSM_Phone_Info("6020b",      "RM-31"  ,  "Nokia 6020"  ,"fbus|irdaphonet", ""));
                Info.push_back(GSM_Phone_Info("6070" ,      "RM-166" ,  "Nokia 6070"  ,"fbus|irdaphonet", ""));
        /*3FP2*/Info.push_back(GSM_Phone_Info("6085" ,      "RM-198" ,  "Nokia 6085"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*1*/   Info.push_back(GSM_Phone_Info("6100" ,      "NPL-2"  ,  "Nokia 6100"  ,"fbus|irdaphonet|dku2phonet|dku2", "nonote;"));
        /*2*/	Info.push_back(GSM_Phone_Info("6101" ,      "RM-76"  ,  "Nokia 6101"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "nonote;"));
//RM-162 6102i
        /*2*/	Info.push_back(GSM_Phone_Info("6103" ,      "RM-161" ,  "Nokia 6103"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "nonote;"));
        /*3*/   Info.push_back(GSM_Phone_Info("6111" ,      "RM-82"  ,  "Nokia 6111"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP1*/Info.push_back(GSM_Phone_Info("6125" ,      "RM-178" ,  "Nokia 6125"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP1*/Info.push_back(GSM_Phone_Info("6131" ,      "RM-115" ,  "Nokia 6131"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*1*/   Info.push_back(GSM_Phone_Info("6170" ,      "RM-47"  ,  "Nokia 6170"  ,"fbus|irdaphonet|dku2phonet|dku2", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("6170" ,      "RM-48"  ,  "Nokia 6170"  ,"fbus|irdaphonet|dku2phonet|dku2", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("6200" ,      "NPL-3"  ,  "Nokia 6200"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "nonote;"));
        /*1*/   Info.push_back(GSM_Phone_Info("6220" ,      "RH-20"  ,  "Nokia 6220"  ,"fbus|irdaphonet|dku5fbus|dku5", "filesystem1only;nonote;"));
        /*2*/   Info.push_back(GSM_Phone_Info("6230" ,      "RH-12"  ,  "Nokia 6230"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "filesystem1;"));
        /*2*/   Info.push_back(GSM_Phone_Info("6230b",      "RH-28"  ,  "Nokia 6230"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "filesystem1;"));
        /*2*/   Info.push_back(GSM_Phone_Info("6230i",      "RM-72"  ,  "Nokia 6230i" ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", "filesystem1;"));
        /*3*/   Info.push_back(GSM_Phone_Info("6233",       "RM-145" ,  "Nokia 6233"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3*/   Info.push_back(GSM_Phone_Info("6234",       "RM-123" ,  "Nokia 6234"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3*/   Info.push_back(GSM_Phone_Info("6234",       "RM-123" ,  "Nokia 6234"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
//6263
        /*3*/   Info.push_back(GSM_Phone_Info("6270",       "RM-56"  ,  "Nokia 6270"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
		//two phones - three entries
        /*3*/   Info.push_back(GSM_Phone_Info("6280/6288",  "RM-78"  ,  ""            ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3*/   Info.push_back(GSM_Phone_Info("6280",       "RM-78"  ,  "Nokia 6280"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3*/   Info.push_back(GSM_Phone_Info("6288",       "RM-78"  ,  "Nokia 6288"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP2*/Info.push_back(GSM_Phone_Info("6300",       "RM-217" ,  "Nokia 6300"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*0*/   Info.push_back(GSM_Phone_Info("6310",       "NPE-4"  ,  "Nokia 6310"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dlr3fbus|dlr3", "sms1;calendar65;nofilesystem;todo1;nonote;"));
        /*0*/   Info.push_back(GSM_Phone_Info("6310i",      "NPL-1"  ,  "Nokia 6310i" ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dlr3fbus|dlr3", "sms1;calendar65;filesystem1only;todo1;nonote;"));
                Info.push_back(GSM_Phone_Info("6385",       "NHP-2AX",  "Nokia 6385"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dlr3fbus|dlr3", "sms1;calendar65;filesystem1only;todo1;nonote;"));
                Info.push_back(GSM_Phone_Info("6500",       "NHM-7"  ,  "Nokia 6500"  ,"fbus|irdaphonet", "calendar1;nonote;"));
                Info.push_back(GSM_Phone_Info("8310" ,      "NHM-7"  ,  "Nokia 8310"  ,"fbus|irdaphonet", "calendar1;nonote;"));
        /*5FP1*/Info.push_back(GSM_Phone_Info("6500" ,      "RM-265"  , "Nokia 6500"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*5FP1*/Info.push_back(GSM_Phone_Info("6500s" ,     "RM-240"  , "Nokia 6500"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
                Info.push_back(GSM_Phone_Info("6510" ,      "NPM-9"  ,  "Nokia 6510"  ,"fbus|irdaphonet", "calendar65;nonote;"));
        /*5F*/  Info.push_back(GSM_Phone_Info("6555" ,     "RM-271"  , "Nokia 6555"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
                Info.push_back(GSM_Phone_Info("6610" ,      "NHL-4U" ,  "Nokia 6610"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6610i",      "RM-37"  ,  "Nokia 6610i" ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6650" ,      "NHM-1"  ,  "Nokia 6650"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6800" ,      "NHL-6"  ,  "Nokia 6800"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6800" ,      "NSB-9"  ,  "Nokia 6800"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6810" ,      "RM-2"   ,  "Nokia 6810"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6820" ,      "NHL-9"  ,  "Nokia 6820"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("6822" ,      "RM-68"  ,  "Nokia 6822"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet", Feat_Series40_30));
                Info.push_back(GSM_Phone_Info("6822" ,      "RM-69"  ,  "Nokia 6822"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet", Feat_Series40_30));
                Info.push_back(GSM_Phone_Info("7200" ,      "RH-23"  ,  "Nokia 7200"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7200" ,      "RH-33"  ,  "Nokia 7200"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7210" ,      "NHL-4"  ,  "Nokia 7210"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7250" ,      "NHL-4J" ,  "Nokia 7250"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7250i",      "NHL-4JX",  "Nokia 7250i" ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7260" ,      "RM-17"  ,  "Nokia 7260"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("7270" ,      "RM-8"   ,  "Nokia 7270"  ,"fbus|irdaphonet|dku2phonet|dku2", "nonote;"));
                Info.push_back(GSM_Phone_Info("7360" ,      "RM-127" ,  "Nokia 7360"  ,"fbus|irdaphonet", "nonote;"));
        /*3*/   Info.push_back(GSM_Phone_Info("7370" ,      "RM-70"  ,  "Nokia 7370"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
        /*3FP2*/Info.push_back(GSM_Phone_Info("7390" ,      "RM-140" ,  "Nokia 7390"  ,"fbus|irdaphonet|phonetblue|bluephonet|bluerfphonet|dku2phonet|dku2", Feat_Series40_30));
//7500 Prism
                Info.push_back(GSM_Phone_Info("7600" ,      "NMM-3"  ,  "Nokia 7600"  ,"fbus|irdaphonet", "nonote;"));
                Info.push_back(GSM_Phone_Info("8390" ,      "NSB-8"  ,  "Nokia 8390"  ,"fbus|irdaphonet", "calendar1;nonote;"));
//8600 Luna
                Info.push_back(GSM_Phone_Info("8910" ,      "NHM-4"  ,  "Nokia 8910"  ,"fbus|irdaphonet", "calendar1;nonote;"));
                Info.push_back(GSM_Phone_Info("8910i",      "NHM-4NX",  "Nokia 8910i" ,"fbus|irdaphonet", "calendar1;nonote;"));

                DCT34 = new GSM_Phone_NDCT34((*Phones)->GetID(),Deb,&(*Phones));

                ModuleName      = "dct4s40/n6510";
                ModulesUsed     = "";
                ModulesRequired = "";

                for (int i=0;i<5;i++) {
                        CalendarIcons[i].NoteType = Calendar_Type_Not_Assigned;
                }
        }
        ~GSM_Phone_N6510() {
                delete DCT34;
        }

        GSM_Error        Open                   (char *FrameID);
        GSM_Error        Dispatch               (GSM_Protocol_Message *msg, void *Struct, int RequestID);
        GSM_Error        Close();

        //phone info
        GSM_Error        GetManufacturer        (unsigned char *Manufacturer);
        GSM_Error        GetIMEI                (unsigned char *IMEI);
        GSM_Error        GetCodeNameModel       (unsigned char *Model);
        GSM_Error        GetFirmwareVersion     (unsigned char *Firm);
        GSM_Error        GetFirmwareDate        (unsigned char *Dat);
	GSM_Error 	 GetProductCode		(unsigned char *ProductCode);
        //date time
        GSM_Error        GetDateTime            (GSM_DateTime *DT);
	GSM_Error 	 SetDateTime		(GSM_DateTime *DT);
        //phonebook memories
        GSM_Error        GetPBKStatus           (GSM_PBKStatus *Status);
        GSM_Error        GetPBK                 (GSM_PBKEntry *Entry);
        GSM_Error        SetPBK                 (GSM_PBKEntry *Entry);
        GSM_Error        DeletePBK              (GSM_PBKEntry *Entry);
        //calendar
        GSM_Error        GetNextCalendar        (GSM_CalendarEntry *Entry, BOOLEAN start, int *Current, int *Max);
        GSM_Error        AddCalendar            (GSM_CalendarEntry *Entry);
        GSM_Error        DeleteCalendar         (GSM_CalendarEntry *Entry);
        //notes
        GSM_Error        GetNextNote		(GSM_NoteEntry *Entry, BOOLEAN start, int *Current, int *Max);
        GSM_Error        AddNote		(GSM_NoteEntry *Entry);
        GSM_Error        DeleteNote		(GSM_NoteEntry *Entry);
        //todo
        GSM_Error        GetNextToDo		(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max);
        GSM_Error        AddToDo		(GSM_ToDoEntry *Entry);
        GSM_Error        DeleteToDo		(GSM_ToDoEntry *Entry);
        GSM_Error        DeleteAllToDo		();
        //sms
        GSM_Error        GetSMSStatus           (GSM_SMSStatus *Status);
        GSM_Error        GetSMSC                (GSM_SMSC *SMSC);
//      GSM_Error        AddSMS                 (GSM_SMSList *List);
        GSM_Error        SetSMS                 (GSM_SMSList *List);
        GSM_Error        SendSMS                (GSM_SMSEntry *SMS);
        GSM_Error        DeleteSMS              (GSM_SMSList *List);
        //sms & mms
	GSM_Error 	 GetSMSMMSFolders	(GSM_SMSMMSFolders *Folders);
	GSM_Error      GetNextSMSMMSIDFromFolder(BOOLEAN start, GSM_SMSMMSFoldersSubEntry *SMSFolder, GSM_SMSList *SMS, GSM_MMSEntry *MMS, int *Current, int *MaxInFolder);
        //filesystem
        GSM_Error        GetFileFolderInfo      (FileFolderInfo *FInfo);
        GSM_Error        GetFolderInfoList      (GSM_FileFolderInfoList *FInfo, BOOLEAN Start);
        GSM_Error        GetNextRootFolderID    (wchar_t *ID, GSM_MemoryType *MemType);
        GSM_Error        GetFilePart            (GSM_File *File);
        GSM_Error        GetMMSFilePart         (GSM_File *File);
        GSM_Error        AddFilePart            (GSM_File *File, int *Pos);
        GSM_Error        DeleteFile             (const wchar_t *FileID);
        GSM_Error        DeleteFolder           (wchar_t *FolderID);
        GSM_Error        AddFolder              (FileFolderInfo *FInfo);
        GSM_Error        GetJavaGamesFolderID   (wchart *ID, BOOLEAN *NeedSubFolder, BOOLEAN Start);
        GSM_Error        GetJavaAppsFolderID    (wchart *ID, BOOLEAN *NeedSubFolder, BOOLEAN Start);
private:
        GSM_Phone_NDCT34                *DCT34;
	//pbk
	GSM_PBK_Features		PhonePBKFeatures;
	GSM_PBK_Features		SIMPBKFeatures;
//add: speed dial cache
        //calendar
        int                             CurrentCalendarNumber;
        GSM_Cal_Loc                     CalendarLocations;
        GSM_Cal_Types                   CalendarIcons[5];
        //sms 1
        GSM_SMS_Loc                     SMSLocations;
        int                             SMSFoldersNum;
        unsigned char                   SMSFolderID;
        int                             SMSLocation;
        //sms 2
	GSM_FileFolderInfoListsSubEntry *SMSCache2;
        GSM_FileFolderInfoListSubEntry  *SMSSubEntry;
        int                             SMSListMax, SMSListPos;
        GSM_Error                       GetNextSMSFolder2;
        //filesystem 2
        unsignedint                     FileSystemOpened2;
        int                             GetFolderListing2;
	GSM_File			MMSFile;
        //Java folders
        GSM_FileFolderInfoList          JavaFInfo;
        GSM_FileFolderInfoListSubEntry  *JavaFInfoSubEntry;
	
	GSM_Error 	 ReplySetDateTime		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *s);

	//calendar,note,todo
	void 		 FindCalendarDateDifference	(GSM_DateTime *DT,long diff);
	GSM_Error 	 GetToDo1Info			();
	GSM_Error 	 GetNextToDo1			(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	 GetNextCalendar3NoteToDo2	(void *Entry, BOOLEAN start, int *Current, int *Max, int *Location, unsigned char Type, int request);
	GSM_Error 	 PrivGetCalendar3NoteToDo2	(void *Entry, int Location, int request);
	GSM_Error 	 GetCalendar3NoteToDo2Info	(unsigned char type);
        GSM_Error        AddCalendar3           	(GSM_CalendarEntry *Entry);
	GSM_Error 	 AddToDo1			(GSM_ToDoEntry *Entry);
	GSM_Error 	 AddToDo2			(GSM_ToDoEntry *Entry);
        GSM_Error        GetFirstCalendarPos3   	(int *Location,unsigned char type);
	GSM_Error 	 FindCalendarNoteType3		(GSM_CalendarEntry *Entry, int *NoteID);
        //sms
        GSM_Error        GetSMSFolderStatus1    	(GSM_SMS_Loc *SMSLocations);
        GSM_Error        GetSMS1                	(GSM_SMSList *List, wchart SMS_ID);
        GSM_Error        GetSMS2                	(GSM_SMSList *List, GSM_File *File);
        GSM_Error        DecodeSMSFrame1        	(GSM_SMSEntry *SMS, const unsigned char *buffer, int len, GSM_DateTime *SaveDateTime, unsignedstring *PictureText);
        GSM_Error        EncodeSMSFrameToBuffer1	(GSM_SMSEntry *SMS, unsignedstring *Buffer);
	GSM_Error     	 GetNextSMSMMSIDFromFolder1	(BOOLEAN start, GSM_SMSMMSFoldersSubEntry *SMSFolder, GSM_SMSList *SMS, GSM_MMSEntry *MMS, int *Current, int *MaxInFolder);
	GSM_Error     	 GetNextSMSMMSIDFromFolder2	(BOOLEAN start, GSM_SMSMMSFoldersSubEntry *SMSFolder, GSM_SMSList *SMS, GSM_MMSEntry *MMS, int *Current, int *MaxInFolder);
        GSM_Error        GetSMSStatus1          	(GSM_SMSStatus *Status);
	GSM_Error 	 GetSMSMMSFolders1		(GSM_SMSMMSFolders *Folders);
	GSM_Error 	 GetSMSMMSFolders2		(GSM_SMSMMSFolders *Folders);
        GSM_Error        SetSMS1                	(GSM_SMSList *List);
        GSM_Error        DeleteSMS1             	(GSM_SMSList *List);
        GSM_Error        DeleteSMS2             	(GSM_SMSList *List);
        //filesystem
        GSM_Error        GetFileFolderInfo1     	(FileFolderInfo *FInfo);
        GSM_Error        GetFileFolderInfo2     	(FileFolderInfo *FInfo);
        GSM_Error        GetFolderInfoList1     	(GSM_FileFolderInfoList *FInfo, BOOLEAN Start);
        GSM_Error        GetFolderInfoList2     	(GSM_FileFolderInfoList *FInfo, BOOLEAN Start);
        GSM_Error        GetFilePart1           	(GSM_File *File);
        GSM_Error        GetFilePart2           	(GSM_File *File);
        GSM_Error        GetFileCheckSum1       	(GSM_File *File,unsigned int *CheckSum);
        GSM_Error        GetFileCheckSum2       	(GSM_File *File,unsigned int *CheckSum);
        GSM_Error        AddFilePart1           	(GSM_File *File, int *Pos);
        GSM_Error        AddFilePart2           	(GSM_File *File, int *Pos);
        GSM_Error        OpenFile2              	(GSM_File *File, BOOLEAN Create);
        GSM_Error        CloseFile2             	(GSM_File *File);
        void             FFolderPathGammu2Phone2	(const wchar_t *src, unsignedstring *dest);
        unsigned int     FindFileCheckSum12     	(const unsigned char *ptr, int len);
        GSM_Error        DeleteFile1            	(const wchar_t *FileID);
        GSM_Error        DeleteFile2            	(const wchar_t *FileID);
        GSM_Error        DeleteFolder1          	(wchar_t *FolderID);
        GSM_Error        DeleteFolder2          	(wchar_t *FolderID);
        GSM_Error        DeleteFFolder1         	(const wchar_t *MyID);
        GSM_Error        AddFolder1             	(FileFolderInfo *FInfo);
        GSM_Error        AddFolder2             	(FileFolderInfo *FInfo);
        GSM_Error        MakeFileSystemFrame2   	(unsignedstring *Buffer, const wchar_t *Name, unsigned char ID);
        GSM_Error        FileSystemFunc         	(const wchar_t *ID, int *Num);
	//pbk
        GSM_Error        ReplyGetPBKStatus      	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetIMEI           	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);
        GSM_Error        ReplyGetPBK            	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetProductCode		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *ProductCode);
	GSM_Error 	 ReplyGetPBKFeatures		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	//calendar,todo,notes
	GSM_Error 	 ReplyGetToDo1Location		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetToDoInfo1		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetNextToDo1      	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetNextToDo2      	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetNextNote       	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetNextCalendar3  	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetCalendarNoteToDoInfo3	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetDateTime       	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFirstCalPos3   	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        //sms
        GSM_Error        ReplyGetSMSStatus1     	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetSMS1           	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetSMSFolders1    	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetSMSFolderStatus1	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplySetSMS1           	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyDeleteSMS1        	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetSMSC           	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplySendSMS           	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        //filesystem
        GSM_Error        ReplyGetFFolderInfo1   	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFFolderInfo2   	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFolderInfoList1	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFolderInfoList2	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFFolderInfo2Part	(GSM_Protocol_Message *msg, DebugInfo **Debug, FileFolderInfo *FInfo);
        GSM_Error        ReplyOpenFile2         	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyAddFilePart1      	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFilePart12     	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetFileCheckSum12 	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyAddFolder1        	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyAddFolder2        	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyDeleteFFolder1    	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyDeleteFolder2     	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyDeleteFile2       	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
};
