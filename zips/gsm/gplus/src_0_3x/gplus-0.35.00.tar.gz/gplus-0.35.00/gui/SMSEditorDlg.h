//---------------------------------------------------------------------------
//
// Name:        SMSEditorDlg.h
// Author:      Marcinello
// Created:     2007-02-06 23:39:09
// Description: SMSEditorDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __SMSEditorDLG_h__
#define __SMSEditorDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/filedlg.h>
#include <wx/listctrl.h>
#include <wx/choice.h>
#include <wx/listbox.h>
#include <wx/combobox.h>
#include <wx/stattext.h>
#include <wx/bmpbuttn.h>
#include <wx/textctrl.h>
#include <wx/checkbox.h>
#include <wx/button.h>
#include <wx/statbox.h>
#include <wx/notebook.h>
#include <wx/panel.h>
////Header Include End

#include "../common/service/gsmlogo.h"


////Dialog Style Start
#undef SMSEditorDlg_STYLE
#define SMSEditorDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class SMSEditorDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		SMSEditorDlg(GSM_Backup *Backup2, GSM_StateMachine *s2, GSM_SMSList *List2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = SMSEditorDlg_STYLE);
		virtual ~SMSEditorDlg();
		void WxMemo1Updated(wxCommandEvent& event);
		void WxCheckBox1Click(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
	
	public:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxFileDialog *WxOpenFileDialog1;
		wxButton *SendWxButton;
		wxButton *CancelWxButton;
		wxComboBox *ValidityWxComboBox;
		wxStaticText *WxStaticText1;
		wxCheckBox *ReportWxCheckBox;
		wxComboBox *SMSCWxComboBox;
		wxStaticText *WxStaticText2;
		wxStaticBox *WxStaticBox7;
		wxButton *RecipientDeleteWxButton;
		wxButton *WxButton6;
		wxListCtrl *RecipientsWxListCtrl;
		wxStaticBox *WxStaticBox6;
		wxTextCtrl *NewRecipientWxEdit;
		wxButton *NewRecipientAddWxButton;
		wxStaticBox *WxStaticBox5;
		wxPanel *WxNoteBookPage3;
		wxChoice *WxChoice10;
		wxStaticText *WxStaticText18;
		wxListCtrl *WxListCtrl8;
		wxListCtrl *WxListCtrl7;
		wxStaticBox *WxStaticBox21;
		wxStaticBox *WxStaticBox20;
		wxPanel *WxNoteBookPage11;
		wxChoice *WxChoice8;
		wxStaticText *WxStaticText12;
		wxListCtrl *WxListCtrl6;
		wxListCtrl *WxListCtrl5;
		wxStaticBox *WxStaticBox16;
		wxStaticBox *WxStaticBox15;
		wxPanel *WxNoteBookPage8;
		wxStaticText *WxStaticText3;
		wxChoice *WxChoice6;
		wxListCtrl *WxListCtrl4;
		wxListCtrl *WxListCtrl1;
		wxStaticBox *WxStaticBox14;
		wxStaticBox *WxStaticBox13;
		wxPanel *WxNoteBookPage4;
		wxListCtrl *WxListCtrl3;
		wxListCtrl *WxListCtrl2;
		wxChoice *WxChoice5;
		wxStaticText *WxStaticText4;
		wxStaticBox *WxStaticBox12;
		wxStaticBox *WxStaticBox4;
		wxPanel *WxNoteBookPage5;
		wxStaticText *WxStaticText17;
		wxTextCtrl *WxMemo3;
		wxTextCtrl *WxEdit3;
		wxStaticText *WxStaticText15;
		wxButton *WxButton2;
		wxComboBox *WxComboBox3;
		wxStaticText *WxStaticText14;
		wxPanel *WxNoteBookPage10;
		wxTextCtrl *WxMemo2;
		wxStaticBox *WxStaticBox19;
		wxCheckBox *WxCheckBox2;
		wxChoice *WxChoice9;
		wxBitmapButton *WxBitmapButton1;
		wxButton *WxButton1;
		wxTextCtrl *WxMemo1;
		wxComboBox *WxComboBox2;
		wxStaticText *WxStaticText13;
		wxStaticBox *WxStaticBox17;
		wxStaticBox *WxStaticBox18;
		wxPanel *WxNoteBookPage9;
		wxComboBox *WxComboBox5;
		wxStaticText *WxStaticText16;
		wxStaticText *WxStaticText10;
		wxChoice *WxChoice4;
		wxChoice *WxChoice3;
		wxStaticText *WxStaticText7;
		wxChoice *WxChoice2;
		wxStaticText *WxStaticText6;
		wxStaticBox *WxStaticBox11;
		wxStaticText *WxStaticText5;
		wxChoice *WxChoice1;
		wxStaticBox *WxStaticBox10;
		wxStaticBox *WxStaticBox9;
		wxStaticBox *WxStaticBox8;
		wxPanel *WxNoteBookPage7;
		wxChoice *WxChoice7;
		wxStaticText *WxStaticText11;
		wxTextCtrl *WxEdit2;
		wxTextCtrl *WxEdit1;
		wxStaticText *WxStaticText9;
		wxStaticText *WxStaticText8;
		wxPanel *WxNoteBookPage6;
		wxCheckBox *WxCheckBox14;
		wxCheckBox *WxCheckBox13;
		wxStaticText *WxStaticText21;
		wxChoice *WxChoice12;
		wxCheckBox *WxCheckBox12;
		wxCheckBox *WxCheckBox4;
		wxCheckBox *WxCheckBox3;
		wxCheckBox *WxCheckBox1;
		wxChoice *WxChoice11;
		wxStaticText *WxStaticText20;
		wxListBox *WxListBox1;
		wxButton *WxButton9;
		wxComboBox *WxComboBox8;
		wxComboBox *WxComboBox7;
		wxComboBox *WxComboBox6;
		wxStaticText *WxStaticText19;
		wxTextCtrl *WxMemo5;
		wxButton *WxButton8;
		wxBitmapButton *WxBitmapButton2;
		wxCheckBox *WxCheckBox11;
		wxStaticBox *WxStaticBox26;
		wxStaticBox *WxStaticBox25;
		wxTextCtrl *WxMemo4;
		wxStaticBox *WxStaticBox24;
		wxStaticBox *WxStaticBox23;
		wxCheckBox *WxCheckBox10;
		wxCheckBox *WxCheckBox9;
		wxCheckBox *WxCheckBox8;
		wxCheckBox *WxCheckBox7;
		wxCheckBox *WxCheckBox6;
		wxCheckBox *WxCheckBox5;
		wxButton *WxButton7;
		wxButton *WxButton5;
		wxButton *WxButton4;
		wxButton *WxButton3;
		wxStaticBox *WxStaticBox22;
		wxPanel *WxNoteBookPage12;
		wxNotebook *WxNotebook1;
		wxPanel *WxNoteBookPage2;
		wxNotebook *WxNotebook2;
		wxPanel *WxPanel1;
		////GUI Control Declaration End
		void WxButton5Click(wxCommandEvent& event);
		void WxButton7Click(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
		void CancelWxButtonClick(wxCommandEvent& event);
		void RecipientDeleteWxButtonClick(wxCommandEvent& event);
		void SendWxButtonClick(wxCommandEvent& event);
		void NewRecipientAddWxButtonClick(wxCommandEvent& event);
		void NewRecipientWxEditUpdated(wxCommandEvent& event);
		void WxChoice1Selected(wxCommandEvent& event );
		void WxChoice2Selected(wxCommandEvent& event );
		void WxChoice3Selected(wxCommandEvent& event );
		void WxChoice4Selected(wxCommandEvent& event );
		void WxEdit1Updated1(wxCommandEvent& event);
		void WxEdit2Updated(wxCommandEvent& event);
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_SENDWXBUTTON = 1018,
			ID_CANCELWXBUTTON = 1007,
			ID_VALIDITYWXCOMBOBOX = 1039,
			ID_WXSTATICTEXT1 = 1038,
			ID_REPORTWXCHECKBOX = 1034,
			ID_SMSCWXCOMBOBOX = 1033,
			ID_WXSTATICTEXT2 = 1032,
			ID_WXSTATICBOX7 = 1031,
			ID_RECIPIENTDELETEWXBUTTON = 1029,
			ID_WXBUTTON6 = 1028,
			ID_RECIPIENTSWXLISTCTRL = 1027,
			ID_WXSTATICBOX6 = 1026,
			ID_NEWRECIPIENTWXEDIT = 1024,
			ID_NEWRECIPIENTADDWXBUTTON = 1023,
			ID_WXSTATICBOX5 = 1022,
			ID_WXNOTEBOOKPAGE3 = 1017,
			ID_WXCHOICE10 = 1137,
			ID_WXSTATICTEXT18 = 1136,
			ID_WXLISTCTRL8 = 1135,
			ID_WXLISTCTRL7 = 1134,
			ID_WXSTATICBOX21 = 1133,
			ID_WXSTATICBOX20 = 1132,
			ID_WXNOTEBOOKPAGE11 = 1131,
			ID_WXCHOICE8 = 1099,
			ID_WXSTATICTEXT12 = 1098,
			ID_WXLISTCTRL6 = 1097,
			ID_WXLISTCTRL5 = 1096,
			ID_WXSTATICBOX16 = 1093,
			ID_WXSTATICBOX15 = 1092,
			ID_WXNOTEBOOKPAGE8 = 1091,
			ID_WXSTATICTEXT3 = 1090,
			ID_WXCHOICE6 = 1089,
			ID_WXLISTCTRL4 = 1088,
			ID_WXLISTCTRL1 = 1087,
			ID_WXSTATICBOX14 = 1086,
			ID_WXSTATICBOX13 = 1085,
			ID_WXNOTEBOOKPAGE4 = 1043,
			ID_WXLISTCTRL3 = 1084,
			ID_WXLISTCTRL2 = 1083,
			ID_WXCHOICE5 = 1082,
			ID_WXSTATICTEXT4 = 1081,
			ID_WXSTATICBOX12 = 1080,
			ID_WXSTATICBOX4 = 1079,
			ID_WXNOTEBOOKPAGE5 = 1044,
			ID_WXSTATICTEXT17 = 1130,
			ID_WXMEMO3 = 1129,
			ID_WXEDIT3 = 1126,
			ID_WXSTATICTEXT15 = 1125,
			ID_WXBUTTON2 = 1124,
			ID_WXCOMBOBOX3 = 1123,
			ID_WXSTATICTEXT14 = 1122,
			ID_WXNOTEBOOKPAGE10 = 1101,
			ID_WXMEMO2 = 1121,
			ID_WXSTATICBOX19 = 1120,
			ID_WXCHECKBOX2 = 1116,
			ID_WXCHOICE9 = 1114,
			ID_WXBITMAPBUTTON1 = 1113,
			ID_WXBUTTON1 = 1109,
			ID_WXMEMO1 = 1105,
			ID_WXCOMBOBOX2 = 1104,
			ID_WXSTATICTEXT13 = 1103,
			ID_WXSTATICBOX17 = 1117,
			ID_WXSTATICBOX18 = 1118,
			ID_WXNOTEBOOKPAGE9 = 1100,
			ID_WXCOMBOBOX5 = 1128,
			ID_WXSTATICTEXT16 = 1127,
			ID_WXSTATICTEXT10 = 1073,
			ID_WXCHOICE4 = 1068,
			ID_WXCHOICE3 = 1067,
			ID_WXSTATICTEXT7 = 1066,
			ID_WXCHOICE2 = 1064,
			ID_WXSTATICTEXT6 = 1063,
			ID_WXSTATICBOX11 = 1062,
			ID_WXSTATICTEXT5 = 1061,
			ID_WXCHOICE1 = 1060,
			ID_WXSTATICBOX10 = 1057,
			ID_WXSTATICBOX9 = 1054,
			ID_WXSTATICBOX8 = 1053,
			ID_WXNOTEBOOKPAGE7 = 1052,
			ID_WXCHOICE7 = 1095,
			ID_WXSTATICTEXT11 = 1094,
			ID_WXEDIT2 = 1072,
			ID_WXEDIT1 = 1071,
			ID_WXSTATICTEXT9 = 1070,
			ID_WXSTATICTEXT8 = 1069,
			ID_WXNOTEBOOKPAGE6 = 1045,
			ID_WXCHECKBOX14 = 1189,
			ID_WXCHECKBOX13 = 1188,
			ID_WXSTATICTEXT21 = 1187,
			ID_WXCHOICE12 = 1186,
			ID_WXCHECKBOX12 = 1185,
			ID_WXCHECKBOX4 = 1183,
			ID_WXCHECKBOX3 = 1182,
			ID_WXCHECKBOX1 = 1180,
			ID_WXCHOICE11 = 1179,
			ID_WXSTATICTEXT20 = 1178,
			ID_WXLISTBOX1 = 1177,
			ID_WXBUTTON9 = 1176,
			ID_WXCOMBOBOX8 = 1175,
			ID_WXCOMBOBOX7 = 1174,
			ID_WXCOMBOBOX6 = 1173,
			ID_WXSTATICTEXT19 = 1172,
			ID_WXMEMO5 = 1167,
			ID_WXBUTTON8 = 1171,
			ID_WXBITMAPBUTTON2 = 1170,
			ID_WXCHECKBOX11 = 1169,
			ID_WXSTATICBOX26 = 1168,
			ID_WXSTATICBOX25 = 1166,
			ID_WXMEMO4 = 1165,
			ID_WXSTATICBOX24 = 1164,
			ID_WXSTATICBOX23 = 1163,
			ID_WXCHECKBOX10 = 1150,
			ID_WXCHECKBOX9 = 1149,
			ID_WXCHECKBOX8 = 1148,
			ID_WXCHECKBOX7 = 1147,
			ID_WXCHECKBOX6 = 1146,
			ID_WXCHECKBOX5 = 1145,
			ID_WXBUTTON7 = 1144,
			ID_WXBUTTON5 = 1143,
			ID_WXBUTTON4 = 1142,
			ID_WXBUTTON3 = 1141,
			ID_WXSTATICBOX22 = 1139,
			ID_WXNOTEBOOKPAGE12 = 1138,
			ID_WXNOTEBOOK1 = 1004,
			ID_WXNOTEBOOKPAGE2 = 1016,
			ID_WXNOTEBOOK2 = 1015,
			ID_WXPANEL1 = 1003,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
        void SetInfo();		
        void Indicators();        
        void WAPBookmark();
        void DeleteP(wxString Str);   
        void FileTransfer();             
	
    GSM_Backup *Backup;
    	
		GSM_SMSList       *List;
		GSM_StateMachine  *s;
		long              num;
		BOOLEAN           start;
		GSM_PBKEntry      *PBK2;
		GSM_CalendarEntry *Cal2;
		GSM_ToDoEntry     *ToDo2;
        GSM_NoteEntry     *Note2;
		Mono_Bitmap_FileEntry MonoFile;
		BOOLEAN               MonoFileAvail;
		GSM_File          FF;
		BOOLEAN UpdatingFileTransfer;
		GSM_SMSMMSDecodedEntry EMS;
		GSM_SMSMMSDecodedSubEntry *EMSSub;
		BOOLEAN   EMSEdit;
		
	public:
        void SendPBK(GSM_PBKEntry *PBK);    
        void DeleteNormal();            
		void WxChoice5Selected(wxCommandEvent& event );
		void WxChoice6Selected(wxCommandEvent& event );
        void SendCalendar(GSM_CalendarEntry *Cal);		
		void WxChoice7Selected(wxCommandEvent& event );
        void SelectPBK();		
        void SelectCalendar();
        void SelectNote();        
        void SendToDo(GSM_ToDoEntry *ToDo); 
        void SelectToDo();
        void SendNote(GSM_NoteEntry *Not);
		void WxButton1Click1(wxCommandEvent& event);
		void WxMemo1Updated1(wxCommandEvent& event);
        void Image();		
		void WxCheckBox3Click(wxCommandEvent& event);
		void WxCheckBox2Click(wxCommandEvent& event);
		void WxChoice9Selected(wxCommandEvent& event );
		void WxButton2Click1(wxCommandEvent& event);
		void WxComboBox3Selected(wxCommandEvent& event );
		void WxEdit3Updated(wxCommandEvent& event);
		void WxMemo3Updated(wxCommandEvent& event);
		void WxChoice8Selected(wxCommandEvent& event );
		void WxButton6Click(wxCommandEvent& event);
		void RecipientsWxListCtrlSelected(wxListEvent& event);
		void RecipientsWxListCtrlItemActivated(wxListEvent& event);
		void RecipientsWxListCtrlDeselected(wxListEvent& event);
		void WxButton7Click1(wxCommandEvent& event);
        void AddEMSPart(SMS_UDH_Type Type);		
		void WxMemo4Updated(wxCommandEvent& event);
		void WxButton3Click1(wxCommandEvent& event);
		void WxCheckBox6Click(wxCommandEvent& event);
		void WxCheckBox8Click(wxCommandEvent& event);
		void WxCheckBox5Click(wxCommandEvent& event);
		void WxCheckBox7Click(wxCommandEvent& event);
		void WxCheckBox9Click(wxCommandEvent& event);
		void WxCheckBox10Click(wxCommandEvent& event);
		void WxComboBox7Updated(wxCommandEvent& event );
		void WxComboBox8Selected(wxCommandEvent& event );
        void EMS2();
		void WxButton9Click(wxCommandEvent& event);
		void WxListBox1Selected(wxCommandEvent& event);
        void SMSEditorDlg::EMSHide();		
		void WxButton5Click1(wxCommandEvent& event);
		void WxButton4Click(wxCommandEvent& event);
		void WxChoice11Selected(wxCommandEvent& event );
		void WxChoice12Selected(wxCommandEvent& event );
		void WxCheckBox1Click1(wxCommandEvent& event);
		void WxCheckBox3Click1(wxCommandEvent& event);
		void WxCheckBox4Click(wxCommandEvent& event);
		void WxCheckBox12Click(wxCommandEvent& event);
		void WxCheckBox13Click(wxCommandEvent& event);
		void WxCheckBox14Click(wxCommandEvent& event);
		void WxComboBox6Selected(wxCommandEvent& event );
		void WxComboBox6Updated(wxCommandEvent& event );
};

#endif
