//---------------------------------------------------------------------------
//
// Name:        RecipientsDlg.cpp
// Author:      Marcinello
// Created:     2007-09-30 17:43:25
// Description: RecipientsDlg class implementation
//
//---------------------------------------------------------------------------

#include "RecipientsDlg.h"
#include "shared.h"

#include "../common/misc/coding/coding.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// RecipientsDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(RecipientsDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(RecipientsDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON2,RecipientsDlg::WxButton2Click)
	EVT_BUTTON(ID_WXBUTTON1,RecipientsDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

RecipientsDlg::RecipientsDlg(wxListCtrl *List2, GSM_StateMachine *s2, GSM_Backup *Backup2, wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
     GSM_PBKEntry        *Entry;
    GSM_Backup_PBKEntry *PBKEntry;
    wchar_t             buff[400],buff2[40];
    wchar_t             Last[400],First[400];
    char                buff3[200];
    char                buff0[40];
    long                tmp,Num2=0,Num=0;
    GSM_PBKSubEntry     *SubEntry;
    time_t              DT1;
    GSM_DateTime        DT2;
    BOOLEAN             newe2,found2,Found;
    wchart              Str;   
    
    List=List2;
    Backup=Backup2;
	CreateGUIControls();
 
       Found = FALSE;
        PBKEntry = NULL;
        while(Backup->GetNext_PBK(&PBKEntry)) {
            if (PBKEntry->GetEntry()->Memory == MEM_PHONE) {
                Found = TRUE;
                break;
            }
        }
        if (!Found) ReadPBKMemory(MEM_PHONE,s2,Backup);

    PBKEntry = NULL;
    while(Backup->GetNext_PBK(&PBKEntry)) {
        Entry = PBKEntry->GetEntry();
        //find name
        Last[0] = 0;
        First[0] = 0;
        buff[0] = 0;
        SubEntry = NULL;
        while (Entry->GetNext(&SubEntry) == TRUE) {
            switch (SubEntry->GetType()) {
            case PBK_Text_Name:
                CopyUnicode(SubEntry->GetText(),buff);
                break;
            case PBK_Text_Name_First:
                CopyUnicode(SubEntry->GetText(),First);
                break;
            case PBK_Text_Name_Last:
                CopyUnicode(SubEntry->GetText(),Last);
                break;
            default:
                break;
            }
        }
        if (Last[0] != 0 || First[0] != 0) {
            CopyUnicode(Last,buff);
            buff[UnicodeLength(buff)+1] = 0;
            buff[UnicodeLength(buff)] = ' ';
            CopyUnicode(First,buff+UnicodeLength(buff));
        }

        SubEntry = NULL;
        while (Entry->GetNext(&SubEntry) == TRUE) {
            buff3[0] = 0;
            switch (SubEntry->GetType()) {
            case PBK_Text_Phone_General:
                sprintf(buff3," ");
                break;
            case PBK_Text_Phone_Mobile:
                sprintf(buff3,"mobile");
                break;
            case PBK_Text_Phone_Home:
                sprintf(buff3,"home");
                break;
            case PBK_Text_Phone_Work:
                sprintf(buff3,"work");
                break;
            case PBK_Text_Phone_Fax:
                sprintf(buff3,"fax");
                break;
            case PBK_Text_Phone_Video:
                sprintf(buff3,"video");
                break;
            default:
                break;
            }
            if (buff3[0] == 0) continue;
            tmp = WxListCtrl1->InsertItem(Num++,buff,0);
            WxListCtrl1->SetItem(tmp, 1, SubEntry->GetText());
            WxListCtrl1->SetItem(tmp, 2, buff3);
            WxListCtrl1->SetItemData(tmp, Num2);
            Num2++;
        }
    }
}

RecipientsDlg::~RecipientsDlg()
{
} 

void RecipientsDlg::CreateGUIControls()
{


	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Recipients"));
	SetIcon(wxNullIcon);
	SetSize(8,8,546,275);
	Center();
	

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Cancel"), wxPoint(443,216), wxSize(85,24), 0, wxDefaultValidator, wxT("WxButton2"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("&OK"), wxPoint(4,218), wxSize(85,23), 0, wxDefaultValidator, wxT("WxButton1"));

	WxListCtrl1 = new wxListCtrl(this, ID_WXLISTCTRL1, wxPoint(4,4), wxSize(529,204), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Number type"),wxLIST_FORMAT_LEFT,100 );
	WxListCtrl1->InsertColumn(0,wxT("Number"),wxLIST_FORMAT_LEFT,100 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	////GUI Items Creation End
	
 
}

void RecipientsDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton2Click
 */
void RecipientsDlg::WxButton2Click(wxCommandEvent& event)
{
	EndModal(wxID_CANCEL);
}

/*
 * WxButton1Click
 */
void RecipientsDlg::WxButton1Click(wxCommandEvent& event)
{
    GSM_Error                       error;
    GSM_File                        ReadSaveFile;
    int                             i=0,j;
    wchart                          x;
    long                            item,item2;
    wchart                          buf;
    GSM_FileFolderInfoListsSubEntry   *En2;
        GSM_PBKEntry        *Entry;
        GSM_Backup_PBKEntry *PBKEntry;
        wchar_t             buff[400],buff2[40];
        wchar_t             Last[400],First[400];
        char                buff3[200];
        char                buff0[40];
        long                tmp,Num2=-1,Num=0;
        GSM_PBKSubEntry     *SubEntry;
        time_t              DT1;
        GSM_DateTime        DT2;
        BOOLEAN             newe2,found2;
        wchart              Str;

    item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    while (item != -1) {
        item2 = WxListCtrl1->GetItemData(item);
    
        Num2=-1;
        PBKEntry = NULL;
        while(Backup->GetNext_PBK(&PBKEntry)) {
            Entry = PBKEntry->GetEntry();
            //find name
            Last[0] = 0;
            First[0] = 0;
            buff[0] = 0;
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Name:
                    CopyUnicode(SubEntry->GetText(),buff);
                    break;
                case PBK_Text_Name_First:
                    CopyUnicode(SubEntry->GetText(),First);
                    break;
                case PBK_Text_Name_Last:
                    CopyUnicode(SubEntry->GetText(),Last);
                    break;
                default:
                    break;
                }
            }
            if (Last[0] != 0 || First[0] != 0) {
                CopyUnicode(Last,buff);
                buff[UnicodeLength(buff)+1] = 0;
                buff[UnicodeLength(buff)] = ' ';
                CopyUnicode(First,buff+UnicodeLength(buff));
            }
    
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                buff3[0] = 0;
                switch (SubEntry->GetType()) {
                case PBK_Text_Phone_General:
               case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                case PBK_Text_Phone_Video:
                    sprintf(buff3,"video");
                    break;
                default:
                    break;
                }
                if (buff3[0] == 0) continue;

                Num2++;
                if (Num2==item2) {
                    tmp = List->InsertItem(Num++,SubEntry->GetText(),0);
                    List->SetItem(tmp, 1, buff);
                    break;
                }

            }
            if (Num2==item2) {
                break;
            }
        } 
        item = WxListCtrl1->GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    }

	EndModal(wxID_OK);
}
