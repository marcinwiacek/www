
#include "../cfg/config.h"
#include "../common/service/smsmms/gsmmsg.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#include <wx/msgdlg.h>
#include <wx/listctrl.h>
#include <wx/listbox.h>
#include <wx/combobox.h>
#include <wx/mediactrl.h>
#include <wx/textctrl.h>
#include <wx/sizer.h>
#include <wx/image.h>
#include <wx/button.h>
#include <wx/filedlg.h>
#include <wx/progdlg.h>

BOOLEAN PrintError (GSM_Error error)
{
    unsigned char buffer[2000];

    if (error.Code == GSM_ERR_NONE) return FALSE;
    sprintf((char *)buffer,"%s",GSM_GetErrorInfo(error));
    wxMessageBox(buffer,
            wxT("Error"),
            wxICON_WARNING | wxOK);
    return TRUE;
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
    switch (DayOfWeek(Year,Month,Day)) {
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
        case 7: return "Sun";
        default:return "";
    }
}

void PrintDT(GSM_DateTime *DT, char *Buffer)
{
    GSM_DateTime    DT2;
    time_t          One,Two;
    int             Days;

    GSM_GetCurrentDateTime(&DT2);
    DT2.Hour = 23;
    DT2.Minute = 59;
    DT2.Second = 59;
    One=GSMDateTime2TimeT(DT);
    Two=GSMDateTime2TimeT(&DT2);
    Days = (Two - One) / (60*60*24);

    if (Days==0) {
        sprintf(Buffer, "today %02i:%02i:%02i",
            DT->Hour,
            DT->Minute,
            DT->Second);
    } else if (Days==1) {
        sprintf(Buffer, "yesterday %02i:%02i:%02i",
            DT->Hour,
            DT->Minute,
            DT->Second);
    } else if (Days>0) {    
        sprintf(Buffer, "%s %02i-%02i-%04i %02i:%02i:%02i (%i days ago)",
            DayOfWeekStr(
                    DT->Year,
                    DT->Month,
                    DT->Day),
            DT->Day,
            DT->Month,
            DT->Year,
            DT->Hour,
            DT->Minute,
            DT->Second,
            Days);
    } else {
        sprintf(Buffer, "%s %02i-%02i-%04i %02i:%02i:%02i",
            DayOfWeekStr(
                    DT->Year,
                    DT->Month,
                    DT->Day),
            DT->Day,
            DT->Month,
            DT->Year,
            DT->Hour,
            DT->Minute,
            DT->Second);
    }
}

int ViewMMSFile(GSM_File *File, GSM_SMSMMSDecodedEntry *Decoded, wxListCtrl *List, wxComboBox *FilesList, wxListBox *NumbersList, wxBoxSizer *Sizer, wxPanel *Panel)
{
	GSM_SMSMMSDecodedSubEntry  *SubDecoded;
	GSM_Error                   error;
    long                        tmp,EntryNum=0,NumbersNum=0;
    wchar_t                     Buffer[200];
	char                        buff[200];
    BOOLEAN                     Found,AddNum;
    wchart                      Name;
    int                         FileNum=-1,FileNum2=1;
    char                        X[1000];

    if (List!=NULL) List->DeleteAllItems();
    FilesList->Clear();

    if (File != NULL) {
        if (UnicodeLength(File->Info.ID.data())!=0 && List!=NULL) {
            tmp = List->InsertItem(EntryNum++, "ID", 0);
            List->SetItem(tmp, 1, File->Info.ID.data());
        }
    }

    NumbersList->Clear();
    
    SubDecoded = NULL;
    while (Decoded->GetNext(&SubDecoded)) {
        Found = false;
        AddNum=false;
        switch (SubDecoded->Type) {
        case MSG_MMSSMS_Address_Phone_Source:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "From (phone)", 0); Found = true;
            AddNum = true;
            break;
    	case MSG_MMS_Address_Unknown_Source:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "From", 0); Found = true;
            AddNum = true;
            break;
        case MSG_MMS_Address_Phone_Destination:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "To (phone)", 0); Found = true;
            break;
        case MSG_MMS_Address_Unknown_Destination:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "To", 0); Found = true;
            break;
        case MSG_MMS_Address_Phone_CC:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "CC (phone)", 0); Found = true;
            break;
        case MSG_MMS_Address_Unknown_CC:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "CC", 0); Found = true;
            break;
        case MSG_MMS_Address_Phone_BCC:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "BCC (phone)", 0); Found = true;
            break;
        case MSG_MMS_Address_Unknown_BCC:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "BCC", 0); Found = true;
            break;
        case MSG_Unknown:
            if (List != NULL) tmp = List->InsertItem(EntryNum++, "<Unknown content>", 0); Found = true;
            break;
        }
        if (Found) {
            memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
            if (List != NULL) List->SetItem(tmp, 1, Buffer);
            if (AddNum) {
                NumbersList->Append(Buffer);
                NumbersNum++;
            }
            continue;
        }
        if (List!=NULL) {
            switch (SubDecoded->Type) {
            case MSG_MMS_Text_TransactionID:
                tmp = List->InsertItem(EntryNum++, "Transaction ID", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_Subject:
                tmp = List->InsertItem(EntryNum++, "Subject", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_ContentLocation:
                tmp = List->InsertItem(EntryNum++, "Content location", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_ContentType:
                tmp = List->InsertItem(EntryNum++, "Content type", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_MessageType:
                tmp = List->InsertItem(EntryNum++, "Message type", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_MessageID:
                tmp = List->InsertItem(EntryNum++, "Message ID", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_MessageClass:
                tmp = List->InsertItem(EntryNum++, "Message class", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_Priority:
                tmp = List->InsertItem(EntryNum++, "Priority", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_Version:
                tmp = List->InsertItem(EntryNum++, "MMS version", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_Response_Status:
                tmp = List->InsertItem(EntryNum++, "Response status", 0); Found = TRUE;
                break;
            case MSG_MMS_Text_Status:
                tmp = List->InsertItem(EntryNum++, "Status", 0); Found = TRUE;
                break;
            }
            if (Found) {
                List->SetItem(tmp, 1, SubDecoded->Text.data());
                continue;
            }
            switch (SubDecoded->Type) {
            case MSG_MMS_Bool_Report:
                tmp = List->InsertItem(EntryNum++, "Delivery report", 0); Found = TRUE;
                break;
            case MSG_MMS_Bool_Read_Reply:
                tmp = List->InsertItem(EntryNum++, "Read reply", 0); Found = TRUE;
                break;
            case MSG_MMS_Bool_Report_Allowed:
                tmp = List->InsertItem(EntryNum++, "Report allowed", 0); Found = TRUE;
                break;
            }
            if (Found) {
                if (SubDecoded->Bool) {
                    List->SetItem(tmp, 1, "yes");
                } else {
                    List->SetItem(tmp, 1, "no");
                }
                continue;
            }
        }
        switch (SubDecoded->Type) {
        case MSG_MMS_DT_DateTime:
            if (List!=NULL) {
                tmp = List->InsertItem(EntryNum++, "Sent", 0);
                PrintDT(&SubDecoded->DT, buff);
                List->SetItem(tmp, 1, buff);
            }
            break;
    	case MSG_MMS_DT_Expiry:
            if (List!=NULL) {
                tmp = List->InsertItem(EntryNum++, "Expiry", 0);
                List->SetItem(tmp, 1, SubDecoded->Text.data());
            }
            break;
        case MSG_MMSSMS_File:
            if (List!=NULL) {
                tmp = List->InsertItem(EntryNum++, "File", 0);
                tmp = List->InsertItem(EntryNum++, "  Content type", 0);
                sprintf(X,"%s",UnicodeToStringReturn(SubDecoded->Text.data()));
                sprintf(X+strlen(X),"%s",UnicodeToStringReturn(SubDecoded->Text2.data()));
                List->SetItem(tmp, 1, X);            
    
                if (SubDecoded->Header.length()!=0) {
                    tmp = List->InsertItem(EntryNum++, "  Header", 0);
                    List->SetItem(tmp, 1, SubDecoded->Header.data());
                }
                tmp = List->InsertItem(EntryNum++, "  Size", 0);
                sprintf(buff,"%i bytes",SubDecoded->File.Info.Size);
                List->SetItem(tmp, 1, buff);
            }
            
            Name.clear();
            Name.append(SubDecoded->File.Info.Name.data(),UnicodeLength(SubDecoded->File.Info.Name.data()));
            Name.push_back(' ');
            Name.push_back('(');
            Name.append(SubDecoded->Text.data(),UnicodeLength((wchar_t *)SubDecoded->Text.data()));
            Name.push_back(')');
            FilesList->Append(Name.data());

            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/plain"))) {
                if (FileNum==-1) FileNum=FileNum2;
            }
            FileNum2++;
            break;
        }
    }
    if (FileNum==-1 && FileNum2>1) FileNum=1;
    if (NumbersNum==0) NumbersNum++;
    FilesList->Enable(true);
    if (FileNum2<3) FilesList->Enable(false);
    NumbersList->SetSizeHints(500,NumbersNum*15);
    Panel->SetSizeHints(900,NumbersNum*15+10);
    Sizer->Layout();    
    return FileNum;
}

void MMSSelect(int Num, GSM_SMSMMSDecodedEntry *Decoded, wxMediaCtrl *MediaCtrl1, wxTextCtrl *Memo1, wxBoxSizer *BoxSizer3, wxButton *Button) 
{
    int                         num5=0;
    GSM_Error                   error,preverror;
    GSM_MMSEntry                 Entry2;
	GSM_SMSMMSDecodedSubEntry  *SubDecoded;
	wxImage                     newImage ;
	wchart                      UTF8Text;

    Button->Enable(true);

    SubDecoded = NULL;
    while (Decoded->GetNext(&SubDecoded)) {
        if (SubDecoded->Type !=  MSG_MMSSMS_File) continue;
        num5++;
        if (num5-1!=Num) continue;

        if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/plain")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vCard")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vNote")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vTodo")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vImelody")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vCalendar")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("application/smil"))) {

            MediaCtrl1->Show(false);
            Memo1->Show(true);
            BoxSizer3->Layout();

            Memo1->Clear();
            if (UnicodeCaseStr(SubDecoded->Text2.data(),StringToUnicodeReturn("charset=utf8"))!=NULL) {
                UTF8ToUnicode(SubDecoded->File.Buffer.data(), &UTF8Text, SubDecoded->File.Buffer.size());
                Memo1->AppendText(UTF8Text.data());
            } else {
                Memo1->AppendText(SubDecoded->File.Buffer.data());
            }
            break;
        }
        if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/jpeg")) ||
             !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("audio/amr")) ||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/gif"))||
            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/bmp"))) {

            MediaCtrl1->Show(true);
            Memo1->Show(false);
            BoxSizer3->Layout();

            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("audio/amr"))) {
                SubDecoded->File.SaveToDisk("tmpbitmap.amr");
                MediaCtrl1->Load("tmpbitmap.amr");
                MediaCtrl1->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_DEFAULT);
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/jpeg"))) {
                SubDecoded->File.SaveToDisk("tmpbitmap.jpg");
                MediaCtrl1->Load("tmpbitmap.jpg");
                MediaCtrl1->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_NONE);
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/bmp"))) {
                SubDecoded->File.SaveToDisk("tmpbitmap.bmp");
                MediaCtrl1->Load("tmpbitmap.bmp");
                MediaCtrl1->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_NONE);
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/gif"))) {
                SubDecoded->File.SaveToDisk("tmpbitmap.gif");
                MediaCtrl1->Load("tmpbitmap.gif");
                MediaCtrl1->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_NONE);
            }

            break;
        }
            MediaCtrl1->Show(false);
            Memo1->Show(false);
            BoxSizer3->Layout();
    }
}

void SaveMMSFile(GSM_SMSMMSDecodedEntry *Decoded, wxFileDialog *WxSaveFileDialog1, int Num)
{
    int                         num5=0;
	GSM_SMSMMSDecodedSubEntry  *SubDecoded;

    SubDecoded = NULL;
    while (Decoded->GetNext(&SubDecoded)) {
        if (SubDecoded->Type !=  MSG_MMSSMS_File) continue;
        num5++;
        if (num5-1!=Num) continue;

        WxSaveFileDialog1->SetFilename(SubDecoded->File.Info.Name.data());
        if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;

//        if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/plain")) ||
//            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vCard")) ||
//            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/x-vCalendar")) ||
//            !wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("application/smil"))) {
//            if (UnicodeCaseStr(SubDecoded->Text2.data(),StringToUnicodeReturn("charset=utf8"))!=NULL) {
//                if (wxMessageBox("Do you want to save decoded file content ?",
//                        wxT("Question"),
//                        wxICON_QUESTION | wxYES_NO) == wxYES) {
//                    UTF8ToUnicode(SubDecoded->File.Buffer.data(), &UTF8Text, SubDecoded->File.Buffer.size());
//                    SubDecoded->File.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
//                }
//            }
//        }

        SubDecoded->File.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
        break;
    }
}

void DecodePBKSubEntry(GSM_PBKSubEntry *SubEntry, char *type, wchar_t *Value, BOOLEAN *FirstNum)
{
    char                    buff[100];
    time_t                  DT1;
    GSM_DateTime            DT2;

    switch (SubEntry->GetType()) {
    case PBK_Text_Phone_General:
        sprintf(type,"General number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Phone_Mobile:
        sprintf(type,"Mobile number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Phone_Home:
        sprintf(type,"Home number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Phone_Work:
        sprintf(type,"Work number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Phone_Fax:
        sprintf(type,"Fax number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Phone_Video:
        sprintf(type,"Video number");
        if ((*FirstNum)) sprintf(type+strlen(type)," (default)");
        (*FirstNum)=false;
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Postal:
        sprintf(type,"Postal address");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
	case PBK_Text_Postal_Street:
        sprintf(type,"Street");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
	case PBK_Text_Postal_City:
        sprintf(type,"City");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
	case PBK_Text_Postal_State:
        sprintf(type,"State");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
	case PBK_Text_Postal_ZIP_Code:
        sprintf(type,"ZIP code");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
	case PBK_Text_Postal_Country:
        sprintf(type,"Country");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Email:
        sprintf(type,"Email address");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_URL:
        sprintf(type,"URL link");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_UserID:
        sprintf(type,"User ID");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Note:
        sprintf(type,"Note");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Name:
        sprintf(type,"Name");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Name_First:
        sprintf(type,"First name");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Name_Last:
        sprintf(type,"Last name");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_PTT:
        sprintf(type,"Push To Talk address");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Bool_PTT_Subscribed:
        sprintf(type,"Push To Talk subscribed");
        if (SubEntry->BoolValue) {
            sprintf(buff,"yes");
        } else {
            sprintf(buff,"no");
        }
        StringToUnicode(buff,Value);
        break;
    case PBK_DateTime_Call_Length:
        sprintf(type,"Date & time");
        PrintDT(SubEntry->GetDateTime(), buff);
        if (SubEntry->CallLength!=-1) {
            DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
            DT1 += SubEntry->CallLength;
            memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
            sprintf(buff+strlen(buff)," - ");
            PrintDT(&DT2, buff+strlen(buff));
            sprintf(buff+strlen(buff)," (%02i:%02i:%02i)",
                    SubEntry->CallLength/(60*60),
                    SubEntry->CallLength/60,
                    SubEntry->CallLength%60);
        }
        StringToUnicode(buff,Value);
        break;
    case PBK_DateTime_Birthday:
        sprintf(type,"Birthday");
        PrintDT(SubEntry->GetDateTime(), buff);
        StringToUnicode(buff,Value);
        break;
    case PBK_ID_Caller_Group:
        sprintf(type,"Caller group ID");
        sprintf(buff,"%i",SubEntry->LongValue);
        StringToUnicode(buff,Value);
        break;
    case PBK_ID_Picture:
        sprintf(type,"Picture ID");
        sprintf(buff,"%i",SubEntry->LongValue);
        StringToUnicode(buff,Value);
        break;
    case PBK_ID_Ringtone:
        sprintf(type,"Ringtone ID");
        sprintf(buff,"%i",SubEntry->LongValue);
        StringToUnicode(buff,Value);
        break;
    case PBK_ID_Video_File:
        sprintf(type,"Video file ID");
        sprintf(buff,"%i",SubEntry->LongValue);
        StringToUnicode(buff,Value);
        break;
    case PBK_Text_Name_Formal:
        sprintf(type,"Formal name");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Video_Sharing_SIP:
        sprintf(type,"Video SIP");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Job_Title:
        sprintf(type,"Job title");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Company_Name:
        sprintf(type,"Company name");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    case PBK_Text_Nick_Name:
        sprintf(type,"NickName");
        CopyUnicode(SubEntry->GetText(),Value);
        break;
    default:
        break;
    }
    if (SubEntry->VoiceTag!=-1) sprintf(type+strlen(type)," (voice tag ID %i)",SubEntry->VoiceTag);
}

void DecodeCalendarSubEntry(GSM_CalendarSubEntry *SubEntry, char *type, wchart *Value, BOOLEAN Birthday)
{
    char buff[200];

    Value->clear();
    switch (SubEntry->GetType()) {
    case Calendar_Text_Text:
        sprintf(type,"Text");
        Value->append(SubEntry->GetText());
        break;
    case Calendar_Text_Phone:
        sprintf(type,"Phone number");
        Value->append(SubEntry->GetText());
        break;
    case Calendar_Text_Location:
        sprintf(type,"Location");
        Value->append(SubEntry->GetText());
        break;
    case Calendar_DateTime_Start:
        sprintf(type,"Start");
        PrintDT(SubEntry->GetDateTime(), buff);
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_DateTime_End:
        sprintf(type,"End");
        PrintDT(SubEntry->GetDateTime(), buff);
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_DateTime_SilentAlarm:
    case Calendar_DateTime_ToneAlarm:
        if (SubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
            sprintf(type,"Silent alarm");
        } else {
            sprintf(type,"Tone alarm");
        }
        if (Birthday) {
            sprintf(buff,"%02i:%02i:%02i %02i-%02i in each year",
                    SubEntry->GetDateTime()->Hour,
                    SubEntry->GetDateTime()->Minute,
                    SubEntry->GetDateTime()->Second,
                    SubEntry->GetDateTime()->Day,
                    SubEntry->GetDateTime()->Month);
        } else {
            PrintDT(SubEntry->GetDateTime(), buff);
        }
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_DateTime_End_Repeat:
        sprintf(type,"Repeat end");
        PrintDT(SubEntry->GetDateTime(), buff);
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_Int_Repeat_Frequency:
        sprintf(type,"Repeat frequency");
        sprintf(buff,"%i",SubEntry->GetInt());
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_Int_Repeat_DayOfWeek:
        sprintf(type,"Repeat day of week");
        sprintf(buff,"%i",SubEntry->GetInt());
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_Int_Repeat_Day:
        sprintf(type,"Repeat day of month");
        sprintf(buff,"%i",SubEntry->GetInt());
        Value->append(StringToUnicodeReturn(buff));
        break;
    case Calendar_Int_Repeat_Month:
        sprintf(type,"Repeat month");
        sprintf(buff,"%i",SubEntry->GetInt());
        Value->append(StringToUnicodeReturn(buff));
        break;
    }
}

void DisplayCalendar2(GSM_CalendarEntry *CalEntry2, wxListCtrl *CalendarDownWxListCtrl)
{
    wchart                  Text;
    GSM_CalendarSubEntry    *SubEntry;
    long                    EntryNum = 0, tmp;
    char                    buff[200];
    int                     RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;
    wchart                  Buff;
        
    tmp = CalendarDownWxListCtrl->InsertItem(EntryNum++, "Note type", 0);

    switch(CalEntry2->Type) {
    case Calendar_Type_Meeting:
        CalendarDownWxListCtrl->SetItem(tmp, 1, "meeting");
        break;
    case Calendar_Type_Memo:
        CalendarDownWxListCtrl->SetItem(tmp, 1, "memo");
        break;
    case Calendar_Type_Call:
        CalendarDownWxListCtrl->SetItem(tmp, 1, "phone call");
        break;
    case Calendar_Type_Birthday:
        CalendarDownWxListCtrl->SetItem(tmp, 1, "birthday");
        break;
    case Calendar_Type_Reminder:
        CalendarDownWxListCtrl->SetItem(tmp, 1, "reminder");
        break;
    }

    RepeatEach      = -1;
    RepeatDay       = -1;
    RepeatMonth     = -1;
    RepeatDOW       = -1;
    SubEntry        = NULL;
    while (CalEntry2->GetNext(&SubEntry) == TRUE) {
        switch (SubEntry->GetType()) {
        case Calendar_Int_Repeat_Frequency:
            RepeatEach = SubEntry->GetInt();
            break;
        case Calendar_Int_Repeat_DayOfWeek:
            RepeatDOW = SubEntry->GetInt();
            break;
        case Calendar_Int_Repeat_Day:
            RepeatDay = SubEntry->GetInt();
            break;
        case Calendar_Int_Repeat_Month:
            RepeatMonth = SubEntry->GetInt();
            break;
        default:
            if (CalEntry2->Type == Calendar_Type_Birthday) {
                DecodeCalendarSubEntry(SubEntry, buff, &Buff, TRUE);
            } else {
                DecodeCalendarSubEntry(SubEntry, buff, &Buff, FALSE);
            }
            tmp = CalendarDownWxListCtrl->InsertItem(EntryNum++, buff, 0);
            CalendarDownWxListCtrl->SetItemData(tmp, 0);
            CalendarDownWxListCtrl->SetItem(tmp, 1, Buff.data());
            break;
        }
    }

    if (RepeatEach != -1 || RepeatDOW != -1 ||
        RepeatDay != -1 || RepeatMonth != -1) {
        tmp = CalendarDownWxListCtrl->InsertItem(EntryNum++, "Repeat", 0);
        CalendarDownWxListCtrl->SetItemData(tmp, 0);
        buff[0] = 0;
        if (RepeatEach == 1) sprintf(buff+strlen(buff),"each ");
        if (RepeatEach == 2) sprintf(buff+strlen(buff),"each second ");
        if (RepeatDOW != -1) {
            switch (RepeatDOW) {
                case 1: sprintf(buff+strlen(buff),"Monday ");      break;
                case 2: sprintf(buff+strlen(buff),"Tuesday ");     break;
                case 3: sprintf(buff+strlen(buff),"Wednesday ");   break;
                case 4: sprintf(buff+strlen(buff),"Thursday ");    break;
                case 5: sprintf(buff+strlen(buff),"Friday ");      break;
                case 6: sprintf(buff+strlen(buff),"Saturday ");    break;
                case 7: sprintf(buff+strlen(buff),"Sunday ");      break;
                default:sprintf(buff+strlen(buff)," ");
            }
        }
        if (RepeatDay != -1) {
            sprintf(buff+strlen(buff),"%i ",RepeatDay);
            if (RepeatMonth != -1) {
                switch (RepeatMonth) {
                    case  1: sprintf(buff+strlen(buff),"January ");    break;
                    case  2: sprintf(buff+strlen(buff),"February ");   break;
                    case  3: sprintf(buff+strlen(buff),"March ");      break;
                    case  4: sprintf(buff+strlen(buff),"April ");      break;
                    case  5: sprintf(buff+strlen(buff),"May ");        break;
                    case  6: sprintf(buff+strlen(buff),"June ");       break;
                    case  7: sprintf(buff+strlen(buff),"July ");       break;
                    case  8: sprintf(buff+strlen(buff),"August ");     break;
                    case  9: sprintf(buff+strlen(buff),"September ");  break;
                    case 10: sprintf(buff+strlen(buff),"October ");    break;
                    case 11: sprintf(buff+strlen(buff),"November ");   break;
                    case 12: sprintf(buff+strlen(buff),"December ");   break;
                    default:sprintf(buff+strlen(buff)," ");
                }
            } else {
                sprintf(buff+strlen(buff),"month day ");
            }
        }
        CalendarDownWxListCtrl->SetItem(tmp, 1, buff);
    }
}

void DisplayNote2(GSM_NoteEntry *NoteEntry2, wxListCtrl *CalendarDownWxListCtrl)
{
    long                    EntryNum = 0, tmp;

    tmp = CalendarDownWxListCtrl->InsertItem(EntryNum++, "Text", 0);        
    CalendarDownWxListCtrl->SetItem(tmp, 1, NoteEntry2->Text.data());
}

void DecodeToDoSubEntry(GSM_ToDoSubEntry *SubEntry, char *type, wchart *Value)
{
    char buff3[100];

    Value->clear();
    switch (SubEntry->Type) {
    case ToDo_Text_Text:
        sprintf(type,"Text");
        Value->append(SubEntry->Text.data());
        break;
    case ToDo_Priority:
        sprintf(type,"Priority");
        switch (SubEntry->Priority) {
        case GSM_Priority_High   : Value->append(StringToUnicodeReturn("high"));   break;
        case GSM_Priority_Medium : Value->append(StringToUnicodeReturn("medium")); break;
        case GSM_Priority_Low    : Value->append(StringToUnicodeReturn("low"));    break;
        }
        break;
    case ToDo_Bool_Completed:
        sprintf(type, "Completed");
        Value->append(StringToUnicodeReturn("yes"));
        break;
    case ToDo_DateTime_End:
        sprintf(type,"End");
        PrintDT(&SubEntry->DT, buff3);
        Value->append(StringToUnicodeReturn(buff3));
        break;
    case ToDo_DateTime_ToneAlarm:
        sprintf(type,"Alarm with tone");
        PrintDT(&SubEntry->DT, buff3);
        Value->append(StringToUnicodeReturn(buff3));
        break;
    case ToDo_DateTime_SilentAlarm:
        sprintf(type,"Silent alarm");
        PrintDT(&SubEntry->DT, buff3);
        Value->append(StringToUnicodeReturn(buff3));
    }
}

void ReadPBKMemory(GSM_MemoryType Mem, GSM_StateMachine *s, GSM_Backup *Backup)
{
    char                buff[100];
    GSM_Error           error;
    GSM_PBKStatus       Status;
    int                 i = 0,Pos=1;
    GSM_PBKEntry        *Entry;
    BOOLEAN             newe = TRUE;
    bool                skip;
    wxProgressDialog    *Dialog;
    wxString            Name;

    switch (Mem) {
    case MEM_PHONE:             Name = "phone phonebook";   break;
    case MEM_SIM:               Name = "SIM phonebook";     break;
    case MEM_SIM_OWN:           Name = "own numbers";       break;
    case MEM_PHONE_DIALLED:     Name = "dialled calls";     break;
    case MEM_PHONE_RECEIVED:    Name = "received calls";    break;
    case MEM_PHONE_MISSED:      Name="missed calls";        break;
    case MEM_PHONE_SMS_LOGS:    Name="sent SMS list";       break;
    default: break;
    }

    switch (Mem) {
    case MEM_PHONE:
    case MEM_SIM:
    case MEM_SIM_OWN:
        Status.Memory = Mem;
        error = s->Phones->Current->GetPBKStatus(&Status);

        Dialog = new wxProgressDialog("Reading "+Name,"" , Status.Used, NULL, wxPD_APP_MODAL | wxPD_AUTO_HIDE | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
        while (i!=Status.Used) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            }
            Entry->Location= Pos;
            Entry->Memory = Status.Memory;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            newe = true;
            i++;
            sprintf(buff,"%i %% (%i/%i)",i*100/Status.Used,i,Status.Used);
            Dialog->Update((int)i,buff,&skip);
            Backup->Add_PBK(Entry);
        }
        break;
    default:
        Dialog = new wxProgressDialog("Reading "+Name, "", 100, NULL, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
        error.Code = GSM_ERR_NONE;
        while (error.Code != GSM_ERR_EMPTY) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            } else {
                Entry->ClearAll();
            }
            Entry->Location= Pos;
            Entry->Memory=Mem;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            sprintf(buff,"%i",Pos);
            Dialog->Pulse(buff,&skip);
            newe=true;
            Backup->Add_PBK(Entry);
        }
    }
    delete Dialog;
}

