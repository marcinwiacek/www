--
-- PostgreSQL database dump
--

-- Started on 2007-11-11 21:45:02

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- TOC entry 2 (class 2615 OID 16406)
-- Name: daemon; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA daemon;


--
-- TOC entry 1624 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- TOC entry 271 (class 2612 OID 16386)
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = daemon, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1278 (class 1259 OID 16581)
-- Dependencies: 1614 1615 1616 1617 1618 1619 2
-- Name: inbox_decoded; Type: TABLE; Schema: daemon; Owner: -; Tablespace: 
--

CREATE TABLE inbox_decoded (
    "type" smallint,
    id bigint,
    seq_num smallint,
    content text,
    type2 text,
    filename text,
    bold boolean DEFAULT false,
    italic boolean DEFAULT false,
    underline boolean DEFAULT false,
    strikethrough boolean DEFAULT false,
    small boolean DEFAULT false,
    "large" boolean DEFAULT false,
    dt timestamp with time zone
);


--
-- TOC entry 1279 (class 1259 OID 16589)
-- Dependencies: 2
-- Name: inbox_decoded_id; Type: SEQUENCE; Schema: daemon; Owner: -
--

CREATE SEQUENCE inbox_decoded_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 1280 (class 1259 OID 16600)
-- Dependencies: 1620 2
-- Name: inbox_mms; Type: TABLE; Schema: daemon; Owner: -; Tablespace: 
--

CREATE TABLE inbox_mms (
    id bigint,
    content text,
    processed boolean DEFAULT false
);


--
-- TOC entry 1281 (class 1259 OID 16605)
-- Dependencies: 2
-- Name: inbox_mms_id; Type: SEQUENCE; Schema: daemon; Owner: -
--

CREATE SEQUENCE inbox_mms_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 1277 (class 1259 OID 16412)
-- Dependencies: 2
-- Name: inbox_sms_id; Type: SEQUENCE; Schema: daemon; Owner: -
--

CREATE SEQUENCE inbox_sms_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 1276 (class 1259 OID 16407)
-- Dependencies: 1612 1613 2
-- Name: inbox_sms; Type: TABLE; Schema: daemon; Owner: -; Tablespace: 
--

CREATE TABLE inbox_sms (
    tpudl smallint,
    tpdcs smallint,
    tpstatus smallint,
    tpvp smallint,
    firstbyte smallint,
    tpmr smallint,
    tppid smallint,
    id bigint DEFAULT nextval('inbox_sms_id'::regclass),
    userdata text,
    smscnumber text,
    datetime text,
    smsctime text,
    processed boolean DEFAULT false,
    phonenumbers text
);


--
-- TOC entry 1625 (class 0 OID 0)
-- Dependencies: 5
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2007-11-11 21:45:02

--
-- PostgreSQL database dump complete
--

