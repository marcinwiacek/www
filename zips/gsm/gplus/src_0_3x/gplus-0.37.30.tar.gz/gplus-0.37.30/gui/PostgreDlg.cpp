//---------------------------------------------------------------------------
//
// Name:        PostgreDlg.cpp
// Author:      Marcinello
// Created:     2007-10-29 23:14:13
// Description: PostgreDlg class implementation
//
//---------------------------------------------------------------------------

#include "PostgreDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// PostgreDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(PostgreDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(PostgreDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,PostgreDlg::WxButton1Click)
	EVT_BUTTON(ID_WXBUTTON2,PostgreDlg::WxButton2Click)
END_EVENT_TABLE()
////Event Table End

PostgreDlg::PostgreDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

PostgreDlg::~PostgreDlg()
{
} 

void PostgreDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("PostgreSQL database details"));
	SetIcon(wxNullIcon);
	SetSize(8,8,289,207);
	Center();
	

	WxStaticText5 = new wxStaticText(this, ID_WXSTATICTEXT5, wxT("Database"), wxPoint(4,70), wxDefaultSize, 0, wxT("WxStaticText5"));

	WxStaticText4 = new wxStaticText(this, ID_WXSTATICTEXT4, wxT("Port (optional)"), wxPoint(4,43), wxDefaultSize, 0, wxT("WxStaticText4"));

	WxStaticText3 = new wxStaticText(this, ID_WXSTATICTEXT3, wxT("IP address"), wxPoint(4,20), wxDefaultSize, 0, wxT("WxStaticText3"));

	WxStaticText2 = new wxStaticText(this, ID_WXSTATICTEXT2, wxT("Password"), wxPoint(5,124), wxDefaultSize, 0, wxT("WxStaticText2"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("User"), wxPoint(5,99), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, wxT(""), wxPoint(77,18), wxSize(194,19), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxEdit2 = new wxTextCtrl(this, ID_WXEDIT2, wxT(""), wxPoint(77,42), wxSize(194,19), 0, wxDefaultValidator, wxT("WxEdit2"));

	WxEdit3 = new wxTextCtrl(this, ID_WXEDIT3, wxT(""), wxPoint(77,67), wxSize(195,20), 0, wxDefaultValidator, wxT("WxEdit3"));

	WxEdit4 = new wxTextCtrl(this, ID_WXEDIT4, wxT(""), wxPoint(77,94), wxSize(196,20), 0, wxDefaultValidator, wxT("WxEdit4"));

	WxEdit5 = new wxTextCtrl(this, ID_WXEDIT5, wxT(""), wxPoint(77,119), wxSize(197,21), wxTE_PASSWORD, wxDefaultValidator, wxT("WxEdit5"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("OK"), wxPoint(5,155), wxSize(66,21), 0, wxDefaultValidator, wxT("WxButton1"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Cancel"), wxPoint(213,156), wxSize(63,21), 0, wxDefaultValidator, wxT("WxButton2"));
	////GUI Items Creation End
}

void PostgreDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void PostgreDlg::WxButton1Click(wxCommandEvent& event)
{
    EndModal(wxID_OK);
}

/*
 * WxButton2Click
 */
void PostgreDlg::WxButton2Click(wxCommandEvent& event)
{
    EndModal(wxID_CANCEL);
}
