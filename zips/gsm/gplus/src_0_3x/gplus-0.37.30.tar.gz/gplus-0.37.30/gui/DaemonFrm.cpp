//---------------------------------------------------------------------------
//
// Name:        DaemonFrm.cpp
// Author:      Marcinello
// Created:     2007-11-01 22:50:00
// Description: DaemonFrm class implementation
//
//---------------------------------------------------------------------------

#include "DaemonFrm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// DaemonFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(DaemonFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(DaemonFrm::OnClose)
END_EVENT_TABLE()
////Event Table End

DaemonFrm::DaemonFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

DaemonFrm::~DaemonFrm()
{
}

void DaemonFrm::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxPanel1 = new wxPanel(this, ID_WXPANEL1, wxPoint(0,0), wxSize(320,109));

	WxCheckBox1 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX1, wxT("Add SMS from inbox to database and delete from phone"), wxPoint(7,11), wxSize(304,18), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxCheckBox2 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX2, wxT("Add MMS from inbox to database and delete from phone"), wxPoint(7,31), wxSize(305,16), 0, wxDefaultValidator, wxT("WxCheckBox2"));

	WxCheckBox3 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX3, wxT("Put decoded SMS/MMS content to database too"), wxPoint(7,49), wxSize(305,17), 0, wxDefaultValidator, wxT("WxCheckBox3"));

	WxButton1 = new wxButton(WxPanel1, ID_WXBUTTON1, wxT("Start"), wxPoint(101,77), wxSize(99,24), 0, wxDefaultValidator, wxT("WxButton1"));

	SetTitle(wxT("Daemon"));
	SetIcon(wxNullIcon);
	SetSize(8,8,328,136);
	Center();
	
	////GUI Items Creation End
}

void DaemonFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}
