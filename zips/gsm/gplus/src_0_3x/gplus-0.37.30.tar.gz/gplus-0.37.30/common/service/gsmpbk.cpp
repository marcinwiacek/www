/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include "../../cfg/config.h"
#include "gsmpbk.h"
#include "../misc/coding/coding.h"

wchar_t	*GSM_PBKSubEntry::GetText()
{
	if (Text==NULL) return 0x00;
	return Text;
}

GSM_PBKSubEntry::GSM_PBKSubEntry()
{
	SMSLists.clear();
	BoolValue = false;
	CallLength = -1;
	VoiceTag = -1;
	Type   = PBK_Not_Assigned;
	Text   = NULL;
	Next   = NULL;
}

GSM_PBKSubEntry::~GSM_PBKSubEntry()
{
	delete(Next);
	free(Text);
}

GSM_PBK_SubEntryType GSM_PBKSubEntry::GetType()
{
	return Type;
}

GSM_Error GSM_PBKSubEntry::SetToLong(GSM_PBK_SubEntryType Typ, long long2)
{
	Type = Typ;

	LongValue = long2;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKSubEntry::SetToBool(GSM_PBK_SubEntryType Typ, bool bool2)
{
	Type = Typ;

	BoolValue = bool2;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKSubEntry::SetToText(GSM_PBK_SubEntryType Typ, wchar_t *Txt)
{
	int len = (UnicodeLength(Txt)+1)*sizeof(wchar_t);

	if (Typ < PBK_Text_Phone_General || Typ > PBK_Text_Job_Title) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

	Type = Typ;

	Text = (wchar_t *)realloc(Text,len);
	memcpy(Text,Txt,len);

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_PBKSubEntry *GSM_PBKSubEntry::GetNext()
{
	return Next;
}

void GSM_PBKSubEntry::SetNext(GSM_PBKSubEntry *Nxt)
{
	Next = Nxt;
}

GSM_Error GSM_PBKSubEntry::SetToDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2)
{
	if (Typ != PBK_DateTime_Call_Length && Typ != PBK_DateTime_Birthday) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
	Type = Typ;

	memcpy(&DT,&DT2,sizeof(GSM_DateTime));
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_DateTime *GSM_PBKSubEntry::GetDateTime()
{
	return &DT;
}

/* ------------------------------------------------------------------------ */

GSM_PBKEntry::GSM_PBKEntry()
{
	Entries = NULL;
}


GSM_PBKEntry::~GSM_PBKEntry()
{
	delete(Entries);
}

BOOLEAN GSM_PBKEntry::GetNext(GSM_PBKSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

GSM_Error GSM_PBKEntry::AddText(GSM_PBK_SubEntryType Typ, wchar_t *Txt)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	error = Entry->SetToText(Typ, Txt);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) {
			Entry2 = Entry2->GetNext();
		}
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddLong(GSM_PBK_SubEntryType Typ, long long2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	Entry->SetToLong(Typ, long2);

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddBool(GSM_PBK_SubEntryType Typ, bool bool2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	Entry->SetToBool(Typ, bool2);

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	error = Entry->SetToDateTime(Typ, DT2);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_PBKEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

//todo: address
GSM_Error GSM_PBKEntry::EncodeToVCARD(unsignedstring *dest, GSM_VCARDType Type)
{
	wchart		Buff;
	GSM_PBKSubEntry *SubEntry;
	BOOLEAN		firstnum=TRUE;
	char 		buff[500];

	//name searching
	SubEntry  = NULL;
	while (GetNext(&SubEntry)) {
		if (SubEntry->GetType()==PBK_Text_Name_Last) {
			Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
		}	
	}
	SubEntry  = NULL;
	while (GetNext(&SubEntry)) {
		if (SubEntry->GetType()==PBK_Text_Name_First) {
			if (Buff.size()!=0) Buff.push_back(';');
			Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
		}
	}
	if (Buff.size()==0) {
		SubEntry  = NULL;
		while (GetNext(&SubEntry)) {
			if (SubEntry->GetType()==PBK_Text_Name) {
				Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
			}
		}
	}

	dest->clear();
	if (Type == VCARD_10) {
		SaveVCalendarText(dest,"BEGIN:VCARD",NULL);
		SubEntry = NULL;
		while (GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Phone_General:
			case PBK_Text_Phone_Mobile:
			case PBK_Text_Phone_Home:
			case PBK_Text_Phone_Work:
			case PBK_Text_Phone_Fax:
			case PBK_Text_Phone_Video:
				if (!firstnum) break;
				firstnum=FALSE;
				SaveVCalendarText(dest, "TEL", SubEntry->GetText());
				break;
			default:
				break;
			}
		}
		if (Buff.length()!=0) SaveVCalendarText(dest,"N",Buff.data());
		SaveVCalendarText(dest,"END:VCARD",NULL);
	}
	if (Type == VCARD_21) {
		SaveVCalendarText(dest,"BEGIN:VCARD",NULL);
		SaveVCalendarText(dest,"VERSION:2.1",NULL);
		SubEntry = NULL;
		while (GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Phone_General:
				sprintf(buff,"TEL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Mobile:
				sprintf(buff,"TEL;CELL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Home:
				sprintf(buff,"TEL;HOME");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Work:
				sprintf(buff,"TEL;WORK");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Fax:
				sprintf(buff,"TEL;FAX");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Video://fixme
				sprintf(buff,"TEL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Postal:
			case PBK_Text_Postal_Street:
			case PBK_Text_Postal_City:
			case PBK_Text_Postal_State:
			case PBK_Text_Postal_ZIP_Code:
			case PBK_Text_Postal_Country:
				break;
			case PBK_Text_Email:
				SaveVCalendarText(dest, "EMAIL", SubEntry->GetText());
				break;
			case PBK_Text_URL:
				SaveVCalendarText(dest, "URL", SubEntry->GetText());
				break;
			case PBK_Text_Note:
				SaveVCalendarText(dest, "NOTE", SubEntry->GetText());
				break;
			case PBK_Text_Job_Title:
				SaveVCalendarText(dest, "TITLE", SubEntry->GetText());
				break;
			case PBK_DateTime_Birthday:
				//todo
				break;
			case PBK_Text_Name: //processed earlier
			case PBK_Text_Name_Last:
			case PBK_Text_Name_First:
				break;
			case PBK_Text_Name_Formal:
			case PBK_Text_Company_Name:
			case PBK_Text_Nick_Name:
			case PBK_Text_PTT:
			case PBK_Text_Video_Sharing_SIP:
			case PBK_DateTime_Call_Length:
			case PBK_ID_Caller_Group:
			case PBK_ID_Picture:
			case PBK_ID_Ringtone:
			case PBK_ID_Video_File:
			case PBK_Bool_PTT_Subscribed:
			case PBK_Text_UserID:
				break;
			}
		}
		if (Buff.length()!=0) SaveVCalendarText(dest, "N", Buff.data());
		SaveVCalendarText(dest, "END:VCARD", NULL);
	}

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::DecodeFromVCARD(unsignedstring *src)
{
	int pos = 0;
	unsignedstring line;

//	while (pos!=src.size()) {
//		line.clear();
//		if (src.data
//		pos++;
//	}

	return GSM_Return_Error(GSM_ERR_NONE);
}

//-----------------------------------------------------------------------------

GSM_CallerGroupSubEntry::GSM_CallerGroupSubEntry()
{
	Next = NULL;
}

GSM_CallerGroupSubEntry::~GSM_CallerGroupSubEntry()
{
	delete(Next);
}

GSM_CallerGroupSubEntry *GSM_CallerGroupSubEntry::GetNext()
{
	return Next;
}

void GSM_CallerGroupSubEntry::SetNext(GSM_CallerGroupSubEntry *Nxt)
{
	Next = Nxt;
}

/* ------------------------------------------------------------------------ */

GSM_CallerGroupEntry::GSM_CallerGroupEntry()
{
	Entries = NULL;
}

GSM_CallerGroupEntry::~GSM_CallerGroupEntry()
{
	delete(Entries);
}

BOOLEAN GSM_CallerGroupEntry::GetNext(GSM_CallerGroupSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

void GSM_CallerGroupEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

BOOLEAN GSM_CallerGroupEntry::AddSubEntry(GSM_CallerGroupSubEntry *En)
{
	GSM_CallerGroupSubEntry *Entry2;

	if (Entries == NULL) {
		Entries = En;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(En);
	}
	return TRUE;
}
