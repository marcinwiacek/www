/* (C) 2007 by Marcin Wiacek www.mwiacek.com */

#ifdef WIN32
#  include <windows.h>
#endif
#include <stdio.h>

#include "../misc/misc.h"
#include "../misc/files.h"

#ifndef gsm_logo_h
#define gsm_logo_h

typedef enum {
	GSM_NokiaStartupLogo = 1,	/*size 84*48*/
	GSM_NokiaOperatorLogo,		/*size 72*14*/
	GSM_Nokia7110OperatorLogo,	/*size 78*21*/
	GSM_Nokia6510OperatorLogo,	/*size 78*21*/
	GSM_NokiaCallerLogo,		/*size 72*14*/
	GSM_NokiaPictureImage,		/*size 72*28*/
	GSM_Nokia7110StartupLogo,	/*size 96*65*/
	GSM_Nokia6210StartupLogo,	/*size 96*60*/
	GSM_AlcatelBMMIPicture,
	GSM_EMSSmallPicture,		/*size  8* 8*/
	GSM_EMSMediumPicture,		/*size 16*16*/
	GSM_EMSBigPicture,		/*size 32*32*/
	GSM_EMSPicture
} GSM_Phone_Bitmap_Types;

class Mono_Bitmap_FileSubEntry
{
	friend class Mono_Bitmap_FileEntry;
public:
	Mono_Bitmap_FileSubEntry(int W, int H);
	~Mono_Bitmap_FileSubEntry();

	Mono_Bitmap_FileSubEntry	*GetNext();
	BOOLEAN IsPointBlack		(int x, int y);
	BOOLEAN	SetPointColor		(int x, int y, BOOLEAN Black);
	int GetWidth			();
	int GetHeight			();
	void ClearBitmap		();
	int GetBitmapSize		();
	void SaveToPhoneBitmap		(GSM_Phone_Bitmap_Types Type, unsignedstring *buffer);
private:
	void 				SetNext(Mono_Bitmap_FileSubEntry *Nxt);

	Mono_Bitmap_FileSubEntry	*Next;
	int				Width;
	int				Height;
	unsigned char			Data[1000];
};

class Mono_Bitmap_FileEntry:virtual public Gen_File
{
public:
	Mono_Bitmap_FileEntry();
	~Mono_Bitmap_FileEntry();

	BOOLEAN ReadFile		(char *FileName);

	void 				ClearAll();
	BOOLEAN 			GetNext(Mono_Bitmap_FileSubEntry **En);
	BOOLEAN	 			AddSubEntry(Mono_Bitmap_FileSubEntry *En);
	BOOLEAN 			ReadFromNLM(unsignedstring Buff);
	BOOLEAN 			ReadFromBMP(unsignedstring Buff);
	BOOLEAN				SaveToBMP(unsignedstring *Buff, int Frame);
BOOLEAN ReadFromPhoneBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring buffer, int Width, int Height);
private:
	Mono_Bitmap_FileSubEntry	*Entries;
};

int PHONE_GetBitmapSize(GSM_Phone_Bitmap_Types Type, int Width, int Height);

#endif
