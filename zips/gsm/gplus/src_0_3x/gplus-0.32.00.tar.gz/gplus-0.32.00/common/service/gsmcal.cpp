/* (C) 2005-2007 by Marcin Wiacek www.mwiacek.com */

#include "../../cfg/config.h"
#include "gsmcal.h"
#include "../misc/coding/coding.h"

GSM_CalendarSubEntry::GSM_CalendarSubEntry()
{
	Type = Calendar_Not_Assigned;
	Text = NULL;
	Next = NULL;
}

GSM_CalendarSubEntry::~GSM_CalendarSubEntry()
{
	delete(Next);
	free(Text);
}

GSM_Calendar_SubEntryType GSM_CalendarSubEntry::GetType()
{
	return Type;
}

GSM_CalendarSubEntry *GSM_CalendarSubEntry::GetNext()
{
	return Next;
}

void GSM_CalendarSubEntry::SetNext(GSM_CalendarSubEntry *Nxt)
{
	Next = Nxt;
}

GSM_Error GSM_CalendarSubEntry::SetToDateTime(GSM_Calendar_SubEntryType Typ, GSM_DateTime DT2)
{
	if (Typ < Calendar_DateTime_Start || Typ > Calendar_DateTime_SilentAlarm) {
		return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
	}
	Type = Typ;

	memcpy(&DT,&DT2,sizeof(GSM_DateTime));
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_DateTime *GSM_CalendarSubEntry::GetDateTime()
{
	return &DT;
}

GSM_Error GSM_CalendarSubEntry::SetToInt(GSM_Calendar_SubEntryType Typ, int Value)
{
	if (Typ < Calendar_Int_Repeat_Frequency || Typ > Calendar_Int_Repeat_Month) {
		return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
	}

	Type = Typ;

	IntValue = Value;

	return GSM_Return_Error(GSM_ERR_NONE);
}

int GSM_CalendarSubEntry::GetInt()
{
	return IntValue;
}

GSM_Error GSM_CalendarSubEntry::SetToText(GSM_Calendar_SubEntryType Typ, wchar_t *Txt)
{
	int len = (UnicodeLength(Txt)+1)*sizeof(wchar_t);

	if (Typ < Calendar_Text_Text || Typ > Calendar_Text_Phone) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

	Type = Typ;

	Text = (wchar_t *)realloc(Text,len);
	memcpy(Text,Txt,len);

	return GSM_Return_Error(GSM_ERR_NONE);
}

wchar_t	*GSM_CalendarSubEntry::GetText()
{
	if (Text==NULL) return 0x00;
	return Text;
}

/* ------------------------------------------------------------------------ */

GSM_CalendarEntry::GSM_CalendarEntry()
{
	Type = Calendar_Type_Not_Assigned;
	Entries = NULL;
}


GSM_CalendarEntry::~GSM_CalendarEntry()
{
	delete(Entries);
}

BOOLEAN GSM_CalendarEntry::GetNext(GSM_CalendarSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

GSM_Error GSM_CalendarEntry::AddText(GSM_Calendar_SubEntryType Typ, wchar_t *Txt)
{
	GSM_CalendarSubEntry 	*Entry,*Entry2;
	GSM_Error		error;

	Entry = new GSM_CalendarSubEntry;
	error = Entry->SetToText(Typ, Txt);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_CalendarEntry::AddDateTime(GSM_Calendar_SubEntryType Typ, GSM_DateTime DT2)
{
	GSM_CalendarSubEntry 	*Entry,*Entry2;
	GSM_Error		error;

	Entry = new GSM_CalendarSubEntry;
	error = Entry->SetToDateTime(Typ, DT2);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_CalendarEntry::AddInt(GSM_Calendar_SubEntryType Typ, int Value)
{
	GSM_CalendarSubEntry 	*Entry,*Entry2;
	GSM_Error		error;

	Entry = new GSM_CalendarSubEntry;
	error = Entry->SetToInt(Typ, Value);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_CalendarEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

BOOLEAN GSM_CalendarEntry::IsNoteInDay(GSM_DateTime DT)
{
	int 			RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;
	GSM_CalendarSubEntry 	*SubEntry;
	time_t			start=0,end=0,tnow;

		tnow=GSMDateTime2TimeT(&DT);
        RepeatEach      = -1;
        RepeatDay       = -1;
        RepeatMonth     = -1;
        RepeatDOW       = -1;
        SubEntry        = NULL;
        while (GetNext(&SubEntry)) {
		switch (SubEntry->GetType()) {
		case Calendar_DateTime_Start:
			start = GSMDateTime2TimeT(SubEntry->GetDateTime());
                	break;
		case Calendar_DateTime_End:
			end = GSMDateTime2TimeT(SubEntry->GetDateTime());
                	break;
            	case Calendar_DateTime_End_Repeat:
                	break;
            	case Calendar_Int_Repeat_Frequency:
                	RepeatEach = SubEntry->GetInt();
                	break;
            	case Calendar_Int_Repeat_DayOfWeek:
                	RepeatDOW = SubEntry->GetInt();
                	break;                  
            	case Calendar_Int_Repeat_Day:
                	RepeatDay = SubEntry->GetInt();
                	break;
            	case Calendar_Int_Repeat_Month:
                	RepeatMonth = SubEntry->GetInt();
                	break;
		default:
			break;
            	}
        }
		if (start==0) {
			if (end!=0) {
				if (tnow < end) return TRUE;
				return FALSE;
			}
		} else {
			if (end==0) {
				if (tnow>start) return TRUE;
				return FALSE;
			} else {
				if (tnow>start && tnow<end) return TRUE;
				return FALSE;
			}
		}

	return TRUE;
}

//todo: repeat
GSM_Error GSM_CalendarEntry::EncodeToVCALENDAR(unsignedstring *dest)
{
	char			buff2[50];
	wchart			Buff;
	GSM_CalendarSubEntry 	*SubEntry;
	int			RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;

	SaveVCalendarText(dest,"BEGIN:VCALENDAR",NULL);
	SaveVCalendarText(dest,"VERSION:1.0",NULL);
	SaveVCalendarText(dest,"BEGIN:VEVENT",NULL);

	switch(Type) {
	case Calendar_Type_Meeting:
		SaveVCalendarText(dest,"CATEGORIES:MEETING",NULL);
		break;
	case Calendar_Type_Memo:
		SaveVCalendarText(dest,"CATEGORIES:MISCELLANEOUS",NULL);
		break;
	case Calendar_Type_Call:
		SaveVCalendarText(dest,"CATEGORIES:PHONE CALL",NULL);
		break;
	case Calendar_Type_Birthday:
		SaveVCalendarText(dest,"CATEGORIES:SPECIAL OCCASION",NULL);
		break;
	case Calendar_Type_Reminder:
		SaveVCalendarText(dest,"CATEGORIES:REMINDER",NULL);
		break;
	}

	if (Type == Calendar_Type_Call) {
		SubEntry 	= NULL;
		while (GetNext(&SubEntry) == TRUE) {
			if (SubEntry->GetType()==Calendar_Text_Phone) {
				Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
			}
		}
	}
	SubEntry = NULL;
	while (GetNext(&SubEntry) == TRUE) {
		if (SubEntry->GetType() == Calendar_Text_Text) {
			if (Buff.size()!=0) Buff.append(StringToUnicodeReturn(" "),1);
			Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
		}
	}
	if (Buff.size()!=0) SaveVCalendarText(dest,"SUMMARY",Buff.data());

	RepeatEach 	= -1;
	RepeatDay 	= -1;
	RepeatMonth 	= -1;
	RepeatDOW 	= -1;
	SubEntry 	= NULL;
	while (GetNext(&SubEntry) == TRUE) {
		switch (SubEntry->GetType()) {
		case Calendar_Text_Text: //processed earlier
		case Calendar_Text_Phone:
			break;
		case Calendar_Text_Location:
			SaveVCalendarText(dest, "LOCATION", SubEntry->GetText());
			break;
		case Calendar_DateTime_Start:
			sprintf(buff2,"DTSTART:");
			SaveVCalendarDateTime(SubEntry->GetDateTime(), buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case Calendar_DateTime_End:
			sprintf(buff2,"DTEND:");
			SaveVCalendarDateTime(SubEntry->GetDateTime(), buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case Calendar_DateTime_SilentAlarm:
			sprintf(buff2,"DALARM:");
			SaveVCalendarDateTime(SubEntry->GetDateTime(), buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case Calendar_DateTime_ToneAlarm:
			sprintf(buff2,"AALARM:");
			SaveVCalendarDateTime(SubEntry->GetDateTime(), buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case Calendar_DateTime_End_Repeat:
			break;
		case Calendar_Int_Repeat_Frequency:
			RepeatEach = SubEntry->GetInt();
			break;
		case Calendar_Int_Repeat_DayOfWeek:
			RepeatDOW = SubEntry->GetInt();
			break;			
		case Calendar_Int_Repeat_Day:
			RepeatDay = SubEntry->GetInt();
			break;
		case Calendar_Int_Repeat_Month:
			RepeatMonth = SubEntry->GetInt();
			break;
		}
	}
	SaveVCalendarText(dest,"END:VEVENT",NULL);
	SaveVCalendarText(dest,"END:VCALENDAR",NULL);

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_CalendarEntry::DecodeFromVCALENDAR(unsignedstring *src)
{
	return GSM_Return_Error(GSM_ERR_NONE);
}

//----------------------------------- todo ------------------------------------

GSM_ToDoSubEntry::GSM_ToDoSubEntry()
{
	Next = NULL;
}

GSM_ToDoSubEntry::~GSM_ToDoSubEntry()
{
	delete(Next);
}

GSM_ToDoSubEntry *GSM_ToDoSubEntry::GetNext()
{
	return Next;
}

void GSM_ToDoSubEntry::SetNext(GSM_ToDoSubEntry *Nxt)
{
	Next = Nxt;
}

/* ------------------------------------------------------------------------ */

GSM_ToDoEntry::GSM_ToDoEntry()
{
	Entries = NULL;
}


GSM_ToDoEntry::~GSM_ToDoEntry()
{
	delete(Entries);
}

BOOLEAN GSM_ToDoEntry::GetNext(GSM_ToDoSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}


void GSM_ToDoEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

GSM_Error GSM_ToDoEntry::AddSubEntry(GSM_ToDoSubEntry *En)
{
	GSM_ToDoSubEntry *Entry2;

	if (Entries == NULL) {
		Entries = En;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(En);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_ToDoEntry::EncodeToVTODO(unsignedstring *dest)
{        
	GSM_ToDoSubEntry *SubEntry;
	BOOLEAN 	 completed = FALSE;
   	char 		 buff2[200];

	SaveVCalendarText(dest,"BEGIN:VCALENDAR",NULL);
	SaveVCalendarText(dest,"VERSION:1.0",NULL);
	SaveVCalendarText(dest,"BEGIN:VTODO",NULL);

	SubEntry = NULL;
	while (GetNext(&SubEntry)) {
    		switch (SubEntry->Type) {
    		case ToDo_Text_Text:
			SaveVCalendarText(dest, "SUMMARY", SubEntry->Text.data());
        		break;
    		case ToDo_Priority:
     	   		switch (SubEntry->Priority) {
        		case GSM_Priority_High   : SaveVCalendarText(dest,"PRIORITY:3",NULL); break;
        		case GSM_Priority_Medium : SaveVCalendarText(dest,"PRIORITY:2",NULL); break;
        		case GSM_Priority_Low    : SaveVCalendarText(dest,"PRIORITY:1",NULL); break;
        		}
        		break;
    		case ToDo_Bool_Completed:
			SaveVCalendarText(dest,"STATUS:COMPLETED",NULL);
			completed = TRUE;
        		break;
    		case ToDo_DateTime_End:
			sprintf(buff2,"DUE:");
			SaveVCalendarDateTime(&SubEntry->DT, buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case ToDo_DateTime_SilentAlarm:
			sprintf(buff2,"DALARM:");
			SaveVCalendarDateTime(&SubEntry->DT, buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		case ToDo_DateTime_ToneAlarm:
			sprintf(buff2,"AALARM:");
			SaveVCalendarDateTime(&SubEntry->DT, buff2);
			SaveVCalendarText(dest, buff2, NULL);			
			break;
		}
        }
	if (!completed) SaveVCalendarText(dest,"STATUS:NEEDS ACTION",NULL);

	SaveVCalendarText(dest,"END:VTODO",NULL);
	SaveVCalendarText(dest,"END:VCALENDAR",NULL);

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_ToDoEntry::DecodeFromVTODO(unsignedstring *src)
{
	return GSM_Return_Error(GSM_ERR_NONE);
}
