//---------------------------------------------------------------------------
//
// Name:        SMSEditorDlg.h
// Author:      Marcinello
// Created:     2007-02-06 23:39:09
// Description: SMSEditorDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __SMSEditorDLG_h__
#define __SMSEditorDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/filedlg.h>
#include <wx/bmpbuttn.h>
#include <wx/button.h>
#include <wx/stattext.h>
#include <wx/choice.h>
#include <wx/listctrl.h>
#include <wx/combobox.h>
#include <wx/textctrl.h>
#include <wx/checkbox.h>
#include <wx/statbox.h>
#include <wx/notebook.h>
#include <wx/panel.h>
////Header Include End

#include "../common/service/gsmlogo.h"


////Dialog Style Start
#undef SMSEditorDlg_STYLE
#define SMSEditorDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class SMSEditorDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		SMSEditorDlg(GSM_StateMachine *s2, GSM_SMSList *List2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = SMSEditorDlg_STYLE);
		virtual ~SMSEditorDlg();
		void WxMemo1Updated(wxCommandEvent& event);
		void WxCheckBox1Click(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
	
	public:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxFileDialog *WxOpenFileDialog1;
		wxButton *SendWxButton;
		wxButton *CancelWxButton;
		wxComboBox *ValidityWxComboBox;
		wxStaticText *WxStaticText1;
		wxCheckBox *ReportWxCheckBox;
		wxComboBox *SMSCWxComboBox;
		wxStaticText *WxStaticText2;
		wxStaticBox *WxStaticBox7;
		wxButton *RecipientDeleteWxButton;
		wxButton *WxButton6;
		wxListCtrl *RecipientsWxListCtrl;
		wxStaticBox *WxStaticBox6;
		wxTextCtrl *NewRecipientWxEdit;
		wxButton *NewRecipientAddWxButton;
		wxStaticBox *WxStaticBox5;
		wxPanel *WxNoteBookPage3;
		wxPanel *WxNoteBookPage11;
		wxPanel *WxNoteBookPage10;
		wxTextCtrl *WxMemo2;
		wxStaticBox *WxStaticBox19;
		wxCheckBox *WxCheckBox2;
		wxChoice *WxChoice9;
		wxBitmapButton *WxBitmapButton1;
		wxButton *WxButton1;
		wxTextCtrl *WxMemo1;
		wxComboBox *WxComboBox2;
		wxStaticText *WxStaticText13;
		wxStaticBox *WxStaticBox17;
		wxStaticBox *WxStaticBox18;
		wxPanel *WxNoteBookPage9;
		wxChoice *WxChoice8;
		wxStaticText *WxStaticText12;
		wxListCtrl *WxListCtrl6;
		wxListCtrl *WxListCtrl5;
		wxStaticBox *WxStaticBox16;
		wxStaticBox *WxStaticBox15;
		wxPanel *WxNoteBookPage8;
		wxStaticText *WxStaticText10;
		wxChoice *WxChoice4;
		wxChoice *WxChoice3;
		wxStaticText *WxStaticText7;
		wxChoice *WxChoice2;
		wxStaticText *WxStaticText6;
		wxStaticBox *WxStaticBox11;
		wxStaticText *WxStaticText5;
		wxChoice *WxChoice1;
		wxStaticBox *WxStaticBox10;
		wxStaticBox *WxStaticBox9;
		wxStaticBox *WxStaticBox8;
		wxPanel *WxNoteBookPage7;
		wxChoice *WxChoice7;
		wxStaticText *WxStaticText11;
		wxTextCtrl *WxEdit2;
		wxTextCtrl *WxEdit1;
		wxStaticText *WxStaticText9;
		wxStaticText *WxStaticText8;
		wxPanel *WxNoteBookPage6;
		wxListCtrl *WxListCtrl3;
		wxListCtrl *WxListCtrl2;
		wxChoice *WxChoice5;
		wxStaticText *WxStaticText4;
		wxStaticBox *WxStaticBox12;
		wxStaticBox *WxStaticBox4;
		wxPanel *WxNoteBookPage5;
		wxStaticText *WxStaticText3;
		wxChoice *WxChoice6;
		wxListCtrl *WxListCtrl4;
		wxListCtrl *WxListCtrl1;
		wxStaticBox *WxStaticBox14;
		wxStaticBox *WxStaticBox13;
		wxPanel *WxNoteBookPage4;
		wxCheckBox *WxCheckBox3;
		wxCheckBox *ReplyWxCheckBox;
		wxComboBox *WxComboBox4;
		wxCheckBox *WxCheckBox4;
		wxComboBox *WxComboBox1;
		wxCheckBox *WxCheckBox1;
		wxTextCtrl *TextSMSPreviewWxMemo;
		wxTextCtrl *TextSMSWxMemo;
		wxCheckBox *TextSMSClassWxCheckBox;
		wxCheckBox *TextSMSUnicodeWxCheckBox;
		wxStaticBox *WxStaticBox3;
		wxStaticBox *WxStaticBox2;
		wxStaticBox *WxStaticBox1;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook1;
		wxPanel *WxNoteBookPage2;
		wxNotebook *WxNotebook2;
		wxPanel *WxPanel1;
		////GUI Control Declaration End
		void WxButton5Click(wxCommandEvent& event);
		void WxButton7Click(wxCommandEvent& event);
		void WxEdit1Updated(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
		void CancelWxButtonClick(wxCommandEvent& event);
		void TextSMSWxMemoUpdated(wxCommandEvent& event);
		void RecipientDeleteWxButtonClick(wxCommandEvent& event);
		void SendWxButtonClick(wxCommandEvent& event);
		void TextSMSUnicodeWxCheckBoxClick(wxCommandEvent& event);
		void NewRecipientAddWxButtonClick(wxCommandEvent& event);
		void NewRecipientWxEditUpdated(wxCommandEvent& event);
		void TextSMSClassWxCheckBoxClick(wxCommandEvent& event);
		void WxCheckBox1Click1(wxCommandEvent& event);
		void WxComboBox1Updated(wxCommandEvent& event );
		void WxChoice1Selected(wxCommandEvent& event );
		void WxChoice2Selected(wxCommandEvent& event );
		void WxChoice3Selected(wxCommandEvent& event );
		void WxChoice4Selected(wxCommandEvent& event );
		void WxEdit1Updated1(wxCommandEvent& event);
		void WxEdit2Updated(wxCommandEvent& event);
		void WxComboBox4Updated(wxCommandEvent& event );
		void WxCheckBox4Click(wxCommandEvent& event);
		void ReplyWxCheckBoxClick(wxCommandEvent& event);
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_SENDWXBUTTON = 1018,
			ID_CANCELWXBUTTON = 1007,
			ID_VALIDITYWXCOMBOBOX = 1039,
			ID_WXSTATICTEXT1 = 1038,
			ID_REPORTWXCHECKBOX = 1034,
			ID_SMSCWXCOMBOBOX = 1033,
			ID_WXSTATICTEXT2 = 1032,
			ID_WXSTATICBOX7 = 1031,
			ID_RECIPIENTDELETEWXBUTTON = 1029,
			ID_WXBUTTON6 = 1028,
			ID_RECIPIENTSWXLISTCTRL = 1027,
			ID_WXSTATICBOX6 = 1026,
			ID_NEWRECIPIENTWXEDIT = 1024,
			ID_NEWRECIPIENTADDWXBUTTON = 1023,
			ID_WXSTATICBOX5 = 1022,
			ID_WXNOTEBOOKPAGE3 = 1017,
			ID_WXNOTEBOOKPAGE11 = 1102,
			ID_WXNOTEBOOKPAGE10 = 1101,
			ID_WXMEMO2 = 1121,
			ID_WXSTATICBOX19 = 1120,
			ID_WXCHECKBOX2 = 1116,
			ID_WXCHOICE9 = 1114,
			ID_WXBITMAPBUTTON1 = 1113,
			ID_WXBUTTON1 = 1109,
			ID_WXMEMO1 = 1105,
			ID_WXCOMBOBOX2 = 1104,
			ID_WXSTATICTEXT13 = 1103,
			ID_WXSTATICBOX17 = 1117,
			ID_WXSTATICBOX18 = 1118,
			ID_WXNOTEBOOKPAGE9 = 1100,
			ID_WXCHOICE8 = 1099,
			ID_WXSTATICTEXT12 = 1098,
			ID_WXLISTCTRL6 = 1097,
			ID_WXLISTCTRL5 = 1096,
			ID_WXSTATICBOX16 = 1093,
			ID_WXSTATICBOX15 = 1092,
			ID_WXNOTEBOOKPAGE8 = 1091,
			ID_WXSTATICTEXT10 = 1073,
			ID_WXCHOICE4 = 1068,
			ID_WXCHOICE3 = 1067,
			ID_WXSTATICTEXT7 = 1066,
			ID_WXCHOICE2 = 1064,
			ID_WXSTATICTEXT6 = 1063,
			ID_WXSTATICBOX11 = 1062,
			ID_WXSTATICTEXT5 = 1061,
			ID_WXCHOICE1 = 1060,
			ID_WXSTATICBOX10 = 1057,
			ID_WXSTATICBOX9 = 1054,
			ID_WXSTATICBOX8 = 1053,
			ID_WXNOTEBOOKPAGE7 = 1052,
			ID_WXCHOICE7 = 1095,
			ID_WXSTATICTEXT11 = 1094,
			ID_WXEDIT2 = 1072,
			ID_WXEDIT1 = 1071,
			ID_WXSTATICTEXT9 = 1070,
			ID_WXSTATICTEXT8 = 1069,
			ID_WXNOTEBOOKPAGE6 = 1045,
			ID_WXLISTCTRL3 = 1084,
			ID_WXLISTCTRL2 = 1083,
			ID_WXCHOICE5 = 1082,
			ID_WXSTATICTEXT4 = 1081,
			ID_WXSTATICBOX12 = 1080,
			ID_WXSTATICBOX4 = 1079,
			ID_WXNOTEBOOKPAGE5 = 1044,
			ID_WXSTATICTEXT3 = 1090,
			ID_WXCHOICE6 = 1089,
			ID_WXLISTCTRL4 = 1088,
			ID_WXLISTCTRL1 = 1087,
			ID_WXSTATICBOX14 = 1086,
			ID_WXSTATICBOX13 = 1085,
			ID_WXNOTEBOOKPAGE4 = 1043,
			ID_WXCHECKBOX3 = 1119,
			ID_REPLYWXCHECKBOX = 1077,
			ID_WXCOMBOBOX4 = 1075,
			ID_WXCHECKBOX4 = 1074,
			ID_WXCOMBOBOX1 = 1042,
			ID_WXCHECKBOX1 = 1041,
			ID_TEXTSMSPREVIEWWXMEMO = 1014,
			ID_TEXTSMSWXMEMO = 1013,
			ID_TEXTSMSCLASSWXCHECKBOX = 1012,
			ID_TEXTSMSUNICODEWXCHECKBOX = 1011,
			ID_WXSTATICBOX3 = 1010,
			ID_WXSTATICBOX2 = 1009,
			ID_WXSTATICBOX1 = 1008,
			ID_WXNOTEBOOKPAGE1 = 1005,
			ID_WXNOTEBOOK1 = 1004,
			ID_WXNOTEBOOKPAGE2 = 1016,
			ID_WXNOTEBOOK2 = 1015,
			ID_WXPANEL1 = 1003,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
        void SetInfo();		
        void Indicators();        
        void WAPBookmark();
        void DeleteP(wxString Str);        
		
		GSM_SMSList       *List;
		GSM_StateMachine  *s;
		long              num;
		BOOLEAN           start;
		GSM_PBKEntry      *PBK2;
		GSM_CalendarEntry *Cal2;
		GSM_ToDoEntry     *ToDo2;
		Mono_Bitmap_FileEntry MonoFile;
		BOOLEAN               MonoFileAvail;
		
	public:
        void SendPBK(GSM_PBKEntry *PBK);    
        void DeleteNormal();            
		void WxChoice5Selected(wxCommandEvent& event );
		void WxChoice6Selected(wxCommandEvent& event );
        void SendCalendar(GSM_CalendarEntry *Cal);		
		void WxChoice7Selected(wxCommandEvent& event );
        void SelectPBK();		
        void SelectCalendar();
        void SendToDo(GSM_ToDoEntry *ToDo); 
        void SelectToDo();               
		void WxButton1Click1(wxCommandEvent& event);
		void WxMemo1Updated1(wxCommandEvent& event);
        void Image();		
		void WxCheckBox3Click(wxCommandEvent& event);
		void WxCheckBox2Click(wxCommandEvent& event);
		void WxChoice9Selected(wxCommandEvent& event );
};

#endif
