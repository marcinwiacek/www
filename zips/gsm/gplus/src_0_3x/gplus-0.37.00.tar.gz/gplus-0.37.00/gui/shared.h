
#ifndef yyy
#define yyy

#include <wx/listctrl.h>
#include <wx/mediactrl.h>
#include <wx/textctrl.h>
#include <wx/sizer.h>
#include <wx/image.h>
#include <wx/button.h>
#include <wx/filedlg.h>
#include <wx/sizer.h>


#include "../cfg/config.h"
#include "../common/service/smsmms/gsmmsg.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

BOOLEAN PrintError (GSM_Error error);
char *DayOfWeekStr(int Year, int Month, int Day);
void PrintDT(GSM_DateTime *DT, char *Buffer);
int ViewMMSFile(GSM_File *File, GSM_SMSMMSDecodedEntry *Decoded, wxListCtrl *List, wxComboBox *FilesList, wxListBox *NumbersList, wxBoxSizer *Sizer, wxPanel *Panel);
void MMSSelect(int Num, GSM_SMSMMSDecodedEntry *Decoded, wxMediaCtrl *MediaCtrl1, wxTextCtrl *Memo1, wxBoxSizer *BoxSizer3, wxButton *Button);
void SaveMMSFile(GSM_SMSMMSDecodedEntry *Decoded, wxFileDialog *WxSaveFileDialog1, int Num);
void DecodePBKSubEntry(GSM_PBKSubEntry *SubEntry, char *type, wchar_t *Value, BOOLEAN *FirstNum);
void DisplayCalendar2(GSM_CalendarEntry *CalEntry2, wxListCtrl *CalendarDownWxListCtrl);
void DecodeCalendarSubEntry(GSM_CalendarSubEntry *SubEntry, char *type, wchart *Value, BOOLEAN Birthday);
void DecodeToDoSubEntry(GSM_ToDoSubEntry *SubEntry, char *type, wchart *Value);
void DisplayNote2(GSM_NoteEntry *NoteEntry2, wxListCtrl *CalendarDownWxListCtrl);
void ReadPBKMemory(GSM_MemoryType Mem, GSM_StateMachine *s, GSM_Backup *Backup);

#endif
