//---------------------------------------------------------------------------
//
// Name:        SMSEditorDlg.cpp
// Author:      Marcinello
// Created:     2007-02-06 23:39:09
// Description: SMSEditorDlg class implementation
//
//---------------------------------------------------------------------------

#include <wx/progdlg.h>

#include "../cfg/config.h"
#include "../common/service/smsmms/gsmmsg.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"
#include "../common/misc/misc.h"

#include "SMSEditorDlg.h"
#include "RecipientsDlg.h"
#include "shared.h"
#include "EMSAddDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// SMSEditorDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(SMSEditorDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(SMSEditorDlg::OnClose)
	EVT_BUTTON(ID_SENDWXBUTTON,SMSEditorDlg::SendWxButtonClick)
	EVT_BUTTON(ID_CANCELWXBUTTON,SMSEditorDlg::CancelWxButtonClick)
	EVT_BUTTON(ID_RECIPIENTDELETEWXBUTTON,SMSEditorDlg::RecipientDeleteWxButtonClick)
	EVT_BUTTON(ID_WXBUTTON6,SMSEditorDlg::WxButton6Click)
	
	EVT_LIST_ITEM_SELECTED(ID_RECIPIENTSWXLISTCTRL,SMSEditorDlg::RecipientsWxListCtrlSelected)
	EVT_LIST_ITEM_DESELECTED(ID_RECIPIENTSWXLISTCTRL,SMSEditorDlg::RecipientsWxListCtrlDeselected)
	
	EVT_TEXT(ID_NEWRECIPIENTWXEDIT,SMSEditorDlg::NewRecipientWxEditUpdated)
	EVT_BUTTON(ID_NEWRECIPIENTADDWXBUTTON,SMSEditorDlg::NewRecipientAddWxButtonClick)
	EVT_CHOICE(ID_WXCHOICE8,SMSEditorDlg::WxChoice8Selected)
	EVT_CHOICE(ID_WXCHOICE6,SMSEditorDlg::WxChoice6Selected)
	EVT_CHOICE(ID_WXCHOICE5,SMSEditorDlg::WxChoice5Selected)
	
	EVT_TEXT(ID_WXMEMO3,SMSEditorDlg::WxMemo3Updated)
	
	EVT_TEXT(ID_WXEDIT3,SMSEditorDlg::WxEdit3Updated)
	EVT_BUTTON(ID_WXBUTTON2,SMSEditorDlg::WxButton2Click1)
	EVT_COMBOBOX(ID_WXCOMBOBOX3,SMSEditorDlg::WxComboBox3Selected)
	EVT_CHECKBOX(ID_WXCHECKBOX2,SMSEditorDlg::WxCheckBox2Click)
	EVT_CHOICE(ID_WXCHOICE9,SMSEditorDlg::WxChoice9Selected)
	EVT_BUTTON(ID_WXBUTTON1,SMSEditorDlg::WxButton1Click1)
	
	EVT_TEXT(ID_WXMEMO1,SMSEditorDlg::WxMemo1Updated1)
	EVT_CHOICE(ID_WXCHOICE4,SMSEditorDlg::WxChoice4Selected)
	EVT_CHOICE(ID_WXCHOICE3,SMSEditorDlg::WxChoice3Selected)
	EVT_CHOICE(ID_WXCHOICE2,SMSEditorDlg::WxChoice2Selected)
	EVT_CHOICE(ID_WXCHOICE1,SMSEditorDlg::WxChoice1Selected)
	EVT_CHOICE(ID_WXCHOICE7,SMSEditorDlg::WxChoice7Selected)
	
	EVT_TEXT(ID_WXEDIT2,SMSEditorDlg::WxEdit2Updated)
	
	EVT_TEXT(ID_WXEDIT1,SMSEditorDlg::WxEdit1Updated1)
	EVT_CHECKBOX(ID_WXCHECKBOX14,SMSEditorDlg::WxCheckBox14Click)
	EVT_CHECKBOX(ID_WXCHECKBOX13,SMSEditorDlg::WxCheckBox13Click)
	EVT_CHOICE(ID_WXCHOICE12,SMSEditorDlg::WxChoice12Selected)
	EVT_CHECKBOX(ID_WXCHECKBOX12,SMSEditorDlg::WxCheckBox12Click)
	EVT_CHECKBOX(ID_WXCHECKBOX4,SMSEditorDlg::WxCheckBox4Click)
	EVT_CHECKBOX(ID_WXCHECKBOX3,SMSEditorDlg::WxCheckBox3Click1)
	EVT_CHECKBOX(ID_WXCHECKBOX1,SMSEditorDlg::WxCheckBox1Click1)
	EVT_CHOICE(ID_WXCHOICE11,SMSEditorDlg::WxChoice11Selected)
	EVT_LISTBOX(ID_WXLISTBOX1,SMSEditorDlg::WxListBox1Selected)
	EVT_BUTTON(ID_WXBUTTON9,SMSEditorDlg::WxButton9Click)
	EVT_COMBOBOX(ID_WXCOMBOBOX8,SMSEditorDlg::WxComboBox8Selected)
	
	EVT_TEXT(ID_WXCOMBOBOX7,SMSEditorDlg::WxComboBox7Updated)
	
	EVT_TEXT(ID_WXCOMBOBOX6,SMSEditorDlg::WxComboBox6Updated)
	
	EVT_TEXT(ID_WXMEMO4,SMSEditorDlg::WxMemo4Updated)
	EVT_CHECKBOX(ID_WXCHECKBOX10,SMSEditorDlg::WxCheckBox10Click)
	EVT_CHECKBOX(ID_WXCHECKBOX9,SMSEditorDlg::WxCheckBox9Click)
	EVT_CHECKBOX(ID_WXCHECKBOX8,SMSEditorDlg::WxCheckBox8Click)
	EVT_CHECKBOX(ID_WXCHECKBOX7,SMSEditorDlg::WxCheckBox7Click)
	EVT_CHECKBOX(ID_WXCHECKBOX6,SMSEditorDlg::WxCheckBox6Click)
	EVT_CHECKBOX(ID_WXCHECKBOX5,SMSEditorDlg::WxCheckBox5Click)
	EVT_BUTTON(ID_WXBUTTON7,SMSEditorDlg::WxButton7Click1)
	EVT_BUTTON(ID_WXBUTTON5,SMSEditorDlg::WxButton5Click1)
	EVT_BUTTON(ID_WXBUTTON4,SMSEditorDlg::WxButton4Click)
	EVT_BUTTON(ID_WXBUTTON3,SMSEditorDlg::WxButton3Click1)
END_EVENT_TABLE()
////Event Table End

SMSEditorDlg::SMSEditorDlg(GSM_Backup *Backup2, GSM_StateMachine *s2, GSM_SMSList *List2, wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
    GSM_SMSC                SMSC;
    int                     Num=1,i;
    GSM_Error               error;
    char                    buff[200];
    wxProgressDialog        *Dialog;
    bool                    skip;
    wxCommandEvent          event;

    EMSEdit=FALSE;
    EMSSub=NULL;
    Backup=Backup2;
    UpdatingFileTransfer=FALSE;
	num = 0;
    s=s2;
    List = List2;
    PBK2 = NULL;
    Cal2=NULL;
    Note2=NULL;
    ToDo2=NULL;
    start = true;
    MonoFileAvail = FALSE;
    
	CreateGUIControls();
    
    SetTitle(title);
    
    Dialog = new wxProgressDialog("Reading SMSC", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_CAN_ABORT);
    while (true) {
                Dialog->Pulse("Reading SMSC",&skip);        
    	SMSC.Location = Num;
    	error = s->Phones->Current->GetSMSC(&SMSC);
    	if (error.Code != GSM_ERR_NONE) break;
     	sprintf(buff,"%s",UnicodeToStringReturn(SMSC.GetSMSCNumber()));
    //    	if (UnicodeLength(SMSC.GetName())!=0) {
    //        	sprintf(buff+strlen(buff)," (%s)",UnicodeToStringReturn(SMSC.GetName()));
    //        }
        if (strlen(buff)!=0) SMSCWxComboBox->Append(buff);
        Num++;
    }
    delete Dialog;
    SMSCWxComboBox->Select(0);    
    ValidityWxComboBox->Select(5);
 //   TextSMSWxMemo->SetFocus();
    WxComboBox7->Select(0);
    
    for(i=1;i<255;i++) {
        sprintf(buff,"%i messages",i); 
        WxChoice1->Append(buff);
        WxChoice2->Append(buff);
        WxChoice3->Append(buff);
        WxChoice4->Append(buff);
    }
    sprintf(buff,"255 or more messages"); 
    WxChoice1->Append(buff);
    WxChoice2->Append(buff);
    WxChoice3->Append(buff);
    WxChoice4->Append(buff);
    
    WxChoice1->Select(0);
    WxChoice2->Select(0);
    WxChoice3->Select(0);
    WxChoice4->Select(0);
  
    for(i=0;i<256;i++) {
        sprintf(buff,"%i",i);
        WxComboBox8->Append(buff);
    }
    WxComboBox8->Select(0);
 
    WxChoice7->Select(0);

    WxComboBox2->Select(0);
    WxComboBox3->Select(0);
    WxComboBox5->Select(0);
  
    WxChoice9->Enable(FALSE);
    WxMemo1->Enable(FALSE);
    WxCheckBox2->Enable(FALSE);
    WxComboBox2->Enable(FALSE);
    
    AddEMSPart(SMS_UDH_EMS_Text_Format);
    WxListBox1->Select(0);
    WxListBox1Selected(event);
    WxMemo4->SetFocus();
//    AddEMSPart(SMS_UDH_EMS_Sound);

    start=false;        
}

void SMSEditorDlg::DeleteP(wxString Str)
{
    int i;

    i=0;
    while (i<WxNotebook1->GetPageCount()) {
        if (WxNotebook1->GetPageText(i) == Str) {
            WxNotebook1->DeletePage(i);
            break;
        }
        i++;
    }
}

void SMSEditorDlg::DeleteNormal()
{
    DeleteP("Calendar");
    DeleteP("PhoneBook");
    DeleteP("ToDo");
    DeleteP("Note");
}

SMSEditorDlg::~SMSEditorDlg()
{
} 

void SMSEditorDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxPanel1 = new wxPanel(this, ID_WXPANEL1, wxPoint(0,0), wxSize(574,525));

	WxNotebook2 = new wxNotebook(WxPanel1, ID_WXNOTEBOOK2, wxPoint(5,5),wxSize(417,516));

	WxNoteBookPage2 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE2, wxPoint(4,24), wxSize(409,488));
	WxNotebook2->AddPage(WxNoteBookPage2, wxT("Content"));

	WxNotebook1 = new wxNotebook(WxNoteBookPage2, ID_WXNOTEBOOK1, wxPoint(1,1),wxSize(400,486));

	WxNoteBookPage12 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE12, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage12, wxT("Text SMS/EMS"));

	WxStaticBox22 = new wxStaticBox(WxNoteBookPage12, ID_WXSTATICBOX22, wxT("SMS sequence"), wxPoint(4,0), wxSize(383,141));

	WxButton3 = new wxButton(WxNoteBookPage12, ID_WXBUTTON3, wxT("Add"), wxPoint(138,17), wxSize(42,21), 0, wxDefaultValidator, wxT("WxButton3"));

	WxButton4 = new wxButton(WxNoteBookPage12, ID_WXBUTTON4, wxT("Delete"), wxPoint(138,37), wxSize(42,20), 0, wxDefaultValidator, wxT("WxButton4"));
	WxButton4->Enable(false);

	WxButton5 = new wxButton(WxNoteBookPage12, ID_WXBUTTON5, wxT("Up"), wxPoint(138,58), wxSize(42,19), 0, wxDefaultValidator, wxT("WxButton5"));
	WxButton5->Enable(false);

	WxButton7 = new wxButton(WxNoteBookPage12, ID_WXBUTTON7, wxT("Down"), wxPoint(138,76), wxSize(42,19), 0, wxDefaultValidator, wxT("WxButton7"));
	WxButton7->Enable(false);

	WxCheckBox5 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX5, wxT("Use Unicode (less chars, all national)"), wxPoint(186,20), wxSize(198,17), 0, wxDefaultValidator, wxT("WxCheckBox5"));

	WxCheckBox6 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX6, wxT("Use 16 bit ID in UDH"), wxPoint(186,53), wxSize(124,19), 0, wxDefaultValidator, wxT("WxCheckBox6"));
	WxCheckBox6->Enable(false);

	WxCheckBox7 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX7, wxT("Send in class 0 (flash SMS)"), wxPoint(186,39), wxSize(180,14), 0, wxDefaultValidator, wxT("WxCheckBox7"));

	WxCheckBox8 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX8, wxT("Allow reply for your cost"), wxPoint(186,72), wxSize(135,15), 0, wxDefaultValidator, wxT("WxCheckBox8"));

	WxCheckBox9 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX9, wxT("Replace SMS with specified ID (saved in recipient phone)"), wxPoint(13,97), wxSize(310,17), 0, wxDefaultValidator, wxT("WxCheckBox9"));

	WxCheckBox10 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX10, wxT("Replace SMS with specified TPMR (if waiting in SMS Center)"), wxPoint(13,117), wxSize(315,18), 0, wxDefaultValidator, wxT("WxCheckBox10"));

	WxStaticBox23 = new wxStaticBox(WxNoteBookPage12, ID_WXSTATICBOX23, wxT("Text"), wxPoint(4,143), wxSize(384,134));
	WxStaticBox23->Show(false);

	WxStaticBox24 = new wxStaticBox(WxNoteBookPage12, ID_WXSTATICBOX24, wxT("Animation/picture"), wxPoint(4,280), wxSize(221,49));
	WxStaticBox24->Show(false);

	WxMemo4 = new wxTextCtrl(WxNoteBookPage12, ID_WXMEMO4, wxT(""), wxPoint(11,159), wxSize(279,94), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo4"));
	WxMemo4->SetMaxLength(0);
	WxMemo4->Show(false);
	WxMemo4->SetFocus();
	WxMemo4->SetInsertionPointEnd();

	WxStaticBox25 = new wxStaticBox(WxNoteBookPage12, ID_WXSTATICBOX25, wxT("Preview in recipients' phone(s)"), wxPoint(4,332), wxSize(385,98));
	WxStaticBox25->Show(false);

	WxStaticBox26 = new wxStaticBox(WxNoteBookPage12, ID_WXSTATICBOX26, wxT("Default element"), wxPoint(229,281), wxSize(159,48));
	WxStaticBox26->Show(false);

	WxCheckBox11 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX11, wxT("no forward"), wxPoint(100,304), wxSize(117,14), 0, wxDefaultValidator, wxT("WxCheckBox11"));
	WxCheckBox11->Show(false);

	wxBitmap WxBitmapButton2_BITMAP (wxNullBitmap);
	WxBitmapButton2 = new wxBitmapButton(WxNoteBookPage12, ID_WXBITMAPBUTTON2, WxBitmapButton2_BITMAP, wxPoint(302,353), wxSize(80,71), wxBU_AUTODRAW, wxDefaultValidator, wxT("WxBitmapButton2"));
	WxBitmapButton2->Show(false);

	WxButton8 = new wxButton(WxNoteBookPage12, ID_WXBUTTON8, wxT("Load file"), wxPoint(10,300), wxSize(84,21), 0, wxDefaultValidator, wxT("WxButton8"));
	WxButton8->Show(false);

	WxMemo5 = new wxTextCtrl(WxNoteBookPage12, ID_WXMEMO5, wxT(""), wxPoint(11,354), wxSize(273,69), wxNO_BORDER | wxTE_READONLY | wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo5"));
	WxMemo5->SetMaxLength(0);
	WxMemo5->Show(false);
	WxMemo5->SetFocus();
	WxMemo5->SetInsertionPointEnd();
	WxMemo5->SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_SCROLLBAR));

	WxStaticText19 = new wxStaticText(WxNoteBookPage12, ID_WXSTATICTEXT19, wxT("ID"), wxPoint(238,302), wxDefaultSize, 0, wxT("WxStaticText19"));
	WxStaticText19->Show(false);

	wxArrayString arrayStringFor_WxComboBox6;
	WxComboBox6 = new wxComboBox(WxNoteBookPage12, ID_WXCOMBOBOX6, wxT("WxComboBox6"), wxPoint(256,299), wxSize(125,21), arrayStringFor_WxComboBox6, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox6"));
	WxComboBox6->Show(false);

	/* 0
	1
	2
	3
	4
	5
	6
	7
	*/
	wxArrayString arrayStringFor_WxComboBox7;
	arrayStringFor_WxComboBox7.Add(wxT("0"));
	arrayStringFor_WxComboBox7.Add(wxT("1"));
	arrayStringFor_WxComboBox7.Add(wxT("2"));
	arrayStringFor_WxComboBox7.Add(wxT("3"));
	arrayStringFor_WxComboBox7.Add(wxT("4"));
	arrayStringFor_WxComboBox7.Add(wxT("5"));
	arrayStringFor_WxComboBox7.Add(wxT("6"));
	arrayStringFor_WxComboBox7.Add(wxT("7"));
	WxComboBox7 = new wxComboBox(WxNoteBookPage12, ID_WXCOMBOBOX7, wxT("WxComboBox7"), wxPoint(329,95), wxSize(52,21), arrayStringFor_WxComboBox7, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox7"));
	WxComboBox7->Enable(false);

	wxArrayString arrayStringFor_WxComboBox8;
	WxComboBox8 = new wxComboBox(WxNoteBookPage12, ID_WXCOMBOBOX8, wxT("WxComboBox8"), wxPoint(329,116), wxSize(52,21), arrayStringFor_WxComboBox8, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox8"));
	WxComboBox8->Enable(false);

	WxButton9 = new wxButton(WxNoteBookPage12, ID_WXBUTTON9, wxT("Load file"), wxPoint(293,251), wxSize(72,22), 0, wxDefaultValidator, wxT("WxButton9"));
	WxButton9->Show(false);

	wxArrayString arrayStringFor_WxListBox1;
	WxListBox1 = new wxListBox(WxNoteBookPage12, ID_WXLISTBOX1, wxPoint(13,16), wxSize(120,78), arrayStringFor_WxListBox1, wxLB_SINGLE);

	WxStaticText20 = new wxStaticText(WxNoteBookPage12, ID_WXSTATICTEXT20, wxT("Size"), wxPoint(296,156), wxDefaultSize, 0, wxT("WxStaticText20"));

	wxArrayString arrayStringFor_WxChoice11;
	arrayStringFor_WxChoice11.Add(wxT("not set"));
	arrayStringFor_WxChoice11.Add(wxT("small"));
	arrayStringFor_WxChoice11.Add(wxT("large"));
	WxChoice11 = new wxChoice(WxNoteBookPage12, ID_WXCHOICE11, wxPoint(322,153), wxSize(61,21), arrayStringFor_WxChoice11, 0, wxDefaultValidator, wxT("WxChoice11"));
	WxChoice11->SetSelection(-1);

	WxCheckBox1 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX1, wxT("Bold"), wxPoint(292,197), wxSize(43,16), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxCheckBox3 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX3, wxT("Italic"), wxPoint(337,198), wxSize(45,15), 0, wxDefaultValidator, wxT("WxCheckBox3"));

	WxCheckBox4 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX4, wxT("Underline"), wxPoint(292,214), wxSize(65,15), 0, wxDefaultValidator, wxT("WxCheckBox4"));

	WxCheckBox12 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX12, wxT("Strikethrough"), wxPoint(292,232), wxSize(83,14), 0, wxDefaultValidator, wxT("WxCheckBox12"));

	wxArrayString arrayStringFor_WxChoice12;
	arrayStringFor_WxChoice12.Add(wxT("not set"));
	arrayStringFor_WxChoice12.Add(wxT("left"));
	arrayStringFor_WxChoice12.Add(wxT("center"));
	arrayStringFor_WxChoice12.Add(wxT("right"));
	WxChoice12 = new wxChoice(WxNoteBookPage12, ID_WXCHOICE12, wxPoint(322,174), wxSize(61,21), arrayStringFor_WxChoice12, 0, wxDefaultValidator, wxT("WxChoice12"));
	WxChoice12->SetSelection(-1);

	WxStaticText21 = new wxStaticText(WxNoteBookPage12, ID_WXSTATICTEXT21, wxT("Align"), wxPoint(295,173), wxDefaultSize, 0, wxT("WxStaticText21"));

	WxCheckBox13 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX13, wxT("no forward"), wxPoint(12,257), wxSize(75,12), 0, wxDefaultValidator, wxT("WxCheckBox13"));

	WxCheckBox14 = new wxCheckBox(WxNoteBookPage12, ID_WXCHECKBOX14, wxT("SE short form"), wxPoint(93,256), wxSize(84,14), 0, wxDefaultValidator, wxT("WxCheckBox14"));
	WxCheckBox14->SetValue(true);

	WxNoteBookPage6 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE6, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage6, wxT("URL"));

	WxStaticText8 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT8, wxT("Name"), wxPoint(3,39), wxDefaultSize, 0, wxT("WxStaticText8"));

	WxStaticText9 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT9, wxT("URL"), wxPoint(3,69), wxDefaultSize, 0, wxT("WxStaticText9"));

	WxEdit1 = new wxTextCtrl(WxNoteBookPage6, ID_WXEDIT1, wxT(""), wxPoint(88,38), wxSize(295,22), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxEdit2 = new wxTextCtrl(WxNoteBookPage6, ID_WXEDIT2, wxT(""), wxPoint(88,69), wxSize(295,23), 0, wxDefaultValidator, wxT("WxEdit2"));

	WxStaticText11 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT11, wxT("Format"), wxPoint(3,10), wxDefaultSize, 0, wxT("WxStaticText11"));

	wxArrayString arrayStringFor_WxChoice7;
	arrayStringFor_WxChoice7.Add(wxT("WAP bookmark"));
	arrayStringFor_WxChoice7.Add(wxT("WAP push"));
	WxChoice7 = new wxChoice(WxNoteBookPage6, ID_WXCHOICE7, wxPoint(89,7), wxSize(297,21), arrayStringFor_WxChoice7, 0, wxDefaultValidator, wxT("WxChoice7"));
	WxChoice7->SetSelection(-1);

	WxNoteBookPage7 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE7, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage7, wxT("Indicators"));

	WxStaticBox8 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX8, wxT("Voice"), wxPoint(1,32), wxSize(193,54));

	WxStaticBox9 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX9, wxT("Fax"), wxPoint(196,32), wxSize(194,54));

	WxStaticBox10 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX10, wxT("Email"), wxPoint(1,87), wxSize(193,65));

	wxArrayString arrayStringFor_WxChoice1;
	arrayStringFor_WxChoice1.Add(wxT("Don't set"));
	arrayStringFor_WxChoice1.Add(wxT("Disable"));
	WxChoice1 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE1, wxPoint(55,54), wxSize(133,21), arrayStringFor_WxChoice1, 0, wxDefaultValidator, wxT("WxChoice1"));
	WxChoice1->SetSelection(-1);

	WxStaticText5 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT5, wxT("State"), wxPoint(10,51), wxDefaultSize, 0, wxT("WxStaticText5"));

	WxStaticBox11 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX11, wxT("Other"), wxPoint(196,87), wxSize(193,65));

	WxStaticText6 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT6, wxT("State"), wxPoint(206,57), wxDefaultSize, 0, wxT("WxStaticText6"));

	wxArrayString arrayStringFor_WxChoice2;
	arrayStringFor_WxChoice2.Add(wxT("Don't set"));
	arrayStringFor_WxChoice2.Add(wxT("Disable"));
	WxChoice2 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE2, wxPoint(249,53), wxSize(133,21), arrayStringFor_WxChoice2, 0, wxDefaultValidator, wxT("WxChoice2"));
	WxChoice2->SetSelection(-1);

	WxStaticText7 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT7, wxT("State"), wxPoint(8,110), wxDefaultSize, 0, wxT("WxStaticText7"));

	wxArrayString arrayStringFor_WxChoice3;
	arrayStringFor_WxChoice3.Add(wxT("Don't set"));
	arrayStringFor_WxChoice3.Add(wxT("Disable"));
	WxChoice3 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE3, wxPoint(55,107), wxSize(134,21), arrayStringFor_WxChoice3, 0, wxDefaultValidator, wxT("WxChoice3"));
	WxChoice3->SetSelection(-1);

	wxArrayString arrayStringFor_WxChoice4;
	arrayStringFor_WxChoice4.Add(wxT("Don't set"));
	arrayStringFor_WxChoice4.Add(wxT("Disable"));
	WxChoice4 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE4, wxPoint(249,105), wxSize(132,21), arrayStringFor_WxChoice4, 0, wxDefaultValidator, wxT("WxChoice4"));
	WxChoice4->SetSelection(-1);

	WxStaticText10 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT10, wxT("State"), wxPoint(205,106), wxDefaultSize, 0, wxT("WxStaticText10"));

	WxStaticText16 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT16, wxT("Format"), wxPoint(3,7), wxDefaultSize, 0, wxT("WxStaticText16"));

	wxArrayString arrayStringFor_WxComboBox5;
	arrayStringFor_WxComboBox5.Add(wxT("GSM 3.40"));
	WxComboBox5 = new wxComboBox(WxNoteBookPage7, ID_WXCOMBOBOX5, wxT("WxComboBox5"), wxPoint(56,4), wxSize(131,21), arrayStringFor_WxComboBox5, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox5"));

	WxNoteBookPage9 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE9, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage9, wxT("Smart Messaging"));

	WxStaticBox18 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX18, wxT("Bitmap"), wxPoint(2,27), wxSize(381,128));

	WxStaticBox17 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX17, wxT("Text"), wxPoint(2,160), wxSize(381,126));

	WxStaticText13 = new wxStaticText(WxNoteBookPage9, ID_WXSTATICTEXT13, wxT("Format"), wxPoint(10,5), wxDefaultSize, 0, wxT("WxStaticText13"));

	wxArrayString arrayStringFor_WxComboBox2;
	arrayStringFor_WxComboBox2.Add(wxT("Nokia picture image"));
	WxComboBox2 = new wxComboBox(WxNoteBookPage9, ID_WXCOMBOBOX2, wxT("WxComboBox2"), wxPoint(66,2), wxSize(217,21), arrayStringFor_WxComboBox2, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox2"));

	WxMemo1 = new wxTextCtrl(WxNoteBookPage9, ID_WXMEMO1, wxT(""), wxPoint(8,178), wxSize(365,79), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo1"));
	WxMemo1->SetMaxLength(0);
	WxMemo1->SetFocus();
	WxMemo1->SetInsertionPointEnd();

	WxButton1 = new wxButton(WxNoteBookPage9, ID_WXBUTTON1, wxT("Load"), wxPoint(320,41), wxSize(52,23), 0, wxDefaultValidator, wxT("WxButton1"));

	wxBitmap WxBitmapButton1_BITMAP (wxNullBitmap);
	WxBitmapButton1 = new wxBitmapButton(WxNoteBookPage9, ID_WXBITMAPBUTTON1, WxBitmapButton1_BITMAP, wxPoint(9,69), wxSize(219,74), wxSIMPLE_BORDER | wxSUNKEN_BORDER | wxNO_BORDER | wxBU_AUTODRAW, wxDefaultValidator, wxT("WxBitmapButton1"));
	WxBitmapButton1->SetToolTip(wxT("Image preview"));

	wxArrayString arrayStringFor_WxChoice9;
	WxChoice9 = new wxChoice(WxNoteBookPage9, ID_WXCHOICE9, wxPoint(10,43), wxSize(219,21), arrayStringFor_WxChoice9, 0, wxDefaultValidator, wxT("WxChoice9"));
	WxChoice9->SetSelection(-1);

	WxCheckBox2 = new wxCheckBox(WxNoteBookPage9, ID_WXCHECKBOX2, wxT("Use Unicode alphabet (unsupported by some Nokia models)"), wxPoint(8,260), wxSize(365,17), 0, wxDefaultValidator, wxT("WxCheckBox2"));

	WxStaticBox19 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX19, wxT("Text preview in recipients' phone(s)"), wxPoint(2,290), wxSize(381,101));

	WxMemo2 = new wxTextCtrl(WxNoteBookPage9, ID_WXMEMO2, wxT(""), wxPoint(9,310), wxSize(364,72), wxTE_READONLY | wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo2"));
	WxMemo2->SetMaxLength(0);
	WxMemo2->SetFocus();
	WxMemo2->SetInsertionPointEnd();

	WxNoteBookPage10 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE10, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage10, wxT("File transfer"));

	WxStaticText14 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT14, wxT("Format"), wxPoint(2,8), wxDefaultSize, 0, wxT("WxStaticText14"));

	wxArrayString arrayStringFor_WxComboBox3;
	arrayStringFor_WxComboBox3.Add(wxT("Nokia calendar (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Nokia phonebook (vcf)"));
	arrayStringFor_WxComboBox3.Add(wxT("Nokia todo (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens calendar (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens phonebook (vcf)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens note (vnt)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens todo (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens (bmp, mid or other)"));
	arrayStringFor_WxComboBox3.Add(wxT("EMS sound (IMelody)"));
	WxComboBox3 = new wxComboBox(WxNoteBookPage10, ID_WXCOMBOBOX3, wxT("WxComboBox3"), wxPoint(78,6), wxSize(305,21), arrayStringFor_WxComboBox3, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox3"));

	WxButton2 = new wxButton(WxNoteBookPage10, ID_WXBUTTON2, wxT("Load"), wxPoint(304,34), wxSize(77,23), 0, wxDefaultValidator, wxT("WxButton2"));

	WxStaticText15 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT15, wxT("File name"), wxPoint(2,38), wxDefaultSize, 0, wxT("WxStaticText15"));
	WxStaticText15->Enable(false);

	WxEdit3 = new wxTextCtrl(WxNoteBookPage10, ID_WXEDIT3, wxT(""), wxPoint(78,34), wxSize(219,22), 0, wxDefaultValidator, wxT("WxEdit3"));
	WxEdit3->Enable(false);

	WxMemo3 = new wxTextCtrl(WxNoteBookPage10, ID_WXMEMO3, wxT(""), wxPoint(78,67), wxSize(304,257), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo3"));
	WxMemo3->SetMaxLength(0);
	WxMemo3->Enable(false);
	WxMemo3->SetFocus();
	WxMemo3->SetInsertionPointEnd();

	WxStaticText17 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT17, wxT("File text"), wxPoint(2,68), wxDefaultSize, 0, wxT("WxStaticText17"));
	WxStaticText17->Enable(false);

	WxNoteBookPage5 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE5, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage5, wxT("PhoneBook"));

	WxStaticBox4 = new wxStaticBox(WxNoteBookPage5, ID_WXSTATICBOX4, wxT("Original entry"), wxPoint(7,6), wxSize(379,164));

	WxStaticBox12 = new wxStaticBox(WxNoteBookPage5, ID_WXSTATICBOX12, wxT("Saved in SMS"), wxPoint(7,172), wxSize(380,181));

	WxStaticText4 = new wxStaticText(WxNoteBookPage5, ID_WXSTATICTEXT4, wxT("Format"), wxPoint(14,189), wxDefaultSize, 0, wxT("WxStaticText4"));

	wxArrayString arrayStringFor_WxChoice5;
	arrayStringFor_WxChoice5.Add(wxT("Nokia phonebook (VCARD 1.0)"));
	arrayStringFor_WxChoice5.Add(wxT("Nokia phonebook (VCARD 2.1)"));
	arrayStringFor_WxChoice5.Add(wxT("Siemens phonebook"));
	WxChoice5 = new wxChoice(WxNoteBookPage5, ID_WXCHOICE5, wxPoint(69,187), wxSize(199,21), arrayStringFor_WxChoice5, 0, wxDefaultValidator, wxT("WxChoice5"));
	WxChoice5->SetSelection(-1);

	WxListCtrl2 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL2, wxPoint(16,216), wxSize(366,129), wxLC_REPORT);
	WxListCtrl2->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl2->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl3 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL3, wxPoint(12,28), wxSize(367,131), wxLC_REPORT);
	WxListCtrl3->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl3->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxNoteBookPage4 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE4, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage4, wxT("Calendar"));

	WxStaticBox13 = new wxStaticBox(WxNoteBookPage4, ID_WXSTATICBOX13, wxT("Original entry"), wxPoint(3,4), wxSize(383,167));

	WxStaticBox14 = new wxStaticBox(WxNoteBookPage4, ID_WXSTATICBOX14, wxT("Saved in SMS"), wxPoint(3,175), wxSize(382,167));

	WxListCtrl1 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL1, wxPoint(10,25), wxSize(367,138), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl1->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl4 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL4, wxPoint(10,218), wxSize(366,117), wxLC_REPORT);
	WxListCtrl4->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl4->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	wxArrayString arrayStringFor_WxChoice6;
	arrayStringFor_WxChoice6.Add(wxT("Nokia Calendar"));
	arrayStringFor_WxChoice6.Add(wxT("Siemens Calendar"));
	WxChoice6 = new wxChoice(WxNoteBookPage4, ID_WXCHOICE6, wxPoint(121,190), wxSize(154,21), arrayStringFor_WxChoice6, 0, wxDefaultValidator, wxT("WxChoice6"));
	WxChoice6->SetSelection(-1);

	WxStaticText3 = new wxStaticText(WxNoteBookPage4, ID_WXSTATICTEXT3, wxT("Format"), wxPoint(12,191), wxDefaultSize, 0, wxT("WxStaticText3"));

	WxNoteBookPage8 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE8, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage8, wxT("ToDo"));

	WxStaticBox15 = new wxStaticBox(WxNoteBookPage8, ID_WXSTATICBOX15, wxT("Original entry"), wxPoint(7,8), wxSize(379,166));

	WxStaticBox16 = new wxStaticBox(WxNoteBookPage8, ID_WXSTATICBOX16, wxT("Saved in SMS"), wxPoint(7,180), wxSize(378,168));

	WxListCtrl5 = new wxListCtrl(WxNoteBookPage8, ID_WXLISTCTRL5, wxPoint(13,26), wxSize(364,137), wxLC_REPORT);
	WxListCtrl5->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl5->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl6 = new wxListCtrl(WxNoteBookPage8, ID_WXLISTCTRL6, wxPoint(13,218), wxSize(365,123), wxLC_REPORT);
	WxListCtrl6->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl6->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxStaticText12 = new wxStaticText(WxNoteBookPage8, ID_WXSTATICTEXT12, wxT("Format"), wxPoint(14,196), wxDefaultSize, 0, wxT("WxStaticText12"));

	wxArrayString arrayStringFor_WxChoice8;
	arrayStringFor_WxChoice8.Add(wxT("Nokia ToDo"));
	arrayStringFor_WxChoice8.Add(wxT("Siemens ToDo"));
	WxChoice8 = new wxChoice(WxNoteBookPage8, ID_WXCHOICE8, wxPoint(71,195), wxSize(157,21), arrayStringFor_WxChoice8, 0, wxDefaultValidator, wxT("WxChoice8"));
	WxChoice8->SetSelection(-1);

	WxNoteBookPage11 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE11, wxPoint(4,24), wxSize(392,458));
	WxNotebook1->AddPage(WxNoteBookPage11, wxT("Note"));

	WxStaticBox20 = new wxStaticBox(WxNoteBookPage11, ID_WXSTATICBOX20, wxT("Original entry"), wxPoint(2,5), wxSize(382,182));

	WxStaticBox21 = new wxStaticBox(WxNoteBookPage11, ID_WXSTATICBOX21, wxT("Saved in SMS"), wxPoint(2,198), wxSize(383,183));

	WxListCtrl7 = new wxListCtrl(WxNoteBookPage11, ID_WXLISTCTRL7, wxPoint(11,24), wxSize(367,153), wxLC_REPORT);
	WxListCtrl7->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl7->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl8 = new wxListCtrl(WxNoteBookPage11, ID_WXLISTCTRL8, wxPoint(10,248), wxSize(370,124), wxLC_REPORT);
	WxListCtrl8->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl8->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxStaticText18 = new wxStaticText(WxNoteBookPage11, ID_WXSTATICTEXT18, wxT("Format"), wxPoint(11,220), wxDefaultSize, 0, wxT("WxStaticText18"));

	wxArrayString arrayStringFor_WxChoice10;
	arrayStringFor_WxChoice10.Add(wxT("Siemens note"));
	WxChoice10 = new wxChoice(WxNoteBookPage11, ID_WXCHOICE10, wxPoint(74,219), wxSize(166,21), arrayStringFor_WxChoice10, 0, wxDefaultValidator, wxT("WxChoice10"));
	WxChoice10->SetSelection(-1);

	WxNoteBookPage3 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE3, wxPoint(4,24), wxSize(409,488));
	WxNotebook2->AddPage(WxNoteBookPage3, wxT("Sending options"));

	WxStaticBox5 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX5, wxT("New recipient"), wxPoint(4,9), wxSize(398,74));

	NewRecipientAddWxButton = new wxButton(WxNoteBookPage3, ID_NEWRECIPIENTADDWXBUTTON, wxT("Add"), wxPoint(287,27), wxSize(107,23), 0, wxDefaultValidator, wxT("NewRecipientAddWxButton"));
	NewRecipientAddWxButton->Enable(false);

	NewRecipientWxEdit = new wxTextCtrl(WxNoteBookPage3, ID_NEWRECIPIENTWXEDIT, wxT(""), wxPoint(15,27), wxSize(263,23), 0, wxDefaultValidator, wxT("NewRecipientWxEdit"));

	WxStaticBox6 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX6, wxT("Current recipients"), wxPoint(3,85), wxSize(400,164));

	RecipientsWxListCtrl = new wxListCtrl(WxNoteBookPage3, ID_RECIPIENTSWXLISTCTRL, wxPoint(13,106), wxSize(264,135), wxLC_REPORT | wxLC_NO_HEADER);
	RecipientsWxListCtrl->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	RecipientsWxListCtrl->InsertColumn(0,wxT("Number"),wxLIST_FORMAT_LEFT,100 );

	WxButton6 = new wxButton(WxNoteBookPage3, ID_WXBUTTON6, wxT("Add from phonebook"), wxPoint(287,52), wxSize(107,22), 0, wxDefaultValidator, wxT("WxButton6"));

	RecipientDeleteWxButton = new wxButton(WxNoteBookPage3, ID_RECIPIENTDELETEWXBUTTON, wxT("Delete"), wxPoint(287,106), wxSize(106,21), 0, wxDefaultValidator, wxT("RecipientDeleteWxButton"));
	RecipientDeleteWxButton->Enable(false);

	WxStaticBox7 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX7, wxT("Other"), wxPoint(2,250), wxSize(399,77));

	WxStaticText2 = new wxStaticText(WxNoteBookPage3, ID_WXSTATICTEXT2, wxT("SMS center"), wxPoint(11,264), wxDefaultSize, 0, wxT("WxStaticText2"));

	wxArrayString arrayStringFor_SMSCWxComboBox;
	SMSCWxComboBox = new wxComboBox(WxNoteBookPage3, ID_SMSCWXCOMBOBOX, wxT("SMSCWxComboBox"), wxPoint(74,260), wxSize(202,21), arrayStringFor_SMSCWxComboBox, wxCB_DROPDOWN | wxCB_READONLY | wxTE_READONLY, wxDefaultValidator, wxT("SMSCWxComboBox"));

	ReportWxCheckBox = new wxCheckBox(WxNoteBookPage3, ID_REPORTWXCHECKBOX, wxT("Delivery reports (no extra costs)"), wxPoint(10,305), wxSize(314,19), 0, wxDefaultValidator, wxT("ReportWxCheckBox"));

	WxStaticText1 = new wxStaticText(WxNoteBookPage3, ID_WXSTATICTEXT1, wxT("Validity"), wxPoint(11,285), wxDefaultSize, 0, wxT("WxStaticText1"));

	wxArrayString arrayStringFor_ValidityWxComboBox;
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 hour"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("6 hours"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 day"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("3 days"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 week"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("Max time"));
	ValidityWxComboBox = new wxComboBox(WxNoteBookPage3, ID_VALIDITYWXCOMBOBOX, wxT("ValidityWxComboBox"), wxPoint(74,283), wxSize(202,21), arrayStringFor_ValidityWxComboBox, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("ValidityWxComboBox"));

	CancelWxButton = new wxButton(WxPanel1, ID_CANCELWXBUTTON, wxT("Cancel"), wxPoint(430,115), wxSize(137,26), 0, wxDefaultValidator, wxT("CancelWxButton"));

	SendWxButton = new wxButton(WxPanel1, ID_SENDWXBUTTON, wxT("Send"), wxPoint(431,26), wxSize(136,25), 0, wxDefaultValidator, wxT("SendWxButton"));
	SendWxButton->Enable(false);

	WxOpenFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxOPEN);

	SetTitle(wxT("Untitled1"));
	SetIcon(wxNullIcon);
	SetSize(8,8,582,552);
	Center();
	
	////GUI Items Creation End
}

void SMSEditorDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

void SMSEditorDlg::SetInfo()
{
    char                   buff[200];
	GSM_SMSListSubEntry    *SubEntry;
	int                    Parts=0;
	long item;

     item = RecipientsWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

	RecipientDeleteWxButton->Enable((RecipientsWxListCtrl->GetItemCount()!=0 && item!=-1));

    SubEntry = NULL;
    while (List->GetNext(&SubEntry)) Parts++;

    if (RecipientsWxListCtrl->GetItemCount()!=0 && Parts!=0) {
    	SendWxButton->Enable(TRUE);
    } else {
    	SendWxButton->Enable(FALSE);
    }
    sprintf(buff,"Send %i SMS (%i parts)",Parts*RecipientsWxListCtrl->GetItemCount(),Parts);
    SendWxButton->SetLabel(buff);
}

/*
 * CancelWxButtonClick
 */
void SMSEditorDlg::CancelWxButtonClick(wxCommandEvent& event)
{
	EndModal(wxID_CANCEL);
}

/*
 * RecipientDeleteWxButtonClick
 */
void SMSEditorDlg::RecipientDeleteWxButtonClick(wxCommandEvent& event)
{
    long item=-1;

    for (;;) {
        item = RecipientsWxListCtrl->GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
        if (item==-1) break;
        RecipientsWxListCtrl->DeleteItem(item);
        item=-1;
    }
    SetInfo();
}

/*
 * SendWxButtonClick
 */
void SMSEditorDlg::SendWxButtonClick(wxCommandEvent& event)
{
	GSM_SMSListSubEntry *SMS2;
    
	SMS2 = NULL;
	while (List->GetNext(&SMS2) == TRUE) {
    	SMS2->GetSMS()->SetType(SMS_Submit);

        SMS2->GetSMS()->SetSMSCNumber((wchar_t *)((const wchar_t *)SMSCWxComboBox->GetValue().wc_str(wxConvLibc)));

        switch (ValidityWxComboBox->GetCurrentSelection()) {
            case 0:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Hour);break;
            case 1:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_6_Hours);break;
            case 2:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Day);break;
            case 3:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_3_Days);break;
            case 4:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Week);break;
            case 5:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_Max_Time);break;
        }

    	if (ReportWxCheckBox->GetValue()) SMS2->GetSMS()->SetReportRequest(TRUE);
    }        
	EndModal(wxID_OK);
}

/*
 * NewRecipientAddWxButtonClick
 */
void SMSEditorDlg::NewRecipientAddWxButtonClick(wxCommandEvent& event)
{
    long tmp;

    tmp = RecipientsWxListCtrl->InsertItem((num)++, NewRecipientWxEdit->GetValue(), 0);
    SetInfo();
}

/*
 * NewRecipientWxEditUpdated
 */
void SMSEditorDlg::NewRecipientWxEditUpdated(wxCommandEvent& event)
{
	NewRecipientAddWxButton->Enable((NewRecipientWxEdit->GetValue()!=""));
}

/*
 * WxChoice1Selected
 */
void SMSEditorDlg::WxChoice1Selected(wxCommandEvent& event )
{
    Indicators();
}

void SMSEditorDlg::Indicators()
{
    GSM_Error                   error;
    int                         left;
    GSM_SMSEntry                SMS;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    BOOLEAN                     added = FALSE;
    GSM_SMSMMSDecodedEntry      Decoded;    

    List->ClearAll();

    if (WxChoice1->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Voice_Indicator;
        Decoded2->IntVal = WxChoice1->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice2->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Fax_Indicator;
        Decoded2->IntVal = WxChoice2->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice3->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Email_Indicator;
        Decoded2->IntVal = WxChoice3->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice4->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Other_Indicator;
        Decoded2->IntVal = WxChoice4->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }

    if (!added) {
        SetInfo();        
        return;
    }
    
    error = Decoded.SaveToSMS(List, SMS_Indicators, &left);
    
    SetInfo();    
}

/*
 * WxChoice2Selected
 */
void SMSEditorDlg::WxChoice2Selected(wxCommandEvent& event )
{
Indicators();
}

/*
 * WxChoice3Selected
 */
void SMSEditorDlg::WxChoice3Selected(wxCommandEvent& event )
{
    Indicators();
}

/*
 * WxChoice4Selected
 */
void SMSEditorDlg::WxChoice4Selected(wxCommandEvent& event )
{
    Indicators();
}

void SMSEditorDlg::WAPBookmark()
{
    GSM_Error                   error;
    int                         left;
    GSM_SMSEntry                SMS;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    wchart                      dest;

    if (start) return;

    List->ClearAll();

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_SMS_URL;
    Decoded2->Text.append(WxEdit1->GetValue().wc_str(wxConvLibc));
    Decoded2->Text2.append(WxEdit2->GetValue().wc_str(wxConvLibc));
    Decoded.Add(Decoded2);

    switch (WxChoice7->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_WAP_Bookmark, &left);
        break;
    case 1:
        error = Decoded.SaveToSMS(List, SMS_WAP_Push, &left);
        break;
    }
    PrintError (error);

    SetInfo();
}


/*
 * WxChoice7Selected
 */
void SMSEditorDlg::WxChoice7Selected(wxCommandEvent& event )
{
    WAPBookmark();
}

/*
 * WxEdit1Updated1
 */
void SMSEditorDlg::WxEdit1Updated1(wxCommandEvent& event)
{
    WAPBookmark();
}

/*
 * WxEdit2Updated
 */
void SMSEditorDlg::WxEdit2Updated(wxCommandEvent& event)
{
    WAPBookmark();
}

void SMSEditorDlg::SendPBK(GSM_PBKEntry *PBK)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_PBKSubEntry         *SubEntry;
    int                     EntryNum=0;
    wchart                  x;
    long                    tmp;
    char                    type[50];
    wchar_t                 Value[500];
    BOOLEAN                 FirstNum = true;
	GSM_SMSList		        List;

    DeleteP("Calendar");
    DeleteP("Text SMS/EMS");    
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Smart Messaging");
    DeleteP("File transfer");
    DeleteP("Note");

    PBK2 = PBK;    
    
    SubEntry = NULL;
    while (PBK2->GetNext(&SubEntry)) {
        DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
        tmp = WxListCtrl3->InsertItem(EntryNum++, type, 0);
        WxListCtrl3->SetItemData(tmp, 0);
        WxListCtrl3->SetItem(tmp, 1, Value);
    } 
    
    WxChoice5->Select(1);   
    SelectPBK();
}

/*
 * WxChoice5Selected
 */
void SMSEditorDlg::WxChoice5Selected(wxCommandEvent& event )
{
    SelectPBK();
}

void SMSEditorDlg::SelectPBK()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    switch (WxChoice5->GetCurrentSelection()) {
    case 0:
        error = PBK2->EncodeToVCARD(&txt, VCARD_10);
        break;
    case 1:
    case 2:
        error = PBK2->EncodeToVCARD(&txt, VCARD_21);
        break;
    }

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vCard"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                   wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice5->GetCurrentSelection()) {
    case 0:
    case 1:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCARD, &left);
        break;
    case 2:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("Pbk.vcf"),7);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }
    
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendCalendar(GSM_CalendarEntry *Cal)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    wchart                  x;
	GSM_SMSList		        List;

    DeleteP("PhoneBook");
    DeleteP("Text SMS/EMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Smart Messaging");
    DeleteP("File transfer");
    DeleteP("Note");

    Cal2 = Cal;

    DisplayCalendar2(Cal2, WxListCtrl1);

    WxChoice6->Select(0);
    SelectCalendar();
}

/*
 * WxChoice6Selected
 */
void SMSEditorDlg::WxChoice6Selected(wxCommandEvent& event )
{
    SelectCalendar();
}

void SMSEditorDlg::SelectCalendar()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = Cal2->EncodeToVCALENDAR(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vCalendar"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                   wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice6->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCALENDAR, &left);
        break;
    case 1:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("Cal.vcs"),7);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    } 
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendNote(GSM_NoteEntry *Not)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    wchart                  x;
	GSM_SMSList		        List;

    DeleteP("PhoneBook");
    DeleteP("Text SMS/EMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Smart Messaging");
    DeleteP("File transfer");
    DeleteP("Calendar");

    Note2 = Not;

    DisplayNote2(Note2, WxListCtrl7);

    WxChoice10->Select(0);
    SelectNote();
}


void SMSEditorDlg::SelectNote()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = Note2->EncodeToVNOTE(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vNote"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
    Decoded2->File.Info.Name.append(StringToUnicodeReturn("Note.vnt"),8);
    error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendToDo(GSM_ToDoEntry *ToDo)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_ToDoSubEntry        *SubEntry;
    wchart                  x;
	GSM_SMSList		        List;
    wchart                  Text;
    long                    EntryNum = 0, tmp;
    char                    buff3[200];
    wchart                  buff4;
    
    DeleteP("PhoneBook");
    DeleteP("Text SMS/EMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("Calendar");
    DeleteP("Smart Messaging");
    DeleteP("File transfer");
    DeleteP("Note");

    ToDo2 = ToDo;

    SubEntry = NULL;
    while (ToDo->GetNext(&SubEntry)) {
        DecodeToDoSubEntry(SubEntry, buff3, &buff4);
        tmp = WxListCtrl5->InsertItem(EntryNum++, buff3, 0);
        WxListCtrl5->SetItem(tmp, 1, buff4.data());
    }
        
    WxChoice8->Select(0);
    SelectToDo();
}


/*
 * WxChoice8Selected
 */
void SMSEditorDlg::WxChoice8Selected(wxCommandEvent& event )
{
	SelectToDo();
}

void SMSEditorDlg::SelectToDo()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = ToDo2->EncodeToVTODO(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vTodo"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                  wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice8->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VTODO, &left);
        break;
    case 1:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("ToDo.vcs"),8);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }                   
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::Image()
{
    GSM_File                    File;
    int                         x,y,left,i;
    wxImage                     *Img;
    wxBitmap                    *Bitmap,Bitmap2;
    Mono_Bitmap_FileSubEntry    *Sub;
    char                        buff[200];
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    GSM_Error                   error;
    GSM_SMSListSubEntry         *SMS2;
    wchart                      dest;

    Sub = NULL;
    for(i=0;i<WxChoice9->GetCurrentSelection()+1;i++) {
        MonoFile.GetNext(&Sub);
    }

    //preview
    Img = new wxImage(Sub->GetWidth()*2,Sub->GetHeight()*2,true);
    for (x=0;x<Sub->GetWidth();x++) {
        for (y=0;y<Sub->GetHeight();y++) {
            wxRect r(x,y,x+2,y+2);
            if (Sub->IsPointBlack(x,y)) {
                Img->SetRGB(r,99,207,99);
            } else {
                Img->SetRGB(r,1,1,1);
            }
        }
    }
    wxSize w(Sub->GetWidth(),Sub->GetHeight());
    wxPoint p;
    p.x = 0;
    p.y = 0;
    Img->Resize(w,p);
    Bitmap = new wxBitmap(*Img,-1);
    WxBitmapButton1->SetBitmapLabel(*Bitmap);
    delete Bitmap;
    delete Img;

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("image/bmp"));
    MonoFile.SaveToBMP(&Decoded2->File.Buffer,1);
    Decoded.Add(Decoded2);

    Decoded.SMSUnicode = WxCheckBox2->GetValue();

    if (WxMemo1->GetValue().size()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_MMSSMS_File;
        Decoded2->Text.append(StringToUnicodeReturn("text/plain"));
        UnicodeToUTF8((const wchar_t *)WxMemo1->GetValue().wc_str(wxConvLibc), &Decoded2->File.Buffer);
        Decoded.Add(Decoded2);
    }

    if (WxComboBox2->GetCurrentSelection()==0) {
        error = Decoded.SaveToSMS(List, SMS_Nokia_Picture, &left);
    } else {
        error = Decoded.SaveToSMS(List, SMS_Nokia_Profile, &left);
    }
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }
    sprintf(buff,"Text (%i SMS/%i chars left)",i,left);
    WxStaticBox17->SetLabel(buff);

    //preview
    Decoded.ClearAll();
    error=Decoded.ReadFromSMS(List);
    PrintError (error);    
    WxMemo2->Clear();
    Decoded2=NULL;
    while (Decoded.GetNext(&Decoded2)) {
        if (!strcmp(UnicodeToStringReturn(Decoded2->Text.data()),"text/plain")) {
            UTF8ToUnicode(Decoded2->File.Buffer.data(),&dest,Decoded2->File.Buffer.size());
            WxMemo2->AppendText(dest.data());
        }
    }
            
    return;
}

/*
 * WxButton1Click1
 */
void SMSEditorDlg::WxButton1Click1(wxCommandEvent& event)
{
    Mono_Bitmap_FileSubEntry    *Sub;
    int                         i = 1;
    char               buff[200];

    WxOpenFileDialog1->SetWildcard("Logo pictures|*.nlm;*.bmp|Nokia Logo Manager files|*.nlm");
    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;

    WxChoice9->Enable(FALSE);
    WxMemo1->Enable(FALSE);
    WxCheckBox2->Enable(FALSE);
    WxComboBox2->Enable(FALSE);

    MonoFileAvail=TRUE;
    if (!MonoFile.ReadFile((char *)WxOpenFileDialog1->GetPath().c_str())) return;

    Sub = NULL;
    while (MonoFile.GetNext(&Sub)) {
        sprintf(buff,"Frame %i",i);
        WxChoice9->Append(buff);
        i++;
    }
    
    if (i==1) return;
    
    WxChoice9->Enable(TRUE);
    WxMemo1->Enable(TRUE);
    WxCheckBox2->Enable(TRUE);
    WxComboBox2->Enable(TRUE);
    
    
    WxChoice9->Select(0);

    Image();
}


/*
 * WxMemo1Updated1
 */
void SMSEditorDlg::WxMemo1Updated1(wxCommandEvent& event)
{
    Image();
}

/*
 * WxCheckBox2Click
 */
void SMSEditorDlg::WxCheckBox2Click(wxCommandEvent& event)
{
    Image();
}

/*
 * WxChoice9Selected
 */
void SMSEditorDlg::WxChoice9Selected(wxCommandEvent& event )
{
	Image();
}

/*
 * WxButton2Click1
 */
void SMSEditorDlg::WxButton2Click1(wxCommandEvent& event)
{
    WxOpenFileDialog1->SetWildcard("");
    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;
    
    if (!FF.ReadFromDisk((wchar_t *)((const wchar_t *)WxOpenFileDialog1->GetPath().wc_str(wxConvLibc)))) return;

    FF.SetUnixEndLines();

    if (UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".txt"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vcs"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vcf"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vnt"))!=NULL ||
        WxComboBox3->GetCurrentSelection() == 8) {
            WxMemo3->SetValue(FF.Buffer.data());
            WxMemo3->Enable(TRUE);
            WxStaticText17->Enable(TRUE);
    } else {
            WxMemo3->SetValue("");
            WxMemo3->Enable(false);
            WxStaticText17->Enable(false);
    }
    WxEdit3->SetValue(FF.Info.Name.data());
     
    FileTransfer();
}

void SMSEditorDlg::FileTransfer()
{
    GSM_File                    File;
    int                         left;
    wxBitmap                    Bitmap2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    GSM_Error                   error;
    wchart                      dest;

    if (UpdatingFileTransfer) return;
    if (FF.Buffer.size()==0) return;
    UpdatingFileTransfer=TRUE;

    List->ClearAll();

    WxEdit3->Enable((WxComboBox3->GetCurrentSelection()>2 && WxComboBox3->GetCurrentSelection()!=8));
    WxStaticText15->Enable((WxComboBox3->GetCurrentSelection()>2  && WxComboBox3->GetCurrentSelection()!=8));

    switch (WxComboBox3->GetCurrentSelection()) {
    case 3:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcs"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 4:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcf"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 5:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vnt"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 6:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcs"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    default:
        break;
    }
        
    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    if (WxMemo3->IsEnabled()) {
        Decoded2->File.Buffer.append((const unsigned char *)WxMemo3->GetValue().c_str(),strlen((const char *)WxMemo3->GetValue().c_str()));
    } else {
        Decoded2->File.Buffer.append(FF.Buffer.data(),FF.Buffer.size());
    }
    Decoded2->File.Info.Name.append((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),UnicodeLength((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc)));
    
    switch (WxComboBox3->GetCurrentSelection()) {
    case 0:
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vCalendar"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCALENDAR, &left);
        break;
    case 1: //phonebook
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vCard"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCARD, &left);
        break;
    case 2: //todo
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vTodo"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VTODO, &left);
        break;
    case 8://imelody
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vImelody"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_EMS_Short, &left);
        break;
    default:
        Decoded2->Text.append(StringToUnicodeReturn("text/plain"));
        Decoded.Add(Decoded2);        
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }
    SetInfo();

    UpdatingFileTransfer=FALSE;

    PrintError (error);
}

/*
 * WxComboBox3Selected
 */
void SMSEditorDlg::WxComboBox3Selected(wxCommandEvent& event )
{
    FileTransfer();
}

/*
 * WxEdit3Updated
 */
void SMSEditorDlg::WxEdit3Updated(wxCommandEvent& event)
{
    FileTransfer();
}

/*
 * WxMemo3Updated
 */
void SMSEditorDlg::WxMemo3Updated(wxCommandEvent& event)
{
    FileTransfer();
}

/*
 * WxButton6Click
 */
void SMSEditorDlg::WxButton6Click(wxCommandEvent& event)
{
    RecipientsDlg            *dialog;

    dialog = new RecipientsDlg(RecipientsWxListCtrl,s,Backup,this,-1,"",wxDefaultPosition,wxDefaultSize,RecipientsDlg_STYLE);

    if (dialog->ShowModal()!=wxID_OK) {
        dialog->Destroy();
        return;
    }

    SetInfo();    
    
    dialog->Destroy();
}

/*
 * RecipientsWxListCtrlSelected
 */
void SMSEditorDlg::RecipientsWxListCtrlSelected(wxListEvent& event)
{
    SetInfo();
}

/*
 * RecipientsWxListCtrlDeselected
 */
void SMSEditorDlg::RecipientsWxListCtrlDeselected(wxListEvent& event)
{
    SetInfo();
}

/*
 * WxCheckBox6Click
 */
void SMSEditorDlg::WxCheckBox6Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxCheckBox8Click
 */
void SMSEditorDlg::WxCheckBox8Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxCheckBox5Click
 */
void SMSEditorDlg::WxCheckBox5Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxCheckBox7Click
 */
void SMSEditorDlg::WxCheckBox7Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxCheckBox9Click
 */
void SMSEditorDlg::WxCheckBox9Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxCheckBox10Click
 */
void SMSEditorDlg::WxCheckBox10Click(wxCommandEvent& event)
{
    EMS2();
}

/*
 * WxComboBox7Updated
 */
void SMSEditorDlg::WxComboBox7Updated(wxCommandEvent& event )
{
    EMS2();
}

/*
 * WxComboBox8Selected
 */
void SMSEditorDlg::WxComboBox8Selected(wxCommandEvent& event )
{
    EMS2();
}
/*
 * WxChoice11Selected
 */
void SMSEditorDlg::WxChoice11Selected(wxCommandEvent& event )
{
    switch (WxChoice11->GetCurrentSelection()) {
        case 0:EMSSub->TextSize=MSG_Text_Size_Default;break;
        case 1:EMSSub->TextSize=MSG_Text_Size_Small;break;
        case 2:EMSSub->TextSize=MSG_Text_Size_Large;break;
    }
    
	EMS2();
}

/*
 * WxChoice12Selected
 */
void SMSEditorDlg::WxChoice12Selected(wxCommandEvent& event )
{
    switch (WxChoice12->GetCurrentSelection()) {
        case 0:EMSSub->TextAlign=MSG_Text_Align_Default;break;
        case 1:EMSSub->TextAlign=MSG_Text_Align_Left;break;
        case 2:EMSSub->TextAlign=MSG_Text_Align_Center;break;
        case 3:EMSSub->TextAlign=MSG_Text_Align_Right;break;
    }
                
	EMS2();
}

/*
 * WxCheckBox1Click1
 */
void SMSEditorDlg::WxCheckBox1Click1(wxCommandEvent& event)
{
    EMSSub->TextBold = WxCheckBox1->GetValue();
	EMS2();
}

/*
 * WxCheckBox3Click1
 */
void SMSEditorDlg::WxCheckBox3Click1(wxCommandEvent& event)
{
    EMSSub->TextItalic= WxCheckBox3->GetValue();    
	EMS2();
}

/*
 * WxCheckBox4Click
 */
void SMSEditorDlg::WxCheckBox4Click(wxCommandEvent& event)
{
    EMSSub->TextUnderline = WxCheckBox4->GetValue();    
	EMS2();
}

/*
 * WxCheckBox12Click
 */
void SMSEditorDlg::WxCheckBox12Click(wxCommandEvent& event)
{
    EMSSub->TextStrikethrough = WxCheckBox12->GetValue();
	EMS2();
}

/*
 * WxCheckBox13Click
 */
void SMSEditorDlg::WxCheckBox13Click(wxCommandEvent& event)
{
    EMSSub->DRMForwardLock=WxCheckBox13->GetValue();
	EMS2();
}

void SMSEditorDlg::AddEMSPart(SMS_UDH_Type Type)
{
    GSM_SMSMMSDecodedSubEntry *En;
    GSM_SMSMMSDecodedSubEntry *Sub;
    long num=0;
    
    Sub=NULL;
    while (EMS.GetNext(&Sub)) num++;
        
    En = new GSM_SMSMMSDecodedSubEntry;
    switch (Type) {
    case SMS_UDH_EMS_Text_Format:
        WxListBox1->Append("Text");
        
		En->Text.append(StringToUnicodeReturn("text/plain"));
		En->Text2.append(StringToUnicodeReturn("charset=utf8"));
		En->Type = MSG_MMSSMS_File;
		EMS.Add(En);        
        break;
    case SMS_UDH_EMS_Sound:
        WxListBox1->Append("Sound (IMelody)");

		En->Text.append(StringToUnicodeReturn("text/x-vImelody"));
		En->Text2.append(StringToUnicodeReturn("charset=utf8"));
		En->Type = MSG_MMSSMS_File;
		EMS.Add(En);
        break;
    case SMS_UDH_EMS_Animation_Predef:
        WxListBox1->Append("Predefined animation");

		En->Type = MSG_SMS_Animation_Predef;
		En->IntVal = 0;
		EMS.Add(En);
        break;
    case SMS_UDH_EMS_Sound_Predef:
        WxListBox1->Append("Predefined sound");

		En->Type = MSG_SMS_Sound_Predef;
		En->IntVal = 0;
		EMS.Add(En);
        break;        
    default:
        break;
    }  
}

void SMSEditorDlg::EMS2()
{
    GSM_Error                   error;
    char                        buff2[500];
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    wchart                      dest,dest2;

    List->ClearAll();

    EMS.SMSUnicode = WxCheckBox5->GetValue();

    if (WxCheckBox6->GetValue()) {
        error = EMS.SaveToSMS(List, SMS_EMS_Long, &left);
    } else {
        error = EMS.SaveToSMS(List, SMS_EMS_Short, &left);
    }
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }
    sprintf(buff2,"SMS sequence (%i SMS/%i chars left)",i,left);
    WxStaticBox22->SetLabel(buff2);

    WxCheckBox9->Enable((i<2));
    WxCheckBox10->Enable((i<2));
    WxComboBox7->Enable((WxCheckBox9->GetValue() && WxCheckBox9->IsEnabled()));
    WxComboBox8->Enable((WxCheckBox10->GetValue() && WxCheckBox10->IsEnabled()));

    WxCheckBox6->Enable((i>1));

    //preview  
    if (EMSSub->Type == MSG_MMSSMS_File) {
        WxMemo5->Clear();
        if (!strcmp(UnicodeToStringReturn(EMSSub->Text.data()),"text/plain")) {
            sprintf(buff2,"Text (%i chars)",0);
        } else {
            sprintf(buff2,"Ringtone text (%i chars)",0);
        }
        WxStaticBox23->SetLabel(buff2);
        if (EMSSub->SMSPackedNum!=-1) {
            Decoded.ClearAll();
            error=Decoded.ReadFromSMS(List);
            
            i=0;
            Decoded2=NULL;
            while (Decoded.GetNext(&Decoded2)) {
                i++;
                if (i==EMSSub->SMSPackedNum) break;
            }
            if (i!=EMSSub->SMSPackedNum) {
                sprintf(buff2,"error 1");
                WxStaticBox23->SetLabel(buff2);
            } else if (Decoded2->Type!=MSG_MMSSMS_File) {
                sprintf(buff2,"error 2");
                WxStaticBox23->SetLabel(buff2);
            } else {
                UTF8ToUnicode(Decoded2->File.Buffer.data(),&dest,Decoded2->File.Buffer.size());
                if (EMSSub->SMSPackedTextStartup+EMSSub->SMSPackedTextLength<=dest.size()) {
                    dest2.append(dest.data()+EMSSub->SMSPackedTextStartup,EMSSub->SMSPackedTextLength);
                    if (!strcmp(UnicodeToStringReturn(Decoded2->Text.data()),"text/plain")) {
                        WxMemo5->AppendText(dest2.data());
                    }
                    if (!strcmp(UnicodeToStringReturn(Decoded2->Text.data()),"text/plain")) {
                        sprintf(buff2,"Text (%i chars)",dest2.size());
                    } else {
                        sprintf(buff2,"Ringtone text (%i chars)",dest2.size());
                    }
                } else {
                    sprintf(buff2,"error 3");
                }
                WxStaticBox23->SetLabel(buff2);
            }
        }
    }
    
    SetInfo();

    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
    	SMS2->GetSMS()->SetType(SMS_Submit);
        if (WxCheckBox7->GetValue()) SMS2->GetSMS()->SetClass(0);
        if (WxCheckBox9->GetValue() && WxCheckBox9->IsEnabled()) {
            SMS2->GetSMS()->SetReplace(WxComboBox7->GetCurrentSelection());
        } else {
            SMS2->GetSMS()->SetReplace(-1);
        }
        if (WxCheckBox10->GetValue() && WxCheckBox10->IsEnabled()) {
            SMS2->GetSMS()->SetRejectDuplicates(TRUE);
            SMS2->GetSMS()->TPMR = WxComboBox8->GetCurrentSelection();
        } else {
            SMS2->GetSMS()->SetRejectDuplicates(FALSE);
        }
    	if (WxCheckBox8->GetValue()) SMS2->GetSMS()->SetSenderSMSCReply(TRUE);
    }
}

/*
 * WxMemo4Updated
 */
void SMSEditorDlg::WxMemo4Updated(wxCommandEvent& event)
{
    if (!EMSEdit) {
        EMSSub->File.Buffer.clear();
        UnicodeToUTF8((const wchar_t *)WxMemo4->GetValue().wc_str(wxConvLibc), &EMSSub->File.Buffer);
    }
    
    EMS2();
}

/*
 * WxButton3Click1
 */
void SMSEditorDlg::WxButton3Click1(wxCommandEvent& event)
{
    EMSAddDlg            *dialog;
    long                 item;
    
    dialog = new EMSAddDlg(this,-1,"",wxDefaultPosition,wxDefaultSize,EMSAddDlg_STYLE);

    if (dialog->ShowModal()!=wxID_OK) {
        dialog->Destroy();
        return;
    }

    item = dialog->WxListBox1->GetSelection();
    switch (item) {
        case 0: AddEMSPart(SMS_UDH_EMS_Text_Format);      break;
        case 1: AddEMSPart(SMS_UDH_EMS_Sound);            break;
        case 2: AddEMSPart(SMS_UDH_EMS_Animation_Predef); break;
        case 3: AddEMSPart(SMS_UDH_EMS_Sound_Predef);     break;
    }
        
    dialog->Destroy();
    
    WxListBox1->Select(WxListBox1->GetCount()-1);
    WxListBox1Selected(event);    
}

/*
 * WxButton9Click
 */
void SMSEditorDlg::WxButton9Click(wxCommandEvent& event)
{
    GSM_File file;
    
    WxOpenFileDialog1->SetWildcard("All files|*.*");
    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;

    if (!file.ReadFromDisk((wchar_t *)((const wchar_t *)WxOpenFileDialog1->GetFilename().wc_str(wxConvLibc)))) return;

    file.SetUnixEndLines();

    if (file.Buffer.size()!=0) {
        EMSSub->File.Buffer.clear();
        EMSSub->File.Buffer.append(file.Buffer.data(),file.Buffer.size());
        
        WxListBox1Selected(event);
    }
}

void SMSEditorDlg::EMSHide()
{
    //preview
    WxStaticBox25->Show(FALSE);
    WxMemo5->Show(FALSE);
    WxMemo5->Clear();
    WxBitmapButton2->Show(FALSE);

    //text
    WxStaticBox23->Show(FALSE);
    WxMemo4->Show(FALSE);
    WxButton9->Show(FALSE);
    WxCheckBox1->Show(FALSE);
    WxCheckBox3->Show(FALSE);
    WxCheckBox4->Show(FALSE);
    WxCheckBox12->Show(FALSE);
    WxCheckBox13->Show(FALSE);  
    WxCheckBox14->Show(FALSE);  
    WxChoice11->Show(FALSE);
    WxChoice12->Show(FALSE);
    WxStaticText20->Show(FALSE);
    WxStaticText21->Show(FALSE);

    //picture
    WxStaticBox24->Show(FALSE);
    WxButton8->Show(FALSE);
    WxCheckBox11->Show(FALSE);

    //default
    WxStaticBox26->Show(FALSE);
    WxComboBox6->Show(FALSE);
    WxStaticText19->Show(FALSE);
}
   
/*
 * WxListBox1Selected
 */
void SMSEditorDlg::WxListBox1Selected(wxCommandEvent& event)
{
    long                        item;
    long                        num=0;
    wchart                      dest;
    char                        buff2[50];

    EMSHide();

    item = WxListBox1->GetSelection();

    EMSSub=NULL;
    while (EMS.GetNext(&EMSSub)) {
        if (num==item) break;
        
        num++;
    }
    
    WxButton5->Enable(item > 0);
    WxButton7->Enable(EMSSub->GetNext()!=NULL);
    WxButton4->Enable(TRUE);

    switch (EMSSub->Type) {
    case MSG_MMSSMS_File:
        if (!wcscmp(EMSSub->Text.data(),StringToUnicodeReturn("text/plain")) ||
            !wcscmp(EMSSub->Text.data(),StringToUnicodeReturn("text/x-vImelody"))) {
            WxStaticBox23->Show(TRUE);
            WxMemo4->Show(TRUE);
            WxButton9->Show(TRUE);

            EMSEdit=TRUE;
            WxMemo4->Clear();
            if (EMSSub->File.Buffer.size()!=0) {
                UTF8ToUnicode(EMSSub->File.Buffer.data(),&dest,EMSSub->File.Buffer.size());
                WxMemo4->AppendText(dest.data());
            }
            EMSEdit=FALSE;
        }
        if (!wcscmp(EMSSub->Text.data(),StringToUnicodeReturn("text/plain"))) {
            //preview
            WxStaticBox25->Show(TRUE);
            WxMemo5->Show(TRUE);

            dest.clear();
            if (EMSSub->File.Buffer.size()!=0) {
                UTF8ToUnicode(EMSSub->File.Buffer.data(),&dest,EMSSub->File.Buffer.size());
            }
            sprintf(buff2,"Text (%i chars)",dest.size());
            WxStaticBox23->SetLabel(buff2);
            
            WxCheckBox1->Show(TRUE);
            WxCheckBox3->Show(TRUE);
            WxCheckBox4->Show(TRUE);
            WxCheckBox12->Show(TRUE);
            WxChoice11->Show(TRUE);
            WxChoice12->Show(TRUE);
            WxStaticText20->Show(TRUE);
            WxStaticText21->Show(TRUE);   
            
            WxCheckBox1->SetValue(EMSSub->TextBold);         
            WxCheckBox3->SetValue(EMSSub->TextItalic);
            WxCheckBox4->SetValue(EMSSub->TextUnderline);
            WxCheckBox12->SetValue(EMSSub->TextStrikethrough);
            
			switch (EMSSub->TextAlign) {
			case MSG_Text_Align_Default:WxChoice12->Select(0);break;
			case MSG_Text_Align_Left:WxChoice12->Select(1);break;
			case MSG_Text_Align_Center:WxChoice12->Select(2);break;
			case MSG_Text_Align_Right:WxChoice12->Select(3); break;
			}

			switch (EMSSub->TextSize) {
			case MSG_Text_Size_Default:WxChoice11->Select(0);break;
			case MSG_Text_Size_Small:WxChoice11->Select(1); break;
			case MSG_Text_Size_Large:WxChoice11->Select(2);break;
			}
        } else {
            dest.clear();
            if (EMSSub->File.Buffer.size()!=0) {
                UTF8ToUnicode(EMSSub->File.Buffer.data(),&dest,EMSSub->File.Buffer.size());
            }
            sprintf(buff2,"Ringtone text (%i chars)",dest.size());
            WxStaticBox23->SetLabel(buff2);
            
            WxCheckBox13->Show(TRUE);      
            WxCheckBox13->SetValue(EMSSub->DRMForwardLock);
            WxCheckBox14->Show(TRUE); 
        }
        break;
    case MSG_SMS_Animation_Predef:
        WxStaticBox26->Show(TRUE);
        WxComboBox6->Show(TRUE);
        WxStaticText19->Show(TRUE);        
        WxComboBox6->Clear();
        WxComboBox6->Append("0 (I am ironic, flirty");
        WxComboBox6->Append("1 (I am glad)");
        WxComboBox6->Append("2 (I am sceptic)");
        WxComboBox6->Append("3 (I am sad)");
        WxComboBox6->Append("4 (WOW!)");
        WxComboBox6->Append("5 (I am crying)");
        WxComboBox6->Select(EMSSub->IntVal);
        EMS2();
        break;
    case MSG_SMS_Sound_Predef:        
        WxStaticBox26->Show(TRUE);
        WxComboBox6->Show(TRUE);
        WxStaticText19->Show(TRUE);
        WxComboBox6->Clear();
        WxComboBox6->Append("0 (Chimes high)");
        WxComboBox6->Append("1 (Chimes low)");
        WxComboBox6->Append("2 (Ding)");
        WxComboBox6->Append("3 (TaDa)");
        WxComboBox6->Append("4 (Notify)");
        WxComboBox6->Append("5 (Drum)");
        WxComboBox6->Append("6 (Claps)");
        WxComboBox6->Append("7 (FanFare)");
        WxComboBox6->Append("8 (Chord high)");
        WxComboBox6->Append("9 (Chord low)");
        WxComboBox6->Select(EMSSub->IntVal);
        EMS2();
    default:
        break;
    }
}

/*
 * WxButton4Click
 */
void SMSEditorDlg::WxButton4Click(wxCommandEvent& event)
{
    long    i = WxListBox1->GetSelection();
    char    buff2[500];
    
    EMS.Remove(i+1);    
    WxListBox1->Delete(i);
    if (WxListBox1->GetCount()!=0) {
        if (i+1>WxListBox1->GetCount()) i--;
        WxListBox1->Select(i);
        WxListBox1Selected(event);
    } else {
        EMSHide();
        WxButton5->Enable(FALSE);
        WxButton7->Enable(FALSE);
        WxButton4->Enable(FALSE);     
        
        List->ClearAll();
        sprintf(buff2,"SMS sequence");
        WxStaticBox22->SetLabel(buff2);

        SetInfo();           
    }    
}

/*
 * WxButton5Click1
 */
void SMSEditorDlg::WxButton5Click1(wxCommandEvent& event)
{
    wxString x;

    EMS.MoveUp(WxListBox1->GetSelection()+1);
    x=WxListBox1->GetString(WxListBox1->GetSelection());
    WxListBox1->SetString(WxListBox1->GetSelection(), WxListBox1->GetString(WxListBox1->GetSelection()-1));
    WxListBox1->SetString(WxListBox1->GetSelection()-1, x);
    WxListBox1->Select(WxListBox1->GetSelection()-1);        
}

/*
 * WxButton7Click1
 */
void SMSEditorDlg::WxButton7Click1(wxCommandEvent& event)
{
    wxString x;
    
    EMS.MoveDown(WxListBox1->GetSelection()+1);
    x=WxListBox1->GetString(WxListBox1->GetSelection());
    WxListBox1->SetString(WxListBox1->GetSelection(), WxListBox1->GetString(WxListBox1->GetSelection()+1));
    WxListBox1->SetString(WxListBox1->GetSelection()+1, x); 
    WxListBox1->Select(WxListBox1->GetSelection()+1);   
}

/*
 * WxCheckBox14Click
 */
void SMSEditorDlg::WxCheckBox14Click(wxCommandEvent& event)
{
    WxCheckBox14->SetValue(TRUE);
}

/*
 * WxComboBox6Updated
 */
void SMSEditorDlg::WxComboBox6Updated(wxCommandEvent& event )
{
	EMSSub->IntVal = WxComboBox6->GetCurrentSelection();
	EMS2();
}
