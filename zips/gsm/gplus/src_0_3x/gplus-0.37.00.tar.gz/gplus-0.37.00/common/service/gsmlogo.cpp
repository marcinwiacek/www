/* (C) 2007 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>
#include <wctype.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#ifdef WIN32
#  include <sys/types.h>
#  ifndef BORLANDC
#    include <sys/utime.h>
#  endif
#else
#  include <netdb.h>
#  include <netinet/in.h>
#  include <utime.h>
#endif

#include "../../cfg/config.h" //msvc2005
#include "../misc/files.h"
#include "../misc/coding/coding.h"
#include "../misc/misc.h"
#include "gsmlogo.h"

static void PHONE_GetBitmapWidthHeight(GSM_Phone_Bitmap_Types Type, int *width, int *height)
{
	*width  = 0;
	*height	= 0;
	switch (Type) {
		case GSM_EMSSmallPicture	: *width=8;  *height=8;  break;
		case GSM_EMSMediumPicture	: *width=16; *height=16; break;
		case GSM_EMSBigPicture		: *width=32; *height=32; break;
		case GSM_NokiaOperatorLogo	:
		case GSM_NokiaCallerLogo	: *width=72; *height=14; break;
		case GSM_NokiaPictureImage	: *width=72; *height=28; break;
		case GSM_Nokia7110OperatorLogo	:
		case GSM_Nokia6510OperatorLogo	: *width=78; *height=21; break;
		case GSM_NokiaStartupLogo	: *width=84; *height=48; break;
		case GSM_Nokia6210StartupLogo	: *width=96; *height=60; break;
		case GSM_Nokia7110StartupLogo	: *width=96; *height=65; break;
		case GSM_EMSPicture	: 			 break;
		case GSM_AlcatelBMMIPicture	:			 break;
	}
}

int PHONE_GetBitmapSize(GSM_Phone_Bitmap_Types Type, int Width, int Height)
{
	int width, height, x;

	PHONE_GetBitmapWidthHeight(Type, &width, &height);
	if (width == 0 && height == 0) {
		width  = Width;
		height = Height;
	}
	switch (Type) {
		case GSM_Nokia6510OperatorLogo:
			x = width * height;
			return x/8 + (x%8 > 0);
		case GSM_Nokia7110OperatorLogo:
			return (width*height + 7)/8;
		case GSM_NokiaStartupLogo:
		case GSM_NokiaOperatorLogo:
		case GSM_NokiaCallerLogo:
		case GSM_NokiaPictureImage:
		case GSM_EMSSmallPicture:
		case GSM_EMSMediumPicture:
		case GSM_EMSBigPicture:
		case GSM_EMSPicture:
			return height*width/8;
		case GSM_Nokia7110StartupLogo:
		case GSM_Nokia6210StartupLogo:
			return (height+7)/8*width;
		case GSM_AlcatelBMMIPicture:
			return width*((height+7)/8);
	}
	return 0;
}

static void PHONE_SetPointBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring *buffer, int x, int y, int width, int height)
{
	int 		pixel,num;
	unsigned char 	chr;
	unsignedstring 	buffer2;

	switch (Type) {
	case GSM_NokiaStartupLogo:
	case GSM_Nokia6210StartupLogo:
	case GSM_Nokia7110StartupLogo:
	case GSM_Nokia6510OperatorLogo:
		num = (y/8*width)+x;
		chr = buffer->data()[num];
		chr |= 1 << (y%8);
		break;
	case GSM_NokiaOperatorLogo:
	case GSM_Nokia7110OperatorLogo:
	case GSM_NokiaCallerLogo:
	case GSM_EMSSmallPicture:
	case GSM_EMSMediumPicture:
	case GSM_EMSBigPicture:
	case GSM_EMSPicture:
		pixel = width*y + x;
		num = pixel/8;
		chr = buffer->data()[num];
		chr |= 1 << (7-(pixel%8));
		break;
	case GSM_NokiaPictureImage:
		num = 9*y + x/8;
		chr = buffer->data()[num];
		chr |= 1 << (7-(x%8));
		break;
	case GSM_AlcatelBMMIPicture:
		pixel = height / 8;
		if ((height % 8) != 0) pixel++;
		num = pixel*x + y/8;
		chr = buffer->data()[num];
		chr |= 1 << (7 - (y%8));
		break;
	}
	buffer2.push_back(chr);
	buffer->replace(num,1,buffer2);
}

static void PHONE_ClearBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring *buffer, int width, int height)
{
	int i;

	buffer->clear();
	for(i=0;i<PHONE_GetBitmapSize(Type,width,height);i++) buffer->push_back(0);
}

static BOOLEAN PHONE_IsPointBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring *buffer, int x, int y, int width, int height)
{
	int i=0, pixel;

	switch (Type) {
	case GSM_NokiaStartupLogo:
	case GSM_Nokia6210StartupLogo:
	case GSM_Nokia7110StartupLogo:
	case GSM_Nokia6510OperatorLogo:
		i=(buffer->data()[(y/8*width) + x] & 1<<(y%8));
		break;
	case GSM_NokiaOperatorLogo:
	case GSM_Nokia7110OperatorLogo:
	case GSM_NokiaCallerLogo:
	case GSM_EMSPicture:
	case GSM_EMSSmallPicture:
	case GSM_EMSMediumPicture:
	case GSM_EMSBigPicture:
		pixel=width*y + x;
		i=(buffer->data()[pixel/8] & 1<<(7-(pixel%8)));
		break;
	case GSM_NokiaPictureImage:
		i=(buffer->data()[9*y + x/8] & 1<<(7-(x%8)));
		break;
	case GSM_AlcatelBMMIPicture:
		break;
	}
	if (i) return true; else return false;
}

// ----------------------------------------------------------------------------

int Mono_Bitmap_FileSubEntry::GetWidth()
{
	return Width;
}

int Mono_Bitmap_FileSubEntry::GetHeight()
{
	return Height;
}

Mono_Bitmap_FileSubEntry::Mono_Bitmap_FileSubEntry(int W, int H)
{
	Width 	= W;
	Height 	= H;
	Next 	= NULL;
	ClearBitmap();
}

Mono_Bitmap_FileSubEntry::~Mono_Bitmap_FileSubEntry()
{
	delete(Next);
}

Mono_Bitmap_FileSubEntry *Mono_Bitmap_FileSubEntry::GetNext()
{
	return Next;
}

void Mono_Bitmap_FileSubEntry::SetNext(Mono_Bitmap_FileSubEntry *Nxt)
{
	Next = Nxt;
}

BOOLEAN Mono_Bitmap_FileSubEntry::IsPointBlack(int x, int y)
{
	if (GetBit(Data,y*Width+x)) return TRUE;
	return FALSE;
}

BOOLEAN	Mono_Bitmap_FileSubEntry::SetPointColor(int x, int y, BOOLEAN Black)
{
	if (x>Width) return FALSE;
	if (y>Height) return FALSE;
	if (Black) {
		SetBit(Data,y*Width+x);
	} else {
		ClearBit(Data,y*Width+x);
	}
	return TRUE;
}

void Mono_Bitmap_FileSubEntry::ClearBitmap()
{
	memset(Data,0,GetBitmapSize());
}

int Mono_Bitmap_FileSubEntry::GetBitmapSize()
{
	return Width*Height/8+1;
}

/* ------------------------------------------------------------------------ */

Mono_Bitmap_FileEntry::Mono_Bitmap_FileEntry()
{
	Entries = NULL;
}

Mono_Bitmap_FileEntry::~Mono_Bitmap_FileEntry()
{
	delete(Entries);
}

BOOLEAN Mono_Bitmap_FileEntry::GetNext(Mono_Bitmap_FileSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

void Mono_Bitmap_FileEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

BOOLEAN Mono_Bitmap_FileEntry::AddSubEntry(Mono_Bitmap_FileSubEntry *En)
{
	Mono_Bitmap_FileSubEntry *Entry2;

	if (Entries == NULL) {
		Entries = En;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(En);
	}
	return TRUE;
}

BOOLEAN Mono_Bitmap_FileEntry::ReadFromNLM(unsignedstring Buff)
{
	int 				pos,pos2,x,y,i,Pos, Width, Height,BN;
	div_t				division;
	Mono_Bitmap_FileSubEntry 	*Bitmap;

	if (Buff.size()<6) return FALSE;

	BN 	  = Buff.data()[6] + 1;
	Width     = Buff.data()[7];
	Height 	  = Buff.data()[8];
	Pos	  = 10;
	for (i=0;i<BN;i++) {
		Bitmap = new Mono_Bitmap_FileSubEntry(Width,Height);
		division=div(Width,8);
		/* For startup logos */
		if (division.rem!=0) division.quot++;
		if (Buff.size()-Pos<(unsigned int)(division.quot*Height)) return FALSE;
    
		pos=0;pos2=7;
		for (y=0;y<Height;y++) {
			for (x=0;x<Width;x++) {
				if ((Buff.data()[pos+Pos]&(1<<pos2))>0) {
					if (y<Height && x<Width) Bitmap->SetPointColor(x,y,TRUE);
				}
				pos2--;
				/* going to new byte */
				if (pos2<0) {pos2=7;pos++;}
			}
			/* for startup logos-new line means new byte */
			if (pos2!=7) {pos2=7;pos++;}
		}
		AddSubEntry(Bitmap);
	}
   	return TRUE;
}

BOOLEAN Mono_Bitmap_FileEntry::ReadFromPhoneBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring buffer, int Width, int Height)
{
	int 				x,y,width,height;
	Mono_Bitmap_FileSubEntry 	*Bitmap;

	PHONE_GetBitmapWidthHeight(Type, &width, &height);
	if (width==0 && height==0) {
		width=Width;
		height=Height;
	}

	Bitmap = new Mono_Bitmap_FileSubEntry(width,height);

	for (y=0;y<height;y++) {
		for (x=0;x<width;x++) {
			if (PHONE_IsPointBitmap(Type, &buffer, x, y, width, height))
				Bitmap->SetPointColor(x,y,TRUE);
		}
	}
	AddSubEntry(Bitmap);
   	return TRUE;
}

BOOLEAN Mono_Bitmap_FileEntry::ReadFile(char *FileName)
{
	if (!ReadFromDisk(StringToUnicodeReturn(FileName))) return FALSE;

	return ReadFromNLM(Buffer);
}

BOOLEAN	Mono_Bitmap_FileEntry::SaveToBMP(unsignedstring *Buff, int Frame)
{
	Mono_Bitmap_FileSubEntry    	*Sub;
	int				x,y,pos,i,sizeimage,buffpos=0;
	unsigned char			buff[1];
	div_t				division;
	unsigned char 			header[]={
/*1'st header*/   'B','M',             /* BMP file ID */
                  0x00,0x00,0x00,0x00, /* Size of file */
		  0x00,0x00,           /* Reserved for future use */
		  0x00,0x00,           /* Reserved for future use */
	            62,0x00,0x00,0x00, /* Offset for image data */

/*2'nd header*/     40,0x00,0x00,0x00, /* Length of this part of header */
		  0x00,0x00,0x00,0x00, /* Width of image */
		  0x00,0x00,0x00,0x00, /* Height of image */
		     1,0x00,           /* How many planes in target device */
		     1,0x00,           /* How many colors in image. 1 means 2^1=2 colors */
		  0x00,0x00,0x00,0x00, /* Type of compression. 0 means no compression */
/*Sometimes */    0x00,0x00,0x00,0x00, /* Size of part with image data */
/*ttttttt...*/    0xE8,0x03,0x00,0x00, /* XPelsPerMeter */
/*hhiiiiissss*/   0xE8,0x03,0x00,0x00, /* YPelsPerMeter */
/*part of header*/0x02,0x00,0x00,0x00, /* How many colors from palette is used */
/*doesn't exist*/ 0x00,0x00,0x00,0x00, /* How many colors from palette is required to display image. 0 means all */

/*Color palette*/ 0x00,0x00,0x00,      /* First color in palette in Blue, Green, Red. Here white */
		  0x00,                /* Each color in palette is end by 4'th byte */
                   102, 204, 102,      /* Second color in palette in Blue, Green, Red. Here green */
		  0x00};               /* Each color in palette is end by 4'th byte */

	i=0;
	Sub=NULL;
	while (true) {
		GetNext(&Sub);
		i++;
		if (Sub==NULL) return FALSE;
		if (i==Frame) break;
	}

	Buff->clear();

	header[18]=Sub->GetWidth();
	header[22]=Sub->GetHeight();

	pos	  = 7;
	sizeimage = 0;
	/*lines are written from the last to the first*/
	for (y=Sub->GetHeight()-1;y>=0;y--) {
		i=1;
		for (x=0;x<Sub->GetWidth();x++) {
			/*new byte !*/
			if (pos==7) {
				if (x!=0) sizeimage++;
				i++;
				/*each line is written in multiply of 4 bytes*/
				if(i==5) i=1;
			}
			pos--;
			/*going to new byte*/
			if (pos<0) pos=7;
		}
		/*going to new byte*/
		pos=7;
		sizeimage++;
		if (i!=1) {
			/*each line is written in multiply of 4 bytes*/
			while (i!=5) {
				sizeimage++;
				i++;
			}
		}
	}
	division=div(sizeimage,256);
	header[35]=division.quot;
	header[34]=sizeimage-(division.quot*256);
  	sizeimage=sizeimage+sizeof(header);
	division=div(sizeimage,256);
	header[3]=division.quot;
	header[2]=sizeimage-(division.quot*256);

	Buff->append(header,sizeof(header));

	pos=7;
	/*lines are written from the last to the first*/
	for (y=Sub->GetHeight()-1;y>=0;y--) {
		i=1;
		for (x=0;x<Sub->GetWidth();x++) {
			/*new byte !*/
			if (pos==7) {
				if (x!=0) {
					Buff->push_back(buff[0]);
				}
				i++;
				/*each line is written in multiply of 4 bytes*/
				if(i==5) i=1;
				buff[0]=0;
			}
			if (Sub->IsPointBlack(x,y)) buff[0]|=(1<<pos);
			pos--;
			/*going to new byte*/
			if (pos<0) pos=7;
		}
		/*going to new byte*/
		pos=7;
		Buff->push_back(buff[0]);
		if (i!=1) {
			/*each line is written in multiply of 4 bytes*/
			while (i!=5) {
				buff[0]=0;
				Buff->append(buff,sizeof(buff));
				i++;
			}
		}
	}
	return TRUE;
}

void Mono_Bitmap_FileSubEntry::SaveToPhoneBitmap(GSM_Phone_Bitmap_Types Type, unsignedstring *buffer)
{
	int		width, height, x, y;
//	GSM_Bitmap	dest;

	PHONE_GetBitmapWidthHeight(Type, &width, &height);
	if (width == 0 && height == 0) {
//		width  = Bitmap->BitmapWidth;
//		height = Bitmap->BitmapHeight;
	}
	PHONE_ClearBitmap(Type, buffer, width, height);

	for (x=0;x<width;x++) {
		for (y=0;y<height;y++) {
			if (!IsPointBlack(x,y)) PHONE_SetPointBitmap(Type, buffer, x, y, width, height);
		}
	}
}

BOOLEAN Mono_Bitmap_FileEntry::ReadFromBMP(unsignedstring Buff)
{
	Mono_Bitmap_FileSubEntry *Bitmap;
	bool		first_white,isfile=false;
	unsigned char 	buff[34];
	int		w,h,pos,y,x,i,buffpos=0;
#ifdef DEBUG
	int		sizeimage=0;
#endif

	if (Buff.size()<34) return FALSE;

	/* height and width of image in the file */
	h=Buff.data()[22]+256*Buff.data()[21];
	w=Buff.data()[18]+256*Buff.data()[17];
//	GSM_GetMaxBitmapWidthHeight(bitmap->Type, &bitmap->BitmapWidth, &bitmap->BitmapHeight);
//	if (h<bitmap->BitmapHeight)	bitmap->BitmapHeight=h;
//	if (w<bitmap->BitmapWidth)	bitmap->BitmapWidth=w;
	Bitmap = new Mono_Bitmap_FileSubEntry(w,h);

	if (Buff.data()[28]!=1) {
//		dbgprintf("Wrong number of colors\n");
		return FALSE;
	}

	if (Buff.data()[30]!=0) {
//		dbgprintf("Compression type not supported\n");
		return FALSE;
	}

	/* read rest of header (if exists) and color palette */
	pos=Buff.data()[10]-34;
	buffpos=Buff.data()[10];

	first_white=true;
	if (Buff.data()[pos-8]!=0 || Buff.data()[pos-7]!=0 || Buff.data()[pos-6]!=0) first_white=false;

	pos=7;
	/* lines are written from the last to the first */
	for (y=h-1;y>=0;y--) {
		i=1;
		for (x=0;x<w;x++) {
			/* new byte ! */
			if (pos==7) {
				buff[0]=Buff.data()[buffpos];
				buffpos++;
				i++;
				/* each line is written in multiply of 4 bytes */
				if(i==5) i=1;
			}
			/* we have top left corner ! */
			if (x<=w && y<=h) {
				if (first_white) {
					if ((buff[0]&(1<<pos))<=0) Bitmap->SetPointColor(x, y, TRUE);
				} else {
					if ((buff[0]&(1<<pos))>0) Bitmap->SetPointColor(x, y, TRUE);
				}
			}
			pos--;
			/* going to new byte */
			if (pos<0) pos=7;
		}
		/* going to new byte */
		pos=7;
		if (i!=1) {
			/* each line is written in multiply of 4 bytes */
			while (i!=5) {
				buff[0]=Buff.data()[buffpos];
				buffpos++;
				i++;
			}
		}
	}
	AddSubEntry(Bitmap);
	return TRUE;
}
