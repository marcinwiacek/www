--
-- PostgreSQL database dump
--

SET client_encoding = 'UNICODE';
SET check_function_bodies = false;

--
-- TOC entry 2 (OID 0)
-- Name: gplusmsmms; Type: DATABASE; Schema: -; Owner: gplus
--

CREATE DATABASE gplusmsmms WITH TEMPLATE = template0 ENCODING = 'UNICODE';


\connect gplusmsmms gplus

SET client_encoding = 'UNICODE';
SET check_function_bodies = false;

--
-- TOC entry 3 (OID 17144)
-- Name: daemon; Type: SCHEMA; Schema: -; Owner: 
--

CREATE SCHEMA daemon;


--
-- TOC entry 5 (OID 2200)
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


SET search_path = daemon, pg_catalog;

--
-- TOC entry 9 (OID 17145)
-- Name: inbox_decoded; Type: TABLE; Schema: daemon; Owner: gplus
--

CREATE TABLE inbox_decoded (
    "type" smallint,
    id bigint,
    seq_num smallint,
    content text,
    type2 text,
    filename text,
    bold boolean DEFAULT false,
    italic boolean DEFAULT false,
    underline boolean DEFAULT false,
    strikethrough boolean DEFAULT false,
    small boolean DEFAULT false,
    large boolean DEFAULT false,
    dt timestamp with time zone
);


--
-- TOC entry 6 (OID 17156)
-- Name: inbox_decoded_id; Type: SEQUENCE; Schema: daemon; Owner: gplus
--

CREATE SEQUENCE inbox_decoded_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 10 (OID 17158)
-- Name: inbox_mms; Type: TABLE; Schema: daemon; Owner: gplus
--

CREATE TABLE inbox_mms (
    id bigint,
    content text,
    processed boolean DEFAULT false
);


--
-- TOC entry 7 (OID 17164)
-- Name: inbox_mms_id; Type: SEQUENCE; Schema: daemon; Owner: gplus
--

CREATE SEQUENCE inbox_mms_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 8 (OID 17166)
-- Name: inbox_sms_id; Type: SEQUENCE; Schema: daemon; Owner: gplus
--

CREATE SEQUENCE inbox_sms_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 11 (OID 17174)
-- Name: inbox_sms; Type: TABLE; Schema: daemon; Owner: gplus
--

CREATE TABLE inbox_sms (
    tpudl smallint,
    tpdcs smallint,
    tpstatus smallint,
    tpvp smallint,
    firstbyte smallint,
    tpmr smallint,
    tppid smallint,
    id bigint,
    userdata text,
    smscnumber text,
    datetime text,
    smsctime text,
    processed boolean DEFAULT false,
    phonenumbers text
);


--
-- TOC entry 4 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


