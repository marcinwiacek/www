What is this ?
--------------
These are applications from Gammu+ project. You can read more about this
project on www.gammu.org.

In short words: project was planned long time. Currently Marcin Wiacek is
moving much faster all functionality from older Gammu (see www.gammu.org).
After getting full compatibility with non Symbian Nokias, Linux and Windows
there will be other devices supported.

Don't worry, that something doesn't work yet. Graphic User Interface was 
started in December 2006. See, what was done since this time...You can try to 
boost fixing by reporting problem too (marcin@mwiacek.com)...

Links
-----

http://www.gammu.org/wiki/index.php?title=HydePark:Reports

   Many notes from Marcin about development, project problems and news

http://www.gammu.org/wiki/index.php?title=GPlus:Main_Page

   Gammu+ page with developer/users docs and much more...

Help if you can
---------------
If you want and/or can, please donate this work. Even small sum (5 or 10 Euro)
can be really nice help, which can allow in getting some required hardware,
documentation or something else and which will more motivate Marcin for this
work. More about donations on http://www.mwiacek.com/gsm/money/money.htm

Marcin will accept some bounties (you will pay for concrete features) too...

Full freedom and giving employment
----------------------------------
Please note, that this project is given for free with full source (GPL/LGPL)
and you can compile it and change as you want. There is also possibility of
buying license, which will allow for making static compilation and other
nice things...

Marcin can also add extensions for available functionality and modify it to
your needs. And he can do constant job connected with this and/or connected
with older Gammu too (if you have :-)).

Technical notes
---------------
Tested on Nokia 6111, 6230, 6230i, but should work on any GSM and non
Symbian Nokia. Config file is generally compatible with Gammu and Wammu.
You can compile sources using MS Visual Studio 2005 (for example with free 
Express Edition) and wxDev-C++. Under Linux there is required GCC with C++ 
extensions (but because of lack of hardware drivers there will be infrared
active only).

What is planned ?
-----------------
All Gammu project features + more... ToDo is long:

* decoding SMS/MMS with VCARD, VCALENDAR, VTODO
* encoding and decoding pictures in SMS
* encoding and decoding EMS
* info about missed parts in linked SMS
* ending calendar sheet
* caller groups support using caller groups names
* decoding XML backup
* refresh after uploading Java
* FM radio
* selecting BT address from list
* full Linux GUI
* (if people will interested and/or will donate this work)
  adding/editing/deleting single entries from GUI
* automatic creating playlists
....
* SMSD/MMSD daemon
* Outlook integration
* native Symbian support
* OBEX, AT support
