/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include "../../../cfg/config.h"
#include "../../misc/misc.h"
#include "../../service/gsmmisc.h"
#include "../gsmdev.h"

class GSM_Device_Bluetooth:virtual public GSM_Device
{
public:
        GSM_Device_Bluetooth(DebugInfo **Deb):GSM_Device(Deb) {
		Info.push_back(GSM_Device_Info(Deb,"bluetooth"));
		Sock = new(GSM_Socket);
        }
	~GSM_Device_Bluetooth() {
		delete Sock;
	}

        GSM_Error       Open            (char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones);
        GSM_Error       Close           ();
        GSM_Error       Read            (unsigned char *buf, int *len);
        GSM_Error       Write           (const unsigned char *buf, int len);
private:
	int		Device;
	GSM_Socket	*Sock;

	GSM_Error 	Connect		(char *address, int channel);
#ifdef BLUETOOTH_RF_SEARCHING
	bool 		CheckServiceName	(char *service, char *Prot);
	GSM_Error 	FindChannelInDevice	(char *address, char *Prot, void *protocolInfo);
	GSM_Error 	FindChannelInAllDevices	(char *Prot, void *protocolInfo);
#endif
};
