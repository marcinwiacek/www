/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../service/gsmmisc.h"
#include "../../misc/misc.h"
#include "../gsmprot.h"

class GSM_Protocol_AT:virtual public GSM_Protocol
{
public:
        GSM_Protocol_AT(GSM_Device **Dev, DebugInfo **Deb):GSM_Protocol(Dev,Deb) {
		Info.push_back(GSM_Protocol_Info("infrared", "irdaat",  false,  false));
		Info.push_back(GSM_Protocol_Info("bluetooth","blueat",  false,  false));
		Info.push_back(GSM_Protocol_Info("serial","at115200",  false,  false));
                Msg = new GSM_Protocol_Message();
        }
        ~GSM_Protocol_AT() {
        }

        GSM_Error Open		(char *Prot);
        GSM_Error Close		();
        GSM_Error Write		(unsigned char *buffer, int length, unsigned char type);
	GSM_Error Dispatch	(unsigned char *buffer, int length, int *position);
private:
        int                     linestartnum;
        GSM_Protocol_Message    *Msg;
};
