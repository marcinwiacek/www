/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#ifndef gsm_pbk_h
#define gsm_pbk_h

#ifdef WIN32
#  include <windows.h>
#endif

#include "gsmmisc.h"
#include "../misc/misc.h"

typedef enum {
	PBK_Not_Assigned = 1,

	PBK_Text_Phone_General,
	PBK_Text_Phone_Mobile,
	PBK_Text_Phone_Home,
	PBK_Text_Phone_Work,
	PBK_Text_Phone_Fax,
	PBK_Text_Phone_Video,
	PBK_Text_Postal,
	PBK_Text_Postal_Street,
	PBK_Text_Postal_City,
	PBK_Text_Postal_State,
	PBK_Text_Postal_ZIP_Code,
	PBK_Text_Postal_Country,
	PBK_Text_Email,
	PBK_Text_URL,
	PBK_Text_UserID,
	PBK_Text_Note,
	PBK_Text_Name,
	PBK_Text_Name_Last,
	PBK_Text_Name_First,
	PBK_Text_Name_Formal,
	PBK_Text_Company_Name,
	PBK_Text_Nick_Name,
	PBK_Text_PTT,
	PBK_Text_Video_Sharing_SIP,
	PBK_Text_Job_Title,
	PBK_DateTime_Call_Length,
	PBK_DateTime_Birthday,
	PBK_ID_Caller_Group,
	PBK_ID_Picture,
	PBK_ID_Ringtone,
	PBK_ID_Video_File,
	PBK_Bool_PTT_Subscribed
} GSM_PBK_SubEntryType;

typedef enum {
	VCARD_10 = 1,
	VCARD_21
} GSM_VCARDType;

class GSM_PBKSubEntry
{
	friend class GSM_PBKEntry;
public:
	GSM_PBKSubEntry();
	~GSM_PBKSubEntry();

	GSM_Error		SetError;
	GSM_PBK_SubEntryType 	GetType();
	GSM_Error 		SetToText(GSM_PBK_SubEntryType Typ, wchar_t *Txt);
	wchar_t			*GetText();
	GSM_Error 		SetToDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2);
	GSM_DateTime		*GetDateTime();
	GSM_Error 		SetToLong(GSM_PBK_SubEntryType Typ, long long2);
	long			LongValue;
	GSM_Error 		SetToBool(GSM_PBK_SubEntryType Typ, bool bool2);
	bool			BoolValue;

	long			VoiceTag;
	GSM_Error		VoiceTagSetError;
	long			CallLength;
	unsignedint		SMSLists;
	GSM_Error		SMSListsSetError;

	GSM_PBKSubEntry		*GetNext();
private:
	void 			SetNext(GSM_PBKSubEntry *Nxt);

	GSM_DateTime		DT;
	GSM_PBKSubEntry		*Next;
	wchar_t			*Text;
	GSM_PBK_SubEntryType	Type;
};

class GSM_PBKEntry
{
public:
	GSM_PBKEntry();
	~GSM_PBKEntry();

	int 			Location;
	GSM_MemoryType		Memory;

	void 			ClearAll();	
	BOOLEAN 		GetNext(GSM_PBKSubEntry **En);
	GSM_Error	 	AddText(GSM_PBK_SubEntryType Typ, wchar_t *Txt);
	GSM_Error	 	AddDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2);
	GSM_Error	 	AddLong(GSM_PBK_SubEntryType Typ, long long2);
	GSM_Error	 	AddBool(GSM_PBK_SubEntryType Typ, bool bool2);
	GSM_Error 		EncodeToVCARD(unsignedstring *dest, GSM_VCARDType Type);
	GSM_Error 		DecodeFromVCARD(unsignedstring *src);
private:
	GSM_PBKSubEntry		*Entries;
};

typedef struct {
	int 			Used;
	int 			Free;
	GSM_MemoryType		Memory;
} GSM_PBKStatus;

#endif
