/* (C) 2007 by Marcin Wiacek www.mwiacek.com */

void GetMMSFolders(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
	GSM_Error			error;
	GSM_SMSMMSFolders		Folders;
	GSM_SMSMMSFoldersSubEntry  	*SubEntry;
	int				i=1;
	
	error = s->Open(CFG);
	PrintError(error);

	error = s->Phones->Current->GetSMSMMSFolders(&Folders);
	PrintError(error);

	SubEntry = NULL;
	while (Folders.GetNext(&SubEntry) == TRUE) {
		if (!SubEntry->MMS) continue;
		printf("%i. %s - memory %s\n",i++,UnicodeToStringReturn(SubEntry->GetName()),GSM_GetMemoryName(SubEntry->Memory));
//		printf(" %s\n",UnicodeToStringReturn(SubEntry->ID.data()));
	}
}

void ReadMMSFile(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
	GSM_SMSMMSDecodedEntry     Decoded;
	GSM_SMSMMSDecodedSubEntry  *SubDecoded;
	GSM_Error                   error;
    	long                        EntryNum=0,NumbersNum=0;
    	wchar_t                     Buffer[200];
    	BOOLEAN                     Found,AddNum;
    	wchart                      Name;
    	int                         FileNum=-1,FileNum2=1,Num=0;
    	char                        X[1000];
	GSM_File		    File;

	if (!File.ReadFromDisk(StringToUnicodeReturn(argv[0]))) return;

	Decoded.ReadFromMMS(&File);

    	SubDecoded = NULL;
    	while (Decoded.GetNext(&SubDecoded)) {
        	Found = false;
        	AddNum=false;
        	switch (SubDecoded->Type) {
        	case MSG_MMSSMS_Address_Phone_Source:
            		printf("From (phone)      "); Found = true;
            		break;
    		case MSG_MMS_Address_Unknown_Source:
            		printf("From              "); Found = true;
            		break;
        	case MSG_MMS_Address_Phone_Destination:
            		printf("To (phone)        "); Found = true;
            		break;
        	case MSG_MMS_Address_Unknown_Destination:
            		printf("To                "); Found = true;
            		break;
        	case MSG_MMS_Address_Phone_CC:
            		printf("CC (phone)        "); Found = true;
            		break;
        	case MSG_MMS_Address_Unknown_CC:
            		printf("CC                "); Found = true;
            		break;
        	case MSG_MMS_Address_Phone_BCC:
            		printf("BCC (phone)       "); Found = true;
            		break;
        	case MSG_MMS_Address_Unknown_BCC:
            		printf("BCC               "); Found = true;
            		break;
        	case MSG_Unknown:
            		printf("<Unknown content> "); Found = true;
            		break;
        	}
        	if (Found) {
           		memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
			printf(": %s\n",UnicodeToStringReturn(Buffer));
            		continue;
        	}
        	switch (SubDecoded->Type) {
            	case MSG_MMS_Text_TransactionID:
			printf("Transaction ID    "); Found = true;
                	break;
            	case MSG_MMS_Text_Subject:
			printf("Subject           "); Found = true;
               		break;
            	case MSG_MMS_Text_ContentLocation:
			printf("Content location  "); Found = true;
                	break;
            	case MSG_MMS_Text_ContentType:
			printf("Content type      "); Found = true;
                	break;
            	case MSG_MMS_Text_MessageType:
			printf("Message type      "); Found = true;
                	break;
            	case MSG_MMS_Text_MessageID:
			printf("Message ID        "); Found = true;
                	break;
            	case MSG_MMS_Text_MessageClass:
			printf("Message class     "); Found = true;
                	break;
            	case MSG_MMS_Text_Priority:
			printf("Priority          "); Found = true;
                	break;
            	case MSG_MMS_Text_Version:
			printf("MMS version       "); Found = true;
                	break;
            	case MSG_MMS_Text_Response_Status:
			printf("Response status   "); Found = true;
                	break;
            	case MSG_MMS_Text_Status:
			printf("Status            "); Found = true;
                	break;
            	}
            	if (Found) {
			printf(": %s\n",UnicodeToStringReturn(SubDecoded->Text.data()));
                	continue;
            	}
            	switch (SubDecoded->Type) {
            	case MSG_MMS_Bool_Report:
			printf("Delivery report   "); Found = TRUE;
                	break;
            	case MSG_MMS_Bool_Read_Reply:
			printf("Read reply        "); Found = TRUE;
                	break;
            	case MSG_MMS_Bool_Report_Allowed:
			printf("Report allowed    "); Found = TRUE;
                	break;
            	}
            	if (Found) {
               		if (SubDecoded->Bool) {
				printf(": yes\n");
                	} else {
				printf(": no\n");
                	}
                	continue;
            	}
        	switch (SubDecoded->Type) {
        	case MSG_MMS_DT_DateTime:
			printf("Sent              ");
			printf(": %02i:%02i:%02i %02i-%02i-%04i %s\n",
				SubDecoded->DT.Hour,
				SubDecoded->DT.Minute,
				SubDecoded->DT.Second,
				SubDecoded->DT.Day,
				SubDecoded->DT.Month,
				SubDecoded->DT.Year,
				DayOfWeekStr(
					SubDecoded->DT.Year,
					SubDecoded->DT.Month,
					SubDecoded->DT.Day));
            		break;
    		case MSG_MMS_DT_Expiry:
			printf("Expiry            : %s\n",SubDecoded->Text.data());
            		break;
        	case MSG_MMSSMS_File:
            		printf("File\n");
			printf("  Content type    : ");
                	sprintf(X,"%s",UnicodeToStringReturn(SubDecoded->Text.data()));
                	sprintf(X+strlen(X),"%s",UnicodeToStringReturn(SubDecoded->Text2.data()));
            		printf("%s\n",X);

                	if (SubDecoded->Header.length()!=0) {
				printf("  Header          : %s\n",UnicodeToStringReturn(SubDecoded->Header.data()));
                	}
			printf("  Size            : %i bytes\n",SubDecoded->File.Info.Size);
			if (argc==2 && StringCaseCmp(argv[1],"-save",-1)) {
				Num++;
				if (SubDecoded->File.Info.Name.size()!=0) {
					SubDecoded->File.SaveToDisk(UnicodeToStringReturn(SubDecoded->File.Info.Name.data()));
				} else {
					sprintf(X,"file %i",Num);
					SubDecoded->File.SaveToDisk(X);
				}
			}
            		break;
        	}
    	}
}
