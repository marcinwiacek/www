//---------------------------------------------------------------------------
//
// Name:        SMSEditorDlg.cpp
// Author:      Marcinello
// Created:     2007-02-06 23:39:09
// Description: SMSEditorDlg class implementation
//
//---------------------------------------------------------------------------

#include <wx/progdlg.h>

#include "../cfg/config.h"
#include "../common/service/smsmms/gsmmsg.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"
#include "../common/misc/misc.h"

#include "SMSEditorDlg.h"
#include "shared.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// SMSEditorDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(SMSEditorDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(SMSEditorDlg::OnClose)
	EVT_BUTTON(ID_SENDWXBUTTON,SMSEditorDlg::SendWxButtonClick)
	EVT_BUTTON(ID_CANCELWXBUTTON,SMSEditorDlg::CancelWxButtonClick)
	EVT_BUTTON(ID_RECIPIENTDELETEWXBUTTON,SMSEditorDlg::RecipientDeleteWxButtonClick)
	
	EVT_TEXT(ID_NEWRECIPIENTWXEDIT,SMSEditorDlg::NewRecipientWxEditUpdated)
	EVT_BUTTON(ID_NEWRECIPIENTADDWXBUTTON,SMSEditorDlg::NewRecipientAddWxButtonClick)
	EVT_CHOICE(ID_WXCHOICE8,SMSEditorDlg::WxChoice8Selected)
	EVT_CHOICE(ID_WXCHOICE6,SMSEditorDlg::WxChoice6Selected)
	EVT_CHOICE(ID_WXCHOICE5,SMSEditorDlg::WxChoice5Selected)
	
	EVT_TEXT(ID_WXMEMO3,SMSEditorDlg::WxMemo3Updated)
	
	EVT_TEXT(ID_WXEDIT3,SMSEditorDlg::WxEdit3Updated)
	EVT_BUTTON(ID_WXBUTTON2,SMSEditorDlg::WxButton2Click1)
	EVT_COMBOBOX(ID_WXCOMBOBOX3,SMSEditorDlg::WxComboBox3Selected)
	EVT_CHECKBOX(ID_WXCHECKBOX2,SMSEditorDlg::WxCheckBox2Click)
	EVT_CHOICE(ID_WXCHOICE9,SMSEditorDlg::WxChoice9Selected)
	EVT_BUTTON(ID_WXBUTTON1,SMSEditorDlg::WxButton1Click1)
	
	EVT_TEXT(ID_WXMEMO1,SMSEditorDlg::WxMemo1Updated1)
	EVT_CHOICE(ID_WXCHOICE4,SMSEditorDlg::WxChoice4Selected)
	EVT_CHOICE(ID_WXCHOICE3,SMSEditorDlg::WxChoice3Selected)
	EVT_CHOICE(ID_WXCHOICE2,SMSEditorDlg::WxChoice2Selected)
	EVT_CHOICE(ID_WXCHOICE1,SMSEditorDlg::WxChoice1Selected)
	EVT_CHOICE(ID_WXCHOICE7,SMSEditorDlg::WxChoice7Selected)
	
	EVT_TEXT(ID_WXEDIT2,SMSEditorDlg::WxEdit2Updated)
	
	EVT_TEXT(ID_WXEDIT1,SMSEditorDlg::WxEdit1Updated1)
	EVT_CHECKBOX(ID_WXCHECKBOX3,SMSEditorDlg::WxCheckBox3Click)
	EVT_CHECKBOX(ID_REPLYWXCHECKBOX,SMSEditorDlg::ReplyWxCheckBoxClick)
	
	EVT_TEXT(ID_WXCOMBOBOX4,SMSEditorDlg::WxComboBox4Updated)
	EVT_CHECKBOX(ID_WXCHECKBOX4,SMSEditorDlg::WxCheckBox4Click)
	
	EVT_TEXT(ID_WXCOMBOBOX1,SMSEditorDlg::WxComboBox1Updated)
	EVT_CHECKBOX(ID_WXCHECKBOX1,SMSEditorDlg::WxCheckBox1Click1)
	
	EVT_TEXT(ID_TEXTSMSWXMEMO,SMSEditorDlg::TextSMSWxMemoUpdated)
	EVT_CHECKBOX(ID_TEXTSMSCLASSWXCHECKBOX,SMSEditorDlg::TextSMSClassWxCheckBoxClick)
	EVT_CHECKBOX(ID_TEXTSMSUNICODEWXCHECKBOX,SMSEditorDlg::TextSMSUnicodeWxCheckBoxClick)
END_EVENT_TABLE()
////Event Table End

SMSEditorDlg::SMSEditorDlg(GSM_StateMachine *s2, GSM_SMSList *List2, wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
    GSM_SMSC    SMSC;
    int         Num=1,i;
    GSM_Error   error;
    char        buff[200];
    wxProgressDialog        *Dialog;
    bool                    skip;

UpdatingFileTransfer=FALSE;
	num = 0;
    s=s2;
    List = List2;
    PBK2 = NULL;
    Cal2=NULL;
    Note2=NULL;
    ToDo2=NULL;
    start = true;
    MonoFileAvail = FALSE;
    
	CreateGUIControls();
    
    SetTitle(title);
    
    Dialog = new wxProgressDialog("Reading SMSC", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_CAN_ABORT);
    while (true) {
                Dialog->Pulse("Reading SMSC",&skip);        
    	SMSC.Location = Num;
    	error = s->Phones->Current->GetSMSC(&SMSC);
    	if (error.Code != GSM_ERR_NONE) break;
     	sprintf(buff,"%s",UnicodeToStringReturn(SMSC.GetSMSCNumber()));
    //    	if (UnicodeLength(SMSC.GetName())!=0) {
    //        	sprintf(buff+strlen(buff)," (%s)",UnicodeToStringReturn(SMSC.GetName()));
    //        }
        if (strlen(buff)!=0) SMSCWxComboBox->Append(buff);
        Num++;
    }
    delete Dialog;
    SMSCWxComboBox->Select(0);    
    ValidityWxComboBox->Select(5);
    TextSMSWxMemo->SetFocus();
    WxComboBox1->Select(0);
    
    for(i=1;i<255;i++) {
        sprintf(buff,"%i messages",i); 
        WxChoice1->Append(buff);
        WxChoice2->Append(buff);
        WxChoice3->Append(buff);
        WxChoice4->Append(buff);
    }
    sprintf(buff,"255 or more messages"); 
    WxChoice1->Append(buff);
    WxChoice2->Append(buff);
    WxChoice3->Append(buff);
    WxChoice4->Append(buff);
    
    WxChoice1->Select(0);
    WxChoice2->Select(0);
    WxChoice3->Select(0);
    WxChoice4->Select(0);
  
    for(i=0;i<256;i++) {
        sprintf(buff,"%i",i);
        WxComboBox4->Append(buff);
    }
    WxComboBox4->Select(0);
 
    WxChoice7->Select(0);

    WxComboBox2->Select(0);
    WxComboBox3->Select(0);
    WxComboBox5->Select(0);
  
    WxChoice9->Enable(FALSE);
    WxMemo1->Enable(FALSE);
    WxCheckBox2->Enable(FALSE);
    WxComboBox2->Enable(FALSE);
    
    start=false;        
}

void SMSEditorDlg::DeleteP(wxString Str)
{
    int i;

    i=0;
    while (i<WxNotebook1->GetPageCount()) {
        if (WxNotebook1->GetPageText(i) == Str) {
            WxNotebook1->DeletePage(i);
            break;
        }
        i++;
    }
}

void SMSEditorDlg::DeleteNormal()
{
    DeleteP("Calendar");
    DeleteP("PhoneBook");
    DeleteP("ToDo");
    DeleteP("Note");
}

SMSEditorDlg::~SMSEditorDlg()
{
} 

void SMSEditorDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxPanel1 = new wxPanel(this, ID_WXPANEL1, wxPoint(0,0), wxSize(574,471));

	WxNotebook2 = new wxNotebook(WxPanel1, ID_WXNOTEBOOK2, wxPoint(5,5),wxSize(417,463));

	WxNoteBookPage2 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE2, wxPoint(4,24), wxSize(409,435));
	WxNotebook2->AddPage(WxNoteBookPage2, wxT("Content"));

	WxNotebook1 = new wxNotebook(WxNoteBookPage2, ID_WXNOTEBOOK1, wxPoint(-2,3),wxSize(400,424));

	WxNoteBookPage1 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE1, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage1, wxT("Text SMS"));

	WxStaticBox1 = new wxStaticBox(WxNoteBookPage1, ID_WXSTATICBOX1, wxT("Text (0 SMS/160 chars left)"), wxPoint(4,3), wxSize(381,124));

	WxStaticBox2 = new wxStaticBox(WxNoteBookPage1, ID_WXSTATICBOX2, wxT("Text preview in recipients' phone(s)"), wxPoint(4,129), wxSize(381,122));

	WxStaticBox3 = new wxStaticBox(WxNoteBookPage1, ID_WXSTATICBOX3, wxT("Options"), wxPoint(4,252), wxSize(381,142));

	TextSMSUnicodeWxCheckBox = new wxCheckBox(WxNoteBookPage1, ID_TEXTSMSUNICODEWXCHECKBOX, wxT("Use Unicode alphabet (less chars in single SMS, all national supported)"), wxPoint(10,266), wxSize(369,17), 0, wxDefaultValidator, wxT("TextSMSUnicodeWxCheckBox"));

	TextSMSClassWxCheckBox = new wxCheckBox(WxNoteBookPage1, ID_TEXTSMSCLASSWXCHECKBOX, wxT("Send in class 0 (displayed immediately on screen)"), wxPoint(10,304), wxSize(259,24), 0, wxDefaultValidator, wxT("TextSMSClassWxCheckBox"));

	TextSMSWxMemo = new wxTextCtrl(WxNoteBookPage1, ID_TEXTSMSWXMEMO, wxT(""), wxPoint(13,21), wxSize(366,98), wxTE_MULTILINE, wxDefaultValidator, wxT("TextSMSWxMemo"));
	TextSMSWxMemo->SetMaxLength(0);
	TextSMSWxMemo->SetFocus();
	TextSMSWxMemo->SetInsertionPointEnd();

	TextSMSPreviewWxMemo = new wxTextCtrl(WxNoteBookPage1, ID_TEXTSMSPREVIEWWXMEMO, wxT(""), wxPoint(13,147), wxSize(365,96), wxTE_READONLY | wxTE_WORDWRAP | wxTE_MULTILINE, wxDefaultValidator, wxT("TextSMSPreviewWxMemo"));
	TextSMSPreviewWxMemo->SetMaxLength(0);
	TextSMSPreviewWxMemo->SetFocus();
	TextSMSPreviewWxMemo->SetInsertionPointEnd();
	TextSMSPreviewWxMemo->SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE));

	WxCheckBox1 = new wxCheckBox(WxNoteBookPage1, ID_WXCHECKBOX1, wxT("Replace SMS with specified ID (saved in recipient phone)"), wxPoint(10,347), wxSize(293,18), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	wxArrayString arrayStringFor_WxComboBox1;
	arrayStringFor_WxComboBox1.Add(wxT("0"));
	arrayStringFor_WxComboBox1.Add(wxT("1"));
	arrayStringFor_WxComboBox1.Add(wxT("2"));
	arrayStringFor_WxComboBox1.Add(wxT("3"));
	arrayStringFor_WxComboBox1.Add(wxT("4"));
	arrayStringFor_WxComboBox1.Add(wxT("5"));
	arrayStringFor_WxComboBox1.Add(wxT("6"));
	arrayStringFor_WxComboBox1.Add(wxT("7"));
	WxComboBox1 = new wxComboBox(WxNoteBookPage1, ID_WXCOMBOBOX1, wxT("WxComboBox1"), wxPoint(322,344), wxSize(54,21), arrayStringFor_WxComboBox1, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox1"));
	WxComboBox1->Enable(false);

	WxCheckBox4 = new wxCheckBox(WxNoteBookPage1, ID_WXCHECKBOX4, wxT("Replace SMS with specified TPMR (if waiting in SMS Center)"), wxPoint(10,369), wxSize(311,18), 0, wxDefaultValidator, wxT("WxCheckBox4"));

	wxArrayString arrayStringFor_WxComboBox4;
	WxComboBox4 = new wxComboBox(WxNoteBookPage1, ID_WXCOMBOBOX4, wxT("WxComboBox4"), wxPoint(322,367), wxSize(54,21), arrayStringFor_WxComboBox4, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox4"));
	WxComboBox4->Enable(false);

	ReplyWxCheckBox = new wxCheckBox(WxNoteBookPage1, ID_REPLYWXCHECKBOX, wxT("Allow reply for your (sender) cost"), wxPoint(10,326), wxSize(216,20), 0, wxDefaultValidator, wxT("ReplyWxCheckBox"));

	WxCheckBox3 = new wxCheckBox(WxNoteBookPage1, ID_WXCHECKBOX3, wxT("Use 16 bit ID instead of 8 bit in UDH (less chars in single SMS)"), wxPoint(10,287), wxSize(367,18), 0, wxDefaultValidator, wxT("WxCheckBox3"));
	WxCheckBox3->Enable(false);

	WxNoteBookPage6 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE6, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage6, wxT("URL"));

	WxStaticText8 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT8, wxT("Name"), wxPoint(3,39), wxDefaultSize, 0, wxT("WxStaticText8"));

	WxStaticText9 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT9, wxT("URL"), wxPoint(3,69), wxDefaultSize, 0, wxT("WxStaticText9"));

	WxEdit1 = new wxTextCtrl(WxNoteBookPage6, ID_WXEDIT1, wxT(""), wxPoint(88,38), wxSize(295,22), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxEdit2 = new wxTextCtrl(WxNoteBookPage6, ID_WXEDIT2, wxT(""), wxPoint(88,69), wxSize(295,23), 0, wxDefaultValidator, wxT("WxEdit2"));

	WxStaticText11 = new wxStaticText(WxNoteBookPage6, ID_WXSTATICTEXT11, wxT("Format"), wxPoint(3,10), wxDefaultSize, 0, wxT("WxStaticText11"));

	wxArrayString arrayStringFor_WxChoice7;
	arrayStringFor_WxChoice7.Add(wxT("WAP bookmark"));
	arrayStringFor_WxChoice7.Add(wxT("WAP push"));
	WxChoice7 = new wxChoice(WxNoteBookPage6, ID_WXCHOICE7, wxPoint(89,7), wxSize(297,21), arrayStringFor_WxChoice7, 0, wxDefaultValidator, wxT("WxChoice7"));
	WxChoice7->SetSelection(-1);

	WxNoteBookPage7 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE7, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage7, wxT("Indicators"));

	WxStaticBox8 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX8, wxT("Voice"), wxPoint(1,32), wxSize(193,54));

	WxStaticBox9 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX9, wxT("Fax"), wxPoint(196,32), wxSize(194,54));

	WxStaticBox10 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX10, wxT("Email"), wxPoint(1,87), wxSize(193,65));

	wxArrayString arrayStringFor_WxChoice1;
	arrayStringFor_WxChoice1.Add(wxT("Don't set"));
	arrayStringFor_WxChoice1.Add(wxT("Disable"));
	WxChoice1 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE1, wxPoint(55,54), wxSize(133,21), arrayStringFor_WxChoice1, 0, wxDefaultValidator, wxT("WxChoice1"));
	WxChoice1->SetSelection(-1);

	WxStaticText5 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT5, wxT("State"), wxPoint(10,51), wxDefaultSize, 0, wxT("WxStaticText5"));

	WxStaticBox11 = new wxStaticBox(WxNoteBookPage7, ID_WXSTATICBOX11, wxT("Other"), wxPoint(196,87), wxSize(193,65));

	WxStaticText6 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT6, wxT("State"), wxPoint(206,57), wxDefaultSize, 0, wxT("WxStaticText6"));

	wxArrayString arrayStringFor_WxChoice2;
	arrayStringFor_WxChoice2.Add(wxT("Don't set"));
	arrayStringFor_WxChoice2.Add(wxT("Disable"));
	WxChoice2 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE2, wxPoint(249,53), wxSize(133,21), arrayStringFor_WxChoice2, 0, wxDefaultValidator, wxT("WxChoice2"));
	WxChoice2->SetSelection(-1);

	WxStaticText7 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT7, wxT("State"), wxPoint(8,110), wxDefaultSize, 0, wxT("WxStaticText7"));

	wxArrayString arrayStringFor_WxChoice3;
	arrayStringFor_WxChoice3.Add(wxT("Don't set"));
	arrayStringFor_WxChoice3.Add(wxT("Disable"));
	WxChoice3 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE3, wxPoint(55,107), wxSize(134,21), arrayStringFor_WxChoice3, 0, wxDefaultValidator, wxT("WxChoice3"));
	WxChoice3->SetSelection(-1);

	wxArrayString arrayStringFor_WxChoice4;
	arrayStringFor_WxChoice4.Add(wxT("Don't set"));
	arrayStringFor_WxChoice4.Add(wxT("Disable"));
	WxChoice4 = new wxChoice(WxNoteBookPage7, ID_WXCHOICE4, wxPoint(249,105), wxSize(132,21), arrayStringFor_WxChoice4, 0, wxDefaultValidator, wxT("WxChoice4"));
	WxChoice4->SetSelection(-1);

	WxStaticText10 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT10, wxT("State"), wxPoint(205,106), wxDefaultSize, 0, wxT("WxStaticText10"));

	WxStaticText16 = new wxStaticText(WxNoteBookPage7, ID_WXSTATICTEXT16, wxT("Format"), wxPoint(3,7), wxDefaultSize, 0, wxT("WxStaticText16"));

	wxArrayString arrayStringFor_WxComboBox5;
	arrayStringFor_WxComboBox5.Add(wxT("GSM 3.40"));
	WxComboBox5 = new wxComboBox(WxNoteBookPage7, ID_WXCOMBOBOX5, wxT("WxComboBox5"), wxPoint(56,4), wxSize(131,21), arrayStringFor_WxComboBox5, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox5"));

	WxNoteBookPage9 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE9, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage9, wxT("Image"));

	WxStaticBox18 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX18, wxT("Bitmap"), wxPoint(2,27), wxSize(381,128));

	WxStaticBox17 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX17, wxT("Text"), wxPoint(2,160), wxSize(381,126));

	WxStaticText13 = new wxStaticText(WxNoteBookPage9, ID_WXSTATICTEXT13, wxT("Format"), wxPoint(10,5), wxDefaultSize, 0, wxT("WxStaticText13"));

	wxArrayString arrayStringFor_WxComboBox2;
	arrayStringFor_WxComboBox2.Add(wxT("Nokia picture image"));
	WxComboBox2 = new wxComboBox(WxNoteBookPage9, ID_WXCOMBOBOX2, wxT("WxComboBox2"), wxPoint(66,2), wxSize(217,21), arrayStringFor_WxComboBox2, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox2"));

	WxMemo1 = new wxTextCtrl(WxNoteBookPage9, ID_WXMEMO1, wxT(""), wxPoint(8,178), wxSize(365,79), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo1"));
	WxMemo1->SetMaxLength(0);
	WxMemo1->SetFocus();
	WxMemo1->SetInsertionPointEnd();

	WxButton1 = new wxButton(WxNoteBookPage9, ID_WXBUTTON1, wxT("Load"), wxPoint(320,41), wxSize(52,23), 0, wxDefaultValidator, wxT("WxButton1"));

	wxBitmap WxBitmapButton1_BITMAP (wxNullBitmap);
	WxBitmapButton1 = new wxBitmapButton(WxNoteBookPage9, ID_WXBITMAPBUTTON1, WxBitmapButton1_BITMAP, wxPoint(9,69), wxSize(219,74), wxSIMPLE_BORDER | wxSUNKEN_BORDER | wxNO_BORDER | wxBU_AUTODRAW, wxDefaultValidator, wxT("WxBitmapButton1"));
	WxBitmapButton1->SetToolTip(wxT("Image preview"));

	wxArrayString arrayStringFor_WxChoice9;
	WxChoice9 = new wxChoice(WxNoteBookPage9, ID_WXCHOICE9, wxPoint(10,43), wxSize(219,21), arrayStringFor_WxChoice9, 0, wxDefaultValidator, wxT("WxChoice9"));
	WxChoice9->SetSelection(-1);

	WxCheckBox2 = new wxCheckBox(WxNoteBookPage9, ID_WXCHECKBOX2, wxT("Use Unicode alphabet (unsupported by some Nokia models)"), wxPoint(8,260), wxSize(365,17), 0, wxDefaultValidator, wxT("WxCheckBox2"));

	WxStaticBox19 = new wxStaticBox(WxNoteBookPage9, ID_WXSTATICBOX19, wxT("Text preview in recipients' phone(s)"), wxPoint(2,290), wxSize(381,101));

	WxMemo2 = new wxTextCtrl(WxNoteBookPage9, ID_WXMEMO2, wxT(""), wxPoint(9,310), wxSize(364,72), wxTE_READONLY | wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo2"));
	WxMemo2->SetMaxLength(0);
	WxMemo2->SetFocus();
	WxMemo2->SetInsertionPointEnd();

	WxNoteBookPage10 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE10, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage10, wxT("File transfer"));

	WxStaticText14 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT14, wxT("Format"), wxPoint(2,8), wxDefaultSize, 0, wxT("WxStaticText14"));

	wxArrayString arrayStringFor_WxComboBox3;
	arrayStringFor_WxComboBox3.Add(wxT("Nokia calendar (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Nokia phonebook (vcf)"));
	arrayStringFor_WxComboBox3.Add(wxT("Nokia todo (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens calendar (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens phonebook (vcf)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens note (vnt)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens todo (vcs)"));
	arrayStringFor_WxComboBox3.Add(wxT("Siemens (bmp, mid or other)"));
	WxComboBox3 = new wxComboBox(WxNoteBookPage10, ID_WXCOMBOBOX3, wxT("WxComboBox3"), wxPoint(78,6), wxSize(305,21), arrayStringFor_WxComboBox3, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("WxComboBox3"));

	WxButton2 = new wxButton(WxNoteBookPage10, ID_WXBUTTON2, wxT("Load"), wxPoint(304,34), wxSize(77,23), 0, wxDefaultValidator, wxT("WxButton2"));

	WxStaticText15 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT15, wxT("File name"), wxPoint(2,38), wxDefaultSize, 0, wxT("WxStaticText15"));
	WxStaticText15->Enable(false);

	WxEdit3 = new wxTextCtrl(WxNoteBookPage10, ID_WXEDIT3, wxT(""), wxPoint(78,34), wxSize(219,22), 0, wxDefaultValidator, wxT("WxEdit3"));
	WxEdit3->Enable(false);

	WxMemo3 = new wxTextCtrl(WxNoteBookPage10, ID_WXMEMO3, wxT(""), wxPoint(78,67), wxSize(304,257), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo3"));
	WxMemo3->SetMaxLength(0);
	WxMemo3->Enable(false);
	WxMemo3->SetFocus();
	WxMemo3->SetInsertionPointEnd();

	WxStaticText17 = new wxStaticText(WxNoteBookPage10, ID_WXSTATICTEXT17, wxT("File text"), wxPoint(2,68), wxDefaultSize, 0, wxT("WxStaticText17"));
	WxStaticText17->Enable(false);

	WxNoteBookPage5 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE5, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage5, wxT("PhoneBook"));

	WxStaticBox4 = new wxStaticBox(WxNoteBookPage5, ID_WXSTATICBOX4, wxT("Original entry"), wxPoint(7,6), wxSize(379,164));

	WxStaticBox12 = new wxStaticBox(WxNoteBookPage5, ID_WXSTATICBOX12, wxT("Saved in SMS"), wxPoint(7,172), wxSize(380,181));

	WxStaticText4 = new wxStaticText(WxNoteBookPage5, ID_WXSTATICTEXT4, wxT("Format"), wxPoint(14,189), wxDefaultSize, 0, wxT("WxStaticText4"));

	wxArrayString arrayStringFor_WxChoice5;
	arrayStringFor_WxChoice5.Add(wxT("Nokia phonebook (VCARD 1.0)"));
	arrayStringFor_WxChoice5.Add(wxT("Nokia phonebook (VCARD 2.1)"));
	arrayStringFor_WxChoice5.Add(wxT("Siemens phonebook"));
	WxChoice5 = new wxChoice(WxNoteBookPage5, ID_WXCHOICE5, wxPoint(69,187), wxSize(199,21), arrayStringFor_WxChoice5, 0, wxDefaultValidator, wxT("WxChoice5"));
	WxChoice5->SetSelection(-1);

	WxListCtrl2 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL2, wxPoint(16,216), wxSize(366,129), wxLC_REPORT);
	WxListCtrl2->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl2->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl3 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL3, wxPoint(12,28), wxSize(367,131), wxLC_REPORT);
	WxListCtrl3->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl3->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxNoteBookPage4 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE4, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage4, wxT("Calendar"));

	WxStaticBox13 = new wxStaticBox(WxNoteBookPage4, ID_WXSTATICBOX13, wxT("Original entry"), wxPoint(3,4), wxSize(383,167));

	WxStaticBox14 = new wxStaticBox(WxNoteBookPage4, ID_WXSTATICBOX14, wxT("Saved in SMS"), wxPoint(3,175), wxSize(382,167));

	WxListCtrl1 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL1, wxPoint(10,25), wxSize(367,138), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl1->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl4 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL4, wxPoint(10,218), wxSize(366,117), wxLC_REPORT);
	WxListCtrl4->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl4->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	wxArrayString arrayStringFor_WxChoice6;
	arrayStringFor_WxChoice6.Add(wxT("Nokia Calendar"));
	arrayStringFor_WxChoice6.Add(wxT("Siemens Calendar"));
	WxChoice6 = new wxChoice(WxNoteBookPage4, ID_WXCHOICE6, wxPoint(121,190), wxSize(154,21), arrayStringFor_WxChoice6, 0, wxDefaultValidator, wxT("WxChoice6"));
	WxChoice6->SetSelection(-1);

	WxStaticText3 = new wxStaticText(WxNoteBookPage4, ID_WXSTATICTEXT3, wxT("Format"), wxPoint(12,191), wxDefaultSize, 0, wxT("WxStaticText3"));

	WxNoteBookPage8 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE8, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage8, wxT("ToDo"));

	WxStaticBox15 = new wxStaticBox(WxNoteBookPage8, ID_WXSTATICBOX15, wxT("Original entry"), wxPoint(7,8), wxSize(379,166));

	WxStaticBox16 = new wxStaticBox(WxNoteBookPage8, ID_WXSTATICBOX16, wxT("Saved in SMS"), wxPoint(7,180), wxSize(378,168));

	WxListCtrl5 = new wxListCtrl(WxNoteBookPage8, ID_WXLISTCTRL5, wxPoint(13,26), wxSize(364,137), wxLC_REPORT);
	WxListCtrl5->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl5->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl6 = new wxListCtrl(WxNoteBookPage8, ID_WXLISTCTRL6, wxPoint(13,218), wxSize(365,123), wxLC_REPORT);
	WxListCtrl6->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl6->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxStaticText12 = new wxStaticText(WxNoteBookPage8, ID_WXSTATICTEXT12, wxT("Format"), wxPoint(14,196), wxDefaultSize, 0, wxT("WxStaticText12"));

	wxArrayString arrayStringFor_WxChoice8;
	arrayStringFor_WxChoice8.Add(wxT("Nokia ToDo"));
	arrayStringFor_WxChoice8.Add(wxT("Siemens ToDo"));
	WxChoice8 = new wxChoice(WxNoteBookPage8, ID_WXCHOICE8, wxPoint(71,195), wxSize(157,21), arrayStringFor_WxChoice8, 0, wxDefaultValidator, wxT("WxChoice8"));
	WxChoice8->SetSelection(-1);

	WxNoteBookPage11 = new wxPanel(WxNotebook1, ID_WXNOTEBOOKPAGE11, wxPoint(4,24), wxSize(392,396));
	WxNotebook1->AddPage(WxNoteBookPage11, wxT("Note"));

	WxStaticBox20 = new wxStaticBox(WxNoteBookPage11, ID_WXSTATICBOX20, wxT("Original entry"), wxPoint(2,5), wxSize(382,182));

	WxStaticBox21 = new wxStaticBox(WxNoteBookPage11, ID_WXSTATICBOX21, wxT("Saved in SMS"), wxPoint(2,198), wxSize(383,183));

	WxListCtrl7 = new wxListCtrl(WxNoteBookPage11, ID_WXLISTCTRL7, wxPoint(11,24), wxSize(367,153), wxLC_REPORT);
	WxListCtrl7->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl7->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxListCtrl8 = new wxListCtrl(WxNoteBookPage11, ID_WXLISTCTRL8, wxPoint(10,248), wxSize(370,124), wxLC_REPORT);
	WxListCtrl8->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,180 );
	WxListCtrl8->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,180 );

	WxStaticText18 = new wxStaticText(WxNoteBookPage11, ID_WXSTATICTEXT18, wxT("Format"), wxPoint(11,220), wxDefaultSize, 0, wxT("WxStaticText18"));

	wxArrayString arrayStringFor_WxChoice10;
	arrayStringFor_WxChoice10.Add(wxT("Siemens note"));
	WxChoice10 = new wxChoice(WxNoteBookPage11, ID_WXCHOICE10, wxPoint(74,219), wxSize(166,21), arrayStringFor_WxChoice10, 0, wxDefaultValidator, wxT("WxChoice10"));
	WxChoice10->SetSelection(-1);

	WxNoteBookPage3 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE3, wxPoint(4,24), wxSize(409,435));
	WxNotebook2->AddPage(WxNoteBookPage3, wxT("Sending options"));

	WxStaticBox5 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX5, wxT("New recipient"), wxPoint(4,9), wxSize(398,74));

	NewRecipientAddWxButton = new wxButton(WxNoteBookPage3, ID_NEWRECIPIENTADDWXBUTTON, wxT("Add"), wxPoint(287,27), wxSize(107,23), 0, wxDefaultValidator, wxT("NewRecipientAddWxButton"));
	NewRecipientAddWxButton->Enable(false);

	NewRecipientWxEdit = new wxTextCtrl(WxNoteBookPage3, ID_NEWRECIPIENTWXEDIT, wxT(""), wxPoint(15,27), wxSize(263,23), 0, wxDefaultValidator, wxT("NewRecipientWxEdit"));

	WxStaticBox6 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX6, wxT("Current recipients"), wxPoint(3,85), wxSize(400,164));

	RecipientsWxListCtrl = new wxListCtrl(WxNoteBookPage3, ID_RECIPIENTSWXLISTCTRL, wxPoint(13,106), wxSize(263,135), wxLC_REPORT | wxLC_NO_HEADER);
	RecipientsWxListCtrl->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,200 );
	RecipientsWxListCtrl->InsertColumn(0,wxT("Number"),wxLIST_FORMAT_LEFT,100 );

	WxButton6 = new wxButton(WxNoteBookPage3, ID_WXBUTTON6, wxT("Add from phonebook"), wxPoint(287,52), wxSize(107,22), 0, wxDefaultValidator, wxT("WxButton6"));
	WxButton6->Show(false);

	RecipientDeleteWxButton = new wxButton(WxNoteBookPage3, ID_RECIPIENTDELETEWXBUTTON, wxT("Delete"), wxPoint(287,106), wxSize(106,21), 0, wxDefaultValidator, wxT("RecipientDeleteWxButton"));
	RecipientDeleteWxButton->Enable(false);

	WxStaticBox7 = new wxStaticBox(WxNoteBookPage3, ID_WXSTATICBOX7, wxT("Other"), wxPoint(2,250), wxSize(399,77));

	WxStaticText2 = new wxStaticText(WxNoteBookPage3, ID_WXSTATICTEXT2, wxT("SMS center"), wxPoint(11,264), wxDefaultSize, 0, wxT("WxStaticText2"));

	wxArrayString arrayStringFor_SMSCWxComboBox;
	SMSCWxComboBox = new wxComboBox(WxNoteBookPage3, ID_SMSCWXCOMBOBOX, wxT("SMSCWxComboBox"), wxPoint(74,260), wxSize(202,21), arrayStringFor_SMSCWxComboBox, wxCB_DROPDOWN | wxCB_READONLY | wxTE_READONLY, wxDefaultValidator, wxT("SMSCWxComboBox"));

	ReportWxCheckBox = new wxCheckBox(WxNoteBookPage3, ID_REPORTWXCHECKBOX, wxT("Delivery reports (no extra costs)"), wxPoint(10,305), wxSize(314,19), 0, wxDefaultValidator, wxT("ReportWxCheckBox"));

	WxStaticText1 = new wxStaticText(WxNoteBookPage3, ID_WXSTATICTEXT1, wxT("Validity"), wxPoint(11,285), wxDefaultSize, 0, wxT("WxStaticText1"));

	wxArrayString arrayStringFor_ValidityWxComboBox;
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 hour"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("6 hours"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 day"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("3 days"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("1 week"));
	arrayStringFor_ValidityWxComboBox.Add(wxT("Max time"));
	ValidityWxComboBox = new wxComboBox(WxNoteBookPage3, ID_VALIDITYWXCOMBOBOX, wxT("ValidityWxComboBox"), wxPoint(74,283), wxSize(202,21), arrayStringFor_ValidityWxComboBox, wxCB_DROPDOWN | wxCB_READONLY, wxDefaultValidator, wxT("ValidityWxComboBox"));

	CancelWxButton = new wxButton(WxPanel1, ID_CANCELWXBUTTON, wxT("Cancel"), wxPoint(431,115), wxSize(137,26), 0, wxDefaultValidator, wxT("CancelWxButton"));

	SendWxButton = new wxButton(WxPanel1, ID_SENDWXBUTTON, wxT("Send"), wxPoint(431,26), wxSize(136,25), 0, wxDefaultValidator, wxT("SendWxButton"));
	SendWxButton->Enable(false);

	WxOpenFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxOPEN);

	SetTitle(wxT("Untitled1"));
	SetIcon(wxNullIcon);
	SetSize(8,8,582,498);
	Center();
	
	////GUI Items Creation End
}

void SMSEditorDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

void SMSEditorDlg::SetInfo()
{
    char                   buff[200];
	GSM_SMSListSubEntry    *SubEntry;
	int                    Parts=0;

	RecipientDeleteWxButton->Enable((RecipientsWxListCtrl->GetItemCount()!=0));

    SubEntry = NULL;
    while (List->GetNext(&SubEntry)) Parts++;

    if (RecipientsWxListCtrl->GetItemCount()!=0 && Parts!=0) {
    	SendWxButton->Enable(TRUE);
    } else {
    	SendWxButton->Enable(FALSE);
    }
    sprintf(buff,"Send %i SMS (%i parts)",Parts*RecipientsWxListCtrl->GetItemCount(),Parts);
    SendWxButton->SetLabel(buff);
}

/*
 * CancelWxButtonClick
 */
void SMSEditorDlg::CancelWxButtonClick(wxCommandEvent& event)
{
	EndModal(wxID_CANCEL);
}

/*
 * TextSMSWxMemoUpdated
 */
void SMSEditorDlg::TextSMSWxMemoUpdated(wxCommandEvent& event)
{
    GSM_Error                   error;
    char                        buff2[500];
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    List->ClearAll();

    Decoded.SMSUnicode = TextSMSUnicodeWxCheckBox->GetValue();
    
    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/plain"));
    UnicodeToUTF8((const wchar_t *)TextSMSWxMemo->GetValue().wc_str(wxConvLibc), &Decoded2->File.Buffer);
    Decoded.Add(Decoded2);
     
    if (WxCheckBox3->GetValue()) {
        error = Decoded.SaveToSMS(List, SMS_Text_Long, &left);
    } else {
        error = Decoded.SaveToSMS(List, SMS_Text_Short, &left);
    }
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }
    sprintf(buff2,"Text (%i SMS/%i chars left)",i,left);
    WxStaticBox1->SetLabel(buff2);

    WxCheckBox1->Enable((i<2));
    WxComboBox1->Enable((WxCheckBox1->GetValue() && WxCheckBox1->IsEnabled()));
    WxCheckBox3->Enable((i>1));
    WxComboBox4->Enable((i<2));
    WxComboBox4->Enable((WxCheckBox4->GetValue() && WxCheckBox4->IsEnabled()));

    //preview
    TextSMSPreviewWxMemo->Clear();
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        UTF8ToUnicode(Decoded3->File.Buffer.data(),&dest,Decoded3->File.Buffer.size());
        TextSMSPreviewWxMemo->AppendText(dest.data());
    }

    SetInfo();

    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
    	SMS2->GetSMS()->SetType(SMS_Submit);
        if (TextSMSClassWxCheckBox->GetValue()) SMS2->GetSMS()->SetClass(0);
        if (WxCheckBox1->GetValue() && WxCheckBox1->IsEnabled()) {
            SMS2->GetSMS()->SetReplace(WxComboBox1->GetCurrentSelection());
        } else {
            SMS2->GetSMS()->SetReplace(-1);
        }
        if (WxCheckBox4->GetValue() && WxCheckBox4->IsEnabled()) {
            SMS2->GetSMS()->SetRejectDuplicates(TRUE);
            SMS2->GetSMS()->TPMR = WxComboBox4->GetCurrentSelection();
        } else {
            SMS2->GetSMS()->SetRejectDuplicates(FALSE);
        }   
    	if (ReplyWxCheckBox->GetValue()) SMS2->GetSMS()->SetSenderSMSCReply(TRUE);             
    }
}

/*
 * RecipientDeleteWxButtonClick
 */
void SMSEditorDlg::RecipientDeleteWxButtonClick(wxCommandEvent& event)
{
    long item=-1;

    for (;;) {
        item = RecipientsWxListCtrl->GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
        if (item==-1) break;
        RecipientsWxListCtrl->DeleteItem(item);
        item=-1;
    }
    SetInfo();
}

/*
 * SendWxButtonClick
 */
void SMSEditorDlg::SendWxButtonClick(wxCommandEvent& event)
{
	GSM_SMSListSubEntry *SMS2;
    
	SMS2 = NULL;
	while (List->GetNext(&SMS2) == TRUE) {
    	SMS2->GetSMS()->SetType(SMS_Submit);

        SMS2->GetSMS()->SetSMSCNumber((wchar_t *)((const wchar_t *)SMSCWxComboBox->GetValue().wc_str(wxConvLibc)));

        switch (ValidityWxComboBox->GetCurrentSelection()) {
            case 0:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Hour);break;
            case 1:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_6_Hours);break;
            case 2:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Day);break;
            case 3:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_3_Days);break;
            case 4:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_1_Week);break;
            case 5:SMS2->GetSMS()->SetRelativeValidity(SMS_RelativeValidity_Max_Time);break;
        }

    	if (ReportWxCheckBox->GetValue()) SMS2->GetSMS()->SetReportRequest(TRUE);
    }        
	EndModal(wxID_OK);
}

/*
 * TextSMSUnicodeWxCheckBoxClick
 */
void SMSEditorDlg::TextSMSUnicodeWxCheckBoxClick(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * NewRecipientAddWxButtonClick
 */
void SMSEditorDlg::NewRecipientAddWxButtonClick(wxCommandEvent& event)
{
    long tmp;

    tmp = RecipientsWxListCtrl->InsertItem((num)++, NewRecipientWxEdit->GetValue(), 0);
    SetInfo();
}

/*
 * NewRecipientWxEditUpdated
 */
void SMSEditorDlg::NewRecipientWxEditUpdated(wxCommandEvent& event)
{
	NewRecipientAddWxButton->Enable((NewRecipientWxEdit->GetValue()!=""));
}

/*
 * TextSMSClassWxCheckBoxClick
 */
void SMSEditorDlg::TextSMSClassWxCheckBoxClick(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxCheckBox1Click1
 */
void SMSEditorDlg::WxCheckBox1Click1(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxComboBox1Updated
 */
void SMSEditorDlg::WxComboBox1Updated(wxCommandEvent& event )
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxComboBox4Updated
 */
void SMSEditorDlg::WxComboBox4Updated(wxCommandEvent& event )
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxCheckBox4Click
 */
void SMSEditorDlg::WxCheckBox4Click(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * ReplyWxCheckBoxClick
 */
void SMSEditorDlg::ReplyWxCheckBoxClick(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxCheckBox3Click
 */
void SMSEditorDlg::WxCheckBox3Click(wxCommandEvent& event)
{
    TextSMSWxMemoUpdated(event);
}

/*
 * WxChoice1Selected
 */
void SMSEditorDlg::WxChoice1Selected(wxCommandEvent& event )
{
    Indicators();
}

void SMSEditorDlg::Indicators()
{
    GSM_Error                   error;
    int                         left;
    GSM_SMSEntry                SMS;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    BOOLEAN                     added = FALSE;
    GSM_SMSMMSDecodedEntry      Decoded;    

    List->ClearAll();

    if (WxChoice1->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Voice_Indicator;
        Decoded2->IntVal = WxChoice1->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice2->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Fax_Indicator;
        Decoded2->IntVal = WxChoice2->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice3->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Email_Indicator;
        Decoded2->IntVal = WxChoice3->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }
    if (WxChoice4->GetCurrentSelection()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_SMS_Other_Indicator;
        Decoded2->IntVal = WxChoice4->GetCurrentSelection() - 1;
        Decoded.Add(Decoded2);
        added=TRUE;
    }

    if (!added) {
        SetInfo();        
        return;
    }
    
    error = Decoded.SaveToSMS(List, SMS_Indicators, &left);
    
    SetInfo();    
}

/*
 * WxChoice2Selected
 */
void SMSEditorDlg::WxChoice2Selected(wxCommandEvent& event )
{
Indicators();
}

/*
 * WxChoice3Selected
 */
void SMSEditorDlg::WxChoice3Selected(wxCommandEvent& event )
{
    Indicators();
}

/*
 * WxChoice4Selected
 */
void SMSEditorDlg::WxChoice4Selected(wxCommandEvent& event )
{
    Indicators();
}

void SMSEditorDlg::WAPBookmark()
{
    GSM_Error                   error;
    int                         left;
    GSM_SMSEntry                SMS;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    wchart                      dest;

    if (start) return;

    List->ClearAll();

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_SMS_URL;
    Decoded2->Text.append(WxEdit1->GetValue().wc_str(wxConvLibc));
    Decoded2->Text2.append(WxEdit2->GetValue().wc_str(wxConvLibc));
    Decoded.Add(Decoded2);

    switch (WxChoice7->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_WAP_Bookmark, &left);
        break;
    case 1:
        error = Decoded.SaveToSMS(List, SMS_WAP_Push, &left);
        break;
    }
    PrintError (error);

    SetInfo();
}


/*
 * WxChoice7Selected
 */
void SMSEditorDlg::WxChoice7Selected(wxCommandEvent& event )
{
    WAPBookmark();
}

/*
 * WxEdit1Updated1
 */
void SMSEditorDlg::WxEdit1Updated1(wxCommandEvent& event)
{
    WAPBookmark();
}

/*
 * WxEdit2Updated
 */
void SMSEditorDlg::WxEdit2Updated(wxCommandEvent& event)
{
    WAPBookmark();
}

void SMSEditorDlg::SendPBK(GSM_PBKEntry *PBK)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_PBKSubEntry         *SubEntry;
    int                     EntryNum=0;
    wchart                  x;
    long                    tmp;
    char                    type[50];
    wchar_t                 Value[500];
    BOOLEAN                 FirstNum = true;
	GSM_SMSList		        List;

    DeleteP("Calendar");
    DeleteP("Text SMS");    
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Image");
    DeleteP("File transfer");
    DeleteP("Note");

    PBK2 = PBK;    
    
    SubEntry = NULL;
    while (PBK2->GetNext(&SubEntry)) {
        DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
        tmp = WxListCtrl3->InsertItem(EntryNum++, type, 0);
        WxListCtrl3->SetItemData(tmp, 0);
        WxListCtrl3->SetItem(tmp, 1, Value);
    } 
    
    WxChoice5->Select(1);   
    SelectPBK();
}

/*
 * WxChoice5Selected
 */
void SMSEditorDlg::WxChoice5Selected(wxCommandEvent& event )
{
    SelectPBK();
}

void SMSEditorDlg::SelectPBK()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    switch (WxChoice5->GetCurrentSelection()) {
    case 0:
        error = PBK2->EncodeToVCARD(&txt, VCARD_10);
        break;
    case 1:
    case 2:
        error = PBK2->EncodeToVCARD(&txt, VCARD_21);
        break;
    }

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vCard"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                   wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice5->GetCurrentSelection()) {
    case 0:
    case 1:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCARD, &left);
        break;
    case 2:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("Pbk.vcf"),7);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }
    
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendCalendar(GSM_CalendarEntry *Cal)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    wchart                  x;
	GSM_SMSList		        List;

    DeleteP("PhoneBook");
    DeleteP("Text SMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Image");
    DeleteP("File transfer");
    DeleteP("Note");

    Cal2 = Cal;

    DisplayCalendar2(Cal2, WxListCtrl1);

    WxChoice6->Select(0);
    SelectCalendar();
}

/*
 * WxChoice6Selected
 */
void SMSEditorDlg::WxChoice6Selected(wxCommandEvent& event )
{
    SelectCalendar();
}

void SMSEditorDlg::SelectCalendar()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = Cal2->EncodeToVCALENDAR(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vCalendar"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                   wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice6->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCALENDAR, &left);
        break;
    case 1:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("Cal.vcs"),7);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    } 
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendNote(GSM_NoteEntry *Not)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    wchart                  x;
	GSM_SMSList		        List;

    DeleteP("PhoneBook");
    DeleteP("Text SMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("ToDo");
    DeleteP("Image");
    DeleteP("File transfer");
    DeleteP("Calendar");

    Note2 = Not;

    DisplayNote2(Note2, WxListCtrl7);

    WxChoice10->Select(0);
    SelectNote();
}


void SMSEditorDlg::SelectNote()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = Note2->EncodeToVNOTE(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vNote"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
    Decoded2->File.Info.Name.append(StringToUnicodeReturn("Note.vnt"),8);
    error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::SendToDo(GSM_ToDoEntry *ToDo)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_ToDoSubEntry        *SubEntry;
    wchart                  x;
	GSM_SMSList		        List;
    wchart                  Text;
    long                    EntryNum = 0, tmp;
    char                    buff3[200];
    wchart                  buff4;
    
    DeleteP("PhoneBook");
    DeleteP("Text SMS");
    DeleteP("URL");
    DeleteP("Indicators");
    DeleteP("Calendar");
    DeleteP("Image");
    DeleteP("File transfer");
    DeleteP("Note");

    ToDo2 = ToDo;

    SubEntry = NULL;
    while (ToDo->GetNext(&SubEntry)) {
        DecodeToDoSubEntry(SubEntry, buff3, &buff4);
        tmp = WxListCtrl5->InsertItem(EntryNum++, buff3, 0);
        WxListCtrl5->SetItem(tmp, 1, buff4.data());
    }
        
    WxChoice8->Select(0);
    SelectToDo();
}


/*
 * WxChoice8Selected
 */
void SMSEditorDlg::WxChoice8Selected(wxCommandEvent& event )
{
	SelectToDo();
}

void SMSEditorDlg::SelectToDo()
{
    unsignedstring              txt;
    GSM_PBKEntry                PBK3;
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    GSM_PBKSubEntry             *SubEntry;
    int                         EntryNum=0;
    wchart                      x;
    long                        tmp;
    char                        type[50];
    wchar_t                     Value[500];
    BOOLEAN                     FirstNum = true;
    int                         i,left;
    GSM_SMSEntry                SMS;
    GSM_SMSListSubEntry         *SMS2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2,*Decoded3;
    wchart                      dest;

    error = ToDo2->EncodeToVTODO(&txt);

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("text/x-vTodo"));
    Decoded2->File.Buffer.append(txt);
    Decoded.Add(Decoded2);
//            wxMessageBox(txt.data(),
//                  wxT("Error"),
//                   wxICON_WARNING | wxOK);
    switch (WxChoice8->GetCurrentSelection()) {
    case 0:
        error = Decoded.SaveToSMS(List, SMS_Nokia_VTODO, &left);
        break;
    case 1:
        Decoded2->File.Info.Name.append(StringToUnicodeReturn("ToDo.vcs"),8);
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }                   
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }

    SetInfo();
return;

    //preview
    if (i!=0) {
    	Decoded.ClearAll();
        error = Decoded.ReadFromSMS(List);
        PrintError (error);
        Decoded3 = NULL;
        Decoded.GetNext(&Decoded3);
        PBK3.DecodeFromVCARD(&Decoded3->File.Buffer);

        WxListCtrl2->DeleteAllItems();
        SubEntry = NULL;
        while (PBK3.GetNext(&SubEntry)) {
            DecodePBKSubEntry(SubEntry, type, Value, &FirstNum);
            tmp = WxListCtrl2->InsertItem(EntryNum++, type, 0);
            WxListCtrl2->SetItemData(tmp, 0);
            WxListCtrl2->SetItem(tmp, 1, Value);
        }
    }

    SetInfo();
}

void SMSEditorDlg::Image()
{
    GSM_File                    File;
    int                         x,y,left,i;
    wxImage                     *Img;
    wxBitmap                    *Bitmap,Bitmap2;
    Mono_Bitmap_FileSubEntry    *Sub;
    char                        buff[200];
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    GSM_Error                   error;
    GSM_SMSListSubEntry         *SMS2;
    wchart                      dest;

    Sub = NULL;
    for(i=0;i<WxChoice9->GetCurrentSelection()+1;i++) {
        MonoFile.GetNext(&Sub);
    }

    //preview
    Img = new wxImage(Sub->GetWidth()*2,Sub->GetHeight()*2,true);
    for (x=0;x<Sub->GetWidth();x++) {
        for (y=0;y<Sub->GetHeight();y++) {
            wxRect r(x,y,x+2,y+2);
            if (Sub->IsPointBlack(x,y)) {
                Img->SetRGB(r,99,207,99);
            } else {
                Img->SetRGB(r,1,1,1);
            }
        }
    }
    wxSize w(Sub->GetWidth(),Sub->GetHeight());
    wxPoint p;
    p.x = 0;
    p.y = 0;
    Img->Resize(w,p);
    Bitmap = new wxBitmap(*Img,-1);
    WxBitmapButton1->SetBitmapLabel(*Bitmap);
    delete Bitmap;
    delete Img;

    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    Decoded2->Text.append(StringToUnicodeReturn("image/bmp"));
    MonoFile.SaveToBMP(&Decoded2->File.Buffer,1);
    Decoded.Add(Decoded2);

    Decoded.SMSUnicode = WxCheckBox2->GetValue();

    if (WxMemo1->GetValue().size()!=0) {
        Decoded2 = new GSM_SMSMMSDecodedSubEntry;
        Decoded2->Type = MSG_MMSSMS_File;
        Decoded2->Text.append(StringToUnicodeReturn("text/plain"));
        UnicodeToUTF8((const wchar_t *)WxMemo1->GetValue().wc_str(wxConvLibc), &Decoded2->File.Buffer);
        Decoded.Add(Decoded2);
    }

    if (WxComboBox2->GetCurrentSelection()==0) {
        error = Decoded.SaveToSMS(List, SMS_Nokia_Picture, &left);
    } else {
        error = Decoded.SaveToSMS(List, SMS_Nokia_Profile, &left);
    }
    PrintError (error);

    i=0;
    SMS2 = NULL;
    while (List->GetNext(&SMS2)) {
        i++;
    }
    sprintf(buff,"Text (%i SMS/%i chars left)",i,left);
    WxStaticBox17->SetLabel(buff);

    //preview
    Decoded.ClearAll();
    error=Decoded.ReadFromSMS(List);
    PrintError (error);    
    WxMemo2->Clear();
    Decoded2=NULL;
    while (Decoded.GetNext(&Decoded2)) {
        if (!strcmp(UnicodeToStringReturn(Decoded2->Text.data()),"text/plain")) {
            UTF8ToUnicode(Decoded2->File.Buffer.data(),&dest,Decoded2->File.Buffer.size());
            WxMemo2->AppendText(dest.data());
        }
    }
            
    return;
}

/*
 * WxButton1Click1
 */
void SMSEditorDlg::WxButton1Click1(wxCommandEvent& event)
{
    Mono_Bitmap_FileSubEntry    *Sub;
    int                         i = 1;
    char               buff[200];

    WxOpenFileDialog1->SetWildcard("Logo pictures|*.nlm;*.bmp|Nokia Logo Manager files|*.nlm");
    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;

    WxChoice9->Enable(FALSE);
    WxMemo1->Enable(FALSE);
    WxCheckBox2->Enable(FALSE);
    WxComboBox2->Enable(FALSE);

    MonoFileAvail=TRUE;
    if (!MonoFile.ReadFile((char *)WxOpenFileDialog1->GetPath().c_str())) return;

    Sub = NULL;
    while (MonoFile.GetNext(&Sub)) {
        sprintf(buff,"Frame %i",i);
        WxChoice9->Append(buff);
        i++;
    }
    
    if (i==1) return;
    
    WxChoice9->Enable(TRUE);
    WxMemo1->Enable(TRUE);
    WxCheckBox2->Enable(TRUE);
    WxComboBox2->Enable(TRUE);
    
    
    WxChoice9->Select(0);

    Image();
}


/*
 * WxMemo1Updated1
 */
void SMSEditorDlg::WxMemo1Updated1(wxCommandEvent& event)
{
    Image();
}

/*
 * WxCheckBox2Click
 */
void SMSEditorDlg::WxCheckBox2Click(wxCommandEvent& event)
{
    Image();
}

/*
 * WxChoice9Selected
 */
void SMSEditorDlg::WxChoice9Selected(wxCommandEvent& event )
{
	Image();
}

/*
 * WxButton2Click1
 */
void SMSEditorDlg::WxButton2Click1(wxCommandEvent& event)
{
    WxOpenFileDialog1->SetWildcard("");
    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;
    
    if (!FF.ReadFromDisk((wchar_t *)((const wchar_t *)WxOpenFileDialog1->GetPath().wc_str(wxConvLibc)))) return;

    if (UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".txt"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vcs"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vcf"))!=NULL ||
        UnicodeCaseStr(FF.Info.ID.data(),StringToUnicodeReturn(".vnt"))!=NULL) {
            WxMemo3->SetValue(FF.Buffer.data());
            WxMemo3->Enable(TRUE);
            WxStaticText17->Enable(TRUE);
    } else {
            WxMemo3->SetValue("");
            WxMemo3->Enable(false);
            WxStaticText17->Enable(false);
    }
    WxEdit3->SetValue(FF.Info.Name.data());
     
    FileTransfer();
}

void SMSEditorDlg::FileTransfer()
{
    GSM_File                    File;
    int                         left;
    wxBitmap                    Bitmap2;
    GSM_SMSMMSDecodedEntry      Decoded;
    GSM_SMSMMSDecodedSubEntry   *Decoded2;
    GSM_Error                   error;
    wchart                      dest;

    if (UpdatingFileTransfer) return;
    if (FF.Buffer.size()==0) return;
    UpdatingFileTransfer=TRUE;

    List->ClearAll();

    WxEdit3->Enable((WxComboBox3->GetCurrentSelection()>2));
    WxStaticText15->Enable((WxComboBox3->GetCurrentSelection()>2));

    switch (WxComboBox3->GetCurrentSelection()) {
    case 3:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcs"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 4:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcf"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 5:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vnt"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    case 6:
        if (UnicodeCaseStr((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),StringToUnicodeReturn(".vcs"))==NULL) {
            SetInfo();
            UpdatingFileTransfer=FALSE;
            return;
        }
        break;
    default:
        break;
    }
        
    Decoded2 = new GSM_SMSMMSDecodedSubEntry;
    Decoded2->Type = MSG_MMSSMS_File;
    if (WxMemo3->IsEnabled()) {
        Decoded2->File.Buffer.append((const unsigned char *)WxMemo3->GetValue().c_str(),strlen((const char *)WxMemo3->GetValue().c_str()));
    } else {
        Decoded2->File.Buffer.append(FF.Buffer.data(),FF.Buffer.size());
    }
    Decoded2->File.Info.Name.append((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc),UnicodeLength((const wchar_t *)WxEdit3->GetValue().wc_str(wxConvLibc)));
    
    switch (WxComboBox3->GetCurrentSelection()) {
    case 0:
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vCalendar"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCALENDAR, &left);
        break;
    case 1: //phonebook
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vCard"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VCARD, &left);
        break;
    case 2: //todo
        Decoded2->Text.append(StringToUnicodeReturn("text/x-vTodo"));
        Decoded.Add(Decoded2);
        error = Decoded.SaveToSMS(List, SMS_Nokia_VTODO, &left);
        break;
    default:
        Decoded2->Text.append(StringToUnicodeReturn("text/plain"));
        Decoded.Add(Decoded2);        
        error = Decoded.SaveToSMS(List, SMS_Siemens_File, &left);
        break;
    }
    SetInfo();

    UpdatingFileTransfer=FALSE;

    PrintError (error);
}

/*
 * WxComboBox3Selected
 */
void SMSEditorDlg::WxComboBox3Selected(wxCommandEvent& event )
{
    FileTransfer();
}

/*
 * WxEdit3Updated
 */
void SMSEditorDlg::WxEdit3Updated(wxCommandEvent& event)
{
    FileTransfer();
}

/*
 * WxMemo3Updated
 */
void SMSEditorDlg::WxMemo3Updated(wxCommandEvent& event)
{
    FileTransfer();
}

