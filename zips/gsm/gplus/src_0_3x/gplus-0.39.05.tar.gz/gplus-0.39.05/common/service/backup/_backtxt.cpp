/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include "../../../cfg/config.h" //msvc2005
#include "../../misc/files.h"
#include "../../misc/coding/coding.h"
#include "../../misc/coding/md5.h"
#include "../gsmpbk.h"
#include "gsmback.h"

GSM_Error GSM_Backup::FindTextFileChecksum(INI_File *File, char *checksum)
{
	INI_File_Section 	*Section;
	INI_File_Entry 		*Entry;
	wchart			Buff,Buff2,Buff3;
	unsignedstring		Buff4;
	wchart			x;
	//variables taken from md5main.c
	md5_state_t 		state;
	md5_byte_t 		digest[16];
	char 			hex_output[16*2 + 1];
	unsigned int 		di;

	StringToUnicode("Checksum",&x);

	Section = NULL;
	while (File->GetNextSection(&Section)) {
		if (UnicodeCaseCmp(x.data(),Section->Name.data(),-1)) continue;

		Buff.append(Section->Name.data(),Section->Name.size());
		Buff3.clear();
		Entry = NULL;
		while (Section->GetNextEntry(&Entry)) {
			//we add next entry on start because it's done this way in Gammu
			Buff2.clear();
			Buff2.append(Entry->Name.data(),Entry->Name.size());
			Buff2.append(Entry->Value.data(),Entry->Value.size());
			Buff2.append(Buff3.data(),Buff3.size());
			Buff3.clear();
			Buff3.append(Buff2.data(),Buff2.size());
		}
		Buff.append(Buff3.data(),Buff3.size());
	}

	for (di=0;di<Buff.size();di++) {
		Buff4.push_back(Buff.data()[di]/256);
		Buff4.push_back(Buff.data()[di]%256);
	}

	//4 lines taken from md5main.c
	md5_init(&state);
	md5_append(&state, (const md5_byte_t *)Buff4.data(), Buff4.size());
	md5_finish(&state, digest);
	for (di = 0; di < 16; ++di) sprintf(hex_output + di * 2, "%02x", digest[di]);

	sprintf(checksum,"%s",hex_output);
	for (di = 0; di < strlen(checksum); di++) checksum[di] = toupper(checksum[di]);

	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_Backup::SaveTextFilePart(const wchar_t *Text, FILE *file, BOOLEAN LineEnd)
{
	int 		i = 0;
	unsignedstring 	Buffer;

	while(1) {
		if (Text[i] == 0x00) break;
		if (Text[i] == 13) {
			Buffer.push_back('\\'); Buffer.push_back(0); 
			Buffer.push_back('r');  Buffer.push_back(0); 
		} else if (Text[i] == 10) {
			Buffer.push_back('\\'); Buffer.push_back(0); 
			Buffer.push_back('n');  Buffer.push_back(0); 
		} else {
			Buffer.push_back(Text[i]%256);
			Buffer.push_back(Text[i]/256);
		}
		i++;
	}
	if (LineEnd) {
		Buffer.push_back(13);
		Buffer.push_back(0);
		Buffer.push_back(10);
		Buffer.push_back(0);
	}
	fwrite(Buffer.data(),1,Buffer.size(),file);
}

GSM_Error GSM_Backup::SaveCallerToTextFile(FILE *file)
{
	GSM_Backup_CallerGroupEntry		*CallerEntry;
	GSM_CallerGroupSubEntry		*Sub;
	int				Num=1;
	char				buff[500];
	unsignedstring			buff2;
	wchart				buff3;

	CallerEntry = NULL;
	while(GetNext_CallerGroup(&CallerEntry)) {
	    	SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[Caller%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		sprintf(buff,"Location = %03i",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		Sub = NULL;
		while (CallerEntry->GetEntry()->GetNext(&Sub)) {
			switch(Sub->Type) {
			case GSM_CallerName:
				sprintf(buff,"Name = \"");
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				SaveTextFilePart(Sub->Text.data(), file, FALSE);
				sprintf(buff,"\"");
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			default:
				break;
			}
		}

		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

GSM_Error GSM_Backup::SaveSMSToTextFile(FILE *file)
{
	GSM_Backup_SMSEntry		*SMSEntry;
	GSM_SMSListSubEntry		*SubEntry;
	int				Num=1,Seq=1,Part,i,j,NumbersNum;
	char				buff[500];
	GSM_SMSNumbersSubEntry  	*Numbers;
	GSM_SMSMMSFoldersSubEntry	*SubEntry2;
	unsignedstring			buff2;
	wchart				buff3;

	SMSEntry = NULL;
	if(GetNext_SMS(&SMSEntry)) {
	    	SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[SMSFolders]");
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		SubEntry2 = NULL;
		while (SMSMMSFolders.GetNext(&SubEntry2)) {
			if (SubEntry2->MMS) continue;
			sprintf(buff,"Entry%02i = \"",Num);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
			SaveTextFilePart(SubEntry2->GetName(), file, FALSE);
			sprintf(buff,"\"");
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			Num++;
		}
	}

	Num=1;
	SMSEntry = NULL;
	while (GetNext_SMS(&SMSEntry)) {
		SubEntry = NULL;

		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[SMSList%05i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		i=0;
		SubEntry2 = NULL;
		for (j=0;j<SMSEntry->GetEntry()->Folder;j++) {
			SMSMMSFolders.GetNext(&SubEntry2);
			if (!SubEntry2->MMS) i++;
		}
		sprintf(buff,"Folder = %i",i);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		Part = 1;
		while (SMSEntry->GetEntry()->GetNext(&SubEntry)) {
			SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
			sprintf(buff,"[SMSPart%05i_%02i]",Num,Part);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

			sprintf(buff,"TPDCS = %02x",SubEntry->GetSMS()->TPDCS);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"TPStatus = %02x",SubEntry->GetSMS()->TPStatus);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"TPUDL = %02x",SubEntry->GetSMS()->TPUDL);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"TPVP = %02x",SubEntry->GetSMS()->TPVP);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"TPMR = %02x",SubEntry->GetSMS()->TPMR);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"TPPID = %02x",SubEntry->GetSMS()->TPPID);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"firstbyte = %02x",SubEntry->GetSMS()->firstbyte);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"UserData = ");			
			SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
			StringToHexBin(&SubEntry->GetSMS()->UserData, &buff2);
			buff3.clear();
			StringToUnicode((char *)buff2.data(), &buff3);
			SaveTextFilePart(buff3.data(), file, TRUE);

			sprintf(buff,"SMSCNumber = ");			
			SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
			StringToHexBin(&SubEntry->GetSMS()->SMSCNumber, &buff2);
			buff3.clear();
			StringToUnicode((char *)buff2.data(), &buff3);
			SaveTextFilePart(buff3.data(), file, TRUE);

			sprintf(buff,"DateTime = ");			
			for (i=0;i<7;i++) {
				sprintf(buff+(i*2+11),"%02X",SubEntry->GetSMS()->DateTime[i]);
			}
			buff[i*2+11]=0;
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			sprintf(buff,"SMSCTime = ");			
			for (i=0;i<7;i++) {
				sprintf(buff+(i*2+11),"%02X",SubEntry->GetSMS()->SMSCTime[i]);
			}
			buff[i*2+11]=0;
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

			Numbers=NULL;
			NumbersNum=1;
			while (SubEntry->GetSMS()->PhoneNumbers.GetNext(&Numbers)) {
				sprintf(buff,"Number%03i = ",NumbersNum);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				StringToHexBin(&Numbers->PhoneNumber, &buff2);
				buff3.clear();
				StringToUnicode((char *)buff2.data(), &buff3);
				SaveTextFilePart(buff3.data(), file, TRUE);
				NumbersNum++;
			}
			if (SubEntry->GetSMS()->SaveDateTimeAvailable) {
				sprintf(buff,"Saved = ");				
				SaveVCalendarDateTime(&SubEntry->GetSMS()->SaveDateTime,buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			}
			
			Part++;
		}
		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

GSM_Error GSM_Backup::SaveMMSToTextFile(FILE *file)
{
	GSM_Backup_MMSEntry		*MMSEntry;
	int				Num=1,Seq=1,i,j;
	char				buff[500];
	GSM_SMSMMSFoldersSubEntry	*SubEntry2;
	unsignedstring			buff2;
	wchart				buff3;

	MMSEntry = NULL;
	if(GetNext_MMS(&MMSEntry)) {
	    	SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[MMSFolders]");
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		SubEntry2 = NULL;
		while (SMSMMSFolders.GetNext(&SubEntry2)) {
			if (!SubEntry2->MMS) continue;
			sprintf(buff,"Entry%02i = \"",Num);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
			SaveTextFilePart(SubEntry2->GetName(), file, FALSE);
			sprintf(buff,"\"");
			SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			Num++;
		}
	}

	Num=1;
	MMSEntry = NULL;
	while (GetNext_MMS(&MMSEntry)) {
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[MMSMessage%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		i=0;
		SubEntry2 = NULL;
		for (j=0;j<MMSEntry->GetEntry()->Folder;j++) {
			SMSMMSFolders.GetNext(&SubEntry2);
			if (SubEntry2->MMS) i++;
		}
		sprintf(buff,"Folder = %i",i);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		sprintf(buff,"Content = ");			
		SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
		StringToHexBin(&MMSEntry->GetEntry()->File.Buffer, &buff2);
		buff3.clear();
		StringToUnicode((const char *)buff2.data(), &buff3);
		SaveTextFilePart(buff3.data(), file, TRUE);

		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);	
}

static GetMemoryTypes GetMemoryType2[] = {
"NumberGeneral", 		PBK_Text_Phone_General,
"NumberCar", 			PBK_Text_Phone_Car,
"NumberHome", 			PBK_Text_Phone_Home,
"NumberWork", 			PBK_Text_Phone_Work,
"NumberFax", 			PBK_Text_Phone_Fax,
"NumberHomeFax", 		PBK_Text_Phone_Fax_Home,
"NumberWorkFax", 		PBK_Text_Phone_Fax_Work,
"NumberVideo",			PBK_Text_Phone_Video,
"NumberHomeVideo",		PBK_Text_Phone_Video_Home,
"NumberWorkVideo",		PBK_Text_Phone_Video_Work,
"NumberMobile",			PBK_Text_Phone_Mobile,
"NumberHomeMobile",		PBK_Text_Phone_Mobile_Home,
"NumberWorkMobile",		PBK_Text_Phone_Mobile_Work,
"NumberInternet",		PBK_Text_Phone_Internet,
"NumberHomeInternet",		PBK_Text_Phone_Internet_Home,
"NumberWorkInternet",		PBK_Text_Phone_Internet_Work,
"NumberAssistant",		PBK_Text_Phone_Assistant,
"Address",			PBK_Text_Postal_ZIP,
"Street",			PBK_Text_Postal_Street,
"City",				PBK_Text_Postal_City,
"State",			PBK_Text_Postal_State,
"ZIP",			PBK_Text_Postal_ZIP_Code,
"POBox",			PBK_Text_Postal_PO_Box,
"Country",			PBK_Text_Postal_Country,
"Extension",			PBK_Text_Postal_Extension,
"Region",			PBK_Text_Postal_Region,
"HomeAddress",		PBK_Text_Postal_ZIP_Home,
"HomeStreet",		PBK_Text_Postal_Street_Home,
"HomeCity",			PBK_Text_Postal_City_Home,
"HomeState",			PBK_Text_Postal_State_Home,
"HomeZIP",		PBK_Text_Postal_ZIP_Home,
"HomePOBox",		PBK_Text_Postal_PO_Box_Home,
"HomeCountry",		PBK_Text_Postal_Country_Home,
"HomeExtension",		PBK_Text_Postal_Extension_Home,
"HomeRegion",		PBK_Text_Postal_Region_Home,
"WorkZIP",		PBK_Text_Postal_ZIP_Work,
"WorkStreet",		PBK_Text_Postal_Street_Work,
"WorkCity",			PBK_Text_Postal_City_Work,
"WorkState",			PBK_Text_Postal_State_Work,
"WorkZIP",		PBK_Text_Postal_ZIP_Code_Work,
"WorkPOBox",		PBK_Text_Postal_PO_Box_Work,
"WorkCountry",		PBK_Text_Postal_Country_Work,
"WorkExtension",		PBK_Text_Postal_Extension_Work,
"WorkRegion",		PBK_Text_Postal_Region_Work,
"Email",			PBK_Text_Email,
"HomeEmail",			PBK_Text_Email_Home,
"WorkEmail",			PBK_Text_Email_Work,
"Pager",			PBK_Text_Pager,
"URL",				PBK_Text_URL,
"HomeURL",			PBK_Text_URL_Home,
"WorkURL",			PBK_Text_URL_Work,
"Spouse",			PBK_Text_Spouse,
"Children",			PBK_Text_Children,
"UserID",			PBK_Text_UserID,
"Note",				PBK_Text_Note,
"Name",				PBK_Text_Name,
"LastName",			PBK_Text_Name_Last,
"FirstName",			PBK_Text_Name_First,
"MiddleName",			PBK_Text_Name_Middle,
"FormalName",			PBK_Text_Name_Formal,
"Title",			PBK_Text_Name_Title,
"Suffix",			PBK_Text_Name_Suffix,
"NickName",			PBK_Text_Name_Nick,
"CompanyName",			PBK_Text_Company_Name,
"DepartmentName",		PBK_Text_Department_Name,
"JobTitle",			PBK_Text_Job_Title,
"AssistantName",		PBK_Text_Assistant,
"PTT",			PBK_Text_PTT,
"VideoSIP",		PBK_Text_Video_Sharing_SIP,
"ShareView",			PBK_Text_Share_View,
	"",				PBK_Not_Assigned	
};

/**
 * method for saving phonebook entries to backup text file. used internally
 */
GSM_Error GSM_Backup::SavePbkToTextFile(FILE *file, BOOLEAN Phone)
{
	GSM_Backup_PBKEntry	*PBKEntry;
	GSM_PBKSubEntry 	*PBKSubEntry;
	char			buff[100],buff2[100];
	int			Num,Num2,i;
	BOOLEAN			Found;

	Num = 1;
	PBKEntry = NULL;
	while (GetNext_PBK(&PBKEntry)) {
		if (PBKEntry->GetEntry()->Memory != MEM_PHONE && Phone) continue;
		if (PBKEntry->GetEntry()->Memory != MEM_SIM && !Phone) continue;

		Found = FALSE;
		Num2 = 1;
		PBKSubEntry = NULL;
		while (PBKEntry->GetEntry()->GetNext(&PBKSubEntry) == TRUE) {
			buff2[0] = 0;

			i=0;
			while(GetMemoryType2[i].Type!=PBK_Not_Assigned) {
				if (GetMemoryType2[i].Type==PBKSubEntry->GetType()) {
					sprintf(buff2,"%s",GetMemoryType2[i].Name);
					break;
				}
				i++;
			}
			switch (PBKSubEntry->GetType()) {
			case PBK_Bool_PTT_Subscribed : sprintf(buff2,"PTTSubscribed"); 	break;
			case PBK_ID_Caller_Group     : sprintf(buff2,"CallerGroup");	break;
			case PBK_ID_Picture          : sprintf(buff2,"PictureID");	break;
			case PBK_ID_Video_File       : sprintf(buff2,"VideoFileID");	break;
			case PBK_DateTime_Birthday   : sprintf(buff2,"Birthday");       break;
			case PBK_DateTime_Modified   : sprintf(buff2,"Modified");       break;
			default			     : break;
			}
			if (buff2[0] == 0) continue;
			if (!Found) {
				SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
				if (Phone) {
					sprintf(buff,"[PhonePBK%03i]",Num);
				} else {
					sprintf(buff,"[SIMPBK%03i]",Num);
				}
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				sprintf(buff,"Location = %03i",PBKEntry->GetEntry()->Location);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				Num++;
				Found = TRUE;
			}
			sprintf(buff,"Entry%02iType = ",Num2);
			SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
			SaveTextFilePart(StringToUnicodeReturn(buff2), file, TRUE);

			switch (PBKSubEntry->GetType()) {
			case PBK_DateTime_Birthday:
				sprintf(buff,"Entry%02iValue = ",Num2);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				buff[0] = 0;
				SaveVCalendarDateTime(PBKSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case PBK_DateTime_Modified:
				sprintf(buff,"Entry%02iValue = ",Num2);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				buff[0] = 0;
				SaveVCalendarDateTime(PBKSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case PBK_Bool_PTT_Subscribed:
				if (PBKSubEntry->BoolValue) {
					sprintf(buff,"Entry%02iValue = yes",Num2);
				} else {
					sprintf(buff,"Entry%02iValue = no",Num2);
				}
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case PBK_ID_Caller_Group:
			case PBK_ID_Picture:
				sprintf(buff,"Entry%02iNumber = %i",Num2,PBKSubEntry->LongValue);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			default:
				sprintf(buff,"Entry%02iText = \"",Num2);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				SaveTextFilePart(PBKSubEntry->GetText(), file, FALSE);
				sprintf(buff,"\"");
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			}

			switch (PBKSubEntry->GetType()) {
			case PBK_Text_Phone_General:
			case PBK_Text_Phone_Car:
			case PBK_Text_Phone_Home:
			case PBK_Text_Phone_Work:
			case PBK_Text_Phone_Fax:
			case PBK_Text_Phone_Fax_Home:
			case PBK_Text_Phone_Fax_Work:
			case PBK_Text_Phone_Video:
			case PBK_Text_Phone_Video_Home:
			case PBK_Text_Phone_Video_Work:
			case PBK_Text_Phone_Mobile:
			case PBK_Text_Phone_Mobile_Home:
			case PBK_Text_Phone_Mobile_Work:
			case PBK_Text_Phone_Internet:
			case PBK_Text_Phone_Internet_Home:
			case PBK_Text_Phone_Internet_Work:
			case PBK_Text_Phone_Assistant:
				if (PBKSubEntry->VoiceTag!=-1) {
					sprintf(buff,"Entry%02iVoiceTag = %i",Num2,PBKSubEntry->VoiceTag);
					SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				}
				break;
			default:
				break;
			}

			Num2++;
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveCalendarToTextFile(FILE *file)
{
	GSM_CalendarSubEntry 	*CalSubEntry;
	GSM_Backup_CalEntry	*CalEntry;
	char			buff[100];
	int			Num;

	Num = 1;
	CalEntry = NULL;
	while (GetNext_Cal(&CalEntry)) {		
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[Calendar%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		sprintf(buff,"Location = %03i",CalEntry->GetEntry()->Location);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		Num++;

		switch (CalEntry->GetEntry()->Type) {
		case Calendar_Type_Meeting :SaveTextFilePart(StringToUnicodeReturn("Type = Meeting"), file, TRUE);break;
		case Calendar_Type_Memo	   :SaveTextFilePart(StringToUnicodeReturn("Type = Memo"), file, TRUE);break;
		case Calendar_Type_Call	   :SaveTextFilePart(StringToUnicodeReturn("Type = Call"), file, TRUE);break;
		case Calendar_Type_Birthday:SaveTextFilePart(StringToUnicodeReturn("Type = Birthday"), file, TRUE);break;
		case Calendar_Type_Reminder:SaveTextFilePart(StringToUnicodeReturn("Type = Reminder"), file, TRUE);break;
		}

		CalSubEntry = NULL;
		while (CalEntry->GetEntry()->GetNext(&CalSubEntry) == TRUE) {
			switch (CalSubEntry->GetType()) {
			case Calendar_Text_Text:
				SaveTextFilePart(StringToUnicodeReturn("Text = \""), file, FALSE);
				SaveTextFilePart(CalSubEntry->GetText(), file, FALSE);
				SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);
				break;
			case Calendar_Text_Phone:
				SaveTextFilePart(StringToUnicodeReturn("Phone = \""), file, FALSE);
				SaveTextFilePart(CalSubEntry->GetText(), file, FALSE);
				SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);
				break;
			case Calendar_Text_Location:
				SaveTextFilePart(StringToUnicodeReturn("EventLocation = \""), file, FALSE);
				SaveTextFilePart(CalSubEntry->GetText(), file, FALSE);
				SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);
				break;
			case Calendar_DateTime_Modified:
				sprintf(buff,"Modified = ");
				SaveVCalendarDateTime(CalSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_DateTime_Start:
				sprintf(buff,"StartTime = ");
				SaveVCalendarDateTime(CalSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_DateTime_End:
				sprintf(buff,"StopTime = ");
				SaveVCalendarDateTime(CalSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_DateTime_SilentAlarm:
			case Calendar_DateTime_ToneAlarm:
				sprintf(buff,"Alarm = ");
				SaveVCalendarDateTime(CalSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				if (CalSubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
					SaveTextFilePart(StringToUnicodeReturn("AlarmType = Silent"), file, TRUE);
				} else {
					SaveTextFilePart(StringToUnicodeReturn("AlarmType = Tone"), file, TRUE);
				}
				break;
			case Calendar_DateTime_End_Repeat:
				sprintf(buff,"RepeatStopDate = ");
				SaveVCalendarDateTime(CalSubEntry->GetDateTime(),buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_Int_Repeat_Frequency:
				sprintf(buff,"RepeatFrequency = %i",CalSubEntry->GetInt());
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_Int_Repeat_DayOfWeek:
				sprintf(buff,"DayOfWeek = %i",CalSubEntry->GetInt());
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;			
			case Calendar_Int_Repeat_Day:
				sprintf(buff,"RepeatDay = %i",CalSubEntry->GetInt());
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			case Calendar_Int_Repeat_Month:
				sprintf(buff,"RepeatMonth = %i",CalSubEntry->GetInt());
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
				break;
			}
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveWAPBookmarksToTextFile(FILE *file)
{
	GSM_Backup_WAPBookmarkEntry	*BookEntry;
	char				buff[100];
	int				Num;

	Num = 1;
	BookEntry = NULL;
	while (GetNext_WAPBookmark(&BookEntry)) {		
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[WAPBookmark%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		SaveTextFilePart(StringToUnicodeReturn("URL = \""), file, FALSE);
		SaveTextFilePart(BookEntry->GetEntry()->URL.data(), file, FALSE);
		SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);

		SaveTextFilePart(StringToUnicodeReturn("Title = \""), file, FALSE);
		SaveTextFilePart(BookEntry->GetEntry()->Name.data(), file, FALSE);
		SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);

		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveFMStationsToTextFile(FILE *file)
{
	GSM_Backup_FMStationEntry	*FMEntry;
	char				buff[100];
	int				Num;

	Num = 1;
	FMEntry = NULL;
	while (GetNext_FMStation(&FMEntry)) {		
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[FMStation%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		sprintf(buff,"Location = %i",FMEntry->GetEntry()->Location);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		sprintf(buff,"Frequency = %.03f",FMEntry->GetEntry()->Frequency);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		SaveTextFilePart(StringToUnicodeReturn("StationName = \""), file, FALSE);
		SaveTextFilePart(FMEntry->GetEntry()->Name.data(), file, FALSE);
		SaveTextFilePart(StringToUnicodeReturn("\""), file, TRUE);

		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveNoteToTextFile(FILE *file)
{
	GSM_Backup_NoteEntry	*NoteEntry;
	char			buff[100];
	int			Num;
	
	Num = 1;
	NoteEntry = NULL;
	while (GetNext_Note(&NoteEntry)) {
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[Note%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		sprintf(buff,"Location = %03i",NoteEntry->GetEntry()->Location);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		sprintf(buff,"Text = \"");
		SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
		SaveTextFilePart((wchar_t *)NoteEntry->GetEntry()->Text.data(), file, FALSE);
		sprintf(buff,"\"");
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveToDoToTextFile(FILE *file)
{
	GSM_Backup_ToDoEntry	*ToDoEntry;
	GSM_ToDoSubEntry		*SubEntry;
	char			buff[100];
	int			Num;
	
	Num = 1;
	ToDoEntry = NULL;
	while (GetNext_ToDo(&ToDoEntry)) {
		SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
		sprintf(buff,"[TODO%03i]",Num);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		sprintf(buff,"Location = %03i",ToDoEntry->GetEntry()->Location);
		SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

	        SubEntry = NULL;
	        while (ToDoEntry->GetEntry()->GetNext(&SubEntry)) {
            		switch (SubEntry->Type) {
		        case ToDo_Text_Text:
				sprintf(buff,"Text = \"");
				SaveTextFilePart(StringToUnicodeReturn(buff), file, FALSE);
				SaveTextFilePart((wchar_t *)SubEntry->Text.data(), file, FALSE);
				sprintf(buff,"\"");
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		                break;
		        case ToDo_Priority:
		                switch (SubEntry->Priority) {
				case GSM_Priority_High:
					SaveTextFilePart(StringToUnicodeReturn("Priority = High"), file, TRUE);
					break;
				case GSM_Priority_Medium:
					SaveTextFilePart(StringToUnicodeReturn("Priority = Medium"), file, TRUE);
					break;
				case GSM_Priority_Low:
					SaveTextFilePart(StringToUnicodeReturn("Priority = Low"), file, TRUE);
					break;
		                }
		                break;
		        case ToDo_Bool_Completed:
				SaveTextFilePart(StringToUnicodeReturn("Completed = yes"), file, TRUE);
				break;
		        case ToDo_DateTime_End:
				sprintf(buff,"DueTime = ");
				SaveVCalendarDateTime(&SubEntry->DT,buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		                break;
		        case ToDo_DateTime_Modified:
				sprintf(buff,"Modified = ");
				SaveVCalendarDateTime(&SubEntry->DT,buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		                break;
		        case ToDo_DateTime_ToneAlarm:
				sprintf(buff,"Alarm = ");
				SaveVCalendarDateTime(&SubEntry->DT,buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
		                break;
		        case ToDo_DateTime_SilentAlarm:
				sprintf(buff,"SilentAlarm = ");
				SaveVCalendarDateTime(&SubEntry->DT,buff);
				SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
			}
		}
		Num++;
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::SaveToTextFile(char *FileName,GSM_Backup_FileFormatFunctions Func)
{
	INI_File		File;
	FILE			*file;
	char			buff[100];
	unsigned char 		buff3[100];
	GSM_DateTime		DT;

	if (FileName[0] == 0x00) return GSM_Return_Error(GSM_ERR_UNKNOWN);
	file = fopen(FileName,"wb");
	if (file == NULL) return GSM_Return_Error(GSM_ERR_UNKNOWN);

	buff3[0] = 0xff;
	buff3[1] = 0xfe;
	fwrite(buff3,1,2,file);

	SaveTextFilePart(StringToUnicodeReturn("; This file format is compatible with Gammu+, partially with Gammu"),file,TRUE);
	SaveTextFilePart(StringToUnicodeReturn("; and some based on them programs. See www.gammu.org for more info"), file, TRUE);
	SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);

	SaveTextFilePart(StringToUnicodeReturn("[Backup]"), file, TRUE);
	SaveTextFilePart(StringToUnicodeReturn("Format = 1.05"), file, TRUE);

	sprintf(buff,"IMEI = \"%s\"",DeviceIMEI);
	SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

	sprintf(buff,"Creator = \"Gammu+ %s",VERSION);
	if (strlen(GetOS()) != 0) sprintf(buff+strlen(buff),", %s",GetOS());
	if (strlen(GetCompiler()) != 0) sprintf(buff+strlen(buff),", %s",GetCompiler());
	sprintf(buff+strlen(buff),"\"");
	SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

	sprintf(buff,"DateTime = ");
	GSM_GetCurrentDateTime(&DT);
	SaveVCalendarDateTime(&DT,buff);
	SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

	sprintf(buff,"Phone = \"%s\"",DeviceModel);
	SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);

	if (Func.PhonePBK) SavePbkToTextFile(file, TRUE);
	if (Func.SIMPBK) SavePbkToTextFile(file, FALSE);
	if (Func.PhonePBK || Func.SIMPBK) SaveCallerToTextFile(file);
	if (Func.Calendar) SaveCalendarToTextFile(file);
 	if (Func.Notes) SaveNoteToTextFile(file);
        if (Func.ToDo) SaveToDoToTextFile(file);
	if (Func.SMS) SaveSMSToTextFile(file);
	if (Func.MMS) SaveMMSToTextFile(file);
	if (Func.WAPBookmarks) SaveWAPBookmarksToTextFile(file);
	if (Func.FMStations) SaveFMStationsToTextFile(file);

	fclose(file);

	File.ReadFile(FileName);
	FindTextFileChecksum(&File, (char *)buff3);
	file = fopen(FileName,"ab");
	SaveTextFilePart(StringToUnicodeReturn(""), file, TRUE);
	SaveTextFilePart(StringToUnicodeReturn("[Checksum]"), file, TRUE);
	sprintf(buff,"MD5=%s",buff3);
	SaveTextFilePart(StringToUnicodeReturn(buff), file, TRUE);
	fclose(file);

	return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

/**
 * method for reading phonebook from backup text file. Used internally
 */
GSM_Error GSM_Backup::ReadPbkFromTextFile(INI_File *File, BOOLEAN Phone)
{
	INI_File_Section 	*Section;
	wchar_t			*value;
	wchart			x;
	char			x2[100];
	GSM_PBKEntry		*PBKEntry;
	GSM_PBK_SubEntryType	PBKType;
	GSM_PBKSubEntry 	*SubEntry;
	int			i,j;
	BOOLEAN			Found;
	wchart			Txt;
	GSM_DateTime		DT;

	if (Phone) {
		StringToUnicode("PhonePBK",&x);
	} else {
		StringToUnicode("SIMPBK",&x);
	}
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),8) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Location"));
		if (value == NULL) continue;

		PBKEntry 		= new GSM_PBKEntry;
		PBKEntry->Location 	= atoi(UnicodeToStringReturn(value));
		PBKEntry->Memory	= MEM_PHONE;
		for (i=0;i<50;i++) {
			sprintf(x2,"Entry%02iType",i);
			value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
			if (value == NULL) continue;

			PBKType = PBK_Not_Assigned;

			j=0;
			while(GetMemoryType2[j].Type!=PBK_Not_Assigned) {
				if (!wcscmp(value,StringToUnicodeReturn(GetMemoryType2[j].Name))) {
					PBKType = GetMemoryType2[j].Type;
					break;
				}
				j++;
			}

			if (PBKType == PBK_Not_Assigned) {
				if (!wcscmp(value,StringToUnicodeReturn("CallerGroup"))) 	PBKType = PBK_ID_Caller_Group;
				else if (!wcscmp(value,StringToUnicodeReturn("VideoFileID"))) 	PBKType = PBK_ID_Video_File;
				else if (!wcscmp(value,StringToUnicodeReturn("PictureID"))) 	PBKType = PBK_ID_Picture;

				if (PBKType == PBK_Not_Assigned) {
					if (!wcscmp(value,StringToUnicodeReturn("Birthday"))) 	PBKType = PBK_DateTime_Birthday;
					if (PBKType == PBK_Not_Assigned) continue;

					sprintf(x2,"Entry%02iValue",i);
					value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
					if (value == NULL) continue;

					if (!ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)) continue;
					PBKEntry->AddDateTime(PBKType,DT);
				}

				sprintf(x2,"Entry%02iNumber",i);
				value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
				if (value == NULL) continue;

				PBKEntry->AddLong(PBKType,atol(UnicodeToStringReturn(value)));

				continue;
			}

			sprintf(x2,"Entry%02iText",i);
			value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
			if (value == NULL) continue;
			if (UnicodeLength(value)==0) continue;

			value[UnicodeLength(value)-1] = 0;
			ReadTextFilePart(value+1, &Txt);
			PBKEntry->AddText(PBKType,(wchar_t *)Txt.data());

			if (PBKType == PBK_Text_Phone_Mobile ||
			    PBKType == PBK_Text_Phone_Home ||
			    PBKType == PBK_Text_Phone_Work ||
			    PBKType == PBK_Text_Phone_Fax ||
			    PBKType == PBK_Text_Phone_Video ||
			    PBKType == PBK_Text_Phone_General) {
				sprintf(x2,"Entry%02iVoiceTag",i);
				value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
				if (value != NULL) {
					SubEntry = NULL;
					while (PBKEntry->GetNext(&SubEntry)) {
						if (SubEntry->GetNext() == NULL) {
							SubEntry->VoiceTag = atol(UnicodeToStringReturn(value));
						}
					}
				}
			}
		}
		Found = FALSE;
		SubEntry = NULL;
		while (PBKEntry->GetNext(&SubEntry)) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Name_First:
			case PBK_Text_Name_Last:
				Found = TRUE;
				break;
			default:
				break;
			}
		}
		if (!Found) {
			for (i=0;i<50;i++) {
				sprintf(x2,"Entry%02iType",i);
				value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
				if (value == NULL) continue;

				PBKType = PBK_Not_Assigned;
				if (!wcscmp(value,StringToUnicodeReturn("Name"))) PBKType = PBK_Text_Name;
				if (PBKType == PBK_Not_Assigned) continue;

				sprintf(x2,"Entry%02iText",i);
				value = File->GetValueInSection(Section,StringToUnicodeReturn(x2));
				if (value == NULL) continue;
				if (UnicodeLength(value)==0) continue;

				value[UnicodeLength(value)-1] = 0;
				PBKEntry->AddText(PBKType,value+1);
			}
		}
		Add_PBK(PBKEntry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadCalendarFromTextFile(INI_File *File)
{
	wchar_t			*value;
	wchart		x;
	GSM_CalendarEntry	*CalEntry;
	GSM_Calendar_Type	CalType;
	GSM_DateTime		DT;
	INI_File_Section 	*Section;

	StringToUnicode("Calendar",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),8) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Type"));
		if (value == NULL) continue;

		CalType = Calendar_Type_Not_Assigned;
		if (!wcscmp(value,StringToUnicodeReturn("Meeting"))) 		CalType = Calendar_Type_Meeting;
		else if (!wcscmp(value,StringToUnicodeReturn("Memo"))) 		CalType = Calendar_Type_Memo;
		else if (!wcscmp(value,StringToUnicodeReturn("Call"))) 		CalType = Calendar_Type_Call;
		else if (!wcscmp(value,StringToUnicodeReturn("Birthday"))) 	CalType = Calendar_Type_Birthday;
		else if (!wcscmp(value,StringToUnicodeReturn("Reminder"))) 	CalType = Calendar_Type_Reminder;
		if (CalType == Calendar_Type_Not_Assigned) continue;

		CalEntry = new GSM_CalendarEntry;
		CalEntry->Type = CalType;

		// ----------------------- times ------------------------------

		value = File->GetValueInSection(Section,StringToUnicodeReturn("StartTime"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_Start, DT);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("StopTime"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End, DT);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("AlarmType"));
		if (value != NULL && !strcmp(UnicodeToStringReturn(value),"Silent")) {
			value = File->GetValueInSection(Section,StringToUnicodeReturn("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_SilentAlarm, DT);
			}
		} else {
			value = File->GetValueInSection(Section,StringToUnicodeReturn("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_ToneAlarm, DT);
			}
		}
		
		value = File->GetValueInSection(Section,StringToUnicodeReturn("RepeatStopDate"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End_Repeat, DT);
		}

		// ----------------------- texts ------------------------------

		value = File->GetValueInSection(Section,StringToUnicodeReturn("EventLocation"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Location, value+1);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Text"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Text, value+1);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Phone"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Phone, value+1);
		}

		// ------------------------ int -------------------------------

		value = File->GetValueInSection(Section,StringToUnicodeReturn("RepeatDayOfWeek"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_DayOfWeek, atoi(UnicodeToStringReturn(value)));
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("RepeatDay"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Day, atoi(UnicodeToStringReturn(value)));
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("RepeatMonth"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Month, atoi(UnicodeToStringReturn(value)));
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("RepeatFrequency"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Frequency, atoi(UnicodeToStringReturn(value)));
		}

		Add_Cal(CalEntry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadNoteFromTextFile(INI_File *File)
{
	wchar_t			*value;
	wchart		x;
	GSM_NoteEntry		*NoteEntry;
	INI_File_Section 	*Section;
	wchart			Txt;

	StringToUnicode("Note",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),4) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Text"));
		if (value == NULL) continue;

		ReadTextFilePart(value+1, &Txt);
		NoteEntry = new GSM_NoteEntry;
		NoteEntry->Text.append(Txt.data(),Txt.size()-1);

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Location"));
		if (value == NULL) continue;
		NoteEntry->Location = atoi(UnicodeToStringReturn(value));

		Add_Note(NoteEntry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadToDoFromTextFile(INI_File *File)
{
	wchar_t			*value;
	wchart			x;
	GSM_ToDoEntry		*ToDoEntry;
	GSM_ToDoSubEntry	*ToDoSubEntry;
	INI_File_Section 	*Section;
	GSM_ToDo_Priority	Priority;
	GSM_DateTime		DT;
	wchart			Txt;

	StringToUnicode("TODO",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),4) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Location"));
		if (value == NULL) continue;

		ToDoEntry = new GSM_ToDoEntry;
		ToDoEntry->Location = atoi(UnicodeToStringReturn(value));

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Text"));
		if (value != NULL) {
			ReadTextFilePart(value+1, &Txt);
			ToDoSubEntry = new GSM_ToDoSubEntry;
			ToDoSubEntry->Text.append(Txt.data(),Txt.size()-1);
			ToDoSubEntry->Type = ToDo_Text_Text;
			ToDoEntry->AddSubEntry(ToDoSubEntry);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Priority"));
		if (value != NULL) {
			Priority = GSM_Priority_Not_Assigned;
			if (!wcscmp(value,StringToUnicodeReturn("High"))) 		Priority = GSM_Priority_High;
			else if (!wcscmp(value,StringToUnicodeReturn("Medium"))) 	Priority = GSM_Priority_Medium;
			else if (!wcscmp(value,StringToUnicodeReturn("Low"))) 		Priority = GSM_Priority_Low;
			if (Priority != GSM_Priority_Not_Assigned) {
				ToDoSubEntry = new GSM_ToDoSubEntry;
				ToDoSubEntry->Priority = Priority;
				ToDoSubEntry->Type = ToDo_Priority;
				ToDoEntry->AddSubEntry(ToDoSubEntry);
			}
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Completed"));
		if (value != NULL && !wcscmp(value,StringToUnicodeReturn("yes"))) {
			ToDoSubEntry = new GSM_ToDoSubEntry;
			ToDoSubEntry->BoolValue = TRUE;
			ToDoSubEntry->Type = ToDo_Bool_Completed;
			ToDoEntry->AddSubEntry(ToDoSubEntry);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("DueTime"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			ToDoSubEntry = new GSM_ToDoSubEntry;
			memcpy(&ToDoSubEntry->DT,&DT,sizeof(GSM_DateTime));
			ToDoSubEntry->Type = ToDo_DateTime_End;
			ToDoEntry->AddSubEntry(ToDoSubEntry);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Alarm"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			ToDoSubEntry = new GSM_ToDoSubEntry;
			memcpy(&ToDoSubEntry->DT,&DT,sizeof(GSM_DateTime));
			ToDoSubEntry->Type = ToDo_DateTime_ToneAlarm;
			ToDoEntry->AddSubEntry(ToDoSubEntry);
		}

		value = File->GetValueInSection(Section,StringToUnicodeReturn("SilentAlarm"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			ToDoSubEntry = new GSM_ToDoSubEntry;
			memcpy(&ToDoSubEntry->DT,&DT,sizeof(GSM_DateTime));
			ToDoSubEntry->Type = ToDo_DateTime_SilentAlarm;
			ToDoEntry->AddSubEntry(ToDoSubEntry);
		}

		Add_ToDo(ToDoEntry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadWAPBookmarksFromTextFile(INI_File *File)
{
	GSM_WAPBookmark		*Bookmark;
	wchar_t			*value;
	wchart			x;
	INI_File_Section 	*Section;
	wchart			Txt;

	StringToUnicode("WAPBookmark",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),11) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("URL"));
		if (value == NULL) continue;

		Bookmark = new GSM_WAPBookmark;

		ReadTextFilePart(value+1, &Txt);
		Bookmark->URL.append(Txt.data(),Txt.size()-1);

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Title"));
		if (value == NULL) {
			delete (Bookmark);
			continue;
		}
		ReadTextFilePart(value+1, &Txt);
		Bookmark->Name.append(Txt.data(),Txt.size()-1);

		Add_WAPBookmark(Bookmark);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadFMStationsFromTextFile(INI_File *File)
{
	GSM_FMStation		*Station;
	wchar_t			*value;
	wchart			x;
	INI_File_Section 	*Section;
	wchart			Txt;

	StringToUnicode("FMStation",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),9) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Location"));
		if (value == NULL) continue;

		Station = new GSM_FMStation;
		Station->Location = atoi(UnicodeToStringReturn(value));

		value = File->GetValueInSection(Section,StringToUnicodeReturn("StationName"));
		if (value == NULL) {
			delete (Station);
			continue;
		}
		ReadTextFilePart(value+1, &Txt);
		Station->Name.append(Txt.data(),Txt.size()-1);

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Frequency"));
		if (value == NULL) {
			delete (Station);
			continue;
		}
		Station->Frequency= atof(UnicodeToStringReturn(value));

		Add_FMStation(Station);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadCallerFromTextFile(INI_File *File)
{
	GSM_CallerGroupEntry		*Caller;
	GSM_CallerGroupSubEntry	*Sub;
	wchar_t			*value;
	wchart			x;
	INI_File_Section 	*Section;
	wchart			Txt;

	StringToUnicode("Caller",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),6) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Location"));
		if (value == NULL) continue;
		Caller = new GSM_CallerGroupEntry;
		Caller->Location=atoi(UnicodeToStringReturn(value));

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Name"));
		Sub = new GSM_CallerGroupSubEntry;
		if (value == NULL) {
			switch (Caller->Location) {
			case 1:Sub->Text.append(StringToUnicodeReturn("Family"),6);break;
			case 2:Sub->Text.append(StringToUnicodeReturn("VIP"),3);break;
			case 3:Sub->Text.append(StringToUnicodeReturn("Friends"),7);break;
			case 4:Sub->Text.append(StringToUnicodeReturn("Colleagues"),10);break;
			case 5:Sub->Text.append(StringToUnicodeReturn("Other"),5);break;
			}
			Sub->Type = GSM_CallerDefaultName;
		} else {
			Sub->Type = GSM_CallerName;
			ReadTextFilePart(value+1, &Txt);
			Sub->Text.append(Txt.data(),Txt.size()-1);
		}
		Caller->AddSubEntry(Sub);
		Add_CallerGroup(Caller);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadSMSFromTextFile(INI_File *File)
{
	wchar_t				*value;
	wchart				x,x10;
	INI_File_Section 		*Section,*Section2;
	wchart				Txt;
	int 				i,num,z;
	char				x2[500];
	GSM_SMSMMSFoldersSubEntry	*SubEntry2;
	wchart 				ID;
	GSM_SMSList			*List=NULL;
	GSM_SMSEntry			SMS;
	BOOLEAN				Found;	
	unsignedstring			x3,x4;

	num=0;
	SubEntry2=NULL;
	while (SMSMMSFolders.GetNext(&SubEntry2)) num++;

	StringToUnicode("SMSFolders",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),10) != 0) continue;

		for (i=0;i<50;i++) {
			sprintf(x2,"Entry%02i",i);
			value = File->GetValueInSection(Section,StringToUnicodeReturn((char *)x2));
			if (value == NULL) continue;

			num++;
			sprintf(x2,"%i",num);
			ID.clear(); ID.append(StringToUnicodeReturn(x2));			
			SMSMMSFolders.Add(value, FALSE, FALSE, FALSE, MEM_PHONE, &ID, num, -1);
		}
	}

	StringToUnicode("SMSList",&x10);
	Section2 = NULL;
	while (File->GetNextSection(&Section2)==TRUE) {
		if (wcsncmp(x10.data(),(wchar_t *)Section2->Name.data(),7) != 0) continue;

		value = File->GetValueInSection(Section2,StringToUnicodeReturn("Folder"));
		if (value == NULL) continue;

		List = new GSM_SMSList;
		List->Folder = atoi(UnicodeToStringReturn(value));

		Found = FALSE;
		num=1;
		while (true) {
			x.clear();
			x.append(StringToUnicodeReturn("SMSPart"),7);
			x.append(Section2->Name.data()+7,5);
			sprintf(x2,"_%02i",num);
			x.append(StringToUnicodeReturn((char *)x2),3);

			Found = FALSE;
			Section = NULL;
			while (File->GetNextSection(&Section)==TRUE) {
				if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),15) != 0) continue;
				Found = TRUE;
				break;				
			}
			if (Found) {
				Found = FALSE;
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPDCS"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPDCS=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPStatus"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPStatus=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPUDL"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPUDL=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPVP"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPVP=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPMR"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPMR=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("TPPID"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.TPPID=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("firstbyte"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				SMS.firstbyte=x4.data()[0];
				value = File->GetValueInSection(Section,StringToUnicodeReturn("UserData"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &SMS.UserData);
				value = File->GetValueInSection(Section,StringToUnicodeReturn("SMSCNumber"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &SMS.SMSCNumber);
				value = File->GetValueInSection(Section,StringToUnicodeReturn("DateTime"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				memcpy(&SMS.DateTime,x4.data(),7);
				value = File->GetValueInSection(Section,StringToUnicodeReturn("SMSCTime"));
				if (value == NULL) break;
				UnicodeToString(value, &x3);
				HexBinToString(x3.data(), &x4);
				memcpy(&SMS.SMSCTime,x4.data(),7);
				SMS.PhoneNumbers.ClearAll();
				for(z=1;z<10;z++) {
					sprintf(x2,"Number%03i",z);
					x.clear();
					x.append(StringToUnicodeReturn((char *)x2),9);
					value = File->GetValueInSection(Section,x.data());
					if (value == NULL) break;
					UnicodeToString(value, &x3);
					HexBinToString(x3.data(), &x4);
					SMS.PhoneNumbers.Add(x4.data(),x4.size());
				}
				SMS.SaveDateTimeAvailable=FALSE;
				value = File->GetValueInSection(Section,StringToUnicodeReturn("Saved"));
				if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &SMS.SaveDateTime)==TRUE) {
					SMS.SaveDateTimeAvailable=TRUE;
				}
				List->Add(&SMS);
			} else {
				if (num!=1) Found = TRUE;				
				break;
			}
			num++;
		}
		if (Found) {
			Add_SMS(List);
		} else {
			delete List;
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadMMSFromTextFile(INI_File *File)
{
	wchar_t				*value;
	wchart				x;
	INI_File_Section 		*Section;
	wchart				Txt;
	int 				i,num,numstart;
	char				x2[500];
	GSM_SMSMMSFoldersSubEntry	*SubEntry2;
	wchart 				ID;
	GSM_SMSList			*List=NULL;
	GSM_SMSEntry			SMS;
	GSM_MMSEntry			*MMS;
	unsignedstring			x3;

	num=0;
	SubEntry2=NULL;
	while (SMSMMSFolders.GetNext(&SubEntry2)) num++;
	numstart=num;

	StringToUnicode("MMSFolders",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),10) != 0) continue;

		for (i=0;i<50;i++) {
			sprintf(x2,"Entry%02i",i);
			value = File->GetValueInSection(Section,StringToUnicodeReturn((char *)x2));
			if (value == NULL) continue;

			num++;
			sprintf(x2,"%i",num);
			ID.clear(); ID.append(StringToUnicodeReturn(x2));
			SMSMMSFolders.Add(value, FALSE, FALSE, TRUE, MEM_PHONE, &ID, num, -1);
		}
	}

	StringToUnicode("MMSMessage",&x);
	Section = NULL;
	while (File->GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x.data(),(wchar_t *)Section->Name.data(),10) != 0) continue;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Folder"));
		if (value == NULL) continue;

		MMS = new GSM_MMSEntry;
		MMS->Folder = atoi(UnicodeToStringReturn(value))+numstart;

		value = File->GetValueInSection(Section,StringToUnicodeReturn("Content"));
		if (value == NULL) {
			delete MMS;
			break;
		}
		UnicodeToString(value, &x3);
		HexBinToString(x3.data(), &MMS->File.Buffer);
		MMS->File.Info.Size = MMS->File.Buffer.size();

		Add_MMS(MMS);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Backup::ReadFromTextFile(char *FileName)
{
	INI_File 		File;
	wchar_t			*value;
	wchart			x;

	if (!File.ReadFile(FileName)) return GSM_Return_Error(GSM_ERR_UNKNOWN);

	StringToUnicode("Backup",&x);
	value = File.GetValue(x.data(),StringToUnicodeReturn("Format"));
	if (value == NULL) return GSM_Return_Error(GSM_ERR_UNKNOWN);

	value = File.GetValue(x.data(),StringToUnicodeReturn("IMEI"));
	if (value != NULL) {
		sprintf(DeviceIMEI,"%s",UnicodeToStringReturn(value+1));
		DeviceIMEI[strlen(DeviceIMEI)-1] = 0;
	}

	value = File.GetValue(x.data(),StringToUnicodeReturn("Creator"));
	if (value != NULL) {
		sprintf(FileCreator,"%s",UnicodeToStringReturn(value+1));
		FileCreator[strlen(FileCreator)-1] = 0;
	}

	value = File.GetValue(x.data(),StringToUnicodeReturn("Phone"));
	if (value != NULL) {
		sprintf(DeviceModel,"%s",UnicodeToStringReturn(value+1));
		DeviceModel[strlen(DeviceModel)-1] = 0;
	}

	value = File.GetValue(x.data(),StringToUnicodeReturn("DateTime"));
	if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &FileDateTime)==TRUE) {
		FileDateTimeAvailable=TRUE;
	}

	if ((File.Buffer.data()[0] == 0xFE && File.Buffer.data()[1] == 0xFF) ||
	    (File.Buffer.data()[0] == 0xFF && File.Buffer.data()[1] == 0xFE)) {
		StringToUnicode("Checksum",&x);
		value = File.GetValue(x.data(),StringToUnicodeReturn("MD5"));
		if (value != NULL) {
			sprintf(FileMD5Original,"%s",UnicodeToStringReturn(value));
			FindTextFileChecksum(&File, (char *)FileMD5Calculated);
		}
	}

	ReadCallerFromTextFile(&File);
	ReadPbkFromTextFile(&File,TRUE);
	ReadPbkFromTextFile(&File,FALSE);
	ReadCalendarFromTextFile(&File);
	ReadNoteFromTextFile(&File);
	ReadToDoFromTextFile(&File);
    	ReadSMSFromTextFile(&File);
    	ReadMMSFromTextFile(&File);
    	ReadWAPBookmarksFromTextFile(&File);
    	ReadFMStationsFromTextFile(&File);

	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_Backup::ReadTextFilePart(wchar_t *Src, wchart *Dest)
{
	int i = 0,Level=0;
	unsignedstring Buffer;

	Dest->clear();
	for (i=0;i<UnicodeLength(Src);i++) {
		if (Level == 0) {
			if (Src[i]=='\\') {
				Level = 1;
			} else {
				Dest->push_back(Src[i]);
			}
		} else {
			if (Src[i]=='r') {
				Dest->push_back(13);
			} else if (Src[i]=='n') {
				Dest->push_back(10);
			} else {
				Dest->push_back('\\');
				Dest->push_back(Src[i]);
			}
			Level = 0;
		}
	}
	if (Level == 1) Dest->push_back('\\');
}
