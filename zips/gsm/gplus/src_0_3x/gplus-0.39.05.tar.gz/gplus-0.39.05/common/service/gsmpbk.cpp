/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include "../../cfg/config.h"
#include "gsmpbk.h"
#include "../misc/coding/coding.h"

wchar_t	*GSM_PBKSubEntry::GetText()
{
	if (Text==NULL) return 0x00;
	return Text;
}

GSM_PBKSubEntry::GSM_PBKSubEntry()
{
	SMSLists.clear();
	BoolValue = false;
	CallLength = -1;
	VoiceTag = -1;
	Type   = PBK_Not_Assigned;
	Text   = NULL;
	Next   = NULL;
}

GSM_PBKSubEntry::~GSM_PBKSubEntry()
{
	delete(Next);
	free(Text);
}

GSM_PBK_SubEntryType GSM_PBKSubEntry::GetType()
{
	return Type;
}

GSM_Error GSM_PBKSubEntry::SetToLong(GSM_PBK_SubEntryType Typ, long long2)
{
	Type = Typ;

	LongValue = long2;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKSubEntry::SetToBool(GSM_PBK_SubEntryType Typ, bool bool2)
{
	Type = Typ;

	BoolValue = bool2;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKSubEntry::SetToText(GSM_PBK_SubEntryType Typ, wchar_t *Txt)
{
	int len = (UnicodeLength(Txt)+1)*sizeof(wchar_t);

	if (Typ < PBK_Text_Phone_General || Typ > PBK_Text_Share_View) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

	Type = Typ;

	Text = (wchar_t *)realloc(Text,len);
	memcpy(Text,Txt,len);

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_PBKSubEntry *GSM_PBKSubEntry::GetNext()
{
	return Next;
}

void GSM_PBKSubEntry::SetNext(GSM_PBKSubEntry *Nxt)
{
	Next = Nxt;
}

GSM_Error GSM_PBKSubEntry::SetToDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2)
{
	if (Typ < PBK_DateTime_Call_Length || Typ > PBK_DateTime_Birthday) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
	Type = Typ;

	memcpy(&DT,&DT2,sizeof(GSM_DateTime));
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_DateTime *GSM_PBKSubEntry::GetDateTime()
{
	return &DT;
}

/* ------------------------------------------------------------------------ */

GSM_PBKEntry::GSM_PBKEntry()
{
	Entries = NULL;
}


GSM_PBKEntry::~GSM_PBKEntry()
{
	delete(Entries);
}

BOOLEAN GSM_PBKEntry::GetNext(GSM_PBKSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

GSM_Error GSM_PBKEntry::AddText(GSM_PBK_SubEntryType Typ, wchar_t *Txt)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	error = Entry->SetToText(Typ, Txt);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) {
			Entry2 = Entry2->GetNext();
		}
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddLong(GSM_PBK_SubEntryType Typ, long long2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	Entry->SetToLong(Typ, long2);

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddBool(GSM_PBK_SubEntryType Typ, bool bool2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	Entry->SetToBool(Typ, bool2);

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::AddDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2)
{
	GSM_PBKSubEntry *Entry,*Entry2;
	GSM_Error	error;

	Entry = new GSM_PBKSubEntry;
	error = Entry->SetToDateTime(Typ, DT2);
	if (error.Code != GSM_ERR_NONE) {
		delete (Entry);
		return error;
	}

	if (Entries == NULL) {
		Entries = Entry;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_PBKEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

//todo: address
GSM_Error GSM_PBKEntry::EncodeToVCARD(unsignedstring *dest, GSM_VCARDType Type)
{
	wchart		Buff;
	GSM_PBKSubEntry *SubEntry;
	BOOLEAN		firstnum=TRUE;
	char 		buff[500];

	//name searching
	SubEntry  = NULL;
	while (GetNext(&SubEntry)) {
		if (SubEntry->GetType()==PBK_Text_Name_Last) {
			Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
		}	
	}
	SubEntry  = NULL;
	while (GetNext(&SubEntry)) {
		if (SubEntry->GetType()==PBK_Text_Name_First) {
			if (Buff.size()!=0) Buff.push_back(';');
			Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
		}
	}
	if (Buff.size()==0) {
		SubEntry  = NULL;
		while (GetNext(&SubEntry)) {
			if (SubEntry->GetType()==PBK_Text_Name) {
				Buff.append(SubEntry->GetText(),UnicodeLength(SubEntry->GetText()));
			}
		}
	}

	dest->clear();
	if (Type == VCARD_10) {
		SaveVCalendarText(dest,"BEGIN:VCARD",NULL);
		SubEntry = NULL;
		while (GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Phone_General:
			case PBK_Text_Phone_Mobile:
			case PBK_Text_Phone_Home:
			case PBK_Text_Phone_Work:
			case PBK_Text_Phone_Fax:
			case PBK_Text_Phone_Video:
				if (!firstnum) break;
				firstnum=FALSE;
				SaveVCalendarText(dest, "TEL", SubEntry->GetText());
				break;
			default:
				break;
			}
		}
		if (Buff.length()!=0) SaveVCalendarText(dest,"N",Buff.data());
		SaveVCalendarText(dest,"END:VCARD",NULL);
	}
	if (Type == VCARD_21) {
		SaveVCalendarText(dest,"BEGIN:VCARD",NULL);
		SaveVCalendarText(dest,"VERSION:2.1",NULL);
		SubEntry = NULL;
		while (GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Phone_General:
				sprintf(buff,"TEL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Mobile:
				sprintf(buff,"TEL;CELL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Home:
				sprintf(buff,"TEL;HOME");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Work:
				sprintf(buff,"TEL;WORK");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Fax:
				sprintf(buff,"TEL;FAX");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Phone_Video://fixme
				sprintf(buff,"TEL");
				if (firstnum) sprintf(buff+strlen(buff),";PREF");
				firstnum=FALSE;
				SaveVCalendarText(dest, buff, SubEntry->GetText());
				break;
			case PBK_Text_Postal_ZIP:
			case PBK_Text_Postal_Street:
			case PBK_Text_Postal_City:
			case PBK_Text_Postal_State:
			case PBK_Text_Postal_ZIP_Code:
			case PBK_Text_Postal_Country:
				break;
			case PBK_Text_Email:
				SaveVCalendarText(dest, "EMAIL", SubEntry->GetText());
				break;
			case PBK_Text_URL:
				SaveVCalendarText(dest, "URL", SubEntry->GetText());
				break;
			case PBK_Text_Note:
				SaveVCalendarText(dest, "NOTE", SubEntry->GetText());
				break;
			case PBK_Text_Job_Title:
				SaveVCalendarText(dest, "TITLE", SubEntry->GetText());
				break;
			case PBK_DateTime_Birthday:
				//todo
				break;
			case PBK_Text_Name: //processed earlier
			case PBK_Text_Name_Last:
			case PBK_Text_Name_First:
				break;
			case PBK_Text_Name_Formal:
			case PBK_Text_Company_Name:
			case PBK_Text_Name_Nick:
			case PBK_Text_PTT:
			case PBK_Text_Video_Sharing_SIP:
			case PBK_DateTime_Call_Length:
			case PBK_ID_Caller_Group:
			case PBK_ID_Picture:
			case PBK_ID_Ringtone:
			case PBK_ID_Video_File:
			case PBK_Bool_PTT_Subscribed:
			case PBK_Text_UserID:
				break;
			}
		}
		if (Buff.length()!=0) SaveVCalendarText(dest, "N", Buff.data());
		SaveVCalendarText(dest, "END:VCARD", NULL);
	}

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_PBKEntry::DecodeFromVCARD(unsignedstring *src)
{
	int 			pos = 0,pos2,level,level2;
	unsignedstring 		line;
	GSM_DateTime		DT;
	GSM_PBK_SubEntryType 	Type;
	wchart			Name,Name2;
	BOOLEAN			Home,Work;

	ClearAll();

	level2 = 0;
	while (pos!=src->size()) {
		do {
			line.clear();
			level = 0;
			while(true) {
				switch(level) {
				case 0:
					if (src->data()[pos] == 13 || src->data()[pos] == 10) {
						level++;
					} else {
						line.push_back(src->data()[pos]);
					}
					break;
				case 1:
					if (src->data()[pos] != 13 && src->data()[pos] != 10) level++;
					break;				
				}
				if (level == 2) break;
				pos++;
			}
		} while (line.size()==0);

		if (level2==0) {
			if (strcmp((const char *)line.data(),"BEGIN:VCARD")) {
				return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);				
			}
			level2++;
			continue;
		}
		if (level2==1) {
			if (strcmp((const char *)line.data(),"VERSION:2.1")) {
				return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);				
			}
			level2++;
			continue;
		}

		if (!strcmp((const char *)line.data(),"END:VCARD")) {
			return GSM_Return_Error(GSM_ERR_NONE);
		}
		if (StringCaseCmp((const char *)line.data(), "X-CLASS:", 8)) {
			continue;
		}
		if (StringCaseCmp((const char *)line.data(), "X-EPOCSECONDNAME:", 17)) {
			continue;
		}
		if (StringCaseCmp((const char *)line.data(), "REV:", 4) && ReadVCalendarDateTime((const char *)line.data()+4, &DT)) {
			AddDateTime(PBK_DateTime_Modified, DT);
			continue;
		}
		if (StringCaseCmp((const char *)line.data(), "X-ANNIVERSARY:", 14) && ReadVCalendarDate((const char *)line.data()+14, &DT)) {
			AddDateTime(PBK_DateTime_Anniversary, DT);
			continue;
		}
		if (StringCaseCmp((const char *)line.data(), "BDAY:", 5) && ReadVCalendarDate((const char *)line.data()+5, &DT)) {
			AddDateTime(PBK_DateTime_Birthday, DT);
			continue;
		}
		if (StringCaseCmp((const char *)line.data(), "TEL", 3)) {
			Type = PBK_Text_Phone_General;
			pos2=3;
			while (true) {
				if (line.size()<pos2+2) {
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
				if (line.data()[pos2] == ':') {
					AddText(Type, StringToUnicodeReturn((char *)line.data()+pos2+1));
					break;
				}
				if (line.data()[pos2]!=';') {
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
				pos2++;
				if (StringCaseCmp((const char *)line.data()+pos2, "PREF", 4)) {
					pos2+=3;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "VOICE", 5)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
					case PBK_Text_Phone_Home:
					case PBK_Text_Phone_Work:
						break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=5;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "HOME", 4)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Home; break;
					case PBK_Text_Phone_Fax: 
						Type = PBK_Text_Phone_Fax_Home; break;
					case PBK_Text_Phone_Video: 
						Type = PBK_Text_Phone_Video_Home; break;
					case PBK_Text_Phone_Mobile: 
						Type = PBK_Text_Phone_Mobile_Home; break;
					case PBK_Text_Phone_Internet: 
						Type = PBK_Text_Phone_Internet_Home; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=4;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "WORK", 4)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Work; break;
					case PBK_Text_Phone_Fax: 
						Type = PBK_Text_Phone_Fax_Work; break;
					case PBK_Text_Phone_Video: 
						Type = PBK_Text_Phone_Video_Work; break;
					case PBK_Text_Phone_Mobile: 
						Type = PBK_Text_Phone_Mobile_Work; break;
					case PBK_Text_Phone_Internet: 
						Type = PBK_Text_Phone_Internet_Work; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=4;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "CELL", 4)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Mobile; break;
					case PBK_Text_Phone_Home: 
						Type = PBK_Text_Phone_Mobile_Home; break;
					case PBK_Text_Phone_Work: 
						Type = PBK_Text_Phone_Internet_Work; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=4;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "FAX", 3)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Fax; break;
					case PBK_Text_Phone_Home: 
						Type = PBK_Text_Phone_Fax_Home; break;
					case PBK_Text_Phone_Work: 
						Type = PBK_Text_Phone_Fax_Work; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=3;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "VIDEO", 5)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Video; break;
					case PBK_Text_Phone_Home: 
						Type = PBK_Text_Phone_Video_Home; break;
					case PBK_Text_Phone_Work: 
						Type = PBK_Text_Phone_Video_Work; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=5;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "PAGER", 5)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Pager; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=5;
					continue;
				}
				if (StringCaseCmp((const char *)line.data()+pos2, "CAR", 3)) {
					switch(Type) {
					case PBK_Text_Phone_General: 
						Type = PBK_Text_Phone_Car; break;
					default:
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					pos2+=3;
					continue;
				}
				return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
			}
			continue;
		}
		if (ReadVCalendarText(line.data(), (unsigned char *)"N", &Name)) {
			level = 0;
			pos2=0;
			while (true) {
				if (pos2==Name.size()) break;
				Name2.clear();
				while (true) {
					if (Name.data()[pos2] == ';') {
						pos2++;
						break;
					}
					Name2.push_back(Name.data()[pos2]);
					pos2++;
					if (pos2==Name.size()) break;					
				}
				if (Name2.size() == 0) continue;
				switch(level) {
				case 0: Type = PBK_Text_Name_Last; break;
				case 1: Type = PBK_Text_Name_First; break;
				case 2: Type = PBK_Text_Name_Middle; break;
				case 3: Type = PBK_Text_Name_Title; break;
				case 4: Type = PBK_Text_Name_Suffix; break;
				default:
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
				level++;
				AddText(Type, (wchar_t *)Name2.data());
			}
			continue;
		}
		if (ReadVCalendarText(line.data(), (unsigned char *)"ADR", &Name) ||
		    ReadVCalendarText(line.data(), (unsigned char *)"ADR;HOME", &Name) ||
		    ReadVCalendarText(line.data(), (unsigned char *)"ADR;WORK", &Name)) {
			Home = ReadVCalendarText(line.data(), (unsigned char *)"ADR;HOME", &Name);
			Work = ReadVCalendarText(line.data(), (unsigned char *)"ADR;WORK", &Name);
			level = 0;
			pos2=0;
			while (true) {
				if (pos2==Name.size()) break;
				Name2.clear();
				while (true) {
					if (Name.data()[pos2] == ';') {
						pos2++;
						break;
					}
					Name2.push_back(Name.data()[pos2]);
					pos2++;
					if (pos2==Name.size()) break;					
				}
				if (Name2.size() == 0) continue;
				switch(level) {
				case 0: 
					Type = PBK_Text_Postal_PO_Box; 
					if (Home) Type = PBK_Text_Postal_PO_Box_Home; 
					if (Work) Type = PBK_Text_Postal_PO_Box_Work; 
					break;
				case 1: 
					Type = PBK_Text_Postal_Extension; 
					if (Home) Type = PBK_Text_Postal_Extension_Home; 
					if (Work) Type = PBK_Text_Postal_Extension_Work; 
					break;
				case 2: 
					Type = PBK_Text_Postal_Street; 
					if (Home) Type = PBK_Text_Postal_Street_Home; 
					if (Work) Type = PBK_Text_Postal_Street_Work; 
					break;
				case 3: 
					Type = PBK_Text_Postal_City; 
					if (Home) Type = PBK_Text_Postal_City_Home; 
					if (Work) Type = PBK_Text_Postal_City_Work; 
					break;
				case 4: 
					Type = PBK_Text_Postal_State; 
					if (Home) Type = PBK_Text_Postal_State_Home; 
					if (Work) Type = PBK_Text_Postal_State_Work; 
					break;
				case 5: 
					Type = PBK_Text_Postal_PO_Box; 
					if (Home) Type = PBK_Text_Postal_PO_Box_Home; 
					if (Work) Type = PBK_Text_Postal_PO_Box_Work; 
					break;
				case 6:
					Type = PBK_Text_Postal_Region; 
					if (Home) Type = PBK_Text_Postal_Region_Home; 
					if (Work) Type = PBK_Text_Postal_Region_Work; 
					break;
				default:
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
				level++;
				AddText(Type, (wchar_t *)Name2.data());
			}
			continue;
		}

		return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	}

	return GSM_Return_Error(GSM_ERR_NONE);
}

//-----------------------------------------------------------------------------

GSM_CallerGroupSubEntry::GSM_CallerGroupSubEntry()
{
	Next = NULL;
}

GSM_CallerGroupSubEntry::~GSM_CallerGroupSubEntry()
{
	delete(Next);
}

GSM_CallerGroupSubEntry *GSM_CallerGroupSubEntry::GetNext()
{
	return Next;
}

void GSM_CallerGroupSubEntry::SetNext(GSM_CallerGroupSubEntry *Nxt)
{
	Next = Nxt;
}

/* ------------------------------------------------------------------------ */

GSM_CallerGroupEntry::GSM_CallerGroupEntry()
{
	Entries = NULL;
}

GSM_CallerGroupEntry::~GSM_CallerGroupEntry()
{
	delete(Entries);
}

BOOLEAN GSM_CallerGroupEntry::GetNext(GSM_CallerGroupSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

void GSM_CallerGroupEntry::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

BOOLEAN GSM_CallerGroupEntry::AddSubEntry(GSM_CallerGroupSubEntry *En)
{
	GSM_CallerGroupSubEntry *Entry2;

	if (Entries == NULL) {
		Entries = En;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(En);
	}
	return TRUE;
}
