
GSM_Error GSM_Phone_OBEXGEN::SendSyncMLFile(unsignedstring Buffer)
{
	GSM_File		File;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	int 			Pos;
	unsignedstring 		Type;
    	WB_UTINY 		*wbxml = NULL, *output = NULL, *xml = NULL;
    	WB_ULONG 		wbxml_len = 0,xml_len = 0;
    	WBXMLGenWBXMLParams 	params;
	GSM_Error 		error;

	(*Debug)->Deb("%s\n",Buffer.data());
	Type.clear();
	Type.append((unsigned char *)"application/vnd.syncml+wbxml",28);
	Type.push_back(0x00);
    	params.use_strtbl = TRUE;
    	params.keep_ignorable_ws = FALSE;
	params.wbxml_version=WBXML_VERSION_12;	
	wbxml_conv_xml2wbxml_withlen((unsigned char *)Buffer.data(), Buffer.size(), &wbxml, &wbxml_len, &params);
	File.Buffer.clear();
	File.Buffer.append(wbxml,wbxml_len);
    	wbxml_free(wbxml);
	File.Info.Size=File.Buffer.size();
	File.Info.Name.clear();
	File.Info.ID.clear();
	File.Info.ModificationDateTimeAvailable=FALSE;
	Pos = 0;
	error.Code = GSM_ERR_NONE;
	while (error.Code == GSM_ERR_NONE) {
		error = AddFile(&File, &Pos, Type);
	}
	if (error.Code == GSM_ERR_EMPTY) return GSM_Return_Error(GSM_ERR_NONE);
	return error;
}

GSM_Error GSM_Phone_OBEXGEN::GetSyncMLFile(unsignedstring *Buffer)
{
	GSM_File		File;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring 		Type;
    	WB_UTINY 		*wbxml = NULL, *output = NULL, *xml = NULL;
    	WB_ULONG 		wbxml_len = 0,xml_len = 0;
    	WBXMLGenXMLParams 	params2;
	GSM_Error 		error;

    	params2.lang = WBXML_LANG_UNKNOWN;
    	params2.gen_type = WBXML_GEN_XML_INDENT;
	params2.indent = 1;
    	params2.keep_ignorable_ws = FALSE;
	File.Buffer.clear();
	File.Info.Size = 0;
	error.Code = GSM_ERR_NONE;
	while (error.Code == GSM_ERR_NONE) {
		error = GetFile(&File, Type);
	}
	if (error.Code != GSM_ERR_EMPTY) return error;
    	wbxml_conv_wbxml2xml_withlen((unsigned char *)File.Buffer.data(), File.Buffer.size(), &xml, &xml_len, &params2);
	Buffer->clear();
	Buffer->append(xml,xml_len);
	(*Debug)->Deb("%s\n",Buffer->data());
    	wbxml_free(xml);

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetSyncML(unsignedstring MIME, unsignedstring ServerID, unsignedstring ServerFileID, GSM_File *File2)
{
	GSM_File		File;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;
	char 			buf[200];
	unsignedstring 		Type,Buffer;
    	WB_UTINY 		*wbxml = NULL, *output = NULL, *xml = NULL;
    	WB_ULONG 		wbxml_len = 0,xml_len = 0;
	GSM_Error 		error;
	TiXmlNode* 		node;
	BOOLEAN			WasPUT = FALSE;
	int				SyncMLSession;
	int 			Num;

	SyncMLSession = 28;
	Num = 1;

//---first send
	Buffer.clear();
	sprintf(buf,"<?xml version=\"1.0\"?>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<!DOCTYPE SyncML PUBLIC \"-//SYNCML//DTD SyncML 1.1//EN\" \"http://www.syncml.org/docs/syncml_represent_v11_20020213.dtd.dtd\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<SyncML xmlns=\"SYNCML:SYNCML1.1\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerDTD>1.1</VerDTD>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerProto>SyncML/1.1</VerProto>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <SessionID>%i</SessionID>\n",SyncMLSession);Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <MsgID>%i</MsgID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"    <Target><LocURI>/</LocURI></Target>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Source><LocURI>%s</LocURI></Source>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Alert>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>1</CmdID>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Data>206</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"        <Source><LocURI>%s</LocURI></Source>\n",ServerFileID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"        <Meta><Type xmlns=\"syncml:metinf\">%s</Type></Meta>\n",MIME.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      </Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Alert>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Final></Final>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"</SyncML>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	error = SendSyncMLFile(Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

//--first reply
	error = GetSyncMLFile(&Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

//--second send
	doc.Parse((char *)Buffer.data());
	TiXmlHandle docHandle( &doc );
	Buffer.clear();
	sprintf(buf,"<?xml version=\"1.0\"?>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<!DOCTYPE SyncML PUBLIC \"-//SYNCML//DTD SyncML 1.1//EN\" \"http://www.syncml.org/docs/syncml_represent_v11_20020213.dtd.dtd\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<SyncML xmlns=\"SYNCML:SYNCML1.1\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerDTD>1.1</VerDTD>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerProto>SyncML/1.1</VerProto>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("SessionID").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <SessionID>%s</SessionID>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <MsgID>2</MsgID>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <Target><LocURI>%s</LocURI></Target>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Source><LocURI>%s</LocURI></Source>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <MsgRef>1</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdRef>0</CmdRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Cmd>SyncHdr</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"      <TargetRef>%s</TargetRef>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Data>212</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));

	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncBody").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	for (node = todoElement->FirstChild( "Put" );node;node = node->NextSibling( "Put")) {
		TiXmlHandle docHandle2( node );
		todoElement = docHandle2.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
		if (!todoElement) continue;
		//if (!node->ToElement()->Attribute("name")) continue;
		sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
		Num++;
		sprintf(buf,"      <MsgRef>1</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdRef>%s</CmdRef>\n",docHandle2.FirstChild("CmdID").Element()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Cmd>Put</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <SourceRef>./devinf11</SourceRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Data>200</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		if (Capability.Info.Size == -1) {
			Capability.Buffer.append(Buffer);
			Capability.Info.Size = Capability.Buffer.size();			
		}
	}

	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncBody").FirstChild( "Alert" ).Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
//	if (strcmp(todoElement->FirstChild("Data")->ToElement()->GetText(),"201")) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <MsgRef>1</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdRef>%s</CmdRef>\n",todoElement->FirstChild("CmdID")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Cmd>Alert</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <TargetRef>%s</TargetRef>\n",todoElement->FirstChild("Item")->FirstChild("Target")->FirstChild("LocURI")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->FirstChild("Item")->FirstChild("Source")->FirstChild("LocURI")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	RemoteFile.append((unsigned char *)todoElement->FirstChild("Item")->FirstChild("Source")->FirstChild("LocURI")->ToElement()->GetText(),strlen(todoElement->FirstChild("Item")->FirstChild("Source")->FirstChild("LocURI")->ToElement()->GetText()));
	if (!strcmp(todoElement->FirstChild("Data")->ToElement()->GetText(),"201")) {
		sprintf(buf,"      <Data>200</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	} else {
		sprintf(buf,"      <Data>508</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	}
	sprintf(buf,"      <Item><Data><Anchor xmlns=\"syncml:metinf\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"        <Next>%s</Next>\n",todoElement->FirstChild("Item")->FirstChild("Meta")->FirstChild("Anchor")->FirstChild("Next")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      </Anchor></Data></Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));

	if (Capability.Info.Size == -1) {
		sprintf(buf,"    <Get>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
		Num++;
		sprintf(buf,"      <Meta>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"         <Type xmlns=\"syncml:metinf\">application/vnd.syncml-devinf+xml</Type>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      </Meta>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"         <Target><LocURI>./devinf11</LocURI></Target>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      </Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"    </Get>\n");Buffer.append((unsigned char *)buf,strlen(buf));		
	}

	WasPUT = TRUE;
	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncBody").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	for (node = todoElement->FirstChild( "Get" );node;node = node->NextSibling( "Get")) {
		TiXmlHandle docHandle2( node );
		todoElement = docHandle2.FirstChild("CmdID").Element();
		if (!todoElement) continue;
		sprintf(buf,"    <Results>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
		Num++;
		sprintf(buf,"      <MsgRef>1</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdRef>%s</CmdRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
		WasPUT = FALSE;
	}
	if (WasPUT) {
		sprintf(buf,"    <Put>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
		Num++;
	}
		sprintf(buf,"      <Meta><Type xmlns=\"syncml:metinf\">application/vnd.syncml-devinf+xml</Type></Meta>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Item><Source><LocURI>./devinf11</LocURI></Source>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"        <DevInf xmlns=\"syncml:devinf\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"          <VerDTD>1.1</VerDTD>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"          <Man>Marcin Wiacek</Man>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"          <Mod>GPlus</Mod>\n");Buffer.append((unsigned char *)buf,strlen(buf));

		sprintf(buf,"     <SwV>6.0522.0</SwV>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"     <DevID>PC Suite</DevID>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"     <DevTyp>phone</DevTyp>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"     <SupportLargeObjs/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"     <SupportNumberOfChanges/>\n");Buffer.append((unsigned char *)buf,strlen(buf));

		if (!strcmp((char *)MIME.data(),"text/x-vbookmark")) {
			//from N82
			sprintf(buf,"     <DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <SourceRef>Bookmarks</SourceRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <DisplayName>Bookmarks</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <MaxGUIDSize>8</MaxGUIDSize>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <CTType>text/x-vBookmark</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     </Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Rx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <CTType>application/vnd.omads-folder+xml</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           </Rx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <CTType>text/x-vBookmark</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           </Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Tx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <CTType>application/vnd.omads-folder+xml</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           </Tx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <SyncType>1</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <SyncType>2</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"            <SyncType>7</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           </SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"          </DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"          <CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <CTType>text/x-vBookmark</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>read</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType>bool</DataType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Read</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <CTType>application/vnd.omads-folder+xml</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>read</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType>bool</DataType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Read</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"          </CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		}
		if (!strcmp((char *)MIME.data(),"text/plain")) {
			//from N82
			sprintf(buf,"               <DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <SourceRef>Notes</SourceRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <DisplayName>Notes</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <MaxGUIDSize>8</MaxGUIDSize>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <CTType>text/plain</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                </Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <CTType>text/plain</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                </Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>1</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>2</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>3</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>4</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>5</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>6</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                 <SyncType>7</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                </SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"               </DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"               <CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                <CTType>text/plain</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"               </CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		}
		if (!strcmp((char *)MIME.data(),"text/x-vcalendar")) {
			//from N82
			sprintf(buf,"                     <DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                      <SourceRef>calendar</SourceRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                      <DisplayName>Calendar</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                      <MaxGUIDSize>8</MaxGUIDSize>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                      <Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                       <CTType>text/x-vcalendar</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                       <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"                      </Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"        <Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <CTType>text/x-vcalendar</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <VerCT>1.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>1</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>2</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>3</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>4</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>5</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>6</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>7</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     </DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     <CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <CTType>text/x-vcalendar</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>BEGIN</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VCALENDAR</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VEVENT</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VTODO</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Begin</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>END</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VCALENDAR</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VEVENT</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>VTODO</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>End</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>VERSION</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>1.0</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Version</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>UID</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Uid</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>SUMMARY</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Summary</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DESCRIPTION</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Description</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DTSTART</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Dstart</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DTEND</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Dtend</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>AALARM</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Aalarm</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>CLASS</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>PUBLIC</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>PRIVATE</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ValEnum>CONFIDENTIAL</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Class</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>LOCATION</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Location</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>LAST-MODIFIED</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Last Modified</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>PRIORITY</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Priority</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>STATUS</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Status</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>RRULE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Rrule</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>COMPLETED</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Completed</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DCREATED</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Dcreated</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DUE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Due</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>EXDATE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>ExDate</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>CATEGORIES</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));                                                          
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Categories</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>SEQUENCE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Sequence</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>TZ</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>TZ</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>DAYLIGHT</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Daylight</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>RDATE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>RDate</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>ATTENDEE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Attendee</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>ROLE</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Role</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>STATUS</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Status</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>X-CN</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>X-CN</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>X-ROLE</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Role</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>X-SENTBY</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Sent by</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <ParamName>X-STATUS</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Sent by</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>X-RECURRENCE-ID</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Recurrence</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>X-METHOD</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Method</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>X-SYMBIAN-LUID</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Local UID</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>X-SYMBIAN-DTSTAMP</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>Time stamp</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <PropName>X-EPOCAGENDAENTRYTYPE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <DisplayName>X-Epoc Agenda Entry Type</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     </CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		}
		if (!strcmp((char *)MIME.data(),"text/x-vcard")) {
			//from N82
			sprintf(buf,"     <DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <SourceRef>contacts</SourceRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <MaxGUIDSize>8</MaxGUIDSize>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <CTType>text/x-vcard</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <VerCT>2.1</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </Rx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Rx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <CTType>text/vcard</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <VerCT>3.0</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </Rx>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <CTType>text/x-vcard</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <VerCT>2.1</VerCT>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </Tx-Pref>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>1</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>2</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>3</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>4</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>5</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>6</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"       <SyncType>7</SyncType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      </SyncCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"     </DataStore>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	
			sprintf(buf,"          <CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <CTType>text/x-vcard</CTType>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>BEGIN</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>VCARD</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Begin</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>END</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>VCARD</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>End</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>VERSION</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>2.1</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Version</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>REV</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Revision</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>N</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Name</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>ADR</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Address</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>HOME</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Home address</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>WORK</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Work address</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>TEL</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Telephone number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>HOME</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Home telephone</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>WORK</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Work telephone</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>CELL</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Cellular number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>PAGER</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Pager number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>FAX</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Fax number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>VIDEO</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Video number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>PREF</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Default number</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>CAR</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Car telephone</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>FN</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>FullName</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>EMAIL</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Email address</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>HOME</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Home email</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>WORK</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Work email</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>URL</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>URL address</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>HOME</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Home URL</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>WORK</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Work URL</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>NOTE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Note</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>TITLE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Title</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>ORG</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Organisation</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>PHOTO</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Photo</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>BDAY</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Birthday</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>SOUND</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Sound</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-WV-ID</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Wireless Village Id</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-ASSISTANT</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Assistant name</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-ASSISTANT-TEL</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Assistant phone</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-ANNIVERSARY</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Anniversary</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-SPOUSE</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Spouse</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-CHILDREN</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Children</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-EPOCSECONDNAME</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Nickname</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-CLASS</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>PUBLIC</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>PRIVATE</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ValEnum>CONFIDENTIAL</ValEnum>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Class</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <PropName>X-SIP</PropName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <Size>256</Size>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>SIP protocol</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>POC</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>POC</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>SWIS</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>SWIS</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <ParamName>VOIP</ParamName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DataType/>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"           <DisplayName>Voice over IP</DisplayName>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"          </CTCap>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		}
		sprintf(buf,"        </DevInf>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      </Data></Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	if (WasPUT) {
		sprintf(buf,"    </Put>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	} else {
		sprintf(buf,"    </Results>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	}

	todoElement = docHandle.FirstChild("SyncML").FirstChild("SyncBody").FirstChild( "Alert" ).Element();
	sprintf(buf,"    <Alert>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <Data>201</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"         <Target><LocURI>%s</LocURI></Target>\n",todoElement->FirstChild("Item")->FirstChild("Source")->FirstChild("LocURI")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"         <Source><LocURI>%s</LocURI></Source>\n",todoElement->FirstChild("Item")->FirstChild("Target")->FirstChild("LocURI")->ToElement()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"         <Meta><Anchor xmlns=\"syncml:metinf\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"           <Last>8342</Last>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"           <Next>8342</Next>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"         </Anchor></Meta>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      </Item>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Alert>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Final></Final>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"</SyncML>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	error = SendSyncMLFile(Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

//--second reply
	error = GetSyncMLFile(&Buffer);
	if (error.Code != GSM_ERR_NONE) return error;
	File2->Buffer.append(Buffer);
	File2->Info.Size = File2->Buffer.size();
	if (Capability.Info.Size == -1) {
		Capability.Buffer.append(Buffer);
		Capability.Info.Size = Capability.Buffer.size();
	}

//--3rd send
	doc.Clear();
	doc.Parse((char *)Buffer.data());
	TiXmlHandle docHandle3( &doc );
	Buffer.clear();
	sprintf(buf,"<?xml version=\"1.0\"?>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<!DOCTYPE SyncML PUBLIC \"-//SYNCML//DTD SyncML 1.1//EN\" \"http://www.syncml.org/docs/syncml_represent_v11_20020213.dtd.dtd\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<SyncML xmlns=\"SYNCML:SYNCML1.1\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerDTD>1.1</VerDTD>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerProto>SyncML/1.1</VerProto>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("SessionID").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <SessionID>%s</SessionID>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <MsgID>3</MsgID>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <Target><LocURI>%s</LocURI></Target>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Source><LocURI>%s</LocURI></Source>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <MsgRef>2</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdRef>0</CmdRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Cmd>SyncHdr</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <TargetRef>%s</TargetRef>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Data>212</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));

	//fixme - trzeba dodac branie statusu
//	if (!PutAvail) {
//	}

	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	for (node = todoElement->FirstChild( "Sync" );node;node = node->NextSibling( "Sync")) {
		TiXmlHandle docHandle4( node );
		todoElement = docHandle4.FirstChild( "Source" ).FirstChild("LocURI").Element();
		if (!todoElement) continue;
		sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
		Num++;
		sprintf(buf,"      <MsgRef>2</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <CmdRef>%s</CmdRef>\n",docHandle4.FirstChild("CmdID").Element()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Cmd>Sync</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <TargetRef>%s</TargetRef>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"      <Data>200</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	}
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			TiXmlHandle docHandle5( node );
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
			if (!todoElement) continue;
			sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
			Num++;
			sprintf(buf,"      <MsgRef>2</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <CmdRef>%s</CmdRef>\n",docHandle5.FirstChild("CmdID").Element()->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Cmd>Add</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"      <Data>200</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
			sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
		}
	}
	sprintf(buf,"    <Sync>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <Target><LocURI>%s</LocURI></Target>\n",RemoteFile.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Source><LocURI>%s</LocURI></Source>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Sync>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Final></Final>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"</SyncML>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	error = SendSyncMLFile(Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

//--3rd reply
	error = GetSyncMLFile(&Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

//--4th send
	doc.Clear();
	doc.Parse((char *)Buffer.data());
	TiXmlHandle docHandle5( &doc );
	Buffer.clear();
	sprintf(buf,"<?xml version=\"1.0\"?>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<!DOCTYPE SyncML PUBLIC \"-//SYNCML//DTD SyncML 1.1//EN\" \"http://www.syncml.org/docs/syncml_represent_v11_20020213.dtd.dtd\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"<SyncML xmlns=\"SYNCML:SYNCML1.1\">\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerDTD>1.1</VerDTD>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <VerProto>SyncML/1.1</VerProto>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle5.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("SessionID").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <SessionID>%s</SessionID>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <MsgID>4</MsgID>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"    <Target><LocURI>%s</LocURI></Target>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Source><LocURI>%s</LocURI></Source>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
//	sprintf(buf,"    <NoResp></NoResp>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncHdr>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  <SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdID>%i</CmdID>\n",Num);Buffer.append((unsigned char *)buf,strlen(buf));
	Num++;
	sprintf(buf,"      <MsgRef>3</MsgRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <CmdRef>0</CmdRef>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Cmd>SyncHdr</Cmd>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	todoElement = docHandle5.FirstChild("SyncML").FirstChild("SyncHdr").FirstChild("Source").FirstChild("LocURI").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);	
	sprintf(buf,"      <SourceRef>%s</SourceRef>\n",todoElement->GetText());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <TargetRef>%s</TargetRef>\n",ServerID.data());Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"      <Data>212</Data>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    </Status>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"    <Final></Final>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"  </SyncBody>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	sprintf(buf,"</SyncML>\n");Buffer.append((unsigned char *)buf,strlen(buf));
	error = SendSyncMLFile(Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

        return GSM_Return_Error(GSM_ERR_NONE);

//--4th reply
	error = GetSyncMLFile(&Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

        return GSM_Return_Error(GSM_ERR_NONE);
}


GSM_Error GSM_Phone_OBEXGEN::GetPBKStatus(GSM_PBKStatus *Status)
{
	GSM_File File;
	GSM_Error error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring 		Buffer;
	unsignedstring  	req,MIME,ServerID,ServerFileID;
	wchart			buf2,name,Name2;
	TiXmlElement* 		todoElement;
	TiXmlNode* 		node;

	if (!SyncML) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	if (Status->Memory != MEM_PHONE) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

//	if (PhonePBK.Info.Size == -1) {
//		MIME.append((unsigned char *)"text/x-vcard",12);
//		ServerID.append((unsigned char *)"PC Suite",8);
//		ServerFileID.append((unsigned char *)"Contacts",8);
//		error = GetSyncML(MIME, ServerID, ServerFileID, &PhonePBK);
//		if (error.Code != GSM_ERR_NONE) return error;
//	}

	Status->Used=0;
	Status->Free=-1;
	doc.Parse((char *)PhonePBK.Buffer.data());
	TiXmlHandle docHandle3( &doc );
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			Status->Used++;
		}
	}
        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetPBK(GSM_PBKEntry *Entry)
{
	GSM_File File;
	GSM_Error error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring  	req,MIME,ServerID,ServerFileID,test;
	wchart			buf2,name,Name2;
	TiXmlElement* 		todoElement;
	TiXmlNode* 		node;
	char Buffer[200];

	if (!SyncML) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	if (Entry->Memory != MEM_PHONE) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

//	if (PhonePBK.Info.Size == -1) {
//		MIME.append((unsigned char *)"text/x-vcard",12);
//		ServerID.append((unsigned char *)"PC Suite",8);
//		ServerFileID.append((unsigned char *)"Contacts",8);
//		error = GetSyncML(MIME, ServerID, ServerFileID, &PhonePBK);
//		if (error.Code != GSM_ERR_NONE) return error;
//	}

	doc.Parse((char *)PhonePBK.Buffer.data());
	TiXmlHandle docHandle3( &doc );
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			TiXmlHandle docHandle5( node );
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
			if (!todoElement) continue;
			sprintf(Buffer,"%i",Entry->Location);
			if (strcmp(Buffer,todoElement->GetText())) continue;
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Data" ).Element();
			(*Debug)->Deb("%s\n",(char *)todoElement->GetText());
			test.clear();
			test.append((const unsigned char *)todoElement->GetText(),strlen((char *)todoElement->GetText()));
			Entry->DecodeFromVCARD(&test);
		        return GSM_Return_Error(GSM_ERR_NONE);
		}
	}
        return GSM_Return_Error(GSM_ERR_EMPTY);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextNote(GSM_NoteEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	GSM_File File;
	GSM_Error error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring  	req,MIME,ServerID,ServerFileID,test;
	wchart			buf2,name,Name2;
	TiXmlElement* 		todoElement;
	TiXmlNode* 		node;
	char Buffer[200];
	BOOLEAN Next = FALSE;

	if (!SyncML) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	if (start) {
		error = ResetConnection();
		if (error.Code != GSM_ERR_NONE) return error;

		MIME.append((unsigned char *)"text/plain",10);
		ServerID.append((unsigned char *)"PC Suite",8);
		ServerFileID.append((unsigned char *)"Notes",5);
		error = GetSyncML(MIME, ServerID, ServerFileID, &Notes);
		if (error.Code != GSM_ERR_NONE) return error;
	} else {
		sprintf(Buffer,"%i",NoteID);
	}
	doc.Parse((char *)Notes.Buffer.data());
	TiXmlHandle docHandle3( &doc );
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			TiXmlHandle docHandle5( node );
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
			if (!todoElement) continue;
			if (!start && !strcmp(Buffer,todoElement->GetText())) {
				Next = TRUE;
				continue;
			}
			if (!start && !Next) continue;
			Entry->Location=atoi(todoElement->GetText());
			NoteID = Entry->Location;
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Data" ).Element();
			(*Debug)->Deb("%s\n",(char *)todoElement->GetText());
			UTF8ToUnicode((const unsigned char *)todoElement->GetText(),&Entry->Text, strlen((char *)todoElement->GetText()));
		        return GSM_Return_Error(GSM_ERR_NONE);
		}
	}
	return GSM_Return_Error(GSM_ERR_EMPTY);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	GSM_File File;
	GSM_Error error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring  	req,MIME,ServerID,ServerFileID,test;
	wchart			buf2,name,Name2;
	TiXmlElement* 		todoElement;
	TiXmlNode* 		node;
	char Buffer[200];
	BOOLEAN Next = FALSE;

	if (!SyncML) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	if (start) {
		if (Calendar.Info.Size == -1) {		
			error = ResetConnection();
			if (error.Code != GSM_ERR_NONE) return error;

			MIME.append((unsigned char *)"text/x-vcalendar",16);
			ServerID.append((unsigned char *)"PC Suite",8);
			ServerFileID.append((unsigned char *)"Calendar",8);
			error = GetSyncML(MIME, ServerID, ServerFileID, &Calendar);
			if (error.Code != GSM_ERR_NONE) return error;
		}
	} else {
		sprintf(Buffer,"%i",CalendarID);
	}

	doc.Parse((char *)Calendar.Buffer.data());
	TiXmlHandle docHandle3( &doc );
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			TiXmlHandle docHandle5( node );
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
			if (!todoElement) continue;
			if (!start && !strcmp(Buffer,todoElement->GetText())) {
				Next = TRUE;
				continue;
			}
			if (!start && !Next) continue;
			Entry->Location=atoi(todoElement->GetText());
			CalendarID = Entry->Location;
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Data" ).Element();
			(*Debug)->Deb("%s\n",(char *)todoElement->GetText());
			test.clear();
			test.append((const unsigned char *)todoElement->GetText(),strlen((char *)todoElement->GetText()));
			error = Entry->DecodeFromVCALENDAR(&test);
			if (error.Code != GSM_ERR_NONE) continue;

		        return GSM_Return_Error(GSM_ERR_NONE);
		}
	}
	return GSM_Return_Error(GSM_ERR_EMPTY);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextToDo(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	GSM_File File;
	GSM_Error error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring  	req,MIME,ServerID,ServerFileID,test;
	wchart			buf2,name,Name2;
	TiXmlElement* 		todoElement;
	TiXmlNode* 		node;
	char Buffer[200];
	BOOLEAN Next = FALSE;

	if (!SyncML) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	if (start) {
		if (Calendar.Info.Size == -1) {		
			error = ResetConnection();
			if (error.Code != GSM_ERR_NONE) return error;

			MIME.append((unsigned char *)"text/x-vcalendar",16);
			ServerID.append((unsigned char *)"PC Suite",8);
			ServerFileID.append((unsigned char *)"Calendar",8);
			error = GetSyncML(MIME, ServerID, ServerFileID, &Calendar);
			if (error.Code != GSM_ERR_NONE) return error;
		}
	} else {
		sprintf(Buffer,"%i",ToDoID);
	}

	doc.Parse((char *)Calendar.Buffer.data());
	TiXmlHandle docHandle3( &doc );
	todoElement = docHandle3.FirstChild("SyncML").FirstChild("SyncBody").FirstChild("Sync").Element();
	if (todoElement != NULL) {
		for (node = todoElement->FirstChild( "Add" );node;node = node->NextSibling( "Add")) {
			TiXmlHandle docHandle5( node );
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Source" ).FirstChild("LocURI").Element();
			if (!todoElement) continue;
			if (!start && !strcmp(Buffer,todoElement->GetText())) {
				Next = TRUE;
				continue;
			}
			if (!start && !Next) continue;
			Entry->Location=atoi(todoElement->GetText());
			ToDoID = Entry->Location;
			todoElement = docHandle5.FirstChild("Item").FirstChild( "Data" ).Element();
			(*Debug)->Deb("%s\n",(char *)todoElement->GetText());
			test.clear();
			test.append((const unsigned char *)todoElement->GetText(),strlen((char *)todoElement->GetText()));
			error = Entry->DecodeFromVTODO(&test);
			if (error.Code != GSM_ERR_NONE) continue;

		        return GSM_Return_Error(GSM_ERR_NONE);
		}
	}
	return GSM_Return_Error(GSM_ERR_EMPTY);
}
