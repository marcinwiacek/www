//---------------------------------------------------------------------------
//
// Name:        EMSAddDlg.cpp
// Author:      Marcinello
// Created:     2007-10-04 21:54:58
// Description: EMSAddDlg class implementation
//
//---------------------------------------------------------------------------

#include "EMSAddDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// EMSAddDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(EMSAddDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(EMSAddDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON2,EMSAddDlg::WxButton2Click)
	EVT_BUTTON(ID_WXBUTTON1,EMSAddDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

EMSAddDlg::EMSAddDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
	
	WxListBox1->Select(0);
}

EMSAddDlg::~EMSAddDlg()
{
} 

void EMSAddDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Add part"));
	SetIcon(wxNullIcon);
	SetSize(8,8,270,285);
	Center();
	

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Cancel"), wxPoint(171,203), wxSize(83,34), 0, wxDefaultValidator, wxT("WxButton2"));
	WxButton2->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("OK"), wxPoint(12,203), wxSize(80,35), 0, wxDefaultValidator, wxT("WxButton1"));
	WxButton1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	wxArrayString arrayStringFor_WxListBox1;
	WxListBox1 = new wxListBox(this, ID_WXLISTBOX1, wxPoint(11,14), wxSize(243,180), arrayStringFor_WxListBox1, wxLB_SINGLE);
	WxListBox1->Append(wxT("Text"));
	WxListBox1->Append(wxT("Sound (IMelody)"));
	WxListBox1->Append(wxT("Predefined animation"));
	WxListBox1->Append(wxT("Predefined sound"));
	WxListBox1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));
	////GUI Items Creation End
}

void EMSAddDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void EMSAddDlg::WxButton1Click(wxCommandEvent& event)
{
	EndModal(wxID_OK);
}

/*
 * WxButton2Click
 */
void EMSAddDlg::WxButton2Click(wxCommandEvent& event)
{
	EndModal(wxID_CANCEL);
}
