/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../../gsmcomon.h"
#include "obex.h"

GSM_Error GSM_Protocol_OBEX::Open(char *Prot)
{
        if (!strcmp(Protocol,"irdaobex")) return GSM_ERR_NONE;
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Protocol_OBEX::Close()
{
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Protocol_OBEX::Write(unsigned char *buffer, int length, unsigned char type)
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Protocol_OBEX::Dispatch(unsigned char *buffer, int length, int *position)
{
        return GSM_ERR_NONE;
}
