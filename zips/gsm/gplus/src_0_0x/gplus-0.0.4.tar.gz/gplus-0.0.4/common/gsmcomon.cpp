/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

//#include <stdarg.h>

#include "gsmcomon.h"

typedef struct {
        GSM_Error             ErrorNum;
        char                  *ErrorText;
} PrintErrorEntry;

char *GSM_GetErrorInfo(GSM_Error e)
{
        PrintErrorEntry PrintErrorEntries[] = {
		{GSM_ERR_DRIVERNOTAVAILABLE,		"Some required driver or operating system part not available."},
		{GSM_ERR_DEVICEWRITE,			"Error writing device"},
		{GSM_ERR_DEVICEREAD,			"Error reading device"},
		{GSM_ERR_DEVICEOPEN,			"Error opening device"},
		{GSM_ERR_DEVICECLOSE,			"Error closing device"},
                {GSM_ERR_NONE,                          "No error."},
                {GSM_ERR_UNKNOWN,                       "Unknown error. Please report."},
                {GSM_ERR_SOURCENOTCOMPILED,             "Some parts of source not compiled."},
                {GSM_ERR_UNKNOWNPROTOCOLSTRING,         "Protocol specified in config is not known."},
                {GSM_ERR_UNKNOWNPHONESTRING,            "Phone model specified in config is not known."},
                {GSM_ERR_OTHERPROTOCOL,                 "Phone model specified in config works with others protocols only."},
		{GSM_ERR_TIMEOUT,			"No response in specified time."},
		{GSM_ERR_EMPTY,				"Empty"},
		{GSM_ERR_NOTSUPPORTED,			"Not supported"},
		{GSM_ERR_INSIDEPHONEMENU,		"Data are edited in phone menu. Leave it before editing from PC."},

                {GSM_ERR_NONE,                          ""}
        };
        char   *def    = NULL;
        int    i       = 0;

        while (1) {
                if (PrintErrorEntries[i].ErrorText[0] == 0x00) break;
                if (PrintErrorEntries[i].ErrorNum == e) {
                        def     = PrintErrorEntries[i].ErrorText;
                        break;
                }
                i++;
        }
        if (def == NULL) def = "Unknown error.";
        return def;
}
