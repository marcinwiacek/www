/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../gsmphone.h"
#include "../../../gsmcomon.h"
#include "../ndct34.h"

#include "ndct3.h"

GSM_Phone_NDCT3::GSM_Phone_NDCT3(int id)
{
	ID = id;
}

int GSM_Phone_NDCT3::GetID()
{
	return ID;
}

GSM_Error GSM_Phone_NDCT3::ReplySetSecurity(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident)
{
	(*Debug)->Deb("RECEIVED: set state of security commands\n");
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT3::SetSecurity(DebugInfo *Debug, GSM_Phone *Pho, unsigned char status)
{
	unsigned char Buff[] = {0x00, 0x01, 0x64, 0x01};

	/* 0x00 - phone on
	 * 0x01 - phone off
	 * 0x03 - soft reset. When use it and had during session
	 *        changed time & date some phones (like 6150 or 6210) can ask
         *        for time & date after reset or disable clock on the screen
	 * 0x04 - hard reset
	 * 0x06 - CONTACT SERVICE
	 */
	if (status == 0x06) return GSM_ERR_UNKNOWN;
	Buff[3] = status;

	Debug->Deb("SENT: Setting state of security commands\n");
	return Pho->Write(Buff, sizeof(Buff), 0x40, 4, ID_SetSecurity+ID, NULL);
}

GSM_Error GSM_Phone_NDCT3::ReplyGetIMEI(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI)
{
	memcpy(IMEI,msg->Buffer.data()+4, 16);
	(*Debug)->Deb("RECEIVED: IMEI %s\n",IMEI);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT3::GetIMEI(DebugInfo *Debug, GSM_Phone *Pho, unsigned char *IMEI)
{
	unsigned char 	Buff[] = {0x00, 0x01, 0x66, 0x00};
	GSM_Error 	error;

	error = SetSecurity(Debug,Pho,0x01);
	if (error != GSM_ERR_NONE) return error;

	Debug->Deb("SENT: getting IMEI\n");
	return Pho->Write(Buff, sizeof(Buff), 0x40, 2, ID_GetIMEI+ID, IMEI);
}

GSM_Error GSM_Phone_NDCT3::ReplyGetDateTime(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_DateTime *DT = (GSM_DateTime *)S;

	(*Debug)->Deb("RECEIVED: datetime\n");

	if (msg->Buffer.data()[4] == 0x01) {
		memcpy(DT,NokiaGetDT(msg->Buffer.data()+8),sizeof(GSM_DateTime));
		return GSM_ERR_NONE;
	}
	return GSM_ERR_EMPTY;
}

GSM_Error GSM_Phone_NDCT3::GetDateTime(DebugInfo *Debug, GSM_Phone *Pho, GSM_DateTime *DT, unsigned char msgtype)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x62};

	Debug->Deb("SENT: getting datetime\n");
	return Pho->Write(Buff, sizeof(Buff), msgtype, 4, ID_GetDateTime+ID, DT);
}
