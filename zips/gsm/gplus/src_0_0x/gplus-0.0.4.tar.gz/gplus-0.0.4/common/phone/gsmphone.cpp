/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
#  include <windows.h>
#endif

#include "../protocol/gsmprot.h"
#include "../device/gsmdev.h"
#include "../gsmcomon.h"
#include "gsmphone.h"

BOOLEAN GSM_AllPhones::Feature(char *Name)
{
	char Buff[50];

	sprintf(Buff,"-%s-",Name);
	if (strstr(Features,Buff)!=NULL) return TRUE;
	return FALSE;
}

int GSM_AllPhones::GetID()
{
	ID+=100;
	if (ID > 20000) (*Debug)->Deb("[STATE     : ERROR WITH ID]\n");
	return ID-100;
}

GSM_AllPhones::GSM_AllPhones(DebugInfo **Deb)
{
	ID		= 0;
        ReceivedLen     = 0;
        ReceivedPos     = 0;
        ReplyNum        = 3;
        Current         = NULL;
        AllPhones       = NULL;
        Debug           = Deb;
}

GSM_AllPhones::~GSM_AllPhones()
{
        GSM_Phone       *pho,*pho2;

        pho=AllPhones;
        while(1) {
                if (pho == NULL) break;
                pho2 = pho->Next;
                delete(pho);
                pho = pho2;
        }
}

void GSM_AllPhones::Add(GSM_Phone *Phone)
{
        GSM_Phone *Pho;

        if (AllPhones == NULL) {
                AllPhones = Phone;
        } else {
                Pho = AllPhones;
                while (Pho->Next != NULL) Pho = Pho->Next;
                Pho->Next = Phone;
        }
}

GSM_Error GSM_AllPhones::Switch(char *Pho, char *Pro)
{
        GSM_Phone       		*pho;
        bool            		PhoneFound = false, found;
	list<GSM_Phone_Info>::iterator 	phoinfo;
	int				i;
	char				buf[20];

        (*Debug)->Deb("[STATE     : switching to phone]\n");

        /* Do we have phone model in phone modules ? If yes, switch */
        pho=AllPhones;
        while(1) {
		for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
                        if (strcmp(phoinfo->Model,Pho)) {
				continue;
			} else {
				PhoneFound=true;
			}
			if (phoinfo->CompareProtocol(Pro)) {
				found = true;

				i = 0;
				while(pho->ModulesUsed[i]!=0) {
					memset(buf,0,sizeof(buf));
					while(pho->ModulesUsed[i]!=0) {
						buf[strlen(buf)] = pho->ModulesUsed[i];
						i++;
						if (pho->ModulesUsed[i]=='|') {
							i++;
							break;
						}
					}
//					(*Debug)->Deb("Checking \"%s\" used\n",buf);
				}

				i = 0;
				while(pho->ModulesRequired[i]!=0) {
					memset(buf,0,sizeof(buf));
					while(pho->ModulesRequired[i]!=0) {
						buf[strlen(buf)] = pho->ModulesRequired[i];
						i++;
						if (pho->ModulesRequired[i]=='|') {
							i++;
							break;
						}
					}
//					(*Debug)->Deb("Checking \"%s\" required\n",buf);
				}

				if (found) {
	                                if (Current != NULL) {
	                                        //disable old
	                                }
	                                Current 	= pho;
					Features 	= phoinfo->Features;
					Model 		= phoinfo->Model;
					CodeNameModel 	= phoinfo->CodeNameModel;
	                                return GSM_ERR_NONE;
				}
			}
	        }
                if (pho->Next == NULL) break;
                pho = pho->Next;
        }

        /* We had phone, but with other protocol */
        if (PhoneFound) return GSM_ERR_OTHERPROTOCOL;

        /* Unknown phone model */
        return GSM_ERR_UNKNOWNPHONESTRING;
}

GSM_Error GSM_AllPhones::SwitchToDeviceName(char *Pho, char *Pro)
{
        GSM_Phone       		*pho;
	list<GSM_Phone_Info>::iterator 	phoinfo;
        bool            		PhoneFound = false;

        (*Debug)->Deb("[STATE     : switching to phone with device name]\n");

        /* Do we have phone model in phone modules ? If yes, switch */
        pho=AllPhones;
        while(1) {
		for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
                        if (strcmp(phoinfo->DeviceModel,Pho)) continue; else PhoneFound=true;
			if (phoinfo->CompareProtocol(Pro)) {
	                	if (Current != NULL) {
	                		//disable old
				}
				Current 	= pho;
				Features 	= phoinfo->Features;
				Model 		= phoinfo->Model;
				CodeNameModel 	= phoinfo->CodeNameModel;
				return GSM_ERR_NONE;
			}
	        }
                if (pho->Next == NULL) break;
                pho = pho->Next;
        }

        /* We had phone, but with other protocol */
        if (PhoneFound) return GSM_ERR_OTHERPROTOCOL;

        /* Unknown phone model */
        return GSM_ERR_UNKNOWNPHONESTRING;
}

int GSM_AllPhones::GetNext(GSM_Phone **Pho)
{
        if ((*Pho) == NULL) {
                (*Pho) = AllPhones;
        } else {
                if ((*Pho)->Next == NULL) return 0;
                (*Pho) = ((*Pho)->Next);
        }
        return 1;
}

/* ------------------------------------------------------------------------- */

GSM_Phone_Info::GSM_Phone_Info(char *Mod, char *Code, char *Device, char *Prot, char *Feat)
{
        Model                   = Mod;
        Protocol                = Prot;
        CodeNameModel           = Code;
        DeviceModel             = Device;
        Features                = Feat;
}

GSM_Phone_Info::~GSM_Phone_Info()
{
}

bool GSM_Phone_Info::CompareProtocol(char *Pro)
{
	char		Prot[50];
	int		i;
        bool            PhoneFound = false;

	Prot[0] = 0;
	for (i=0;i<(int)strlen(this->Protocol)+1;i++) {
		if (i == strlen(this->Protocol) || this->Protocol[i] == '|') {
                        if (!strcmp(Prot,Pro)) return true;
			Prot[0] = 0;
		} else {
			Prot[strlen(Prot)+1] = 0;
			Prot[strlen(Prot)]   = this->Protocol[i];
		}
	}
	return false;
}

/* ------------------------------------------------------------------------- */

GSM_Phone::GSM_Phone(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho)
{
	UserReply	= NULL;
	Next            = NULL;
	Protocols       = Prot;
	Device          = Dev;
	Phones          = Pho;
	Debug           = Deb;
	Opened		= false;
	ID		= (*Phones)->GetID();
}

GSM_Phone::~GSM_Phone()
{
}

int GSM_Phone::GetID()
{
	return ID;
}

GSM_Error GSM_Phone::Read(int RequestID, void *Struct)
{
	GSM_Error error;

	if ((*Phones)->ReceivedLen == (*Phones)->ReceivedPos) {
		(*Phones)->ReceivedPos = 0;
                (*Phones)->ReceivedLen = 200;
                error = (*Device)->Read((*Phones)->ReceivedBuffer,&(*Phones)->ReceivedLen);
                if (error != GSM_ERR_NONE) return error;
		if ((*Phones)->ReceivedLen == 0) return GSM_ERR_TIMEOUT;
	}

	error = (*Protocols)->Current->Dispatch((*Phones)->ReceivedBuffer,(*Phones)->ReceivedLen,&(*Phones)->ReceivedPos);
	switch (error) {
	case GSM_ERR_NEWMESSAGE:
		(*Debug)->Deb	 ("RECEIVED frame type 0x%02X/length %i\n",(*Protocols)->Current->MsgReceived.Type,(*Protocols)->Current->MsgReceived.Length);
		(*Debug)->DumpDeb((*Protocols)->Current->MsgReceived.Buffer.data(), (*Protocols)->Current->MsgReceived.Length);

		if (UserReply != NULL) {
	                error = UserReply((*Protocols)->Current->MsgReceived.Length,
					  (*Protocols)->Current->MsgReceived.Type,
					  (unsigned char *)(*Protocols)->Current->MsgReceived.Buffer.data(),
					  Struct, RequestID);
			if (error == GSM_ERR_FRAME_UNKNOWN) {
		                error = Dispatch(&(*Protocols)->Current->MsgReceived, Struct, RequestID);
			}
		} else {
	                error = Dispatch(&(*Protocols)->Current->MsgReceived, Struct, RequestID);
		}

		switch (error) {
		case GSM_ERR_FRAME_NOTREQUESTED:
			(*Debug)->Deb    ("\nFrame not requested. Please report\n");
			(*Debug)->Deb	 ("\nSENT frame type 0x%02X/length %i\n",(*Protocols)->Current->MsgSent.Type,(*Protocols)->Current->MsgSent.Length);
			(*Debug)->DumpDeb((*Protocols)->Current->MsgSent.Buffer.data(), (*Protocols)->Current->MsgSent.Length);
			(*Debug)->Deb	 ("\nRECEIVED frame type 0x%02X/length %i\n",(*Protocols)->Current->MsgReceived.Type,(*Protocols)->Current->MsgReceived.Length);
			(*Debug)->DumpDeb((*Protocols)->Current->MsgReceived.Buffer.data(), (*Protocols)->Current->MsgReceived.Length);
			(*Debug)->Deb	 ("\n");
			return error;
		case GSM_ERR_FRAME_UNKNOWN:
			(*Debug)->Deb    ("\nFrame unknown. Please report\n");
			(*Debug)->Deb	 ("\nSENT frame type 0x%02X/length %i\n",(*Protocols)->Current->MsgSent.Type,(*Protocols)->Current->MsgSent.Length);
			(*Debug)->DumpDeb((*Protocols)->Current->MsgSent.Buffer.data(), (*Protocols)->Current->MsgSent.Length);
			(*Debug)->Deb	 ("\nRECEIVED frame type 0x%02X/length %i\n",(*Protocols)->Current->MsgReceived.Type,(*Protocols)->Current->MsgReceived.Length);
			(*Debug)->DumpDeb((*Protocols)->Current->MsgReceived.Buffer.data(), (*Protocols)->Current->MsgReceived.Length);
			(*Debug)->Deb	 ("\n");
			return error;
		default:
			return error;
		}
	case GSM_ERR_NONE:
		return GSM_ERR_TIMEOUT;
	default:
		return error;
	}
}

GSM_Error GSM_Phone::Write(unsigned char *buffer,int length, unsigned char type, int time, int request, void *Struct)
{      
        int             i, j;
        GSM_Error       error;

        for (i=0;i<(*Phones)->ReplyNum;i++) {
                if (i!=0) (*Debug)->Deb("RETRYING sending frame %i/%i time\n", i+1, (*Phones)->ReplyNum);

                error = (*Protocols)->Current->Write(buffer, length, type);
                if (error!=GSM_ERR_NONE) return error;

		for (j=0;j<200;j++) {
	                error = Read(request, Struct);
	                if (error != GSM_ERR_TIMEOUT) return error;
#ifdef WIN32
			Sleep(5);
#else
			usleep(500);
#endif
		}
        }

        return GSM_ERR_TIMEOUT;
}

bool GSM_Phone::Ans(char *MsgTyp, int SubTypeChar, unsigned char SubType, int Request, AnsStruct *AS)
{
	unsigned char *MsgType = (unsigned char *)MsgTyp;

	/* AT commands */
	if (strlen((const char *)MsgType) > 2) {
	}

	/* ------------ Nokia and other binary stuff ------------------ */

	if ((*Protocols)->Current->MsgReceived.Type != MsgType[0]) return false;

	if (SubTypeChar != 0 && SubTypeChar < (*Protocols)->Current->MsgReceived.Length) {
		if ((*Protocols)->Current->MsgReceived.Buffer[SubTypeChar] != SubType) return false;
	}

	(AS->FrameFound) = true;

	if (Request != ID_IncomingFrame && Request != AS->RequestID) return false;
	return true;
}

GSM_Error GSM_Phone::Open(char *ID)
{
        (*Debug)->Deb("[STATE     : opening phone %s]\n",ModuleName);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone::Close()
{
        return GSM_ERR_NONE;
}

void GSM_Phone::SetUserReply(GSM_Error(*UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID))
{
	UserReply = UsrReply;
}

GSM_Error GSM_Phone::GetModel(unsigned char *Model)
{
	unsigned char			Mod[50];
	list<GSM_Phone_Info>::iterator 	phoinfo;
	GSM_Error			error;

	error = GetCodeNameModel(Mod);
	if (error != GSM_ERR_NONE) return error;

	for (phoinfo=Info.begin(); phoinfo!=Info.end(); ++phoinfo) {
                if (strcmp(phoinfo->CodeNameModel,(const char *)Mod)) continue;
		strcpy((char *)Model,phoinfo->Model);
		return GSM_ERR_NONE;
        }

	return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Phone::GetManufacturer(unsigned char *Manufacturer)
{
	Manufacturer[0] = 0;
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetIMEI(unsigned char *IMEI)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetCodeNameModel(unsigned char *CodeNameModel)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetFirmwareVersion(unsigned char *Firm)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetFirmwareDate(unsigned char *Date)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetPBKMemoryStatus(GSM_PBKStatus *Status)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetPBKMemory(GSM_PBKEntry *Entry)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::SetPBKMemory(GSM_PBKEntry *Entry)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::DeletePBKMemory(GSM_PBKEntry *Entry)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::AddCalendar(GSM_CalendarEntry *Entry)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::DeleteCalendar(GSM_CalendarEntry *Entry)
{
	return GSM_ERR_NOTSUPPORTED;
}

GSM_Error GSM_Phone::GetDateTime(GSM_DateTime *DT)
{
	return GSM_ERR_NOTSUPPORTED;
}
