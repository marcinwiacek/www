/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../protocol/gsmprot.h"
#include "../ndct34.h"
#include "n7110.h"
#include "ndct3.h"

GSM_Error GSM_Phone_N7110::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	int		ID2 = DCT3->GetID(), ID3 = DCT34->GetID();
	AnsStruct 	AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

if(Ans("\x03",0x03,0x04,ID_GetPBKStatus+ID,&AS))return ReplyGetPBKStatus		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x08,ID_GetPBKEntry+ID, &AS))return ReplyGetPBKMemory		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x0C,ID_SetPBKEntry+ID, &AS))return DCT34->ReplySetPBKMemory 	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x10,ID_DelPBKEntry+ID, &AS))return DCT34->ReplyDelPBKMemory 	(msg,Debug,(unsigned char *)Struct);

if(Ans("\x13",0x03,0x02,ID_AddCalendarEntry+ID3,&AS))   return DCT34->ReplyAddCalendar1		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x04,ID_AddCalendarEntry+ID3,&AS))   return DCT34->ReplyAddCalendar1		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x06,ID_AddCalendarEntry+ID3,&AS))   return DCT34->ReplyAddCalendar1		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x08,ID_AddCalendarEntry+ID3,&AS))   return DCT34->ReplyAddCalendar1		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x0C,ID_DelCalendarEntry+ID3,&AS))   return DCT34->ReplyDelCalendar		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x1A,ID_GetCalendarEntry+ID3,&AS))   return DCT34->ReplyGetNextCalendar1	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x32,ID_GetFirstCalendarPos+ID3,&AS))return DCT34->ReplyGetFirstCalendarPos1	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x13",0x03,0x3B,ID_GetCalendarInfo+ID3,&AS))    return DCT34->ReplyGetCalendarInfo1	(msg,Debug,(unsigned char *)Struct);

if(Ans("\x19",0x03,0x63,ID_GetDateTime+ID2,&AS))     return DCT3->ReplyGetDateTime		(msg,Debug,(unsigned char *)Struct);

if(Ans("\x40",0x02,0x64,ID_SetSecurity+ID2,&AS))return DCT3->ReplySetSecurity		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x40",0x02,0x66,ID_GetIMEI+ID2    ,&AS))return DCT3->ReplyGetIMEI    		(msg,Debug,(unsigned char *)Struct);

if(Ans("\xD2",0x02,0x00,ID_GetID+ID3,      &AS))return DCT34->ReplyGetID 	 	(msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_ERR_FRAME_NOTREQUESTED;
        return GSM_ERR_FRAME_UNKNOWN;
}

GSM_Error GSM_Phone_N7110::GetIMEI(unsigned char *IMEI)
{
	return DCT3->GetIMEI(*Debug,(*Phones)->Current,IMEI);
}

GSM_Error GSM_Phone_N7110::GetCodeNameModel(unsigned char *Model)
{
	return DCT34->GetCodeNameModel(Model,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N7110::GetFirmwareVersion(unsigned char *Firm)
{
	return DCT34->GetFirmwareVersion(Firm,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N7110::GetManufacturer(unsigned char *Manufacturer)
{
	strcpy((char *)Manufacturer,"Nokia");
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N7110::ReplyGetPBKStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKStatus *Status = (GSM_PBKStatus *)S;

	(*Debug)->Deb("RECEIVED: PBK memory status\n");

	if (msg->Buffer.data()[10] == 0x10) {
		Status->Free = msg->Buffer.data()[14] * 256 + msg->Buffer.data()[15];
	} else {
		Status->Free = msg->Buffer.data()[18];
	}
	(*Debug)->Deb("Size - %i\n",Status->Free);

	Status->Used = msg->Buffer.data()[16] * 256 + msg->Buffer.data()[17];
	Status->Free -= Status->Used;
	(*Debug)->Deb("Used - %i\n",Status->Used);
	(*Debug)->Deb("Free - %i\n",Status->Free);

        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N7110::GetPBKMemoryStatus(GSM_PBKStatus *Status)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x03, 0x02, 0x00};

	Buff[5] = DCT34->Get7110DCT4MemoryType(Status->Memory);
	if (Buff[5] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: getting status for %s memory\n",Status->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKStatus+ID, Status);
}

GSM_Error GSM_Phone_N7110::Open(char *FrameID)
{
	GSM_Phone::Open(FrameID);

	if (FrameID[0] != 0) DCT34->SetFrameID(FrameID);

	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N7110::ReplyGetPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKEntry *Entry = (GSM_PBKEntry *)S;

	if (msg->Buffer.data()[6] == 0x0F) {
		(*Debug)->Deb("RECEIVED: error %i receiving PBK entry\n",0);
	        return GSM_ERR_UNKNOWN;
	}

	(*Debug)->Deb("RECEIVED: PBK entry received\n");
	DCT34->DecodePBKToEntry(*Debug, msg->Buffer.data()+17, Entry);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N7110::GetPBKMemory(GSM_PBKEntry *Entry)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x07, 0x01, 0x01, 0x00, 0x01, 0x02,
		0x00, 			// memory type
		0x00, 0x00, 		// memory location
		0x00, 0x00};

	Buff[9] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[9] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[10] = Entry->Location / 256;
	Buff[11] = Entry->Location % 256;

	(*Debug)->Deb("SENT: getting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N7110::SetPBKMemory(GSM_PBKEntry *Entry)
{
	unsignedstring 		Buffer, Buffer2;
	GSM_Error		error;
	int			Number;
	unsigned char		Buff[] = {
		NOKIA_FRAME1, 0x0b, 0x00, 0x01, 0x01, 0x00, 0x00, 0x0c, 0x00, 
		0x00,  			// memory type
		0x00, 0x00,  		// location
		0x00, 0x00, 0x00};

	Buff[11] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[11] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[12] = Entry->Location / 256;
	Buff[13] = Entry->Location % 256;

	error = DCT34->EncodeEntryToPBK(*Debug, &Buffer, Entry, &Number);
	if (error != GSM_ERR_NONE) return error;

	Buffer2.append((const unsigned char*)Buff,sizeof(Buff));
	Buffer2.push_back(Number);
	Buffer2.append((const unsigned char*)Buffer.data(),Buffer.size());

	(*Debug)->Deb("SENT: setting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write((unsigned char *)Buffer2.data(), Buffer2.size(), 0x03, 4, ID_SetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N7110::DeletePBKMemory(GSM_PBKEntry *Entry)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x0f, 0x00, 0x01, 0x04, 0x00, 0x00, 0x0c, 0x01, 0xff,
		0x00, 0x00,		// location
		0x00,			// memory type
		0x00, 0x00, 0x00};

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[12] = Entry->Location / 256;
	Buff[13] = Entry->Location % 256;

	Buff[14] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[14] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: deleting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_DelPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N7110::GetFirmwareDate(unsigned char *Dat)
{
	return DCT34->GetFirmwareDate(Dat,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N7110::GetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start)
{
	return DCT34->GetNextCalendar1((*Debug),(*Phones)->Current,Entry,start);
}

GSM_Error GSM_Phone_N7110::AddCalendar(GSM_CalendarEntry *Entry)
{
	GSM_Calendar_Type 	Type = Entry->Type;
	GSM_Error		error;

	if (Type == Calendar_Type_Reminder) Entry->Type = Calendar_Type_Meeting;
	error = DCT34->AddCalendar1((*Debug),(*Phones)->Current,Entry);
	Entry->Type = Type;
	return error;
}

GSM_Error GSM_Phone_N7110::DeleteCalendar(GSM_CalendarEntry *Entry)
{
	return DCT34->DeleteCalendar((*Debug),(*Phones),Entry);
}

GSM_Error GSM_Phone_N7110::GetDateTime(GSM_DateTime *DT)
{
	return DCT3->GetDateTime((*Debug),(*Phones)->Current,DT,0x19);
}
