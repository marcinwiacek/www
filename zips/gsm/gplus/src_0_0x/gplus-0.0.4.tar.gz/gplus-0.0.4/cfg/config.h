
#define VERSION "0.0.4"
#define VERSION_WIN "0,0,4,0"

#define BLUETOOTH_RF_SEARCHING 1
