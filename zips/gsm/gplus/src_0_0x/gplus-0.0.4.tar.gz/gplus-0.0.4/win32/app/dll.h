/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

typedef enum {
        /* Internal errors */
        GSM_ERR_NEWMESSAGE = 1,
        GSM_ERR_FRAME_NOTREQUESTED,
	GSM_ERR_FRAME_UNKNOWN,

	/* Device layer errors */
	GSM_ERR_DRIVERNOTAVAILABLE,

        /* Other errors returned to user */
	GSM_ERR_DEVICEWRITE,
	GSM_ERR_DEVICEREAD,
	GSM_ERR_DEVICEOPEN,
	GSM_ERR_DEVICECLOSE,
        GSM_ERR_NONE,
        GSM_ERR_UNKNOWN,
        GSM_ERR_SOURCENOTCOMPILED,
        GSM_ERR_UNKNOWNPROTOCOLSTRING,
        GSM_ERR_UNKNOWNPHONESTRING,
        GSM_ERR_OTHERPROTOCOL,
        GSM_ERR_TIMEOUT,
        GSM_ERR_EMPTY,
	GSM_ERR_NOTSUPPORTED,
	GSM_ERR_INVALIDLOCATION,
	GSM_ERR_INSIDEPHONEMENU
} GSM_Error;

typedef struct {
	unsigned char			Hour;
	unsigned char 			Minute;
	unsigned char			Second;

	unsigned char			Day;
	unsigned char			Month;		// January = 1
	unsigned int			Year;		// complete year
} GSM_DateTime;

#pragma comment(lib, "gplus.lib")

DECLSPEC_IMPORT void      FAR PASCAL GPlusGetGPlusVersion		(char *Version);
DECLSPEC_IMPORT void 	  FAR PASCAL GPlusGetNextSupportedPhoneInfo	(BOOLEAN start, char *Model, char *Protocol, char *CodeNameModel);
DECLSPEC_IMPORT char* 	  FAR PASCAL GPlusGetErrorInfo			(GSM_Error e);

DECLSPEC_IMPORT void 	  FAR PASCAL GPlusEnableDebug		(int numer, char *FileName);
DECLSPEC_IMPORT void 	  FAR PASCAL GPlusDisableDebug		(int numer);
DECLSPEC_IMPORT char* 	  FAR PASCAL GPlusGetPhoneModuleName	(int numer);
DECLSPEC_IMPORT void 	  FAR PASCAL GPlusSetUserReply		(int numer, GSM_Error (__stdcall *UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID));
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusWrite			(int numer, unsigned char *buffer,int length, unsigned char type, int time, int request, void *Struct);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusOpen			(int numer, char *device, char *connection, char *model);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusOpenFromFile		(int numer);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetIMEI 		(int numer, unsigned char *IMEI);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetModel		(int numer, unsigned char *Model);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetCodeNameModel	(int numer, unsigned char *Model);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetFirmwareVersion	(int numer, unsigned char *Firmware);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetFirmwareDate	(int numer, unsigned char *Date);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusClose			(int numer);

typedef struct {
	int 		Used;
	int 		Free;
	char 		Memory[3];
} GSM_PBKStatus;

DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetPBKMemoryStatus(int numer, GSM_PBKStatus *Status);

typedef enum {
	PBK_Not_Assigned = 1,

	PBK_Text_Phone_General,
	PBK_Text_Phone_Mobile,
	PBK_Text_Phone_Home,
	PBK_Text_Phone_Work,
	PBK_Text_Phone_Fax,
	PBK_Text_Email,
	PBK_Text_URL,
	PBK_Text_Postal,
	PBK_Text_UserID,
	PBK_Text_Note,
	PBK_Text_Name,

	PBK_DateTime_Call,
	PBK_ID_SMSList,
	PBK_ID_Picture,
	PBK_ID_VoiceTag,
	PBK_ID_RingtoneFile,
	PBK_ID_Ringtone,
	PBK_ID_SpeedDial
} GSM_PBK_SubEntryType;

typedef struct _GSM_PBKSubEntry2 GSM_PBKSubEntry2;

struct _GSM_PBKSubEntry2 {
	wchar_t		 	*Text;
	GSM_PBKSubEntry2 	*Next;
	GSM_PBK_SubEntryType	Type;
};

typedef struct {
	int 			Location;
	char 			Memory[3];
	GSM_PBKSubEntry2	*SubEntries;
} GSM_PBKEntry2;

DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetPBKMemory	 (int numer, GSM_PBKEntry2 *E);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusSetPBKMemory	 (int numer, GSM_PBKEntry2 *E);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusDeletePBKMemory(int numer, GSM_PBKEntry2 *E);
DECLSPEC_IMPORT void      FAR PASCAL GPlusCleanPBKEntry2 (GSM_PBKEntry2 *E);

typedef enum {
	Calendar_Not_Assigned = 1,

	Calendar_Text_Text,
	Calendar_Text_Location,
	Calendar_Text_Phone,

	Calendar_DateTime_Start,
	Calendar_DateTime_End,
	Calendar_DateTime_End_Repeat,
	Calendar_DateTime_ToneAlarm,
	Calendar_DateTime_SilentAlarm,

	Calendar_Int_Repeat_Frequency,
	Calendar_Int_Repeat_DayOfWeek,
	Calendar_Int_Repeat_Day,
	Calendar_Int_Repeat_Month
} GSM_Calendar_SubEntryType;

typedef enum {
	Calendar_Type_Not_Assigned = 1,

	Calendar_Type_Meeting,
	Calendar_Type_Memo,
	Calendar_Type_Call,
	Calendar_Type_Birthday,
	Calendar_Type_Reminder
} GSM_Calendar_Type;

typedef struct _GSM_CalSubEntry2 GSM_CalSubEntry2;

struct _GSM_CalSubEntry2 {
	wchar_t		 		*Text;
	GSM_DateTime			DT;
	int				IntValue;
	GSM_CalSubEntry2 		*Next;
	GSM_Calendar_SubEntryType       Type;
};

typedef struct {
	int				Location;
	GSM_Calendar_Type		Type;
	GSM_CalSubEntry2		*SubEntries;
} GSM_CalEntry2;

DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusGetNextCalendar	(int numer, GSM_CalEntry2 *E, BOOLEAN start);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusAddCalendar		(int numer, GSM_CalEntry2 *E);
DECLSPEC_IMPORT GSM_Error FAR PASCAL GPlusDeleteCalendar	(int numer, GSM_CalEntry2 *E);
DECLSPEC_IMPORT void      FAR PASCAL GPlusCleanCalendarEntry2	(GSM_CalEntry2 *E);
