/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#ifdef WIN32
#  include <windows.h>
#endif

#ifndef coding_h
#define coding_h

int 		UnicodeLength			(wchar_t *text);
unsigned int 	DecodeWithUnicodeAlphabet	(wchar_t src, char *dest);
char 		*DecodeUnicodeString 		(wchar_t *src);
wchar_t 	*EncodeUnicodeString		(char *src);
void 		EncodeUnicode			(char *src, wchar_t *dst);
void 		CopyUnicodeString		(wchar_t *dest, wchar_t *src);
unsigned char 	DecodeWithBCDAlphabet		(unsigned char value);
unsigned char 	EncodeWithBCDAlphabet		(unsigned char value);
void 		DecodeBCD 			(wchar_t *dest, const unsigned char *src, int len);
int 		EncodeBCD 			(unsigned char *dest, const unsigned char *src, int len);

#endif
