/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <stdio.h>
#include <wctype.h>

#include "../../../cfg/config.h" //msvc2005
#include "coding.h"

int UnicodeLength(wchar_t *text)
{
	int l = 0;

	while (text[l]!=0) l++;

	return l;
}

unsigned int DecodeWithUnicodeAlphabet(wchar_t src, char *dest)
{
	int r = wctomb(dest, src);

	if (r == -1) {
		r = 1;
		*dest = '?';
	}
	return r;
}

char *DecodeUnicodeString (wchar_t *src)
{
	int 		pos = 0, pos2 = 0;
	static char 	dst[1000];

	while (src[pos] != 0) {
		pos2+=DecodeWithUnicodeAlphabet(src[pos], dst+pos2);
		pos++;
	}
	dst[pos2] = 0;
	return dst;
}

wchar_t *EncodeUnicodeString(char *src)
{
	static 		wchar_t dst[500];
	int 		pos=0;

	while (src[pos] != 0) {
		mbtowc(&dst[pos], src+pos, MB_CUR_MAX);
		pos++;
	}
	dst[pos] = 0;
	return dst;
}

void EncodeUnicode(char *src, wchar_t *dst)
{
	int pos=0;

	while (src[pos] != 0) {
		mbtowc(&dst[pos], src+pos, MB_CUR_MAX);
		pos++;
	}
	dst[pos] = 0;
}

void CopyUnicodeString(wchar_t *dest, wchar_t *src)
{
	int pos = 0;

	while (src[pos] != 0x00) {
		dest[pos] = src[pos];
		pos++;
	}

	dest[pos] = 0;
}

unsigned char DecodeWithBCDAlphabet(unsigned char value)
{
        return 10*(value & 0x0f)+(value >> 4);
}

void DecodeBCD (wchar_t *dest, const unsigned char *src, int len)
{
        int i,current=0,digit;
	
	for (i = 0; i < len; i++) {
		digit=src[i] & 0x0f;
		if (digit<10) dest[current++]=digit + '0';
		digit=src[i] >> 4;
		if (digit<10) dest[current++]=digit + '0';
	}
	dest[current++]=0;
}

unsigned char EncodeWithBCDAlphabet(unsigned char value)
{
	div_t division;

	division=div(value,10);
	return (((value-division.quot*10) & 0x0f) << 4) | (division.quot & 0xf);
}

int EncodeBCD (unsigned char *dest, const unsigned char *src, int len)
{
	int i,current=0;

	for (i = 0; i < len; i++) {
        	if (i & 0x01) {
			dest[current]=dest[current] | ((src[i]-'0') << 4);
			current++;
		} else {
			dest[current]=src[i]-'0';
		}
	}
       	if (i & 0x01) {
		dest[current]=dest[current] | 0xf0;
	}
	return current+1;
}
