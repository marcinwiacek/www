/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../../gsmcomon.h"
#include "../../../device/gsmdev.h"
#include "../../gsmphone.h"
#include "../ndct34.h"

class GSM_Protocol;
class GSM_Protocol_Message;

typedef struct {
	int 			NoteID;
	GSM_Calendar_Type 	NoteType;
} GSM_Cal_Types;

class GSM_Phone_N6510:virtual public GSM_Phone
{
public:
        GSM_Phone_N6510(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("3100" , "RH-19"  ,  ""  		 ,"fbus", ""));
		Info.push_back(GSM_Phone_Info("3200" , "RH-30"  ,  ""  		 ,"fbus|irdaphonet", ""));//fixme
		Info.push_back(GSM_Phone_Info("3200" , "RH-31"  ,  ""  		 ,"fbus|irdaphonet", ""));//fixme
		Info.push_back(GSM_Phone_Info("3220" , "RH-37"  ,  ""  		 ,"fbus", ""));
		Info.push_back(GSM_Phone_Info("3220" , "RH-49"  ,  ""  		 ,"fbus", ""));
		Info.push_back(GSM_Phone_Info("3300" , "NEM-1"  ,  ""  		 ,"fbus", ""));
		Info.push_back(GSM_Phone_Info("3300" , "NEM-2"  ,  ""  		 ,"fbus", ""));
		Info.push_back(GSM_Phone_Info("3510" , "NHM-8"  ,  ""  		 ,"fbus", "-cal35-"));
		Info.push_back(GSM_Phone_Info("3510i", "RH-9"   ,  ""  		 ,"fbus", "-cal35-"));
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6"  ,  "Nokia 5100"  ,"fbus|irdaphonet|dku5fbus|dku5", ""));
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6U" ,  "Nokia 5100"  ,"fbus|irdaphonet|dku5fbus|dku5", ""));
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6X" ,  "Nokia 5100"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("5140" , "NPL-4"  ,  "Nokia 5140"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("5140" , "NPL-5"  ,  "Nokia 5140"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6170" , "RM-47"  ,  "Nokia 6170"  ,"fbus|irdaphonet|dku2phonet|dku2", ""));
		Info.push_back(GSM_Phone_Info("6220" , "RH-20"  ,  "Nokia 6220"  ,"fbus|irdaphonet|dku5fbus|dku5", ""));
		Info.push_back(GSM_Phone_Info("6230" , "RH-12"  ,  "Nokia 6230"  ,"fbus|irdaphonet|bluephonet|dku2phonet|dku2", ""));
		Info.push_back(GSM_Phone_Info("6230" , "RH-28"  ,  "Nokia 6230"  ,"fbus|irdaphonet|bluephonet|dku2phonet|dku2", ""));
		Info.push_back(GSM_Phone_Info("6230i", "RM-72"  ,  "Nokia 6230i" ,"fbus|irdaphonet|bluephonet|dku2phonet|dku2", ""));
		Info.push_back(GSM_Phone_Info("6310" , "NPE-4"  ,  "Nokia 6310"  ,"fbus|irdaphonet|bluephonet|dlr3fbus|dlr3", "-cal65-"));
		Info.push_back(GSM_Phone_Info("6310i", "NPL-1"  ,  "Nokia 6310i" ,"fbus|irdaphonet|bluephonet|dlr3fbus|dlr3", "-cal65-"));
		Info.push_back(GSM_Phone_Info("6510" , "NPM-9"  ,  "Nokia 6510"  ,"fbus|irdaphonet", "-cal65-"));
		Info.push_back(GSM_Phone_Info("6610" , "NHL-4U" ,  "Nokia 6610"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6610i", "RM-37"  ,  "Nokia 6610i" ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6650" , "NHM-1"  ,  "Nokia 6650"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6800" , "NHL-6"  ,  "Nokia 6800"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6800" , "NSB-9"  ,  "Nokia 6800"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6810" , "RM-2"   ,  "Nokia 6810"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("6820" , "NHL-9"  ,  "Nokia 6820"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7200" , "RH-23"  ,  "Nokia 7200"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7200" , "RH-33"  ,  "Nokia 7200"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7210" , "NHL-4"  ,  "Nokia 7210"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7250" , "NHL-4J" ,  "Nokia 7250"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7250i", "NHL-4JX",  "Nokia 7250i" ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7270" , "RM-8"   ,  "Nokia 7270"  ,"fbus|irdaphonet|dku2phonet|dku2", ""));
		Info.push_back(GSM_Phone_Info("7600" , "NMM-3"  ,  "Nokia 7600"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("8910" , "NHM-4"  ,  "Nokia 8910"  ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("8910i", "NHM-4NX",  "Nokia 8910i" ,"fbus|irdaphonet", ""));

		DCT34 = new GSM_Phone_NDCT34((*Phones)->GetID(),Deb,&(*Phones));

		ModuleName 	= "dct4tiku/n6510";
		ModulesUsed  	= "";
		ModulesRequired = "";

		for (int i=0;i<5;i++) {
			CalendarIcons[i].NoteType = Calendar_Type_Not_Assigned;
		}
        }
        ~GSM_Phone_N6510() {
		delete DCT34;
        }

	GSM_Error 	 Open			(char *FrameID);
        GSM_Error        Dispatch		(GSM_Protocol_Message *msg, void *Struct, int RequestID);

	GSM_Error	 GetManufacturer	(unsigned char *Manufacturer);
        GSM_Error        GetIMEI		(unsigned char *IMEI);
	GSM_Error 	 GetCodeNameModel	(unsigned char *Model);
	GSM_Error 	 GetFirmwareVersion	(unsigned char *Firm);
	GSM_Error 	 GetFirmwareDate	(unsigned char *Dat);
	GSM_Error 	 GetDateTime		(GSM_DateTime *DT);
	GSM_Error 	 GetPBKStatus		(GSM_PBKStatus *Status);
	GSM_Error 	 GetPBK			(GSM_PBKEntry *Entry);
	GSM_Error	 SetPBK			(GSM_PBKEntry *Entry);
	GSM_Error	 DeletePBK		(GSM_PBKEntry *Entry);
	GSM_Error 	 GetNextCalendar	(GSM_CalendarEntry *Entry, BOOLEAN start);
	GSM_Error 	 AddCalendar		(GSM_CalendarEntry *Entry);
	GSM_Error 	 DeleteCalendar		(GSM_CalendarEntry *Entry);
	GSM_Error 	 GetNextSMS		(GSM_SMSList *List, BOOLEAN start);
	GSM_Error 	 GetSMSStatus		(GSM_SMSStatus *Status);
	GSM_Error 	 GetSMSFolders		(GSM_SMSFolders *Folders);
	GSM_Error 	 GetSMSC		(GSM_SMSC *SMSC);
//	GSM_Error 	 AddSMS			(GSM_SMSList *List);
	GSM_Error 	 SetSMS			(GSM_SMSList *List);
	GSM_Error 	 SendSMS		(GSM_SMSEntry *SMS);
	GSM_Error 	 DeleteSMS		(GSM_SMSList *List);
private:
	GSM_Phone_NDCT34 *DCT34;
	int		 CurrentCalendarNumber;
	GSM_Cal_Loc	 CalendarLocations;
	GSM_Cal_Types	 CalendarIcons[5];	
	GSM_SMS_Loc	 SMSLocations;
	int		 SMSFoldersNum;

	GSM_Error 	 GetNextCalendar3	(GSM_CalendarEntry *Entry, BOOLEAN start);
	GSM_Error 	 GetCalendarInfo3	();
	GSM_Error 	 AddCalendar3		(GSM_CalendarEntry *Entry);
	GSM_Error 	 GetFirstCalendarPos3	(int *Location);
	GSM_Error	 FindCalendarNoteType3	(GSM_Calendar_Type NoteType, int *NoteID);
	GSM_Error 	 PrivGetCalendar3	(GSM_CalendarEntry *Entry);
	GSM_Error 	 GetSMSFolderStatus	(GSM_SMS_Loc *SMSLocations);
	void		 SetSMSLocation		(GSM_SMSList *sms, unsigned char folderid, int location);
	void 		 GetSMSLocation		(GSM_SMSList *sms, unsigned char *folderid, int *location);
	GSM_Error 	 GetSMS			(GSM_SMSList *List);
	GSM_Error 	 DecodeSMSFrame		(GSM_SMSEntry *SMS, const unsigned char *buffer, int len, GSM_DateTime *SaveDateTime);
	GSM_Error 	 EncodeSMSFrameToBuffer	(GSM_SMSEntry *SMS, unsignedstring *Buffer);

	GSM_Error 	 ReplyGetPBKStatus	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
        GSM_Error        ReplyGetIMEI		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);
	GSM_Error 	 ReplyGetPBK		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetNextCalendar3	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetCalendarInfo3	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetDateTime	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyAddCalendar3	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetFirstCalPos3   (GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetSMSStatus	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetSMS		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetSMSC		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetSMSFolders	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyGetSMSFolderStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplySetSMS		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplySendSMS		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	 ReplyDeleteSMS		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
};
