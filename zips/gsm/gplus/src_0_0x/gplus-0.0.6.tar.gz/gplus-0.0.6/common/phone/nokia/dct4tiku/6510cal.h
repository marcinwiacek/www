/* (C) 2005 by Marcin Wiacek www.mwiacek.com */
