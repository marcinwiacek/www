
typedef struct {
 	char		*Parameter;
 	int		MinArguments;
 	int		MaxArguments;
 	void		(*Function) (int argc, char *argv[]);
	char		*Help;
} CommandLineFunction;
