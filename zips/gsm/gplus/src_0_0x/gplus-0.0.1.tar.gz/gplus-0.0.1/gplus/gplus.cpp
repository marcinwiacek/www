
#include <stdio.h>
#include <stdarg.h>

#include "../common/gsmcomon.h"
#include "../common/misc/misc.h"
#include "../common/gsmstate.h"
#include "gplus.h"

DebugInfo *Debug = new DebugInfo(stdout);

void PrintError(GSM_Error error)
{
	if (error != GSM_ERR_NONE) {
		printf("%s",GSM_GetErrorInfo(error));
		exit(-1);
	}
}

void Identify(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(&Debug);
	unsigned char 		IMEI[20];
	unsigned char 		Model[50];
	unsigned char 		Firm[50];

        error = s.Open("com22:","fbus", "6310i");
	PrintError(error);

	error = s.Phones->Current->GetIMEI(IMEI);
	PrintError(error);
	printf("IMEI     : %s\n",IMEI);

	error = s.Phones->Current->GetModel(Model);
	PrintError(error);
	printf("Model    : %s",Model);
	error = s.Phones->Current->GetCodeNameModel(Model);
	PrintError(error);
	printf(" (%s)",Model);
	printf("\n");

	error = s.Phones->Current->GetFirmware(Firm);
	PrintError(error);
	printf("Firmware : %s\n",Firm);
}

void Modules(int argc, char *argv[])
{
	list<GSM_Device_Info>::iterator 	devinfo;
	list<GSM_Protocol_Info>::iterator 	proinfo;
	list<GSM_Phone_Info>::iterator 		phoinfo;
        GSM_Device              		*dev;
        GSM_Protocol            		*pro;
        GSM_Phone               		*pho;
        GSM_StateMachine 			s(&Debug);

        printf("Available device modules\n");
        dev = NULL;
        while(1) {
                if (!s.Devices->GetNext(&dev)) break;
		for (devinfo=dev->Info.begin(); devinfo!=dev->Info.end(); ++devinfo) {
                        printf("  \"%s\"\n",devinfo->Device);
		}
        }

        printf("Available protocol modules\n");
        pro = NULL;
        while(1) {
                if (!s.Protocols->GetNext(&pro)) break;
		for (proinfo=pro->Info.begin(); proinfo!=pro->Info.end(); ++proinfo) {
                        printf("  \"%s\" dev \"%s\"\n",proinfo->Protocol,proinfo->Device);
	        }
        }

        printf("Available phone modules\n");
        pho = NULL;
        while(1) {
                if (!s.Phones->GetNext(&pho)) break;
		for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
                        printf("  \"%s\" prot \"%s\" cname \"%s\" devname \"%s\" feat \"%s\"\n",
                                phoinfo->Model,phoinfo->Protocol, phoinfo->CodeNameModel, 
                                phoinfo->DeviceModel, phoinfo->Features);
	        }
        }
}

static CommandLineFunction CommandLineFunctions[] = {
	"--identify",		0, 0, Identify,  "get phone identification",
	"--modules",		0, 0, Modules,   "display info about available modules",
	"",			0, 0, NULL,	 ""                
};

void help(int argc, char *argv[])
{
}

void main(int argc, char *argv[])
{
        int i=0,startarg=0;

	if (argc > 1 && !strcmp(argv[1],"nothing")) {
		Debug->DisableDeb();
		startarg++;
	}

	if (argc==1) return;

	while(1) {
		if (CommandLineFunctions[i].Parameter[0] == 0) break;
		if (!strcmp(argv[1+startarg],CommandLineFunctions[i].Parameter)) {
			if (argc-2-startarg < CommandLineFunctions[i].MinArguments) {
				printf("Give more arguments\n");
				return;
			}
			if (argc-2-startarg > CommandLineFunctions[i].MaxArguments) {
				printf("Too many arguments\n");
				return;
			}
			CommandLineFunctions[i].Function(argc-2-startarg,argv+2+startarg);
			return;
		}
		i++;
	}
}
