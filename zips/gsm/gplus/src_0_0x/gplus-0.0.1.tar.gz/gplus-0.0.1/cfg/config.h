
#define VERSION "0.0.1"
#define VERSION_WIN "0,0,1,0"
