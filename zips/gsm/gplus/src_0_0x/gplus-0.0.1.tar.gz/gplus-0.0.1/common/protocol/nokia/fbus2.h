
#include <stdio.h>

#include "../../gsmcomon.h"
#include "../../misc/misc.h"
#include "../gsmprot.h"

const unsigned char FBUS2_FRAME_ID 		= 0x1E;
const unsigned char FBUS2_DEVICE_PHONE		= 0x00;
const unsigned char FBUS2_DEVICE_PC		= 0x0C;
const unsigned char FBUS2_ACK_TYPE		= 0x7F;
const unsigned char FBUS2_MAX_TRANSMIT_LENGTH 	= 120;

class GSM_Protocol_FBUS2:virtual public GSM_Protocol
{
public:
        GSM_Protocol_FBUS2(GSM_Device **Dev, DebugInfo **Deb):GSM_Protocol(Dev,Deb) {
		Info.push_back(GSM_Protocol_Info("serial", "fbus", false));
		Pos 			= 0;
		SendSequenceByte 	= 0;
        }
        ~GSM_Protocol_FBUS2() {
        }

        GSM_Error Open		(char *Prot);
        GSM_Error Close		();
        GSM_Error Write		(unsigned char *buffer, int length, unsigned char type);
	GSM_Error Dispatch	(unsigned char *buffer, int length, int *position);
private:
	/* Sending */
	unsigned char		SendSequenceByte;

	/* Receiving */
	int			Pos;
	unsigned char		CheckSum[2];
	unsigned char		CurFramesLeft,PrevFramesLeft;
	unsigned char		CurSequenceByte,PrevSequenceByte;
        GSM_Protocol_Message    Msg;

	GSM_Error 		WriteSingle(unsigned char *buffer, int length, unsigned char type);
};
