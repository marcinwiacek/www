
#include <stdio.h>

#include "../../gsmcomon.h"
#include "../../misc/misc.h"
#include "../gsmprot.h"

const unsigned char PHONET_FRAME_ID 	= 0x14;
const unsigned char PHONET_DEVICE_PHONE	= 0x00;
const unsigned char PHONET_DEVICE_PC	= 0x0c;

class GSM_Protocol_PHONET:virtual public GSM_Protocol
{
public:
        GSM_Protocol_PHONET(GSM_Device **Dev, DebugInfo **Deb):GSM_Protocol(Dev,Deb) {
		Info.push_back(GSM_Protocol_Info("infrared", "phonetirda", true));
        }
        ~GSM_Protocol_PHONET() {
        }

        GSM_Error Open		(char *Prot);
        GSM_Error Close		();
        GSM_Error Write		(unsigned char *buffer, int length, unsigned char type);
	GSM_Error Dispatch	(unsigned char *buffer, int length, int *position);
};
