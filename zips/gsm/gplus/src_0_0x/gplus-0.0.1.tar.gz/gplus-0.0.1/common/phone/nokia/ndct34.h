
#include <stdio.h>

#include "../../gsmcomon.h"
#include "../../protocol/gsmprot.h"

#ifndef __ndct34
#define __ndct34

#define NOKIA_FRAME1 0x00, 0x01, 0x00

const int ID_GetIdentification = 10000;

class GSM_Phone_NDCT34
{
public:
	GSM_Phone_NDCT34();

	GSM_Error GetCodeNameModel	(unsigned char *Mod, DebugInfo *Debug, GSM_Phone *Pho);
	GSM_Error GetFirmware		(unsigned char *Firm, DebugInfo *Debug, GSM_Phone *Pho);

	GSM_Error ReplyGetIdentification(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident);
private:
	char	  *Identification;

	GSM_Error GetIdentification	(DebugInfo *Debug, GSM_Phone *Pho);
};

#endif
