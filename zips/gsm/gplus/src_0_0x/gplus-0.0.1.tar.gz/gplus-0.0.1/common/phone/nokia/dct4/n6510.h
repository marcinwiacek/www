
#include <stdio.h>

#include "../../../gsmcomon.h"
#include "../../../device/gsmdev.h"
#include "../../gsmphone.h"
#include "../ndct34.h"

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_N6510:virtual public GSM_Phone
{
public:
        GSM_Phone_N6510(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6" ,  "Nokia 5100"  ,"fbus|phonetirda", ""));
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6U",  "Nokia 5100"  ,"fbus|phonetirda", ""));
		Info.push_back(GSM_Phone_Info("5100" , "NPM-6X",  "Nokia 5100"  ,"fbus|phonetirda", ""));
		Info.push_back(GSM_Phone_Info("6310i", "NPL-1" ,  "Nokia 6310i" ,"fbus|phonetirda", ""));

		DCT34 = new(GSM_Phone_NDCT34);

		ModuleName 	= "n6510";
		ModulesUsed  	= "";
		ModulesRequired = "";
        }
        ~GSM_Phone_N6510() {
		delete DCT34;
        }

        GSM_Error       GetIMEI			(unsigned char *IMEI);
	GSM_Error 	GetCodeNameModel	(unsigned char *Model);
	GSM_Error 	GetFirmware		(unsigned char *Firm);
        GSM_Error       Dispatch		(GSM_Protocol_Message *msg, void *Struct, int RequestID);
private:
	GSM_Phone_NDCT34 *DCT34;

        GSM_Error       ReplyGetIMEI		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);
};
