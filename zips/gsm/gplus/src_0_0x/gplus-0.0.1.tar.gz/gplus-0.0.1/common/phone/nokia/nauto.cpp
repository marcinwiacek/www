
#include "../../protocol/gsmprot.h"
#include "nauto.h"

GSM_Error GSM_Phone_NAUTO::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
        return GSM_ERR_UNKNOWN;
}

//GSM_Error GSM_Phone_NAUTO::GetIMEI(unsigned char *IMEI)
//{
//	(*Debug)->Deb("Getting IMEI in NAUTO\n");
//        return GSM_ERR_NONE;
//}
