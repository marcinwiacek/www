
#include "../../../protocol/gsmprot.h"
#include "../ndct34.h"
#include "n6510.h"

GSM_Error GSM_Phone_N6510::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	bool FrameFound = false;

	if (Answer((unsigned char *)"\x1B",0x03,0x01,ID_GetIMEI, RequestID, &FrameFound))
		return ReplyGetIMEI(msg,Debug,(unsigned char *)Struct);

	if (Answer((unsigned char *)"\xD2",0x02,0x00,ID_GetIdentification, RequestID, &FrameFound))
		return DCT34->ReplyGetIdentification(msg,Debug,(unsigned char *)Struct);

	if (FrameFound) return GSM_ERR_FRAME_NOTREQUESTED;
        return GSM_ERR_FRAME_UNKNOWN;
}

GSM_Error GSM_Phone_N6510::ReplyGetIMEI(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI)
{
	memcpy(IMEI,msg->Buffer.data()+10, 16);
	(*Debug)->Deb("IMEI %s\n",IMEI);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::GetIMEI(unsigned char *IMEI)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x00, 0x41};

//	(*Phones)->Switch("auto","phonetirda");
//	(*Phones)->Current->GetIMEI(IMEI);
//	(*Phones)->Switch("6510","phonetirda");
//	(*Debug)->Deb("Getting IMEI2\n");

	(*Debug)->Deb("Getting IMEI\n");
	return Write(Buff, sizeof(Buff), 0x1B, 2, ID_GetIMEI, IMEI);
}

GSM_Error GSM_Phone_N6510::GetCodeNameModel(unsigned char *Model)
{
	return DCT34->GetCodeNameModel(Model,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6510::GetFirmware(unsigned char *Firm)
{
	return DCT34->GetFirmware(Firm,(*Debug),(*Phones)->Current);
}
