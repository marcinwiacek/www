
#include "../gsmphone.h"
#include "../../gsmcomon.h"
#include "ndct34.h"

GSM_Phone_NDCT34::GSM_Phone_NDCT34()
{
	Identification = NULL;
}

GSM_Error GSM_Phone_NDCT34::ReplyGetIdentification(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident)
{
	int i;

	for (i=0;i<msg->Length;i++) {
		if (msg->Buffer[i] == 0x00) {
			Ident[i] = 32;
		} else {
			Ident[i] = msg->Buffer[i];
		}
	}
	Ident[i] = 0x00;
	(*Debug)->Deb("RECEIVED: phone identification\n");
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::GetIdentification(DebugInfo *Debug, GSM_Phone *Pho)
{
	unsigned char 	Buff[] = {NOKIA_FRAME1, 0x03, 0x00};
	unsigned char	Id[200];
	GSM_Error	error;

	Debug->Deb("SENT: Get identification\n");
	error=Pho->Write(Buff, 5, 0xD1, 2, ID_GetIdentification, Id);
	if (error == GSM_ERR_NONE) {
		Identification = (char *)malloc(strlen((const char *)Id)+1);
		memcpy(Identification,(const char *)Id,strlen((const char *)Id)+1);
	}
	return error;
}

GSM_Error GSM_Phone_NDCT34::GetCodeNameModel(unsigned char *Mod, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=5,counter=0;

	if (Identification == NULL) {
		error = GetIdentification(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Mod[0] = 0x00;
	while(1) {
		if (Identification[i]==0x0a) {
			if (counter == 2) break;
			counter++;
		} else {
			if (counter == 2) {
				Mod[strlen((const char *)Mod)+1] = 0x00;
				Mod[strlen((const char *)Mod)]   = Identification[i];
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::GetFirmware(unsigned char *Firm, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=4,counter=0;

	if (Identification == NULL) {
		error = GetIdentification(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Firm[0] = 0x00;
	while(1) {
		if (Identification[i]==0x0a) {
			break;
		} else {
			Firm[strlen((const char *)Firm)+1] = 0x00;
			Firm[strlen((const char *)Firm)]   = Identification[i];
		}
		i++;
	}
	return GSM_ERR_NONE;
}
