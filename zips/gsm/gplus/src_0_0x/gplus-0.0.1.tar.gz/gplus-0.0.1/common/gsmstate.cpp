
#include <stdio.h>

#include "../cfg/config.h"
#include "gsmstate.h"

#ifdef WIN32
#  include "device/serial/ser_w32.h"
#endif
#include "device/irda/irda.h"

#include "protocol/nokia/fbus2.h"
#include "protocol/nokia/phonet.h"
#include "protocol/obex/obex.h"

#include "phone/nokia/dct4/n6510.h"
#include "phone/nokia/nauto.h"

GSM_StateMachine::GSM_StateMachine(DebugInfo **Deb)
{
        Debug           = Deb;
        Devices         = new GSM_AllDevices(Deb);
        Protocols       = new GSM_AllProtocols(Deb);
        Phones          = new GSM_AllPhones(Deb);

	(*Debug)->Deb("[GAMMU+    : %s built %s %s",VERSION,__TIME__,__DATE__);
	if (strlen(GetCompiler()) != 0) (*Debug)->Deb(" in %s]\n",GetCompiler());

	if (strlen(GetOS()) != 0) (*Debug)->Deb("[SYSTEM    : %s]\n",GetOS());

        Devices->Add(new GSM_Device_Serial(Deb));
        Devices->Add(new GSM_Device_Infrared(Deb));

        Protocols->Add(new GSM_Protocol_FBUS2(&(Devices->Current),Debug));
        Protocols->Add(new GSM_Protocol_PHONET(&(Devices->Current),Debug));
        Protocols->Add(new GSM_Protocol_OBEX(&(Devices->Current),Debug));

        Phones->Add(new GSM_Phone_N6510(Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_NAUTO(Debug,&(Devices->Current),&Protocols,&Phones));

	Phones->RemoveUnused();

	Protocols->RemoveUnused(Phones);

	Devices->RemoveUnused(Protocols,Phones);
}

GSM_StateMachine::~GSM_StateMachine()
{
	Close();

	delete(Phones);
	delete(Protocols);
	delete(Devices);
}

GSM_Error GSM_StateMachine::Close()
{
        GSM_Error error;

        if (Phones->Current != NULL) {
                error=Phones->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }

        if (Protocols->Current != NULL) {
                error=Protocols->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }

        if (Devices->Current != NULL) {
	        error=Devices->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }
        return GSM_ERR_NONE;
}

GSM_Error GSM_StateMachine::Open(char *Dev, char *Prot, char *Pho)
{
        GSM_Error       error;
        char            *DeviceName = NULL;
	unsigned char   Buff[100];

	(*Debug)->Deb("[STARTUP   : device \"%s\", protocol \"%s\", phone \"%s\"]\n",Dev,Prot,Pho);

        error=Devices->Switch(Prot,Protocols,Phones);
        if (error != GSM_ERR_NONE) return error;

        error=Protocols->Switch(Prot,Phones);
        if (error != GSM_ERR_NONE) return error;

        if (!Protocols->Current->Info.begin()->CanUseDeviceName) {
                error=Phones->Switch(Pho,Prot);
                if (error != GSM_ERR_NONE) return error;
        }

        error=Devices->Current->Open(Dev,Prot,Pho,&DeviceName,Phones);
        if (error != GSM_ERR_NONE) return error;

        error=Protocols->Current->Open(Prot);
        if (error != GSM_ERR_NONE) return error;

        if (Protocols->Current->Info.begin()->CanUseDeviceName) {
                error=Phones->SwitchToDeviceName(DeviceName,Prot);
                if (error != GSM_ERR_NONE) return error;
        }

        error=Phones->Current->Open();
        if (error != GSM_ERR_NONE) return error;

        error=Phones->Current->GetCodeNameModel(Buff);
        if (error != GSM_ERR_NONE) return error;

        return GSM_ERR_NONE;
}
