#include <string.h>
#include <windows.h>

#include "gsmdev.h"
#include "../protocol/gsmprot.h"

GSM_Device::GSM_Device(DebugInfo **Deb)
{
        Next            = NULL;
        Debug           = Deb;
	Opened		= false;
}

GSM_Device::~GSM_Device()
{
}

GSM_Error GSM_Device::SetParameters(int speed, int bits, bool parity, int stopbits)
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device::SetLines(bool dtr, bool rts)
{
        return GSM_ERR_NONE;
}

/* ------------------------------------------------------------------------- */

GSM_Device_Info::GSM_Device_Info(DebugInfo **Deb, char *Dev)
{
        Device  = Dev;
        Debug   = Deb;
}

GSM_Device_Info::~GSM_Device_Info()
{
}

/* ------------------------------------------------------------------------- */

GSM_AllDevices::GSM_AllDevices(DebugInfo **Deb)
{
        AllDevices      = NULL;
        Current         = NULL;
        Debug           = Deb;
}

int GSM_AllDevices::GetNext(GSM_Device **Dev)
{
        if ((*Dev) == NULL) {
                (*Dev) = AllDevices;
        } else {
                if ((*Dev)->Next == NULL) return 0;
                (*Dev) = ((*Dev)->Next);
        }
        return 1;
}

GSM_AllDevices::~GSM_AllDevices()
{
        GSM_Device *dev,*dev2;

        dev=AllDevices;
        while(1) {
                if (dev == NULL) break;
                dev2 = dev->Next;
                delete(dev);
                dev = dev2;
        }
}

void GSM_AllDevices::Add(GSM_Device *Device)
{
        GSM_Device *Dev;

        if (AllDevices == NULL) {
                AllDevices = Device;
        } else {
                Dev = AllDevices;
                while (Dev->Next != NULL) Dev = Dev->Next;
                Dev->Next = Device;
        }
}

GSM_Error GSM_AllDevices::RemoveUnused(GSM_AllProtocols *AllProt, GSM_AllPhones *AllPhon)
{
	return GSM_ERR_NONE;
}

GSM_Error GSM_AllDevices::Switch(char *Pro, GSM_AllProtocols *AllProt, GSM_AllPhones *AllPhon)
{
        GSM_Device              		*dev;
        GSM_Protocol            		*Prot = NULL;
        GSM_Error               		error;
	list<GSM_Device_Info>::iterator 	devinfo;

	(*Debug)->Deb("[STATE     : switching to device]\n");

        /* First search for protocol in protocols */
        error = AllProt->Find(Pro, &Prot, AllPhon);
        if (error != GSM_ERR_NONE) return error;

        /* Searching for device driver connected with protocol */
        dev=AllDevices;
        while(1) {
		for (devinfo=dev->Info.begin(); devinfo!=dev->Info.end(); ++devinfo) {
//			(*Debug)->Std("%s %s\n",Prot->Info->Device,devinfo->Device);
                        if (!strcmp(Prot->Info.begin()->Device,devinfo->Device)) {
                                if (Current != NULL) {
                                        //disable old device
                                }
                                Current = dev;
                                return GSM_ERR_NONE;
                        }			
		}
                if (dev->Next == NULL) break;
                dev = dev->Next;
        }

        /* No device driver. Not compiled ? */
        return GSM_ERR_SOURCENOTCOMPILED;
}

/* ------------------------------------------------------------------------- */

GSM_Error GSM_Socket::Init(DebugInfo **Deb)
{
	Debug = Deb;
#ifdef WIN32
        WSADATA WSAData;

        if (WSAStartup(MAKEWORD(1,1), &WSAData) != 0) {
	        Error("WSAStartup");
		return GSM_ERR_DRIVERNOTAVAILABLE;
        }

        if (LOBYTE(WSAData.wVersion) != 1 || HIBYTE(WSAData.wVersion) != 1) {
                WSACleanup();
		return GSM_ERR_DRIVERNOTAVAILABLE;
        }
#endif
	return GSM_ERR_NONE;
}

GSM_Error GSM_Socket::Write(SOCKET Device, const unsigned char *buf, int len)
{
	int SentAll = 0, Sent;
	
	while(1) {
		Sent = send(Device,(const char *)(buf+SentAll),len-SentAll,0);
		if (Sent == SOCKET_ERROR) {
		        Error("send");
			return GSM_ERR_DEVICEWRITE;
		}
		SentAll += Sent;
		if (SentAll = len) return GSM_ERR_NONE;
	}
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Socket::Read(SOCKET Device, unsigned char *buf, int *len)
{
	int Rec;

        Rec = recv(Device,(char *)(buf),*len,0);
	if (Rec == SOCKET_ERROR) {
		*len = 0;
	        Error("recv");
		return GSM_ERR_DEVICEREAD;
	}
	*len = Rec;
	return GSM_ERR_NONE;
}

GSM_Error GSM_Socket::Close(SOCKET Device)
{
        WSACleanup();

	if (closesocket(Device) == SOCKET_ERROR) {
	        Error("closesocket");
		return GSM_ERR_DEVICECLOSE;
	}

        return GSM_ERR_NONE;
}

void GSM_Socket::Error(char *Description)
{
	(*Debug)->Deb("SOCKET ERROR: %s");
}
