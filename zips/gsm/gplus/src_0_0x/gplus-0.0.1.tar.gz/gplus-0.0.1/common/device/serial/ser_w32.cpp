
#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <memory.h>

#include "ser_w32.h"

GSM_Error GSM_Device_Serial::Open(char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones)
{
        (*Debug)->Deb("[STATE     : opening device]\n");

	Device = CreateFile(Dev,GENERIC_READ | GENERIC_WRITE,
                     	    0,NULL,OPEN_EXISTING,0,NULL);
	if (Device == INVALID_HANDLE_VALUE) {
		(*Debug)->Error("CreateFile");
	        return GSM_ERR_DEVICEOPEN;
	}

        BackupDCB.DCBlength = sizeof(DCB);
	if (!GetCommState(Device, &BackupDCB)) {
		(*Debug)->Error("GetCommState");
	        return GSM_ERR_DEVICEOPEN;
	}
	memcpy(&CurrentDCB,&BackupDCB,sizeof(DCB));

	if (!SetCommMask(Device, EV_RXCHAR)) {
		(*Debug)->Error("SetCommMask");
	        return GSM_ERR_DEVICEOPEN;
	}

	if (!SetupComm(Device,5000,5000)) {
		(*Debug)->Error("SetupComm");
	        return GSM_ERR_DEVICEOPEN;
	}

        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Close()
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Read(unsigned char *buf, int *len)
{
	COMSTAT		Status;
	DWORD		ErrorCode;

	if (ClearCommError(Device, &ErrorCode, &Status)==0) {
		(*Debug)->Error("ClearCommError");
	        return GSM_ERR_DEVICEREAD;
	}
	*len = Status.cbInQue;

	if (*len <= 0) return GSM_ERR_NONE;

	if (!ReadFile(Device, buf, *len, (LPDWORD)len, NULL)) {
		(*Debug)->Error("ReadFile");
	        return GSM_ERR_DEVICEREAD;
	}
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Write(const unsigned char *buf, int len)
{
	int 	SentAll = 0;
	DWORD 	Sent;
	
	while(1) {
		if (!WriteFile(Device,buf+SentAll,len-SentAll,&Sent,NULL)) {
			(*Debug)->Error("WriteFile");
		        return GSM_ERR_DEVICEREAD;
		}
		SentAll += Sent;
		if (SentAll = len) return GSM_ERR_NONE;
	}
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Device_Serial::SetParameters(int speed, int bits, bool parity, int stopbits)
{
	CurrentDCB.BaudRate 	  = CBR_115200;//speed;
	CurrentDCB.ByteSize 	  = bits;
	if (parity) {
		CurrentDCB.Parity = ODDPARITY;
	} else {
		CurrentDCB.Parity = NOPARITY; 
	}
	CurrentDCB.StopBits 	  = ONESTOPBIT; //fixme

	/* No Xon/Xof flow control */
	CurrentDCB.fOutX 	  = false;
	CurrentDCB.fInX 	  = false;


	/* No hardware flow control */
	CurrentDCB.fOutxDsrFlow = 0;
	CurrentDCB.fOutxCtsFlow = 0;

	if (!SetCommState(Device, &CurrentDCB)) {
		(*Debug)->Error("SetCommState");
	        return GSM_ERR_DEVICEREAD; //aaa
	}

        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::SetLines(bool dtr, bool rts)
{
	CurrentDCB.fDtrControl = DTR_CONTROL_DISABLE;
	if (dtr) CurrentDCB.fDtrControl = DTR_CONTROL_ENABLE;

	CurrentDCB.fRtsControl  = RTS_CONTROL_DISABLE;
	if (rts) CurrentDCB.fRtsControl = RTS_CONTROL_ENABLE;

	if (!SetCommState(Device, &CurrentDCB)) {
		(*Debug)->Error("SetCommState");
	        return GSM_ERR_DEVICEREAD; //aaa
	}

        return GSM_ERR_NONE;
}
