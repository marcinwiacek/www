
/* wsock32.lib library required in Microsoft Visual C++ project */

#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <memory.h>

#include "irda.h"
#include "../../phone/gsmphone.h"

GSM_Error GSM_Device_Infrared::Open(char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones)
{
	GSM_Error			error;
        GSM_Phone               	*pho;
	list<GSM_Phone_Info>::iterator 	phoinfo;
	Irda_Info_List   		List;
	Irda_Socket 			Dest;
        bool				found = false;
	int 				i,j,l = sizeof(List);

        (*Debug)->Deb("[STATE     : opening device]\n");

	error = Sock->Init(Debug);
	if (error != GSM_ERR_NONE) return error;

	Device = socket(AF_IRDA, SOCK_STREAM, 0);
	if (Device == INVALID_SOCKET) {
		return GSM_ERR_DRIVERNOTAVAILABLE;
	}

	List.Number = 0;
	for (i=0;i<400;i++) {
		if (getsockopt(Device, SOL_IRLMP, IRLMP_ENUMDEVICES, (char *)&List, &l) == SOCKET_ERROR) {
		        Sock->Error("getsockopt");
			return GSM_ERR_DEVICEOPEN;
		}
		if (List.Number == 0) continue;

		for (j=0; j<(int)List.Number; j++) {
			(*Debug)->Deb("[DEVICE    : found \"%s\"]\n",List.Devices[j].Name);
		        pho = NULL;
		        while(1) {
		                if (!Phones->GetNext(&pho)) break;
				for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
					if (phoinfo->CompareProtocol(Prot) && !strcmp(List.Devices[j].Name,phoinfo->DeviceModel)) {
						if (Pho[0] == 0x00) found = true;
						if (Pho[0] != 0x00 && !strcmp(phoinfo->Model,Pho)) found = true;
					}
					if (found) break;
				}
				if (found) break;
		        }
			if (found) break;
		}
		if (found) break;
	        Sleep(20);
	}
	if (!found) return GSM_ERR_TIMEOUT;

	Dest.AddressFamily = AF_IRDA;
	memcpy(&Dest.Address[i],&List.Devices[j].RemoteAddress[i],4);

	strcpy(Dest.ServiceName,"IrDA:IrCOMM");
	if (!strcmp(Prot,"phonetirda")) strcpy(Dest.ServiceName, "Nokia:PhoNet");

	if (connect(Device, (struct sockaddr *) &Dest, sizeof(Dest)) == SOCKET_ERROR) {
	        Sock->Error("connect");
		return GSM_ERR_DEVICEOPEN;
	}

	*DeviceModel = (char *)malloc(strlen(List.Devices[j].Name)+1);
	strcpy(*DeviceModel,List.Devices[j].Name);

	Opened = true;

        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Infrared::Close()
{
        (*Debug)->Deb("[STATE     : closing device]\n");

	if (!Opened) return GSM_ERR_NONE;
	return Sock->Close(Device);
}

GSM_Error GSM_Device_Infrared::Read(unsigned char *buf, int *len)
{
	return Sock->Read(Device,buf,len);
}

GSM_Error GSM_Device_Infrared::Write(const unsigned char *buf, int len)
{
	return Sock->Write(Device,buf,len);
}
