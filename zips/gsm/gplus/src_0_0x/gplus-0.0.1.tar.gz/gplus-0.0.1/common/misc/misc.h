
#ifndef misc_h
#define misc_h

#include <string>

#include <stdio.h>

using namespace std;

class DebugInfo
{
public:
        DebugInfo			(FILE *deb_file);

	void 		DisableDeb	();
	void 		DumpDeb		(const unsigned char *buffer, int len);        
        void            Deb		(char *format, ...);
	void 		Error		(char *Description);
private:
	bool		UseDeb;
        FILE            *debfile;
};

char *GetCompiler	(void);
char *GetOS		(void);
char *OSErrorInfo	(void);

typedef basic_string<unsigned char> unsignedstring;

#endif
