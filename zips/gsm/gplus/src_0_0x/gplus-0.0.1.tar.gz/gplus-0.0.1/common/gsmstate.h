
#ifndef gsm_state_h
#define gsm_state_h

#include "misc/misc.h"
#include "device/gsmdev.h"
#include "phone/gsmphone.h"
#include "protocol/gsmprot.h"

class GSM_StateMachine
{
public:
        GSM_AllDevices          *Devices;
        GSM_AllProtocols        *Protocols;
        GSM_AllPhones           *Phones;

        GSM_StateMachine(DebugInfo **Deb);
        ~GSM_StateMachine();

        GSM_Error               Open            (char *Dev, char *Prot, char *Pho);
	GSM_Error		Close		();
private:
        DebugInfo           **Debug;
};

#endif
