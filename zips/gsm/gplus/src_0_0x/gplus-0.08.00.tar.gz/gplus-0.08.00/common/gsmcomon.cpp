/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

//#include <stdarg.h>

#include "../cfg/config.h"
#include "gsmcomon.h"
#include "misc/coding/coding.h"

typedef struct {
        GSM_Error_Code        ErrorNum;
        char                  *ErrorText;
} PrintErrorEntry;

char *GSM_GetErrorInfo(GSM_Error e)
{
        PrintErrorEntry PrintErrorEntries[] = {
		{GSM_ERR_DRIVER_NOT_AVAILABLE,		"Some required driver or operating system part not available."},
		{GSM_ERR_DEVICE_WRITE,			"Error writing device"},
		{GSM_ERR_DEVICE_READ,			"Error reading device"},
		{GSM_ERR_DEVICE_OPEN,			"Error opening device"},
		{GSM_ERR_DEVICE_CLOSE,			"Error closing device"},
                {GSM_ERR_NONE,                          "No error."},
                {GSM_ERR_UNKNOWN,                       "Unknown error. Please report."},
                {GSM_ERR_SOURCE_NOT_COMPILED,           "Some parts of source not compiled."},
                {GSM_ERR_PROTOCOL_STRING_UNKNOWN,       "Protocol specified in config is not known."},
                {GSM_ERR_PHONE_STRING_UNKNOWN,          "Phone model specified in config is not known."},
                {GSM_ERR_OTHER_PROTOCOL,                "Phone model specified in config works with others protocols only."},
		{GSM_ERR_TIMEOUT,			"No response in specified time."},
		{GSM_ERR_EMPTY,				"Empty"},
		{GSM_ERR_NOT_SUPPORTED,			"Not supported by phone"},
		{GSM_ERR_INSIDE_PHONE_MENU,		"Data are edited in phone menu. Leave it before editing from PC."},
		{GSM_ERR_NO_SIM,			"Function requires SIM card"},
		{GSM_ERR_GPLUS_NOT_SUPPORTED,		"Not supported by Gammu+"},
//	GSM_ERR_MEMORY,
//	GSM_ERR_FOLDER_PART,
		{GSM_ERR_FILE_CHECKSUM,			"File checksum error"},
		{GSM_ERR_MUST_BE_FILE,			"%s must be file, not folder"},
		{GSM_ERR_MUST_BE_FOLDER,		"%s must be folder, not file"},
		{GSM_ERR_FILE_EXIST,			"There is already file %s"},
		{GSM_ERR_FOLDER_EXIST,			"There is already folder %s"},
		{GSM_ERR_FOLDER_NOT_EMPTY,		"Folder %s is not empty"},
		{GSM_ERR_FILE_NOT_EXIST,		"File %s doesn't exist (folder with this name too)"},
		{GSM_ERR_FILE_FOLDER_NOT_EXIST,		"File and folder %s doesn't exist"},
		{GSM_ERR_FOLDER_NOT_EXIST,		"Folder %s doesn't exist (file with this name too)"},

                {GSM_ERR_NONE,                          ""}
        };
        char   		*def;
	static char 	buff[500];
        int    		i = 0;

        while (1) {
                if (PrintErrorEntries[i].ErrorText[0] == 0x00) {
			def = "Unknown error.";
		        return def;
		} else if (PrintErrorEntries[i].ErrorNum == e.Code) {
                        def = PrintErrorEntries[i].ErrorText;
			if (strstr(def,"%s")!=NULL) {
				sprintf(buff,def,UnicodeToStringReturn(e.Parameter.data()));
				return buff;
			} else {
				return def;
			}
                }
                i++;
        }
}

GSM_Error GSM_Return_Error(GSM_Error_Code Code) 
{
	GSM_Error error;

	error.Code=Code;
	return error;
}
