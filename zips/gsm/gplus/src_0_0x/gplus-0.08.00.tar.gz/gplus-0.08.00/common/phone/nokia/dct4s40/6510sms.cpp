/* (C) 2005-2006 by Marcin Wiacek www.mwiacek.com */

#include "../../../../cfg/config.h" //msvc2005
#include "../../../protocol/gsmprot.h"
#include "../../../misc/coding/coding.h"
#include "../ndct34.h"
#include "n6510.h"

GSM_Error GSM_Phone_N6510::ReplyGetSMSFolders(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_SMSFolders 		*Folders = (GSM_SMSFolders *)S;
	unsigned int		i, current = 6, num = 0;
	GSM_SMSFoldersSubEntry  *SubFolder;

	(*Debug)->Deb("RECEIVED: SMS folders\n");
	for (i=0;i<msg->Buffer.data()[5];i++) {
		while (true) {
			if (msg->Buffer.data()[current]   == msg->Buffer.data()[6] &&
			    msg->Buffer.data()[current+1] == msg->Buffer.data()[7]) break;
			if (current+4 > msg->Buffer.size()) return GSM_Return_Error(GSM_ERR_UNKNOWN);
			current++;
		}
		current+=4;
		switch (num) {
		case 0x00:
			Folders->Add(NokiaGetUnicodeString(msg->Buffer.data()+current),TRUE,MEM_SIM);
			num++;
			break;
		case 0x01:
			Folders->Add(NokiaGetUnicodeString(msg->Buffer.data()+current),FALSE,MEM_SIM);
			num++;
			SubFolder = NULL;
			Folders->GetNext(&SubFolder);
			Folders->Add(SubFolder->GetName(),TRUE,MEM_PHONE);
			num++;
			Folders->Add(NokiaGetUnicodeString(msg->Buffer.data()+current),FALSE,MEM_PHONE);
			num++;
			break;
		default:
			Folders->Add(NokiaGetUnicodeString(msg->Buffer.data()+current),FALSE,MEM_PHONE);
			num++;
		}
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_N6510::GetSMSFolders(GSM_SMSFolders *Folders)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x12, 0x00, 0x00};

	(*Debug)->Deb("SENT: getting SMS folders\n");
	return Write(Buff, sizeof(Buff), 0x14, 4, ID_GetSMSFolders+ID, Folders);
}

GSM_Error GSM_Phone_N6510::ReplyGetSMSC(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_SMSC 	*SMSC = (GSM_SMSC *)S;
	int		i, current = 14;
	wchar_t		Buff[50];
	GSM_Error	error;

	(*Debug)->Deb("RECEIVED: SMSC\n");

	switch (msg->Buffer.data()[4]) {
		case 0x00:	break;
		case 0x02:	return GSM_Return_Error(GSM_ERR_INVALID_LOCATION);
		default  :	return GSM_Return_Error(GSM_ERR_UNKNOWN);
	}

	switch (msg->Buffer.data()[10]) {
		case 0x00: SMSC->Format = SMS_Text; 	break;
		case 0x22: SMSC->Format = SMS_Fax; 	break;
		case 0x26: SMSC->Format = SMS_Pager;	break;
		case 0x32: SMSC->Format = SMS_Email;	break;
		default  : SMSC->Format = SMS_Text;
	}

	SMSC->RelativeValidity = msg->Buffer.data()[12];
	if (msg->Buffer.data()[12] == 0x00) SMSC->RelativeValidity = SMS_RelativeValidity_Max_Time;

	Buff[0] = 0;
	SMSC->SetDefaultNumber(Buff);
	SMSC->SetSMSCNumber(Buff);
	SMSC->SetName(Buff);

	for (i=0;i<msg->Buffer.data()[13];i++) {
		switch (msg->Buffer.data()[current]) {
		case 0x81:
			SMSC->SetName(NokiaGetUnicodeString(msg->Buffer.data()+current+4));
			(*Debug)->Deb("  Name %s\n",UnicodeToStringReturn(SMSC->GetName()));
			break;
		case 0x82:
			switch (msg->Buffer.data()[current+2]) {
			case 0x01:
				error = GSM_DecodeSMSNumber(Buff, msg->Buffer.data()+current+4, msg->Buffer.data()[current+3], TRUE);
				if (error.Code != GSM_ERR_NONE) return error;
				SMSC->SetDefaultNumber(Buff);
				(*Debug)->Deb("  Default number %s\n",UnicodeToStringReturn(SMSC->GetDefaultNumber()));
				break;
			case 0x02:
				error = GSM_DecodeSMSNumber(Buff, msg->Buffer.data()+current+4, msg->Buffer.data()[current+3], FALSE);
				if (error.Code != GSM_ERR_NONE) return error;
				SMSC->SetSMSCNumber(Buff);
				(*Debug)->Deb("  Number %s\n",UnicodeToStringReturn(SMSC->GetSMSCNumber()));
				break;
			default:
				(*Debug)->Deb("RECEIVED: unknown number\n");
				return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
			}
			break;
		default:
			(*Debug)->Deb("RECEIVED: unknown block\n");
			return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
		}
		current += msg->Buffer.data()[current+1];
	}

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_N6510::GetSMSC(GSM_SMSC *SMSC)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x14,
				0x00,			// location
				0x00};

	if (SMSC->Location == 0 || SMSC->Location > 255) {
		return GSM_Return_Error(GSM_ERR_INVALID_LOCATION);
	}
	
	Buff[4] = SMSC->Location;
	
	(*Debug)->Deb("SENT: getting SMSC\n");
	return Write(Buff, sizeof(Buff), 0x02, 4, ID_GetSMSC+ID, SMSC); 
}

GSM_Error GSM_Phone_N6510::ReplyGetSMSStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_SMSStatus *Status = (GSM_SMSStatus *)S;

	(*Debug)->Deb("RECEIVED: SMS status\n");

	switch (msg->Buffer.data()[3]) {
	case 0x09:
		(*Debug)->Deb("  Phone size   : %i\n",msg->Buffer.data()[10]*256+msg->Buffer.data()[11]);
		(*Debug)->Deb("  Phone used   : %i\n",msg->Buffer.data()[12]*256+msg->Buffer.data()[13]);
		(*Debug)->Deb("  Phone unRead : %i\n",msg->Buffer.data()[14]*256+msg->Buffer.data()[15]);
		(*Debug)->Deb("  SIM size   : %i\n",msg->Buffer.data()[22]*256+msg->Buffer.data()[23]);
		(*Debug)->Deb("  SIM used   : %i\n",msg->Buffer.data()[24]*256+msg->Buffer.data()[25]);
		(*Debug)->Deb("  SIM unRead : %i\n",msg->Buffer.data()[26]*256+msg->Buffer.data()[27]);

		if (Status->Memory==MEM_SIM) {
			Status->SMSUnRead = msg->Buffer.data()[26]*256+msg->Buffer.data()[27];
			Status->SMSFree   = msg->Buffer.data()[22]*256+msg->Buffer.data()[23]-(msg->Buffer.data()[24]*256+msg->Buffer.data()[25]);
			Status->SMSRead   = msg->Buffer.data()[22]*256+msg->Buffer.data()[23]-Status->SMSFree-Status->SMSUnRead;
		} else {
			Status->SMSUnRead = msg->Buffer.data()[14]*256+msg->Buffer.data()[15];
			Status->SMSFree   = msg->Buffer.data()[10]*256+msg->Buffer.data()[11]-(msg->Buffer.data()[12]*256+msg->Buffer.data()[13]);
			Status->SMSRead   = msg->Buffer.data()[10]*256+msg->Buffer.data()[11]-Status->SMSFree-Status->SMSUnRead;
		}
	
		return GSM_Return_Error(GSM_ERR_NONE);
	default:
	        return GSM_Return_Error(GSM_ERR_UNKNOWN);
	}
}

GSM_Error GSM_Phone_N6510::GetSMSStatus(GSM_SMSStatus *Status)
{
	GSM_Error	error;
	unsigned char 	Buff[] = {NOKIA_FRAME1, 0x08, 0x00, 0x00};
	GSM_SMS_Loc 	SMSLocations;

	if (Status->Memory!=MEM_SIM && Status->Memory!=MEM_PHONE) {
		return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	}

	(*Debug)->Deb("SENT: getting status for SMS\n");
	error = Write(Buff, sizeof(Buff), 0x14, 4, ID_GetSMSStatus+ID, Status);
	if (error.Code != GSM_ERR_NONE || Status->Memory==MEM_SIM) return error;

	//status of Templates folder
	SMSLocations.FolderID = 0x06;
	error = GetSMSFolderStatus(&SMSLocations);
	if (error.Code != GSM_ERR_NONE) return error;

	Status->SMSTemplates = SMSLocations.Locations.size();

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_N6510::ReplyGetSMSFolderStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	int		i, last = 0;
	GSM_SMS_Loc 	*SMSLocations = (GSM_SMS_Loc *)S;
	unsignedint	s2;

	(*Debug)->Deb("RECEIVED: SMS folder status received\n");

	(*Debug)->Deb("  locations ");
	for (i=0;i<msg->Buffer.data()[6]*256+msg->Buffer.data()[7];i++) {
		(*Debug)->Deb("%i ",msg->Buffer.data()[8+(i*2)]*256+msg->Buffer.data()[(i*2)+9]);
		if (msg->Buffer.data()[8+(i*2)]*256+msg->Buffer.data()[(i*2)+9] < last) {
			//pushing int on front
			s2.clear();
			SMSLocations->Locations.swap(s2);
			SMSLocations->Locations.push_back(msg->Buffer.data()[8+(i*2)]*256+msg->Buffer.data()[(i*2)+9]);
			SMSLocations->Locations.append(s2);
		} else {
			SMSLocations->Locations.push_back(msg->Buffer.data()[8+(i*2)]*256+msg->Buffer.data()[(i*2)+9]);
		}
		last = msg->Buffer.data()[8+(i*2)]*256+msg->Buffer.data()[(i*2)+9];
	}
	(*Debug)->Deb("\n");

	(*Debug)->Deb("  locations ");
	for (i=0;i<msg->Buffer.data()[6]*256+msg->Buffer.data()[7];i++) {
		(*Debug)->Deb("%i ",SMSLocations->Locations.data()[i]);
	}
	(*Debug)->Deb("\n");

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_N6510::GetSMSFolderStatus(GSM_SMS_Loc *SMSLocations)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x0C,
				0x01,		// 0x01=SIM, 0x02=ME
				0x00,		// folder ID
				0x0F, 0x55, 0x55, 0x55};

	switch (SMSLocations->FolderID) {
	case 0x01: // SIM Inbox
		Buff[5] = 0x02;
		break;
	case 0x02: // SIM Outbox
		Buff[5] = 0x03;
		break;
	default: // ME
		Buff[4] = 0x02;
		Buff[5] = SMSLocations->FolderID - 1;
	}

	(*Debug)->Deb("SENT: getting SMS folder status\n");
	return Write(Buff, sizeof(Buff), 0x14, 4, ID_GetSMSFolderStatus+ID, SMSLocations);
}

GSM_Error GSM_Phone_N6510::GetSMSLocation(GSM_SMSList *sms, unsigned char *folderid, int *location)
{
	int 		ifolderid,i,j;
	char 	buffer[20],chr;

//	memset(buffer,0,20);
//	for (i=0;i<18;i++) {
//		chr=sms->ID.data()[i];
//		if (chr=='\\') break;
//		if (chr==0x00) return GSM_Return_Error(GSM_ERR_UNKNOWN);
//		buffer[i] = chr;
//	}
//	*folderid = atoi(buffer);
//	memset(buffer,0,20);
//	for (j=0;j<18;j++) {
//		chr=sms->ID.data()[i+1+j];
//		if (chr==0) break;
//		buffer[i] = chr;
//	}
//	*location = atoi(buffer);
	
	/* simulate flat SMS memory */
	if (sms->Folder==0x00) {
		ifolderid = sms->Location / PHONE_MAXSMSINFOLDER;
		*folderid = ifolderid + 0x01;
		*location = sms->Location - ifolderid * PHONE_MAXSMSINFOLDER;
	} else {
		*folderid = sms->Folder;
		*location = sms->Location;
	}
	(*Debug)->Deb("SMS folder %i & location %i -> 6510 folder %i & location %i\n",
		sms->Folder,sms->Location,*folderid,*location);
	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_Phone_N6510::SetSMSLocation(GSM_SMSList *sms, unsigned char folderid, int location)
{
	sms->Folder	= 0;
	sms->Location	= (folderid - 0x01) * PHONE_MAXSMSINFOLDER + location;
	(*Debug)->Deb("6510 folder %i & location %i -> SMS folder %i & location %i\n",
		folderid,location,sms->Folder,sms->Location);
}

GSM_Error GSM_Phone_N6510::ReplyGetSMS(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_SMSList 	*List = (GSM_SMSList *)S;
	GSM_SMSEntry 	SMS;
	GSM_Error	error;

	switch (msg->Buffer.data()[3]) {
	case 0x03:
		(*Debug)->Deb("RECEIVED: SMS message\n");
		switch (msg->Buffer.data()[5]) {
			case  1 : List->Icon = SMS_Read;   break;
			case  3 : List->Icon = SMS_UnRead; break;
			case  5 : List->Icon = SMS_Sent;   break;
			case  7 : List->Icon = SMS_UnSent; break;
			default : return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
		}
		List->SaveDateTimeAvailable = FALSE;
		switch (msg->Buffer.data()[14]) {
		case 0x00:
		case 0x01:
		case 0x02:
			List->SaveDateTime.Year = 0;
			error = DecodeSMSFrame(&SMS,msg->Buffer.data()+16,msg->Buffer.size()-16,&List->SaveDateTime);
			if (error.Code == GSM_ERR_NONE) {
				if (List->SaveDateTime.Year != 0) List->SaveDateTimeAvailable = TRUE;
				List->ClearAll();
				List->Add(&SMS);
			}
			return error;
		case 0xA0: // Picture message
			List->ClearAll();
		        return GSM_Return_Error(GSM_ERR_NONE);
		}
		return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
	case 0x0F:
		(*Debug)->Deb("RECEIVED: name for SMS message\n");
		List->SetName(NokiaGetUnicodeString(msg->Buffer.data()+52));
	        return GSM_Return_Error(GSM_ERR_NONE);
	}
	return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
}

GSM_Error GSM_Phone_N6510::GetSMS(GSM_SMSList *List)
{
	GSM_Error		error;
	unsigned char		FolderID;
	int			Location;
	unsigned char 		Buff[] = {NOKIA_FRAME1, 0x02,
					  0x01,		// 0x01=SIM, 0x02=ME
					  0x00,		// folder ID
					  0x00, 0x00,	// location
					  0x01, 0x00};

	GetSMSLocation(List, &FolderID, &Location);

	switch (FolderID) {
	case 0x01: // SIM Inbox
		Buff[5] = 0x02;
		break;
	case 0x02: // SIM Outbox
		Buff[5] = 0x03;
		break;
	default: // ME
		Buff[4] = 0x02;
		Buff[5] = FolderID - 1;
	}

	Buff[6]=Location / 256;
	Buff[7]=Location % 256;

	(*Debug)->Deb("SENT: getting SMS message\n");
	error = Write(Buff, sizeof(Buff), 0x14, 4, ID_GetSMS+ID, List);
	if (error.Code!=GSM_ERR_NONE) return error;

	Buff[3] = 0x0e; Buff[8] = 0x55; Buff[9] = 0x55;
	(*Debug)->Deb("SENT: getting SMS message name\n");
	error = Write(Buff, sizeof(Buff), 0x14, 4, ID_GetSMS+ID, List);
	if (error.Code!=GSM_ERR_NONE) return error;

	SetSMSLocation(List, FolderID, Location);
	List->Folder = FolderID;
	List->Memory = MEM_PHONE;
	if (FolderID == 0x01 || FolderID == 0x02) List->Memory = MEM_SIM;
	return error;
}

GSM_Error GSM_Phone_N6510::GetNextSMS(GSM_SMSList *List, BOOLEAN start)
{
	unsigned char		folderid;
	int			location;
	GSM_Error		error;
	unsigned int		i;
	bool			findnextfolder = TRUE;
	GSM_SMSFolders 		Folders;
	GSM_SMSFoldersSubEntry  *SubEntry;

	if (start == TRUE) {
		folderid 	= 0x00;
		SMSFoldersNum 	= 0;
		SubEntry 	= NULL;
		error = GetSMSFolders(&Folders);
		if (error.Code!=GSM_ERR_NONE) return error;
		while (Folders.GetNext(&SubEntry) == TRUE) SMSFoldersNum++;
	} else {
		GetSMSLocation(List, &folderid, &location);
		for (i=0;i<SMSLocations.Locations.size();i++) {
			if (SMSLocations.Locations.data()[i]==location) break;
		}
		if (i<SMSLocations.Locations.size()-1) {
			location=SMSLocations.Locations.data()[i+1];
			findnextfolder=FALSE;
		}
	}
	if (findnextfolder==TRUE) {
		SMSLocations.Locations.clear();
		while (SMSLocations.Locations.size()==0) {
			folderid++;

			/* Too high folder number */
			if ((folderid-1)>=SMSFoldersNum) return GSM_Return_Error(GSM_ERR_EMPTY);

			/* Get next folder status */
			SMSLocations.FolderID = folderid;
			error = GetSMSFolderStatus(&SMSLocations);
			if (error.Code != GSM_ERR_NONE) return error;

			/* First location from this folder */
			location=SMSLocations.Locations.data()[0];
		}
	}
	SetSMSLocation(List, folderid, location);

	return GetSMS(List);
}

GSM_Error GSM_Phone_N6510::DecodeSMSFrame(GSM_SMSEntry *SMS, const unsigned char *buffer, int len, GSM_DateTime *SaveDateTime)
{
	int current,num,i;
	
	SMS->PhoneNumber.clear();
	SMS->SMSCNumber.clear();
	SMS->UserData.clear();

	SMS->firstbyte = buffer[0];

	switch (SMS->GetType()) {
	case SMS_Deliver:
		SMS->TPPID   = buffer[1];
		SMS->TPDCS   = buffer[2];
		memcpy(SMS->DateTime,buffer+3,7);
		current = 14;
		break;
	case SMS_Submit:
		SMS->TPMR    = buffer[1];
		SMS->TPPID   = buffer[2];
		SMS->TPDCS   = buffer[3];
		//no TPVP
		current = 6;
		break;
	case SMS_Report:
		SMS->TPMR     = buffer[1];
		SMS->TPStatus = buffer[2];
		memcpy(SMS->DateTime,buffer+3,7);
		memcpy(SMS->SMSCTime,buffer+10,7);
		current = 18;
	}

	num = buffer[current-1];
	for (i=0;i<num;i++) {
		switch (buffer[current]) {
		case 0x80:
			(*Debug)->Deb("SMS text\n");
			if (buffer[current + 2] > buffer[current + 3]) {
				SMS->TPUDL = buffer[current+2];
			} else {
				SMS->TPUDL = buffer[current+3];
			}
			SMS->UserData.append(buffer+current+4,buffer[current+1]-4);
			break;
		case 0x82:
			switch (buffer[current+2]) {
			case 0x01:
				(*Debug)->Deb("phone number\n");
				SMS->PhoneNumber.append(buffer+current+4,buffer[current+4]+1);
				break;
			case 0x02:
				(*Debug)->Deb("SMSC number\n");
				SMS->SMSCNumber.append(buffer+current+4,buffer[current+4]+1);
				break;
			default:
				(*Debug)->Deb("unknown number\n");
				break;
			}
			break;
		case 0x84:
			(*Debug)->Deb("Date and time of saving for SMS template\n");
			if (SaveDateTime!=NULL) {
				if (SMS->PhoneNumber.size()>1 || SMS->SMSCNumber.size()>1) {
					SMS->SetType(SMS_Deliver);
					SMS->SetDateTime(NokiaGetDT(buffer+current+2));
				} else {
					memcpy(SaveDateTime,NokiaGetDT(buffer+current+2),sizeof(GSM_DateTime));
				}
			} else {
				return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			break;
		default:
			(*Debug)->Deb("unknown block\n");
		}
		current += buffer[current+1];
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_N6510::EncodeSMSFrameToBuffer(GSM_SMSEntry *SMS, unsignedstring *Buffer)
{
	unsignedstring 	Temp,Temp2;
	int 		num=0;
	unsigned char 	type,subtype;

	switch (SMS->GetType()) {
	case SMS_Deliver:
		Temp.push_back(SMS->TPPID);
		Temp.push_back(SMS->TPDCS);
		Temp.append(SMS->DateTime,7);
		Temp.push_back(0x55);
		Temp.push_back(0x55);
		Temp.push_back(0x55);
		Temp.push_back(0x03);//blocks number
		break;
	case SMS_Submit:
		Temp.push_back(SMS->TPMR);
		Temp.push_back(SMS->TPPID);
		Temp.push_back(SMS->TPDCS);
		Temp.push_back(0x00);
		Temp.push_back(0x04);//blocks number
		break;
	case SMS_Report:
		return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	}

	//phone numbers, validity
	while (true) {
		Temp2.clear();
		switch (num) {
		case 0x01:
			type = 0x82;
			subtype = 0x02;
			Temp2.push_back(SMS->SMSCNumber.size());
			Temp2.append(SMS->SMSCNumber.data(),SMS->SMSCNumber.size());
			break;
		case 0x00:
			type = 0x82;
			subtype = 0x01;
			Temp2.push_back(SMS->PhoneNumber.size());
			Temp2.append(SMS->PhoneNumber.data(),SMS->PhoneNumber.size());
			break;
		case 0x02:
			if (SMS->GetType()==SMS_Submit) {
				type = 0x08;
				subtype = 0x01;
				Temp2.push_back(SMS->TPVP);
			}
		}
		if (Temp2.size()!=0) {
			Temp.push_back(type);
			Temp.push_back(Temp2.size()+3);
			Temp.push_back(subtype);
			Temp.append(Temp2.data(),Temp2.size());
		}
		if (num == 0x02) break;
		num++;
	}

	//text
	Temp2.clear();
	Temp2.push_back(SMS->UserData.size());
	Temp2.push_back(SMS->TPUDL);
	Temp2.append(SMS->UserData.data(),SMS->UserData.size());
	Temp.push_back(0x80);
	Temp.push_back(Temp2.size()+4);
	Temp.append(Temp2.data(),Temp2.size());

	Buffer->push_back(0x01);
	switch (SMS->GetType()) {
		case SMS_Deliver: Buffer->push_back(0x00); break;
		case SMS_Submit : Buffer->push_back(0x02); break;
		case SMS_Report : 			   break;
	}
	Buffer->push_back(Temp.size()+3);
	Buffer->push_back(SMS->firstbyte);
	Buffer->append(Temp.data(),Temp.size());

	return GSM_Return_Error(GSM_ERR_NONE);	
}

GSM_Error GSM_Phone_N6510::ReplySetSMS(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	unsigned char 		folder;
	GSM_SMSList 		*List = (GSM_SMSList *)S;

	switch (msg->Buffer.data()[3]) {
	case 0x01:
		if (msg->Buffer.data()[4]!=0x00) return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);

		folder = msg->Buffer.data()[8] + 1;
		List->Memory = MEM_PHONE;
		//inbox,outbox
		if (msg->Buffer.data()[8] == 0x02 || msg->Buffer.data()[8] == 0x03) {
			if (msg->Buffer.data()[5] == 0x01) {
				folder = msg->Buffer.data()[8] - 1;
				List->Memory = MEM_SIM;
			}
		}
		SetSMSLocation(List, folder, msg->Buffer.data()[6]*256+msg->Buffer.data()[7]);
		List->Folder = folder;
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	return GSM_Return_Error(GSM_ERR_FRAME_CONTENT_UNKNOWN);
}

GSM_Error GSM_Phone_N6510::SetSMS(GSM_SMSList *List)
{
	GSM_Error 		error;
	unsignedstring  	Buffer;
	GSM_SMSListSubEntry 	*SMS = NULL;
	BOOLEAN 		result;
	unsigned char		FolderID, FolderID2;
	int			Location;

	//1 sms only
	result = List->GetNext(&SMS);
	if (result == FALSE) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	if (SMS->GetSMS()->GetType()==SMS_Report) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	Buffer.push_back(0x00);
	Buffer.push_back(0x01);
	Buffer.push_back(0x00);
	Buffer.push_back(0x00);

	GetSMSLocation(List, &FolderID, &Location);
	switch (FolderID) {
	case 0x01: // SIM Inbox
	case 0x02: // SIM Outbox
		Buffer.push_back(0x01); //SIM
		Buffer.push_back(FolderID + 1); //folder ID
		break;
	default:
		Buffer.push_back(0x02); //ME
		Buffer.push_back(FolderID - 1); //folder ID
	}
	Buffer.push_back(Location/256);
	Buffer.push_back(Location%256);

	switch (SMS->GetSMS()->GetType()) {
	case SMS_Deliver:
		switch (List->Icon) {
			case SMS_Sent	: // we use GSM_Read, because phone return error
			case SMS_Read	: Buffer.push_back(0x01); break;
			case SMS_UnSent	: // we use GSM_UnRead, because phone return error
			case SMS_UnRead	: Buffer.push_back(0x03); break;
		}
		break;
	case SMS_Submit:
		switch (List->Icon) {
			case SMS_Sent	: // we use GSM_Sent, because phone change folder
			case SMS_Read	: Buffer.push_back(0x05); break;
			case SMS_UnSent	: // we use GSM_UnSent, because phone change folder
			case SMS_UnRead	: Buffer.push_back(0x07); break;
		}
	default:
		break;
	}

	error = EncodeSMSFrameToBuffer(SMS->GetSMS(), &Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

	(*Debug)->Deb("SENT: Adding SMS\n");
	error = Write((unsigned char *)Buffer.data(), Buffer.size(), 0x14, 4, ID_SetSMS+ID,List);
	if (error.Code != GSM_ERR_NONE) return error;

	if (FolderID<3 || UnicodeLength(List->GetName()) == 0) return GSM_Return_Error(GSM_ERR_NONE);

	FolderID2 = List->Folder;
	List->Folder = 0;
	GetSMSLocation(List, &FolderID, &Location);
	List->Folder = FolderID2;

	Buffer.clear();
	Buffer.push_back(0x00);
	Buffer.push_back(0x01);
	Buffer.push_back(0x00);
	Buffer.push_back(0x16);
	switch (FolderID) {
	case 0x01: // SIM Inbox
	case 0x02: // SIM Outbox
		Buffer.push_back(0x01); //SIM
		Buffer.push_back(FolderID + 1); //folder ID
		break;
	default:
		Buffer.push_back(0x02); //ME
		Buffer.push_back(FolderID - 1); //folder ID
	}
	Buffer.push_back(Location/256);
	Buffer.push_back(Location%256);
	NokiaSetUnicodeString(List->GetName(),&Buffer);
	Buffer.push_back(0x00);
	Buffer.push_back(0x00);

	(*Debug)->Deb("SENT: Setting SMS name\n");
	return Write((unsigned char *)Buffer.data(), Buffer.size(), 0x14, 4, ID_SetSMSName+ID,List);
}

GSM_Error GSM_Phone_N6510::ReplySendSMS(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	switch (msg->Buffer.data()[8]) {
	case 0x00:
		if (SMSSendReply != NULL) SMSSendReply(msg->Buffer.data()[10]);
		return GSM_Return_Error(GSM_ERR_NONE);
	default:
		if (SMSSendReply != NULL) SMSSendReply(-1);
		return GSM_Return_Error(GSM_ERR_NONE);
	}
}

GSM_Error GSM_Phone_N6510::SendSMS(GSM_SMSEntry *SMS)
{
	GSM_Error 		error;
	unsignedstring  	Buffer;

	if (SMS->GetType()!=SMS_Submit) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	Buffer.push_back(0x00);
	Buffer.push_back(0x01);
	Buffer.push_back(0x00);
	Buffer.push_back(0x02);
	Buffer.push_back(0x00);
	Buffer.push_back(0x00);
	Buffer.push_back(0x00);
	Buffer.push_back(0x55);
	Buffer.push_back(0x55);

	error = EncodeSMSFrameToBuffer(SMS, &Buffer);
	if (error.Code != GSM_ERR_NONE) return error;

	(*Debug)->Deb("SENT: Sending SMS\n");
	return (*Protocols)->Current->Write((unsigned char *)Buffer.data(), Buffer.size(), 0x02);
}

GSM_Error GSM_Phone_N6510::ReplyDeleteSMS(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_SMSList *List = (GSM_SMSList *)S;

	switch (msg->Buffer.data()[3]) {
	case 0x05:
		(*Debug)->Deb("SMS deleted\n");
		return GSM_Return_Error(GSM_ERR_NONE);
	case 0x06:
		(*Debug)->Deb("SMS not deleted\n");
	}
	return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

GSM_Error GSM_Phone_N6510::DeleteSMS(GSM_SMSList *List)
{
	unsignedstring  	Buffer;
	GSM_SMSListSubEntry 	*SMS = NULL;
	unsigned char		FolderID;
	int			Location;

	Buffer.push_back(0x00);
	Buffer.push_back(0x01);
	Buffer.push_back(0x00);
	Buffer.push_back(0x04);

	GetSMSLocation(List, &FolderID, &Location);
	switch (FolderID) {
	case 0x01: // SIM Inbox
	case 0x02: // SIM Outbox
		Buffer.push_back(0x01); //SIM
		Buffer.push_back(FolderID + 1); //folder ID
		break;
	default:
		Buffer.push_back(0x02); //ME
		Buffer.push_back(FolderID - 1); //folder ID
	}
	Buffer.push_back(Location/256);
	Buffer.push_back(Location%256);

	Buffer.push_back(0x0F);
	Buffer.push_back(0x55);

	(*Debug)->Deb("SENT: deleting SMS\n");
	return Write((unsigned char *)Buffer.data(), Buffer.size(), 0x14, 4, ID_DelSMS+ID,List);
}
