/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

typedef struct {
 	char		*Parameter;
 	int		MinArguments;
 	int		MaxArguments;
 	void		(*Function) (int argc, char *argv[]);
	char		*Params;
} CommandLineFunction;
