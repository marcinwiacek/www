/* (C) 2003 - 2006 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>
#include <stdarg.h>

#include "../cfg/config.h"
#include "../common/misc/cfg.h"
#include "../common/gsmcomon.h"
#include "../common/misc/misc.h"
#include "../common/gsmstate.h"
#include "../common/service/backup/gsmback.h"
#include "../common/misc/coding/coding.h"

#include "gplus.h"

FILE *DebFile = NULL;
bool UseDeb = false;

void PrintError(GSM_Error error)
{
	if (error.Code != GSM_ERR_NONE) {
		printf("%s",GSM_GetErrorInfo(error));
		exit(-1);
	}
}

#define DCT4GetUEM 50000

GSM_Error DCT4ReplyGetUEM(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID)
{
	// Struct is pointer to any structure given during frame sending
	char *Buf = (char *)Struct;

	//we must check Type of message
	//and how long it is
	if (MsgType == 0x1B && MsgLength > 4) {
		//message is enough long and now we check subtype
		if (MsgBuffer[3] == 0x08) {
			//if we didn't ask for it return error
			if (RequestID != DCT4GetUEM) return GSM_Return_Error(GSM_ERR_FRAME_NOT_REQUESTED);
			//we wanted it now and we fill our structure and return
			strcpy(Buf,(const char *)MsgBuffer+10);
			return GSM_Return_Error(GSM_ERR_NONE);
		}
	}

	//we must tell Gammu+, that we want to parse this frame by internal
	//module
	return GSM_Return_Error(GSM_ERR_FRAME_TYPE_UNKNOWN);
}

void Identify(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	unsigned char 		IMEI[20], Model[50], Model2[50], Firm[50], Man[50], Firm2[50];

	printf("Gammu+\n");
	printf("  Version      : %s",VERSION);
	printf(" built %s %s",__TIME__,__DATE__);
	if (strlen(GetCompiler()) != 0) printf(" using %s",GetCompiler());
	printf("\n");
	if (strlen(GetOS()) != 0) printf("  Run on       : %s\n",GetOS());
	
	error = s.OpenFromFile();
	PrintError(error);

	if (!strcmp(s.Protocols->CurrentName,"irdaphonet")) {
		printf("  Connection   : infrared (%s)",s.Protocols->CurrentName);
#ifndef WIN32
		printf(" on %s",s.Devices->CurrentName);
#endif
	} else if (!strcmp(s.Protocols->CurrentName,"bluephonet")) {
		printf("  Connection   : bluetooth (%s)",s.Protocols->CurrentName);
#ifndef WIN32
		printf(" on %s",s.Devices->CurrentName);
#endif
	} else {
		printf("  Connection   : %s",s.Protocols->CurrentName);
	}
	printf("\n  Phone module : %s\n",s.Phones->Current->ModuleName);

	printf("Phone\n");

	error = s.Phones->Current->GetIMEI(IMEI);
	PrintError(error);
	printf("  IMEI         : %s\n",IMEI);

	error = s.Phones->Current->GetManufacturer(Man);
	PrintError(error);
	error = s.Phones->Current->GetModel(Model);
	PrintError(error);
	error = s.Phones->Current->GetCodeNameModel(Model2);
	PrintError(error);
	printf("  Model        : %s %s (%s)\n",Man, Model, Model2);

	error = s.Phones->Current->GetFirmwareVersion(Firm);
	PrintError(error);
	printf("  Firmware     : %s",Firm);
	error = s.Phones->Current->GetFirmwareDate(Firm2);
	PrintError(error);
	printf(" (%s)\n",Firm2);

	if (!strcmp(s.Phones->Current->ModuleName,"dct4 (n6510)")) {
		//we set handler
		s.SetUserReply(DCT4ReplyGetUEM);
		error = s.Phones->Current->Write((unsigned char *)"\x00\x03\x02\x07\x00\x08",6, 0x1B, 4, DCT4GetUEM, Model);
		PrintError(error);
		s.SetUserReply(NULL);		
		printf("  UEM          : %s\n",Model);
	}
}

void Monitor(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_PBKStatus 		Status;

	error = s.OpenFromFile();
	PrintError(error);

	while (1) {
		Status.Memory=MEM_PHONE;
		error = s.Phones->Current->GetPBKStatus(&Status);
		if (error.Code != GSM_ERR_NOT_SUPPORTED) PrintError(error);

		Status.Memory=MEM_SIM;
		error = s.Phones->Current->GetPBKStatus(&Status);
		if (error.Code != GSM_ERR_NOT_SUPPORTED) PrintError(error);
	}
}

void Restore(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
        GSM_Error 		error;
	GSM_Backup		Backup;
	GSM_PBKStatus 		Status;
	GSM_Backup_PBKEntry	*PBKEntry;
	GSM_PBKEntry 		PBKEntry2;
	GSM_Backup_CalEntry	*CalEntry;
	GSM_CalendarEntry	CalEntry2;
	int			i;
	char			ch;

	error = Backup.ReadFromFile(argv[0]);
	PrintError(error);

	error = s.OpenFromFile();
	PrintError(error);

	Status.Memory=MEM_PHONE;
	error = s.Phones->Current->GetPBKStatus(&Status);
	if (error.Code != GSM_ERR_NONE) {
		PrintError(error);
	} else {
		printf("Do you want to restore phone phonebook ?");
		do {
		      ch = toupper(getc(stdin));
		} while(ch != 'Y' && ch != 'N');
		if (ch == 'Y') {
			PBKEntry2.Memory=MEM_PHONE;
			for(i=1;i<=Status.Used + Status.Free;i++) {
				PBKEntry = NULL;
				while (Backup.GetNext_ME_PBK(&PBKEntry)) {
					if (PBKEntry->GetEntry()->Location != i) continue;
					error = s.Phones->Current->SetPBK(PBKEntry->GetEntry());
					PrintError(error);
					break;
				}
				if (PBKEntry != NULL && PBKEntry->GetEntry()->Location == i) continue;
				PBKEntry2.Location = i;
				error = s.Phones->Current->DeletePBK(&PBKEntry2);
				PrintError(error);
			}
		}
	}

	printf("Do you want to restore phone calendar ?");
	do {
	      ch = toupper(getc(stdin));
	} while(ch != 'Y' && ch != 'N');
	if (ch == 'Y') {
		CalEntry = NULL;
		while (Backup.GetNext_Cal(&CalEntry)) {
			error = s.Phones->Current->AddCalendar(CalEntry->GetEntry());
			PrintError(error);
		}
	}
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
	switch (DayOfWeek(Year,Month,Day)) {
	case 1: return "Monday";
	case 2: return "Tuesday";
	case 3: return "Wednesday";
	case 4: return "Thursday";
	case 5: return "Friday";
	case 6: return "Saturday";
	case 7: return "Sunday";
	default:return "";
	}
}

void GetAllCalendar(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
        GSM_Error 		error;
	GSM_CalendarEntry 	Entry;
	GSM_CalendarSubEntry 	*SubEntry;
	BOOLEAN			start = TRUE;
	int			RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;

	error = s.OpenFromFile();
	PrintError(error);

	while (1) {
		error = s.Phones->Current->GetNextCalendar(&Entry,start);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		printf("\nNote type    : ");
		switch(Entry.Type) {
		case Calendar_Type_Meeting:
			printf("meeting\n");
			break;
		case Calendar_Type_Memo:
			printf("memo\n");
			break;
		case Calendar_Type_Call:
			printf("phone call\n");
			break;
		case Calendar_Type_Birthday:
			printf("birthday\n");
			break;
		case Calendar_Type_Reminder:
			printf("reminder\n");
			break;
		}

		RepeatEach 	= -1;
		RepeatDay 	= -1;
		RepeatMonth 	= -1;
		RepeatDOW 	= -1;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case Calendar_Text_Text:
				printf("Text         : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_Text_Phone:
				printf("Phone number : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_Text_Location:
				printf("Location     : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_DateTime_Start:
				printf("Start time   : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_DateTime_End:
				printf("End time     : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_DateTime_SilentAlarm:
			case Calendar_DateTime_ToneAlarm:
				if (SubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
					printf("Silent alarm : ");
				} else {
					printf("Tone alarm   : ");
				}
				if (Entry.Type == Calendar_Type_Birthday) {
					printf("%02i:%02i:%02i %02i-%02i in each year\n",
						SubEntry->GetDateTime()->Hour,
						SubEntry->GetDateTime()->Minute,
						SubEntry->GetDateTime()->Second,
						SubEntry->GetDateTime()->Day,
						SubEntry->GetDateTime()->Month);
				} else {
					printf("%02i:%02i:%02i %02i-%02i-%04i %s\n",
						SubEntry->GetDateTime()->Hour,
						SubEntry->GetDateTime()->Minute,
						SubEntry->GetDateTime()->Second,
						SubEntry->GetDateTime()->Day,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Year,
						DayOfWeekStr(
							SubEntry->GetDateTime()->Year,
							SubEntry->GetDateTime()->Month,
							SubEntry->GetDateTime()->Day));
				}
				break;
			case Calendar_DateTime_End_Repeat:
				printf("Repeat end   : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_Int_Repeat_Frequency:
				RepeatEach = SubEntry->GetInt();
				break;
			case Calendar_Int_Repeat_DayOfWeek:
				RepeatDOW = SubEntry->GetInt();
				break;			
			case Calendar_Int_Repeat_Day:
				RepeatDay = SubEntry->GetInt();
				break;
			case Calendar_Int_Repeat_Month:
				RepeatMonth = SubEntry->GetInt();
				break;
			}
		}

		if (RepeatEach != -1 || RepeatDOW != -1 ||
		    RepeatDay != -1 || RepeatMonth != -1) {
			printf("Repeat note  : ");
			if (RepeatEach == 1) printf("each ");
			if (RepeatEach == 2) printf("each second ");
			if (RepeatDOW != -1) {
				switch (RepeatDOW) {
					case 1: printf("Monday ");	break;
					case 2: printf("Tuesday ");	break;
					case 3: printf("Wednesday ");	break;
					case 4: printf("Thursday ");	break;
					case 5: printf("Friday ");	break;
					case 6: printf("Saturday ");	break;
					case 7: printf("Sunday ");	break;
					default:printf(" ");
				}
			}
			if (RepeatDay != -1) {
				printf("%i ",RepeatDay);
				if (RepeatMonth != -1) {
					switch (RepeatMonth) {
						case  1: printf("January ");	break;
						case  2: printf("February ");	break;
						case  3: printf("March ");	break;
						case  4: printf("April ");	break;
						case  5: printf("May ");	break;
						case  6: printf("June ");	break;
						case  7: printf("July ");	break;
						case  8: printf("August ");	break;
						case  9: printf("September ");	break;
						case 10: printf("October ");	break;
						case 11: printf("November ");	break;
						case 12: printf("December ");	break;
						default:printf(" ");
					}
				} else {
					printf("month day ");
				}
			}
			printf("\n");
		}

		start = FALSE;
	}
}

static void GetFileFolderInfo(GSM_StateMachine *s, BOOLEAN DetailsAvail, GSM_FileFolderInfo *FInfo, int Level)
{
	int 				i;
	GSM_FileFolderInfoList		List;
	GSM_FileFolderInfoListSubEntry  *SubEntry;
	GSM_Error			error;

	if (DetailsAvail == FALSE) {
		error = s->Phones->Current->GetFileFolderInfo(FInfo);
		PrintError(error);
	}

	if (FInfo->GetID()[0] == 'c' || FInfo->GetID()[0] == 'C') {
		printf("(%s)",UnicodeToStringReturn(FInfo->GetID()));
		for (i=UnicodeLength(FInfo->GetID());i<6;i++) printf(" ");
	}
	
	for (i=0;i<Level-1;i++) printf("|   ");
	if (Level!=0) printf("|---");

	if (FInfo->Folder == FALSE) {
		printf("%s\n",UnicodeToStringReturn(FInfo->GetName()));
		return;
	}
	List.Info.SetID(FInfo->GetID());

	error = s->Phones->Current->GetFolderInfoList(&List);
	if (error.Code == GSM_ERR_FOLDER_PART) {
		printf("part of ");
	} else {
		if (error.Code != GSM_ERR_EMPTY) PrintError(error);
	}
	if (Level!=0) {
		printf("folder");
	} else {
		printf("drive");
	}
	printf(" %s\n",UnicodeToStringReturn(FInfo->GetName()));
	if (error.Code == GSM_ERR_EMPTY) return;
	if (error.Code == GSM_ERR_MEMORY) {
		printf("(currently unavailable)\n");
		return;
	}

	SubEntry = NULL;
	while (List.GetNext(&SubEntry) == TRUE) {
	       	GetFileFolderInfo(s,List.SubEntryFullData,&SubEntry->Info,Level+1);
	}
}

void GetFileSystem(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_FileFolderInfo	Info;
	GSM_Error		error;
	BOOLEAN			Start = TRUE;
	wchar_t			name[20];

	error = s.OpenFromFile();
	PrintError(error);

	name[0] = 0;
	while (true) {
		error = s.Phones->Current->GetNextRootFolderID(name);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		Info.Folder = TRUE;
		Info.SetID(name);
		Info.SetName(name);
		GetFileFolderInfo(&s,TRUE,&Info,0);
	}
}

void GetFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_DateTime		DTStart,DTNow;
	time_t			t,told=0;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	File.Info.SetID(Buffer);

	printf("Reading file %s\n",argv[0]);

	GSM_GetCurrentDateTime(&DTStart);
	
	while(true) {
		error = s.Phones->Current->GetFilePart(&File);
		if (error.Code!=GSM_ERR_NONE) {
			printf("\n  ");
			PrintError(error);
		}

		GSM_GetCurrentDateTime(&DTNow);

		printf("%c  Read %03i percent - ",13,File.Buffer.size()*100/File.Info.Size);
		t=GSMDateTime2TimeT(&DTNow)-GSMDateTime2TimeT(&DTStart);
		printf("during %02i:",t/60);
		printf("%02i minutes",t%60);
		if (File.Info.Size != File.Buffer.size()) {
			t=t*(File.Info.Size-File.Buffer.size())/File.Buffer.size();
			if (told==0 || t<told) {
				printf(", %02i:",t/60);
				printf("%02i minutes left",t%60);
				told=t;
			}
		} else {
			printf("                      ");
		}

		if (File.Info.Size == File.Buffer.size()) break;
	}	

	printf("\n  Saving to %s",UnicodeToStringReturn(File.Info.GetName()));
	error = File.SaveToDisk(UnicodeToStringReturn(File.Info.GetName()));
	PrintError(error);
}

void AddOneFile(GSM_StateMachine *s, GSM_File *File)
{
	int 			Pos = 0;
	GSM_Error		error;
	unsignedstring		Buffer2;

//	printf("Adding file %s to folder %s\n",argv[1],argv[0]);

	while(1) {
		error = s->Phones->Current->AddFilePart(File,&Pos);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		printf("%c%s%03i percent",13,"  Writing: ",Pos*100/File->Info.Size);
	}	

	UnicodeToUTF8QuotedPrintable(File->Info.GetID(), &Buffer2);
	printf("%cFile ID is %s         \n",13,Buffer2.data());
}

void AddFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];

	error = File.ReadFromDisk(StringToUnicodeReturn(argv[1]));
	PrintError(error);

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	File.Info.SetID(Buffer);

	File.Info.SetName(StringToUnicodeReturn(argv[1]));

	File.Info.DRMForwardLock = FALSE;
	File.Info.ReadOnly	 = FALSE;
	File.Info.Hidden	 = FALSE;
	File.Info.System	 = FALSE;

	AddOneFile(&s, &File);	
}

void AddFolder(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	FInfo.SetID(Buffer);

	FInfo.SetName(StringToUnicodeReturn(argv[1]));

	error = s.Phones->Current->AddFolder(&FInfo);
	PrintError(error);
}

void DeleteFolder(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));

	error = s.Phones->Current->DeleteFolder(Buffer);
	PrintError(error);
}

void DeleteFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));

	error = s.Phones->Current->DeleteFile(Buffer);
	PrintError(error);
}

void GetSMSStatus(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_SMSStatus		Status;
	GSM_Error		error;

	error = s.OpenFromFile();
	PrintError(error);

	Status.Memory = MEM_SIM;
	error = s.Phones->Current->GetSMSStatus(&Status);
	PrintError(error);

	printf("SIM card : %i SMS read, %i SMS unread, %i SMS free\n",
		Status.SMSRead,Status.SMSUnRead,Status.SMSFree);

	Status.Memory = MEM_PHONE;
	error = s.Phones->Current->GetSMSStatus(&Status);
	if (error.Code == GSM_ERR_NOT_SUPPORTED) {
		printf("Phone memory : not supported\n");
	} else {
		PrintError(error);

		printf("Phone memory : %i SMS read, %i SMS unread, %i SMS free\n",
			Status.SMSRead,Status.SMSUnRead,Status.SMSFree);
	}
}

int SMSSendTPMR = -2;

void SMSSendReply(int TPMR)
{
	SMSSendTPMR = TPMR;
}

void SendSMS(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_SMSList		Entry;
	GSM_SMSEntry		SMS;
	GSM_Error		error;
	GSM_SMSC		SMSC;

	error = s.OpenFromFile();
	PrintError(error);

	SMSC.Location = 1;
	error = s.Phones->Current->GetSMSC(&SMSC);
	PrintError(error);

	SMS.SetType(SMS_Submit);
	SMS.SetCoding(SMS_Coding_Default_No_Compression);
	SMS.SetDecodedText(StringToUnicodeReturn(argv[1]));
	SMS.SetPhoneNumber(StringToUnicodeReturn(argv[0]));
	SMS.SetSMSCNumber(SMSC.GetSMSCNumber());

	//we set handler
	s.SetSMSSendReply(SMSSendReply);

	error = s.Phones->Current->SendSMS(&SMS);
	PrintError(error);

	while (true) {
#ifdef WIN32
		Sleep(5);
#else
		usleep(500);
#endif
		s.Phones->Current->Read(-1,NULL);

		if (SMSSendTPMR != -2) break;
	}

	if (SMSSendTPMR == -1) {
		printf("Sending error\n");
	} else {
		printf("Sent OK\n");
	}

	//we set handler
	s.SetSMSSendReply(NULL);
}

void AddSMS(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_SMSList		Entry;
	GSM_SMSEntry		SMS;
	GSM_Error		error;
	GSM_DateTime		DT;

	error = s.OpenFromFile();
	PrintError(error);

	SMS.SetType(SMS_Deliver);
//	SMS.SetCoding(SMS_Coding_Unicode_No_Compression);
	SMS.SetCoding(SMS_Coding_Default_No_Compression);
	SMS.SetDecodedText(StringToUnicodeReturn("bzyk"));
	SMS.SetPhoneNumber(StringToUnicodeReturn("+48601602602"));
	SMS.SetSMSCNumber(StringToUnicodeReturn("+48602602602"));

	DT.Year = 2000; DT.Month = 10; DT.Day = 2;
	DT.Hour=14; DT.Minute=5; DT.Second = 3;
	SMS.SetDateTime(&DT);
	
	Entry.Add(&SMS);
	Entry.Folder2=1;
	Entry.Icon = SMS_UnRead;
	Entry.SetName(StringToUnicodeReturn("cos"));

	error = s.Phones->Current->AddSMS(&Entry);
	PrintError(error);
}

void DeleteSMS(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_SMSList		Entry;
	GSM_Error		error;

	error = s.OpenFromFile();
	PrintError(error);

	Entry.ID2.append((const wchar_t *)StringToUnicodeReturn(argv[0]),strlen(argv[0]));

	error = s.Phones->Current->DeleteSMS(&Entry);
	PrintError(error);
}

void GetAllSMS(int argc, char *argv[])
{
	unsignedstring		Buffer2, UDH;
	wchar_t			Buffer[500];
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	GSM_SMSList		Entry;
	GSM_SMSListSubEntry	*SubEntry;
	GSM_SMSFolders		Folders;
	GSM_SMSFoldersSubEntry  *SubFolder;
	GSM_SMSEntry		*SMS;
	BOOLEAN 		start = TRUE;
	GSM_DateTime		DT;
	int			i, smsnum=0, smsparts=0;

	error = s.OpenFromFile();
	PrintError(error);

	while (true) {
		error = s.Phones->Current->GetNextSMS(&Entry,start);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		smsnum++;

		if (start == TRUE) {
			error = s.Phones->Current->GetSMSFolders(&Folders);
		    	PrintError(error);
		}
		
		start = FALSE;
		
		printf("Memory %s, ",GSM_GetMemoryName(Entry.Memory));
		SubFolder = NULL;
		for (i=0;i<Entry.Folder2;i++) Folders.GetNext(&SubFolder);
		printf("folder %s, ",UnicodeToStringReturn(SubFolder->GetName()));

		switch (Entry.Icon) {
			case SMS_Read	: printf("read"); 	break;
			case SMS_UnRead	: printf("unread"); 	break;
			case SMS_Sent	: printf("sent"); 	break;
			case SMS_UnSent	: printf("unsent"); 	break;
		}

		Buffer2.clear();
		UnicodeToUTF8QuotedPrintable((wchar_t *)Entry.ID2.data(), &Buffer2);
		printf(", ID \"%s\"",Buffer2.data());

		printf("\n");
		if (UnicodeLength(Entry.GetName())!=0) {
			printf("  Name %s\n",UnicodeToStringReturn(Entry.GetName()));
		}
		if (Entry.SaveDateTimeAvailable == TRUE) {
			printf("  Saved %02i:%02i:%02i %02i-%02i-%04i %s\n",
				Entry.SaveDateTime.Hour,
				Entry.SaveDateTime.Minute,
				Entry.SaveDateTime.Second,
				Entry.SaveDateTime.Day,
				Entry.SaveDateTime.Month,
				Entry.SaveDateTime.Year,
				DayOfWeekStr(
					Entry.SaveDateTime.Year,
					Entry.SaveDateTime.Month,
					Entry.SaveDateTime.Day));
		}

		SubEntry = NULL;
		while (Entry.GetNext(&SubEntry) == TRUE) {
			smsparts++;
			SMS = SubEntry->GetSMS();
			switch (SMS->GetType()) {
			case SMS_Deliver:
				printf("  SMS Deliver\n");
				error = SMS->GetSMSCNumber(Buffer);
			    	PrintError(error);
				printf("    SMSC Number \"%s\"\n",UnicodeToStringReturn(Buffer));
				SMS->GetDateTime(&DT);
				printf("    Sending date & time %02i:%02i:%02i %02i-%02i-%04i %s\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year,
					DayOfWeekStr(DT.Year,DT.Month,DT.Day));
				/* no break */
			case SMS_Submit:
				if (SMS->GetType() == SMS_Submit)   printf("    SMS Submit\n");
				error = SMS->GetPhoneNumber(Buffer);
		    		PrintError(error);
				if (UnicodeLength(Buffer)!=0) printf("    Phone Number \"%s\"\n",UnicodeToStringReturn(Buffer));
				if (SMS->GetClass() != -1) 	    printf("    SMS Class: %i\n",SMS->GetClass());
				if (SMS->SenderSMSCReply() == TRUE) printf("    SMSC reply: yes\n");

				error = SMS->GetUDH(&UDH);
				PrintError(error);
				if (UDH.size()!=0) printf("    UDH\n");

				switch (SMS->GetCoding()) {
	    			case SMS_Coding_Unicode_No_Compression:
					error = SMS->GetDecodedText(Buffer);
		    			PrintError(error);
					printf("    Unicode, no compression\n%s\n",UnicodeToStringReturn(Buffer));
					break;
		    		case SMS_Coding_Unicode_Compression:
					printf("    Unicode, compression\n");
					break;
				case SMS_Coding_Default_No_Compression:
					error = SMS->GetDecodedText(Buffer);
		    			PrintError(error);
					printf("    Default, no compression\n%s\n",UnicodeToStringReturn(Buffer));
					break;
				case SMS_Coding_Default_Compression:
					printf("    Default, compression\n");
					break;
				case SMS_Coding_8bit:
					printf("    8 bit\n");
					break;
				}
				break;
			case SMS_Report:
				printf("  SMS report\n");
				error = SMS->GetSMSCNumber(Buffer);
			    	PrintError(error);
				printf("    SMSC Number \"%s\"\n",UnicodeToStringReturn(Buffer));
				error = SMS->GetPhoneNumber(Buffer);
		    		PrintError(error);
				printf("    Phone Number \"%s\"\n",UnicodeToStringReturn(Buffer));
				SMS->GetDateTime(&DT);
				printf("    Sending date & time %02i:%02i:%02i %02i-%02i-%04i %s\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year,
					DayOfWeekStr(DT.Year,DT.Month,DT.Day));
				SMS->GetSMSCTime(&DT);
				printf("    Receiving date & time %02i:%02i:%02i %02i-%02i-%04i %s\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year,
					DayOfWeekStr(DT.Year,DT.Month,DT.Day));
				switch (SMS->GetReportStatus()) {
				case SMS_Status_Delivered:
					printf("Delivered - ");
					switch ((SMS->TPStatus & 0x7F)) {
					case 0x00:printf("SMS received by recipient\n");					break;
					case 0x01:printf("SMS forwarded to recipient by SMSC, SMSC can't confirm delivery\n");	break;
					case 0x02:printf("SMS replaced by SMSC\n");						break;
					}
					break;
				case SMS_Status_Unknown:
					printf("Unknown");
					if ((SMS->TPStatus & 0x80) == 0x80) break;
					if ((SMS->TPStatus & 0x7F)>=0x03 &&
					    (SMS->TPStatus & 0x7F)<=0x0F) {
						printf(" - error 'reserved' in specification\n");
					}
					if ((SMS->TPStatus & 0x7F)>=0x10 &&
					    (SMS->TPStatus & 0x7F)<=0x1F) {
						printf(" - error specific to SMSC\n");
					}
					break;					
				case SMS_Status_Pending:
					printf("Pending - temporary error, SMSC still trying to transfer SMS, ");
					switch ((SMS->TPStatus & 0x7F)) {
					case 0x20: printf("congestion\n");			break;
					case 0x21: printf("recipient busy\n");			break;
					case 0x22: printf("no response from recipient\n");	break;
					case 0x23: printf("service rejected\n");		break;
					case 0x24: printf("quality of service not available\n");break;
					case 0x25: printf("error in recipient\n");		break;
					}
					if ((SMS->TPStatus & 0x7F)>=0x26 &&
					    (SMS->TPStatus & 0x7F)<=0x2F) {
						printf("error 'reserved' in specification\n");
					}
					if ((SMS->TPStatus & 0x7F)>=0x30 &&
					    (SMS->TPStatus & 0x7F)<=0x3F) {
						printf("error specific to SMSC\n");
					}
					break;
				case SMS_Status_Failed:				
					printf("Failed - ");
					if ((SMS->TPStatus & 0x7F)>=0x40 &&
					    (SMS->TPStatus & 0x7F)<=0x5F) {
						printf("permanent error, no more SMS transfer attempts from SMSC, ");
						switch ((SMS->TPStatus & 0x7F)) {
					        case 0x40: printf("remote procedure error\n");			break;
					        case 0x41: printf("incompatibile destination\n");		break;
					        case 0x42: printf("connection rejected by recipient\n");	break;
					        case 0x43: printf("not obtainable\n");				break;
					        case 0x44: printf("quality of service not available\n");	break;
					        case 0x45: printf("no internetworking available\n");		break;
					        case 0x46: printf("SMS validity period expired\n");		break;
					        case 0x47: printf("SMS deleted by originating recipient\n");	break;
					        case 0x48: printf("SMS Deleted by SMSC administration\n");	break;
					        case 0x49: printf("SMS does not exist\n");			break;
						}
						if ((SMS->TPStatus & 0x7F)>=0x4A &&
						    (SMS->TPStatus & 0x7F)<=0x4F) {
							printf("error 'reserved' in specification\n");
						}
						if ((SMS->TPStatus & 0x7F)>=0x50 &&
						    (SMS->TPStatus & 0x7F)<=0x5F) {
							printf("error specific to SMSC\n");
						}
					}
					if ((SMS->TPStatus & 0x7F)>=0x60) {
						printf("temporary error, no more SMS transfer attempts from SMSC, ");
						switch ((SMS->TPStatus & 0x7F)) {
					        case 0x60: printf("congestion\n");			break;
					        case 0x61: printf("recipient busy\n");			break;
					        case 0x62: printf("no response from recipient\n");	break;
					        case 0x63: printf("service rejected\n");		break;
					        case 0x64: printf("quality of service not available\n");break;
					        case 0x65: printf("error in recipient\n");		break;
						}
						if ((SMS->TPStatus & 0x7F)>=0x66 &&
						    (SMS->TPStatus & 0x7F)<=0x6F) {
							printf("error 'reserved' in specification\n");
						}
						if ((SMS->TPStatus & 0x7F)>=0x70) {
							printf("error specific to SMSC\n");
						}
					}
				}
				break;
			}
		}		
	}

	printf("\n%i SMS sequences/%i SMS parts\n",smsnum,smsparts);
}

void GetSMSFolders(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	GSM_SMSFolders		Folders;
	GSM_SMSFoldersSubEntry  *SubEntry;
	int			i=1;
	
	error = s.OpenFromFile();
	PrintError(error);

	error = s.Phones->Current->GetSMSFolders(&Folders);
	PrintError(error);

	SubEntry = NULL;
	while (Folders.GetNext(&SubEntry) == TRUE) {
		printf("%i. %s - memory %s\n",i++,UnicodeToStringReturn(SubEntry->GetName()),GSM_GetMemoryName(SubEntry->Memory));
	}
}

void GetSMSC(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	GSM_SMSC		SMSC;
	
	error = s.OpenFromFile();
	PrintError(error);

	SMSC.Location = atoi(argv[0]);
	
	error = s.Phones->Current->GetSMSC(&SMSC);
	PrintError(error);

	printf("Name %s\n",UnicodeToStringReturn(SMSC.GetName()));
	printf("SMSC number %s\n",UnicodeToStringReturn(SMSC.GetSMSCNumber()));
	printf("Default recipient number %s\n",UnicodeToStringReturn(SMSC.GetDefaultNumber()));
	printf("Relative validity %02x\n",SMSC.RelativeValidity);
	
}

void GetDateTime(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
        GSM_Error 		error;
	GSM_DateTime		DT;

	error = s.OpenFromFile();
	PrintError(error);

	error = s.Phones->Current->GetDateTime(&DT);
	PrintError(error);

	printf("Date & time %02i:%02i:%02i %02i-%02i-%04i %s\n",
		DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year,
		DayOfWeekStr(DT.Year,DT.Month,DT.Day));
}

void GetMemory(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
        GSM_Error 		error;
	GSM_PBKEntry 		Entry;
	GSM_PBKSubEntry 	*SubEntry;
	int			Start, End, Tmp;

	Start = End = atoi(argv[1]);
	if (argc > 2) End = atoi(argv[2]);

	if (End < Start) {
		Tmp   = End;
		End   = Start;
		Start = Tmp;
		printf("Swapped last and first location\n");		
	}

	Entry.Memory = GSM_GetMemoryType(argv[0]);
	if (Entry.Memory == MEM_Unknown) {
		printf("Unknown memory type: %s\n",argv[0]);
		return;		
	}

	error = s.OpenFromFile();
	PrintError(error);

	for (Tmp = Start; Tmp <= End; Tmp++) {	
		Entry.ClearAll();

		Entry.Memory = GSM_GetMemoryType(argv[0]);
		Entry.Location = Tmp;

		error = s.Phones->Current->GetPBK(&Entry);
		PrintError(error);

		SubEntry = NULL;
		while (Entry.GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Phone_General:
				printf("General number \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Phone_Mobile:
				printf("Mobile number \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Phone_Home:
				printf("Home number \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Phone_Work:
				printf("Work number \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Phone_Fax:
				printf("Fax number \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Email:
				printf("Email \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_URL:
				printf("URL \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Postal:
				printf("Postal address \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_UserID:
				printf("User ID \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Note:
				printf("Text note \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_Text_Name:
				printf("Name \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case PBK_DateTime_Call:
				printf("Date & time %02i:%02i:%02i %02i-%02i-%04i\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year);
				break;
			}
		}
	}
}

void ClearAll(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
        GSM_Error 		error;
	GSM_CalendarEntry 	Entry;
	char			ch;

	error = s.OpenFromFile();
	PrintError(error);

	printf("Do you want to clear phone calendar ?");
	do {
	      ch = toupper(getc(stdin));
	} while(ch != 'Y' && ch != 'N');
	if (ch == 'Y') {
		while (1) {
			error = s.Phones->Current->GetNextCalendar(&Entry,TRUE);
			if (error.Code == GSM_ERR_EMPTY) break;
			PrintError(error);
	
			error = s.Phones->Current->DeleteCalendar(&Entry);
			PrintError(error);		
		}
	}
}

void Modules(int argc, char *argv[])
{
	list<GSM_Device_Info>::iterator 	devinfo;
	list<GSM_Protocol_Info>::iterator 	proinfo;
	list<GSM_Phone_Info>::iterator 		phoinfo;
        GSM_Device              		*dev;
        GSM_Protocol            		*pro;
        GSM_Phone               		*pho;
        GSM_StateMachine 			s(DebFile,"",UseDeb);

        printf("Available device modules\n");
        dev = NULL;
        while(1) {
                if (!s.Devices->GetNext(&dev)) break;
		for (devinfo=dev->Info.begin(); devinfo!=dev->Info.end(); ++devinfo) {
                        printf("  \"%s\"\n",(*devinfo).Device);
		}
        }

        printf("Available protocol modules\n");
        pro = NULL;
        while(1) {
                if (!s.Protocols->GetNext(&pro)) break;
		for (proinfo=pro->Info.begin(); proinfo!=pro->Info.end(); ++proinfo) {
                        printf("  \"%s\" dev \"%s\"\n",(*proinfo).Protocol,(*proinfo).Device);
	        }
        }

        printf("Available phone modules\n");
        pho = NULL;
        while(1) {
                if (!s.Phones->GetNext(&pho)) break;
	        printf("%s\n",pho->ModuleName);
		for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
                        printf("  \"%s\" prot \"%s\" cname \"%s\" devname \"%s\" feat \"%s\"\n",
                                (*phoinfo).Model,(*phoinfo).Protocol, (*phoinfo).CodeNameModel, 
                                (*phoinfo).DeviceModel, (*phoinfo).Features);
	        }
        }
}

void Help(int argc, char *argv[]);

static CommandLineFunction CommandLineFunctions[] = {
	"--identify",		0, 0, Identify,      "",
	"--modules",		0, 0, Modules,       "",
	"--help",		0, 0, Help,   	     "",
	"--monitor",		0, 0, Monitor, 	     "",
	"--getmemory",		2, 3, GetMemory,     "ME|SM location",
	"--restore",		1, 1, Restore,       "",
	"--getallcalendar",	0, 0, GetAllCalendar,"",
	"--getdatetime",	0, 0, GetDateTime,   "",
	"--clearall",		0, 0, ClearAll,	     "",
	"--getsmsstatus",	0, 0, GetSMSStatus,  "",
	"--getallsms",		0, 0, GetAllSMS,     "",
	"--getsmsfolders",	0, 0, GetSMSFolders, "",
	"--getsmsc",		1, 1, GetSMSC, 	     "",
	"--addsms",		0, 0, AddSMS, 	     "",
	"--sendsms",		2, 2, SendSMS, 	     "number text",
	"--deletesms",		2, 2, DeleteSMS,     "ID",
	"--getfilesystem",	0, 0, GetFileSystem, "",
	"--getfile",		1, 1, GetFile,       "fileID",
	"--addfile",		2, 2, AddFile,       "ParentFolderID FileName",
	"--addfolder",		2, 2, AddFolder,     "ParentFolderID Name",
	"--deletefolder",	1, 1, DeleteFolder,  "ID",
	"--deletefile",		1, 1, DeleteFile,    "ID",
	"",			0, 0, NULL,	     "",
};

void Help(int argc, char *argv[])
{
	int i = 0;

	while (CommandLineFunctions[i].Parameter[0] != 0) {
		printf("%s %s\n",CommandLineFunctions[i].Parameter,CommandLineFunctions[i].Params);
		i++;
	}
}

int main(int argc, char *argv[])
{
        int i=0,startarg=0;

#ifdef DEBUG
	UseDeb 	= true;
	DebFile = stdout;
#endif
	if (argc > 1 && StringCaseCmp(argv[1],"nothing",-1)) {
		UseDeb 	= false;
		DebFile = NULL;
		startarg++;
	} else if (argc > 1 && StringCaseCmp(argv[1],"textall",-1)) {
		UseDeb 	= true;
		DebFile = stdout;
		startarg++;
	}

	if (argc-startarg==1) {
		Help(argc-2-startarg,argv+2+startarg);
		return 0;
	}

	while(1) {
		if (CommandLineFunctions[i].Parameter[0] == 0) break;
		if (!StringCaseCmp(argv[1+startarg],CommandLineFunctions[i].Parameter,-1)) {
			i++;
			continue;
		}
		if (argc-2-startarg < CommandLineFunctions[i].MinArguments) {
			printf("Give more arguments (required ");
			if (CommandLineFunctions[i].MinArguments!=CommandLineFunctions[i].MaxArguments) {
				printf("%i to %i",
					CommandLineFunctions[i].MinArguments,
					CommandLineFunctions[i].MaxArguments);
			} else {
				printf("%i",CommandLineFunctions[i].MaxArguments);
			}
			if (CommandLineFunctions[i].Params[0]!=0) {
				printf(": %s",CommandLineFunctions[i].Params);
			}
			printf(")\n");
			return 0;
		}
		if (argc-2-startarg > CommandLineFunctions[i].MaxArguments) {
			printf("Too many arguments (required ");
			if (CommandLineFunctions[i].MinArguments!=CommandLineFunctions[i].MaxArguments) {
				printf("%i to %i",
					CommandLineFunctions[i].MinArguments,
					CommandLineFunctions[i].MaxArguments);
			} else {
				printf("%i",CommandLineFunctions[i].MaxArguments);
			}
			if (CommandLineFunctions[i].Params[0]!=0) {
				printf(": %s",CommandLineFunctions[i].Params);
			}
			printf(")\n");
			return 0;
		}
		CommandLineFunctions[i].Function(argc-2-startarg,argv+2+startarg);
		return 0;
	}

	Help(argc-2-startarg,argv+2+startarg);
}
