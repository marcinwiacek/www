/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <windows.h>

#include "../../cfg/config.h"
#include "../../common/gsmcomon.h"
#include "../../common/gsmstate.h"
#include "../../common/misc/misc.h"
#include "../../common/misc/coding/coding.h"
#include "../../common/service/gsmpbk.h"

	//FILE *f = fopen( "cos", "w" );
DebugInfo *Debug = new DebugInfo(stdout);

typedef struct {
	GSM_StateMachine 			*s;
	GSM_Phone 				*pho;
	list<GSM_Phone_Info>::iterator 		phoinfo;
} GSM_OnePhone;

GSM_OnePhone Phones[10];

GSM_Error WINAPI GPlusOpenFromFile(int numer)
{
	return Phones[numer].s->OpenFromFile();
}

GSM_Error WINAPI GPlusOpen(int numer, char *device, char *connection, char *model)
{
        return Phones[numer].s->Open(device,connection,model);
}

GSM_Error WINAPI GPlusGetIMEI(int numer, unsigned char *IMEI)
{
	return Phones[numer].s->Phones->Current->GetIMEI(IMEI);
}

GSM_Error WINAPI GPlusGetModel(int numer, unsigned char *Model)
{
	return Phones[numer].s->Phones->Current->GetModel(Model);
}

GSM_Error WINAPI GPlusGetCodeNameModel(int numer, unsigned char *Model)
{
	return Phones[numer].s->Phones->Current->GetCodeNameModel(Model);
}

GSM_Error WINAPI GPlusGetFirmware(int numer, unsigned char *Firmware)
{
	return Phones[numer].s->Phones->Current->GetFirmware(Firmware);
}

GSM_Error WINAPI GPlusClose(int numer)
{
	return Phones[numer].s->Phones->Current->Close();
}

GSM_Error WINAPI GPlusGetPBKMemoryStatus(int numer, GSM_PBKStatus *Status)
{
	return Phones[numer].s->Phones->Current->GetPBKMemoryStatus(Status);
}

void WINAPI GPlusGetGPlusVersion(char *Version)
{
	sprintf(Version,"%s",VERSION);
}

void WINAPI GPlusGetNextSupportedPhoneInfo(BOOLEAN start, char *Model, char *Protocol, char *CodeNameModel)
{
	Protocol[0] = 0;
	if (start) {
	        Phones[0].pho = NULL;
                if (!Phones[0].s->Phones->GetNext(&Phones[0].pho)) return;
		Phones[0].phoinfo=Phones[0].pho->Info.begin();
	} else {
		Phones[0].phoinfo++;
		if (Phones[0].phoinfo == Phones[0].pho->Info.end()) {
	                if (!Phones[0].s->Phones->GetNext(&Phones[0].pho)) return;
			Phones[0].phoinfo=Phones[0].pho->Info.begin();
		}
	}
	strcpy(Model,Phones[0].phoinfo->Model);
	strcpy(Protocol,Phones[0].phoinfo->Protocol);
	strcpy(CodeNameModel,Phones[0].phoinfo->CodeNameModel);
}

char* WINAPI GPlusGetErrorInfo(GSM_Error e)
{
	return GSM_GetErrorInfo(e);
}

typedef struct _GSM_PBKSubEntry2 GSM_PBKSubEntry2;

struct _GSM_PBKSubEntry2 {
	wchar_t		 	*Text;
	GSM_PBKSubEntry2 	*Next;
	GSM_PBK_SubEntryType	Type;
};

typedef struct {
	int 			Location;
	char 			Memory[3];
	GSM_PBKSubEntry2	*SubEntries;
} GSM_PBKEntry2;

GSM_Error WINAPI GPlusGetPBKMemory(int numer, GSM_PBKEntry2 *E)
{
	GSM_PBKEntry 		Entry;
	GSM_Error    		error;
	GSM_PBKSubEntry2	*Sub = NULL;
	GSM_PBKSubEntry		*SubEntry;
	int 			len;

	Entry.Location = E->Location;
	memcpy(Entry.Memory,E->Memory,3);

	error = Phones[numer].s->Phones->Current->GetPBKMemory(&Entry);

	if (error == GSM_ERR_NONE) {
		E->SubEntries 	= NULL;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry)) {
			if (Sub == NULL) {
				E->SubEntries = new GSM_PBKSubEntry2;
				Sub = E->SubEntries;
			} else {
				Sub->Next = new GSM_PBKSubEntry2;
				Sub = Sub->Next;
			}
			Sub->Type = SubEntry->GetType();
			if (SubEntry->GetText()!=NULL) {
				len = UnicodeLength(SubEntry->GetText())+1;
				Sub->Text = (wchar_t *)malloc(len*sizeof(wchar_t));
				CopyUnicodeString(Sub->Text,SubEntry->GetText());
			} else {
				Sub->Text = NULL;
			}
			Sub->Next = NULL;
		}		
	}

	return error;
}

void WINAPI GPlusCleanPBKEntry2(GSM_PBKEntry2 *E)
{
	GSM_PBKSubEntry2 *SubEntry;
	
	while (true) {
		if (E->SubEntries == NULL) break;
		if (E->SubEntries->Next == NULL) {
			delete(E->SubEntries);
			E->SubEntries = NULL;
			break;
		}
		SubEntry = E->SubEntries;
		while (true) {
			if (SubEntry->Next->Next == NULL) break;
			SubEntry = SubEntry->Next;
		}
		free(SubEntry->Next);
		SubEntry->Next = NULL;
	}
}

void WINAPI GPlusSetUserReply(int numer, GSM_Error (__cdecl *UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID))
{
	Phones[numer].s->SetUserReply(UsrReply);	
}

GSM_Error WINAPI GPlusWrite(int numer, unsigned char *buffer,int length, unsigned char type, int time, int request, void *Struct)
{
	return Phones[numer].s->Phones->Current->Write(buffer,length,type,time,request,Struct);
}

char* WINAPI GPlusGetPhoneModuleName(int numer)
{
	return Phones[numer].s->Phones->Current->ModuleName;
}

BOOL WINAPI DllMain (HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	int i;

	switch (ul_reason_for_call) {
		case DLL_PROCESS_ATTACH:
			for (i=0;i<10;i++) Phones[i].s = new GSM_StateMachine(&Debug);
	
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
//			fclose(f);
			break;
    	}
 	return TRUE;

}
