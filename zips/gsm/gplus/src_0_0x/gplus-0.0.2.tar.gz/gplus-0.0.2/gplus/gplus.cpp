/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>
#include <stdarg.h>

#include "../common/misc/cfg.h"
#include "../common/gsmcomon.h"
#include "../common/misc/misc.h"
#include "../common/gsmstate.h"
#include "../common/misc/coding/coding.h"

#include "gplus.h"

DebugInfo *Debug = new DebugInfo(stdout);

void PrintError(GSM_Error error)
{
	if (error != GSM_ERR_NONE) {
		printf("%s",GSM_GetErrorInfo(error));
		exit(-1);
	}
}

#define DCT4GetUEM 50000

GSM_Error DCT4ReplyGetUEM(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID)
{
	// Struct is pointer to any structure given during frame sending
	char *Buf = (char *)Struct;

	//we must check Type of message
	//and how long it is
	if (MsgType == 0x1B && MsgLength > 4) {
		//message is enough long and now we check subtype
		if (MsgBuffer[3] == 0x08) {
			//if we didn't ask for it return error
			if (RequestID != DCT4GetUEM) return GSM_ERR_FRAME_NOTREQUESTED;
			//we wanted it now and we fill our structure and return
			strcpy(Buf,(const char *)MsgBuffer+10);
			return GSM_ERR_NONE;
		}
	}

	//we must tell Gammu+, that we want to parse this frame by internal
	//module
	return GSM_ERR_FRAME_UNKNOWN;
}

void Identify(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(&Debug);
	unsigned char 		IMEI[20], Model[50], Model2[50], Firm[50], Man[50];

	error = s.OpenFromFile();
	PrintError(error);

	error = s.Phones->Current->GetIMEI(IMEI);
	PrintError(error);
	printf("IMEI     : %s\n",IMEI);

	error = s.Phones->Current->GetManufacturer(Man);
	PrintError(error);
	error = s.Phones->Current->GetModel(Model);
	PrintError(error);
	error = s.Phones->Current->GetCodeNameModel(Model2);
	PrintError(error);
	printf("Model    : %s %s (%s)\n",Man, Model, Model2);

	error = s.Phones->Current->GetFirmware(Firm);
	PrintError(error);
	printf("Firmware : %s\n",Firm);

	if (!strcmp(s.Phones->Current->ModuleName,"n6510")) {
		//we set handler
		s.SetUserReply(DCT4ReplyGetUEM);
		error = s.Phones->Current->Write((unsigned char *)"\x00\x03\x02\x07\x00\x08",6, 0x1B, 4, DCT4GetUEM, Model);
		PrintError(error);
		s.SetUserReply(NULL);		
		printf("UEM      : %s\n",Model);
	}
}

void GetPBKStatus(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(&Debug);
	GSM_PBKStatus 		Status;

	if (strlen(argv[0]) > 2) return;
	strcpy(Status.Memory,argv[0]);

	error = s.OpenFromFile();
	PrintError(error);

	error = s.Phones->Current->GetPBKMemoryStatus(&Status);
	PrintError(error);
}

void GetPBKEntry(int argc, char *argv[])
{
        GSM_Error 		error;
        GSM_StateMachine 	s(&Debug);
	GSM_PBKEntry 		Entry;
	GSM_PBKSubEntry 	*SubEntry;

	if (strlen(argv[0]) > 2) return;
	strcpy(Entry.Memory,argv[0]);

	Entry.Location = atoi(argv[1]);

	error = s.OpenFromFile();
	PrintError(error);

	error = s.Phones->Current->GetPBKMemory(&Entry);
	PrintError(error);

	SubEntry = NULL;
	while (Entry.GetNext(&SubEntry)) {
		switch (SubEntry->GetType()) {
		case PBK_Text_Phone_General:
			printf("General number \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Phone_Mobile:
			printf("Mobile number \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Phone_Home:
			printf("Home number \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Phone_Work:
			printf("Work number \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Phone_Fax:
			printf("Fax number \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Email:
			printf("Email \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_URL:
			printf("URL \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Postal:
			printf("Postal address \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_UserID:
			printf("User ID \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Note:
			printf("Text note \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_Text_Name:
			printf("Name \"%s\"\n",DecodeUnicodeString(SubEntry->GetText()));
			break;
		case PBK_DateTime_Call:
			break;
		}
	}
}

void Modules(int argc, char *argv[])
{
	list<GSM_Device_Info>::iterator 	devinfo;
	list<GSM_Protocol_Info>::iterator 	proinfo;
	list<GSM_Phone_Info>::iterator 		phoinfo;
        GSM_Device              		*dev;
        GSM_Protocol            		*pro;
        GSM_Phone               		*pho;
        GSM_StateMachine 			s(&Debug);

        printf("Available device modules\n");
        dev = NULL;
        while(1) {
                if (!s.Devices->GetNext(&dev)) break;
		for (devinfo=dev->Info.begin(); devinfo!=dev->Info.end(); ++devinfo) {
                        printf("  \"%s\"\n",devinfo->Device);
		}
        }

        printf("Available protocol modules\n");
        pro = NULL;
        while(1) {
                if (!s.Protocols->GetNext(&pro)) break;
		for (proinfo=pro->Info.begin(); proinfo!=pro->Info.end(); ++proinfo) {
                        printf("  \"%s\" dev \"%s\"\n",proinfo->Protocol,proinfo->Device);
	        }
        }

        printf("Available phone modules\n");
        pho = NULL;
        while(1) {
                if (!s.Phones->GetNext(&pho)) break;
		for (phoinfo=pho->Info.begin(); phoinfo!=pho->Info.end(); ++phoinfo) {
                        printf("  \"%s\" prot \"%s\" cname \"%s\" devname \"%s\" feat \"%s\"\n",
                                phoinfo->Model,phoinfo->Protocol, phoinfo->CodeNameModel, 
                                phoinfo->DeviceModel, phoinfo->Features);
	        }
        }
}

void Help(int argc, char *argv[]);

static CommandLineFunction CommandLineFunctions[] = {
	"--identify",		0, 0, Identify,     "get phone identification", "",
	"--modules",		0, 0, Modules,      "display info about available modules", "",
	"--help",		0, 0, Help,   	    "display this help", "",
	"--getpbkstatus",	1, 1, GetPBKStatus, "get phonebook status", "ME|SM",
	"--getpbkentry",	2, 2, GetPBKEntry,  "get phonebook entry", "ME|SM location",
	"",			0, 0, NULL,	    "", "",
};

void Help(int argc, char *argv[])
{
	int i = 0;

	while (CommandLineFunctions[i].Parameter[0] != 0) {
		printf("%s\n  %s %s\n",CommandLineFunctions[i].Help,CommandLineFunctions[i].Parameter,CommandLineFunctions[i].Params);
		i++;
	}
}

void main(int argc, char *argv[])
{
        int i=0,startarg=0;

	if (argc > 1 && !strcmp(argv[1],"nothing")) {
		Debug->DisableDeb();
		startarg++;
	}

	if (argc==1) {
		Help(argc-2-startarg,argv+2+startarg);
		return;
	}

	while(1) {
		if (CommandLineFunctions[i].Parameter[0] == 0) break;
		if (strcmp(argv[1+startarg],CommandLineFunctions[i].Parameter)) {
			i++;
			continue;
		}
		if (argc-2-startarg < CommandLineFunctions[i].MinArguments) {
			printf("Give more arguments\n");
			return;
		}
		if (argc-2-startarg > CommandLineFunctions[i].MaxArguments) {
			printf("Too many arguments\n");
			return;
		}
		CommandLineFunctions[i].Function(argc-2-startarg,argv+2+startarg);
		return;
	}

	Help(argc-2-startarg,argv+2+startarg);
}
