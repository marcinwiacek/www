/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#ifndef gsm_state_h
#define gsm_state_h

#include "misc/misc.h"
#include "device/gsmdev.h"
#include "phone/gsmphone.h"
#include "protocol/gsmprot.h"

class GSM_StateMachine
{
public:
        GSM_AllDevices          *Devices;
        GSM_AllProtocols        *Protocols;
        GSM_AllPhones           *Phones;

        GSM_StateMachine(DebugInfo **Deb);
        ~GSM_StateMachine();

        GSM_Error               Open            (char *Dev, char *Prot, char *Pho);
	GSM_Error 		OpenFromFile	();
	GSM_Error		Close		();
	void 			SetUserReply	(GSM_Error(*UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID));
private:
        DebugInfo           	**Debug;
};

#endif
