/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../cfg/config.h"
#include "gsmstate.h"
#include "misc/coding/coding.h"
#include "misc/cfg.h"

#ifdef WIN32
#  include "device/serial/ser_w32.h"
#  include "device/bluetoth/blue_w32.h"
#else
#  include "device/serial/ser_unx.h"
#endif
#include "device/irda/irda.h"

#include "protocol/nokia/fbus2.h"
#include "protocol/nokia/phonet.h"
#include "protocol/obex/obex.h"

#include "phone/nokia/dct3/n6110.h"
#include "phone/nokia/dct3/n7110.h"
#include "phone/nokia/dct4/n6510.h"
#include "phone/nokia/nauto.h"

GSM_StateMachine::GSM_StateMachine(DebugInfo **Deb)
{
	    Debug           = Deb;
        Devices         = new GSM_AllDevices(Deb);
        Protocols       = new GSM_AllProtocols(Deb);
        Phones          = new GSM_AllPhones(Deb);

	(*Debug)->Deb("[GAMMU+    : %s built %s %s",VERSION,__TIME__,__DATE__);
	if (strlen(GetCompiler()) != 0) {
		(*Debug)->Deb(" in %s]\n",GetCompiler());
	} else {
		(*Debug)->Deb("]\n");
	}
	if (strlen(GetOS()) != 0) (*Debug)->Deb("[RUN ON    : %s]\n",GetOS());

        Devices->Add(new GSM_Device_Infrared(Deb));
        Devices->Add(new GSM_Device_Serial(Deb));
#ifdef WIN32
        Devices->Add(new GSM_Device_Bluetooth(Deb));
#endif

        Protocols->Add(new GSM_Protocol_FBUS2(&(Devices->Current),Debug));
        Protocols->Add(new GSM_Protocol_PHONET(&(Devices->Current),Debug));
        Protocols->Add(new GSM_Protocol_OBEX(&(Devices->Current),Debug));
  
        Phones->Add(new GSM_Phone_N6110(Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_N7110(Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_N6510(Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_NAUTO(Debug,&(Devices->Current),&Protocols,&Phones));
}

GSM_StateMachine::~GSM_StateMachine()
{
	Close();

	delete(Phones);
	delete(Protocols);
	delete(Devices);
}

GSM_Error GSM_StateMachine::Close()
{
        GSM_Error error;

	(*Debug)->Deb("[CLOSING]\n");

        if (Phones->Current != NULL) {
                error=Phones->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }

        if (Protocols->Current != NULL) {
                error=Protocols->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }

        if (Devices->Current != NULL) {
	        error=Devices->Current->Close();
                if (error != GSM_ERR_NONE) return error;
        }

        return GSM_ERR_NONE;
}

GSM_Error GSM_StateMachine::Open(char *Dev, char *Prot, char *Pho)
{
        GSM_Error       			error;
        char            			*DeviceName = NULL;
	unsigned char   			Buff[100];
	list<GSM_Protocol_Info>::iterator 	proinfo;

	(*Debug)->Deb("[STARTUP   : device \"%s\", protocol \"%s\", phone \"%s\"]\n",Dev,Prot,Pho);

        error=Devices->Switch(Prot,Protocols,Phones);
        if (error != GSM_ERR_NONE) return error;

        error=Protocols->Switch(Prot,Phones);
        if (error != GSM_ERR_NONE) return error;

        error=Devices->Current->Open(Dev,Prot,Pho,&DeviceName,Phones);
        if (error != GSM_ERR_NONE) return error;

        error=Protocols->Current->Open(Prot);
        if (error != GSM_ERR_NONE) return error;

	for (proinfo=Protocols->Current->Info.begin(); proinfo!=Protocols->Current->Info.end(); ++proinfo) {
		if (!strcmp(Prot,proinfo->Protocol)) break;
        }

        if (Pho[0] == 0 && proinfo->CanUseDeviceName) {
		error=Phones->SwitchToDeviceName(DeviceName,Prot);
	} else {
                error=Phones->Switch(Pho,Prot);
	}
	if (error != GSM_ERR_NONE) return error;

        error=Phones->Current->Open("");
        if (error != GSM_ERR_NONE) return error;

	/* We will get now phone info */
        error=Phones->Current->GetCodeNameModel(Buff);
        if (error != GSM_ERR_NONE) return error;

        return GSM_ERR_NONE;
}

GSM_Error GSM_StateMachine::OpenFromFile()
{
	CFG_File 	File;
	char 		Device[200], Protocol[200], Phone[200];
	wchar_t		*value, x[200];

	strcpy(Device,"com2:");
	strcpy(Protocol,"fbus");
	Phone[0] = 0;

	if (File.ReadFile("gammurc")) {
		EncodeUnicode("gammu",x);

		value = File.GetValue(x,EncodeUnicodeString("device"));
		if (value != NULL) sprintf(Device,"%s",DecodeUnicodeString(value));

		value = File.GetValue(x,EncodeUnicodeString("connection"));
		if (value != NULL) sprintf(Protocol,"%s",DecodeUnicodeString(value));

		value = File.GetValue(x,EncodeUnicodeString("model"));
		if (value != NULL) sprintf(Phone,"%s",DecodeUnicodeString(value));
	}
	return Open(Device, Protocol, Phone);
}

void GSM_StateMachine::SetUserReply(GSM_Error(*UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID))
{
        if (Phones->Current != NULL) Phones->Current->SetUserReply(UsrReply);
}
