/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../gsmcomon.h"
#include "../../device/gsmdev.h"
#include "../gsmphone.h"
#include "ndct34.h"

//id from 6000

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_NAUTO:virtual public GSM_Phone
{
public:
        GSM_Phone_NAUTO(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("", "", "" ,"fbus|bluephonet|dku2phonet|dku2", ""));

		DCT34 = new(GSM_Phone_NDCT34);

		ModuleName 	= "nauto";
		ModulesUsed  	= "n6110|n7110|n6510";
		ModulesRequired = "";
        }
        ~GSM_Phone_NAUTO() {
		delete DCT34;
        }

	GSM_Error 	Open(char *ID);
        GSM_Error       Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID);

//	GSM_Error 	GetIMEI(unsigned char *IMEI);
private:
	GSM_Phone_NDCT34 *DCT34;
};
