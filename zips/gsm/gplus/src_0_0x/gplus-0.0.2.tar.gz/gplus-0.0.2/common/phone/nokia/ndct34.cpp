/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../misc/coding/coding.h"
#include "../../gsmcomon.h"
#include "../gsmphone.h"
#include "ndct34.h"

GSM_Phone_NDCT34::GSM_Phone_NDCT34()
{
	ID = NULL;
}

GSM_Phone_NDCT34::~GSM_Phone_NDCT34()
{
	free(ID);
}

GSM_Error GSM_Phone_NDCT34::ReplyGetID(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident)
{
	int i;

	for (i=0;i<msg->Length;i++) {
		if (msg->Buffer[i] == 0x00) {
			Ident[i] = 32;
		} else {
			Ident[i] = msg->Buffer[i];
		}
	}
	Ident[i] = 0x00;
	(*Debug)->Deb("RECEIVED: phone identification\n");
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::PrivGetID(DebugInfo *Debug, GSM_Phone *Pho)
{
	unsigned char 	Buff[] = {NOKIA_FRAME1, 0x03, 0x00};
	unsigned char	Id[200];
	GSM_Error	error;

	Debug->Deb("SENT: Get identification\n");
	error=Pho->Write(Buff, 5, 0xD1, 2, ID_GetID, Id);
	if (error == GSM_ERR_NONE) {
		ID = (char *)malloc(strlen((const char *)Id)+1);
		memcpy(ID,(const char *)Id,strlen((const char *)Id)+1);
	}
	return error;
}

GSM_Error GSM_Phone_NDCT34::GetCodeNameModel(unsigned char *Mod, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=5,counter=0;

	if (ID == NULL) {
		error = PrivGetID(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Mod[0] = 0x00;
	while(1) {
		if (ID[i]==0x0a) {
			if (counter == 2) break;
			counter++;
		} else {
			if (counter == 2) {
				Mod[strlen((const char *)Mod)+1] = 0x00;
				Mod[strlen((const char *)Mod)]   = ID[i];
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::GetFirmware(unsigned char *Firm, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=4,counter=0;

	if (ID == NULL) {
		error = PrivGetID(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Firm[0] = 0x00;
	while(1) {
		if (ID[i]==0x0a) {
			break;
		} else {
			counter++;
			if (counter >= 3) {
				if (strlen((const char *)Firm) == 0 && ID[i]==0x20) {
				} else {
					Firm[strlen((const char *)Firm)+1] = 0x00;
					Firm[strlen((const char *)Firm)]   = ID[i];
				}
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

unsigned char GSM_Phone_NDCT34::Get7110DCT4MemoryType(char *Description)
{
	if (!strcmp(Description,"DC")) return 0x01;
	if (!strcmp(Description,"MC")) return 0x02;
	if (!strcmp(Description,"RC")) return 0x03;
	if (!strcmp(Description,"ME")) return 0x05;
	if (!strcmp(Description,"SM")) return 0x06;
	if (!strcmp(Description,"ON")) return 0x17;
	return 0x00;
}

char *GSM_Phone_NDCT34::GetID()
{
	return ID;
}

void GSM_Phone_NDCT34::SetID(char *Id)
{
	ID = (char *)malloc(strlen((const char *)Id)+1);
	memcpy(ID,(const char *)Id,strlen((const char *)Id)+1);
}

GSM_Error GSM_Phone_NDCT34::DecodePBKToEntry(DebugInfo *Debug, const unsigned char *Buffer, GSM_PBKEntry *Entry)
{
	int 			i, Pos = 1;
	GSM_PBK_SubEntryType 	Type;

	Debug->Deb("  %i blocks\n",Buffer[0]);
	for (i=0;i<Buffer[0];i++) {
		Debug->Deb("    Block length %i, type %02X\n",Buffer[Pos+3]-6,Buffer[Pos]);

		Type = PBK_Not_Assigned;
		if (Buffer[Pos] == NPBK_NAME)    { Type = PBK_Text_Name;    Debug->Deb("      Name");      }
		if (Buffer[Pos] == NPBK_EMAIL)   { Type = PBK_Text_Email;   Debug->Deb("      Email");     }
		if (Buffer[Pos] == NPBK_POSTAL)  { Type = PBK_Text_Postal;  Debug->Deb("      Postal");    }
		if (Buffer[Pos] == NPBK_NOTE)    { Type = PBK_Text_Note;    Debug->Deb("      Text note"); }
		if (Buffer[Pos] == NPBK_URL)     { Type = PBK_Text_URL;     Debug->Deb("      URL");       }
		if (Buffer[Pos] == NPBK_USER_ID) { Type = PBK_Text_UserID;  Debug->Deb("      User ID");   }
		if (Type != PBK_Not_Assigned) {
			Debug->Deb(" \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+6)));
			Entry->AddText(Type, NokiaGetUnicodeString(Buffer+Pos+6));
			Pos+=Buffer[Pos+3];
			continue;
		}

		if (Buffer[Pos] == NPBK_NUMBER) {
			Type = PBK_Not_Assigned;
			if (Buffer[Pos+5] == NPBK_NUMBER_UNKNOWN1 ||
			    Buffer[Pos+5] == NPBK_NUMBER_UNKNOWN2 ||
			    Buffer[Pos+5] == NPBK_NUMBER_UNKNOWN3 ||
			    Buffer[Pos+5] == NPBK_NUMBER_GENERAL  ||
			    Buffer[Pos+5] == NPBK_NUMBER_BUG) {
				Type = PBK_Text_Phone_General;
				Debug->Deb("      General number");
			}
			if (Buffer[Pos+5] == NPBK_NUMBER_HOME) {
				Type = PBK_Text_Phone_Home;
				Debug->Deb("      Home number");
			}
			if (Buffer[Pos+5] == NPBK_NUMBER_MOBILE) {
				Type = PBK_Text_Phone_Mobile;
				Debug->Deb("      Mobile number");
			}
			if (Buffer[Pos+5] == NPBK_NUMBER_FAX) {
				Type = PBK_Text_Phone_Fax;
				Debug->Deb("      Fax number");
			}
			if (Buffer[Pos+5] == NPBK_NUMBER_WORK) {
				Type = PBK_Text_Phone_Work;
				Debug->Deb("      Work number");
			}
			if (Type == PBK_Not_Assigned) {
				Debug->Deb("      Unknown number");
				Debug->Deb(" \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+10)));
				return GSM_ERR_UNKNOWN;
			}
			Debug->Deb(" \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+10)));
			Entry->AddText(Type, NokiaGetUnicodeString(Buffer+Pos+10));

			/* ID for voice tags in DCT3 phones like 6210 */
			if (Buffer[Pos+7] != 0) {
			}

			Pos+=Buffer[Pos+3];
			continue;
		}

		if (Buffer[Pos] == NPBK_DATETIME) {
			Debug->Deb("      DateTime\n");
			Entry->AddDateTime(PBK_DateTime_Call, *NokiaGetDT(Buffer+Pos+6));
			Pos+=Buffer[Pos+3];
			continue;
		}

		//todo
		if (Buffer[Pos] == NPBK_SMSLIST_ID) {
			Debug->Deb("      SMS list ID\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_PICTURE_ID) {
			Debug->Deb("      Picture ID\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_VOICETAG_ID) {
			Debug->Deb("      Voice tag ID\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_RINGTONEFILE_ID) {
			Debug->Deb("      Ringtone file ID\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_RINGTONE_ID) {
			Debug->Deb("      Ringtone ID\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_SIM_SPEEDDIAL) {
			Debug->Deb("      Speed dial\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_SPEEDDIAL) {
			Debug->Deb("      Speed dial\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_UNKNOWN1) {
			Debug->Deb("      Unknown 1\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_UNKNOWN2) {
			Debug->Deb("      Unknown 2\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_UNKNOWN3) {
			Debug->Deb("      Unknown 3\n");
			Pos+=Buffer[Pos+3];
			continue;
		}
		if (Buffer[Pos] == NPBK_UNKNOWN4) {
			Debug->Deb("      Unknown 4\n");
			Pos+=Buffer[Pos+3];
			continue;
		}

		Debug->Deb("      Unknown block\n");
		return GSM_ERR_UNKNOWN;
	}
	return GSM_ERR_NONE;
}

wchar_t *GSM_Phone_NDCT34::NokiaGetUnicodeString(const unsigned char *Buffer)
{
	static 		wchar_t dst[500];
	int 		pos=0;

	while (Buffer[pos*2] != 0 || Buffer[pos*2+1] != 0) {
		dst[pos] = Buffer[pos*2] * 256 + Buffer[pos*2+1];
		pos++;
	}
	dst[pos] = 0;
	return dst;
}

GSM_DateTime *GSM_Phone_NDCT34::NokiaGetDT(const unsigned char *Buffer)
{
	static GSM_DateTime DT;

	DT.Year   = Buffer[0] * 256 + Buffer[1];
	DT.Month  = Buffer[2];
	DT.Day    = Buffer[3];
	DT.Hour   = Buffer[4];
	DT.Minute = Buffer[5];
	DT.Second = Buffer[6];

	return &DT;
}
