/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../../gsmcomon.h"
#include "../../../device/gsmdev.h"
#include "../../gsmphone.h"
#include "../ndct34.h"
#include "ndct3.h"

//ID from 3000

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_N7110:virtual public GSM_Phone
{
public:
        GSM_Phone_N7110(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("6210", "NPE-3",  "Nokia 6210" ,"fbus|irdaphonet", ""));
		Info.push_back(GSM_Phone_Info("7110", "NSE-5",  "Nokia 7110" ,"fbus|irdaphonet", ""));

		DCT34 = new(GSM_Phone_NDCT34);
		DCT3  = new(GSM_Phone_NDCT3);

		ModuleName 	= "n7110";
		ModulesUsed  	= "";
		ModulesRequired = "";
        }
        ~GSM_Phone_N7110() {
		delete DCT34;
		delete DCT3;
        }

	GSM_Error 	Open			(char *ID);
        GSM_Error       Dispatch		(GSM_Protocol_Message *msg, void *Struct, int RequestID);

	GSM_Error 	GetPBKMemoryStatus	(GSM_PBKStatus *Status);
	GSM_Error	GetManufacturer		(unsigned char *Manufacturer);
        GSM_Error       GetIMEI			(unsigned char *IMEI);
	GSM_Error 	GetCodeNameModel	(unsigned char *Model);
	GSM_Error 	GetFirmware		(unsigned char *Firm);
	GSM_Error 	GetPBKMemory		(GSM_PBKEntry *Entry);
private:
	GSM_Phone_NDCT34 *DCT34;
	GSM_Phone_NDCT3  *DCT3;

        GSM_Error       ReplyGetIMEI		(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);
	GSM_Error 	ReplyGetPBKStatus	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	ReplyGetPBKMemory	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
};
