/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../protocol/gsmprot.h"
#include "../ndct34.h"
#include "n6110.h"
#include "ndct3.h"

GSM_Error GSM_Phone_N6110::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	AnsStruct AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

if(Ans("\x03",0x03,0x08,ID_GetPBKStatus,&AS))return ReplyGetPBKStatus (msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x09,ID_GetPBKStatus,&AS))return ReplyGetPBKStatus (msg,Debug,(unsigned char *)Struct);

if(Ans("\x40",0x02,0x64,ID_SetSecurity,&AS))return DCT3->ReplySetSecurity(msg,Debug,(unsigned char *)Struct);
if(Ans("\x40",0x02,0x66,ID_GetIMEI    ,&AS))return DCT3->ReplyGetIMEI    (msg,Debug,(unsigned char *)Struct);

if(Ans("\xD2",0x02,0x00,ID_GetID,      &AS))return DCT34->ReplyGetID 	 (msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_ERR_FRAME_NOTREQUESTED;
        return GSM_ERR_FRAME_UNKNOWN;
}

GSM_Error GSM_Phone_N6110::GetIMEI(unsigned char *IMEI)
{
	return DCT3->GetIMEI(*Debug,(*Phones)->Current,IMEI);
}

GSM_Error GSM_Phone_N6110::GetCodeNameModel(unsigned char *Model)
{
	return DCT34->GetCodeNameModel(Model,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6110::GetFirmware(unsigned char *Firm)
{
	return DCT34->GetFirmware(Firm,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6110::GetManufacturer(unsigned char *Manufacturer)
{
	strcpy((char *)Manufacturer,"Nokia");
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6110::ReplyGetPBKStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKStatus *Status = (GSM_PBKStatus *)S;

	(*Debug)->Deb("RECEIVED: PBK memory status\n");

	if (msg->Buffer.data()[3] == 0x08) {
		Status->Used = msg->Buffer.data()[6];
		Status->Free = msg->Buffer.data()[5];
		(*Debug)->Deb("Used - %i\n",Status->Used);
		(*Debug)->Deb("Free - %i\n",Status->Free);

	        return GSM_ERR_NONE;
	} else if (msg->Buffer.data()[3] == 0x09) {
		(*Debug)->Deb("Error %i\n",msg->Buffer.data()[4]);
	        return GSM_ERR_UNKNOWN;
	}
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Phone_N6110::GetPBKMemoryStatus(GSM_PBKStatus *Status)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x07, 0x00};

	Buff[4] = GetMemoryType(Status->Memory);
	if (Buff[4] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: getting status for %s memory\n",Status->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKStatus, Status);
}

unsigned char GSM_Phone_N6110::GetMemoryType(char *Description)
{
	if (!strcmp(Description,"ME")) return 0x02;
	if (!strcmp(Description,"SM")) return 0x03;
	if (!strcmp(Description,"ON")) return 0x05;
	if (!strcmp(Description,"DC")) return 0x07;
	if (!strcmp(Description,"RC")) return 0x08;
	if (!strcmp(Description,"MC")) return 0x09;

	return 0x00;
}

GSM_Error GSM_Phone_N6110::Open(char *ID)
{
	if (ID[0] != 0) DCT34->SetID(ID);

	return GSM_ERR_NONE;
}
