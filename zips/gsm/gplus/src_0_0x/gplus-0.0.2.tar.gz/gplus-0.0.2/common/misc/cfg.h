/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <windows.h>

#ifndef cfg_h
#define cfg_h

class CFG_File_Entry {
public:
	CFG_File_Entry();
	~CFG_File_Entry();

	void SetValue		(wchar_t *Txt);
	wchar_t *GetValue	();

	void SetName		(wchar_t *Txt);
	wchar_t *GetName	();

	void SetNext		(CFG_File_Entry *Nxt);
	CFG_File_Entry 		*GetNext();
private:
	CFG_File_Entry 		*Next;
	wchar_t			*Text;
	wchar_t			*Name;
};

class CFG_File_Section {
public:
	CFG_File_Section(wchar_t *Text);
	~CFG_File_Section();

	wchar_t *GetName	();
	void SetName		(wchar_t *Text);

	void AddValue		(wchar_t *Name, wchar_t *Value);
	BOOLEAN GetNextValue	(CFG_File_Entry **Entry);

	void SetNext		(CFG_File_Section *Nxt);
	CFG_File_Section 	*GetNext();
private:
	CFG_File_Section 	*Next;
	CFG_File_Entry 		*Entries;
	wchar_t			*Name;
};

class CFG_File {
public:
	CFG_File();
	~CFG_File();

	BOOLEAN ReadFile	(char *FileName);

	void AddSection		(wchar_t *Name);
	BOOLEAN GetNextSection	(CFG_File_Section **Section);
	CFG_File_Section 	*GetLastSection();

	wchar_t *GetValue	(wchar_t *Sec, wchar_t *Nam);
private:
	CFG_File_Section 	*Sections;

	BOOLEAN ReadFileLine	(FILE *f, unsigned char *Buffer, int *Pos, int *Size, wchar_t **Line, int Unicode);
};

#endif
