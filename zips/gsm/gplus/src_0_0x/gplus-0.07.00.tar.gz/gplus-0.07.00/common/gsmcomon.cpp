/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

//#include <stdarg.h>

#include "gsmcomon.h"

typedef struct {
        GSM_Error             ErrorNum;
        char                  *ErrorText;
} PrintErrorEntry;

char *GSM_GetErrorInfo(GSM_Error e)
{
        PrintErrorEntry PrintErrorEntries[] = {
		{GSM_ERR_DRIVER_NOT_AVAILABLE,		"Some required driver or operating system part not available."},
		{GSM_ERR_DEVICE_WRITE,			"Error writing device"},
		{GSM_ERR_DEVICE_READ,			"Error reading device"},
		{GSM_ERR_DEVICE_OPEN,			"Error opening device"},
		{GSM_ERR_DEVICE_CLOSE,			"Error closing device"},
                {GSM_ERR_NONE,                          "No error."},
                {GSM_ERR_UNKNOWN,                       "Unknown error. Please report."},
                {GSM_ERR_SOURCE_NOT_COMPILED,           "Some parts of source not compiled."},
                {GSM_ERR_PROTOCOL_STRING_UNKNOWN,       "Protocol specified in config is not known."},
                {GSM_ERR_PHONE_STRING_UNKNOWN,          "Phone model specified in config is not known."},
                {GSM_ERR_OTHER_PROTOCOL,                "Phone model specified in config works with others protocols only."},
		{GSM_ERR_TIMEOUT,			"No response in specified time."},
		{GSM_ERR_EMPTY,				"Empty"},
		{GSM_ERR_NOT_SUPPORTED,			"Not supported by phone"},
		{GSM_ERR_INSIDE_PHONE_MENU,		"Data are edited in phone menu. Leave it before editing from PC."},
		{GSM_ERR_NO_SIM,			"Function requires SIM card"},
		{GSM_ERR_GPLUS_NOT_SUPPORTED,		"Not supported by Gammu+"},
		{GSM_ERR_FILE_CHECKSUM,			"File checksum error"},

                {GSM_ERR_NONE,                          ""}
        };
        char   *def    = NULL;
        int    i       = 0;

        while (1) {
                if (PrintErrorEntries[i].ErrorText[0] == 0x00) break;
                if (PrintErrorEntries[i].ErrorNum == e) {
                        def     = PrintErrorEntries[i].ErrorText;
                        break;
                }
                i++;
        }
        if (def == NULL) def = "Unknown error.";
        return def;
}
