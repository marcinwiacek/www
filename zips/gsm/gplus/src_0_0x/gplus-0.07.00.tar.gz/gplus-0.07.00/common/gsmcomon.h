/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */


#include <ctype.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

#ifndef gsm_comon_h
#define gsm_comon_h

#define PHONE_MAXSMSINFOLDER 200

typedef enum {
	/* Device layer errors not returned to user */
	GSM_ERR_DRIVER_NOT_AVAILABLE = 1,
        /* Internal errors not returned to user */
        GSM_ERR_NEWMESSAGE,

        /* Internal errors returned to user */
        GSM_ERR_FRAME_NOT_REQUESTED,
	GSM_ERR_FRAME_TYPE_UNKNOWN,
	GSM_ERR_FRAME_CONTENT_UNKNOWN,
        /* Other errors returned to user */
	GSM_ERR_DEVICE_WRITE,
	GSM_ERR_DEVICE_READ,
	GSM_ERR_DEVICE_OPEN,
	GSM_ERR_DEVICE_CLOSE,
        GSM_ERR_NONE,
        GSM_ERR_UNKNOWN,
        GSM_ERR_SOURCE_NOT_COMPILED,
        GSM_ERR_PROTOCOL_STRING_UNKNOWN,
        GSM_ERR_PHONE_STRING_UNKNOWN,
        GSM_ERR_OTHER_PROTOCOL,
        GSM_ERR_TIMEOUT,
        GSM_ERR_EMPTY,
	GSM_ERR_NOT_SUPPORTED,
	GSM_ERR_INVALID_LOCATION,
	GSM_ERR_INSIDE_PHONE_MENU,
	GSM_ERR_NO_SIM,
	GSM_ERR_GPLUS_NOT_SUPPORTED,
	GSM_ERR_MEMORY,
	GSM_ERR_FOLDER_PART,
	GSM_ERR_FILE_NOT_EXIST,
	GSM_ERR_MUST_BE_FILE,
	GSM_ERR_FILE_CHECKSUM
} GSM_Error;

char *GSM_GetErrorInfo(GSM_Error e);

#endif
