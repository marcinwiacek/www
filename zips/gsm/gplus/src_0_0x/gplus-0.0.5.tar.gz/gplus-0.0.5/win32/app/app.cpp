/* (C) 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>
#include <stdarg.h>
#include <windows.h>

#include "dll.h"

// this function is created for easier operating on unicode strings
// (almost) each language has similiar
unsigned int DecodeWithUnicodeAlphabet(wchar_t src, char *dest)
{
	int r = wctomb(dest, src);

	if (r == -1) {
		r = 1;
		*dest = '?';
	}
	return r;
}

// this function is created for easier operating on unicode strings
// (almost) each language has similiar
char *DecodeUnicodeString (wchar_t *src)
{
	int 		pos = 0, pos2 = 0;
	static char 	dst[1000];

	while (src[pos] != 0) {
		pos2+=DecodeWithUnicodeAlphabet(src[pos], dst+pos2);
		pos++;
	}
	dst[pos2] = 0;
	return dst;
}

//example, how to set own reply handler
#define DCT4GetUEM 50000

GSM_Error __stdcall DCT4ReplyGetUEM(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID)
{
	// Struct is pointer to any structure given during frame sending
	char *Buf = (char *)Struct;

	//we must check Type of message
	//and how long it is
	if (MsgType == 0x1B && MsgLength > 4) {
		//message is enough long and now we check subtype
		if (MsgBuffer[3] == 0x08) {
			//if we didn't ask for it return error
			if (RequestID != DCT4GetUEM) return GSM_ERR_FRAME_NOTREQUESTED;
			//we wanted it now and we fill our structure and return
			strcpy(Buf,(const char *)MsgBuffer+10);
			return GSM_ERR_NONE;
		}
	}

	//we must tell Gammu+, that we want to parse this frame by internal
	//module
	return GSM_ERR_FRAME_UNKNOWN;
}

void main(int argc, char *argv[])
{
	GSM_DateTime		DT;
	GSM_CalEntry2 		CalEntry;
	GSM_CalSubEntry2 	*CalSubEntry;
	GSM_PBKStatus		PBKStatus;
	GSM_PBKEntry2		PBKEntry;
	GSM_PBKSubEntry2        *PBKSubEntry;
	GSM_SMSStatus		SMSStatus;
	GSM_SMSC2		SMSC;
	GSM_SMSFoldersEntry2	SMSFolders;
	GSM_SMSFoldersSubEntry2 *SMSFoldersSubEntry;
	GSM_Error 		error;
	GSM_SMSListEntry2	SMSList;
	GSM_SMSListSubEntry2	*SMSListSubEntry;
	unsigned char 		text[50],text2[50],text3[50];
	wchar_t			wtext[200];
	BOOLEAN 		Start;
	int			RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;

	GPlusGetGPlusVersion((char *)text);
	printf("Gammu+ version: %s\n",text);

	Start = TRUE;
	while (true) {
		GPlusGetNextSupportedPhoneInfo(Start, (char *)text, (char *)text2, (char *)text3);
		if (text2[0] == 0) break;
		Start = FALSE;
		printf("Model %s, codename %s, protocol %s\n",text,text3,text2);
	}

	printf("error description for GSM_ERR_DEVICEREAD is %s\n",GPlusGetErrorInfo(GSM_ERR_DEVICEREAD));

//	GPlusEnableDebug(0, "filename");

	/* --------- now start part requiring phone connection ------------- */

//	error = GPlusOpen(0,"com1:","fbus","");
//	error = GPlusOpen(0,"","bluephonet","");
//	error = GPlusOpen(0,"","dku2phonet","");
	error = GPlusOpen(0,"","irdaphonet","");
	if (error != GSM_ERR_NONE) return;

	error = GPlusGetIMEI(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("IMEI: %s\n",text);

//	GPlusDisableDebug(0);

	error = GPlusGetModel(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Model: %s\n",text);

	error = GPlusGetCodeNameModel(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Model CodeName: %s\n",text);

	error = GPlusGetFirmwareVersion(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Firmware version: %s\n",text);

	error = GPlusGetFirmwareDate(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Firmware date: %s\n",text);

	if (!strcmp(GPlusGetPhoneModuleName(0),"n6510")) {
		//we set handler
		GPlusSetUserReply(0,&DCT4ReplyGetUEM);
		error = GPlusWrite(0,(unsigned char *)"\x00\x03\x02\x07\x00\x08",6, 0x1B, 4, DCT4GetUEM, text);
		if (error != GSM_ERR_NONE) return;
		GPlusSetUserReply(0,NULL);
		printf("UEM      : %s\n",text);
	}

	/* ------------------------ phonebook ------------------------------ */

	PBKStatus.Memory = MEM_SIM;
	error = GPlusGetPBKStatus(0,&PBKStatus);
	if (error != GSM_ERR_NONE) return;
	printf("SIM phonebook: Used %i, Free %i\n",PBKStatus.Used, PBKStatus.Free);

	PBKStatus.Memory = MEM_PHONE;
	error = GPlusGetPBKStatus(0,&PBKStatus);
	if (error != GSM_ERR_NONE) return;
	printf("Phone phonebook: Used %i, Free %i\n",PBKStatus.Used, PBKStatus.Free);

	PBKEntry.SubEntries = NULL;
//	PBKEntry.Memory = MEM_PHONE;
//	PBKEntry.Location = 2;	
//	error = GPlusGetPBK(0,&PBKEntry);
//	if (error != GSM_ERR_NONE) {
//		GPlusCleanPBKEntry2(&PBKEntry);
//		return;
//	}
	PBKSubEntry = PBKEntry.SubEntries;
	while (PBKSubEntry != NULL) {
		switch (PBKSubEntry->Type) {
		case PBK_Text_Phone_General:
			printf("General number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Mobile:
			printf("Mobile number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Home:
			printf("Home number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Work:
			printf("Work number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Fax:
			printf("Fax number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Email:
			printf("Email \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_URL:
			printf("URL \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Postal:
			printf("Postal address \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_UserID:
			printf("User ID \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Note:
			printf("Text note \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Name:
			printf("Name \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		}
		PBKSubEntry = PBKSubEntry->Next;
	}

//	PBKEntry.Location = 3;	
//	error = GPlusSetPBK(0,&PBKEntry);
//	if (error != GSM_ERR_NONE) {
//		GPlusCleanPBKEntry2(&PBKEntry);
//		return;
//	}

	GPlusCleanPBKEntry2(&PBKEntry);

	/* ----------------------- calendar -------------------------------- */

	Start = TRUE;
	while (1) {
		error = GPlusGetNextCalendar(0,&CalEntry,Start);
		if (error == GSM_ERR_EMPTY) break;
		if (error != GSM_ERR_NONE) return;

		printf("\nNote type    : ");
		switch(CalEntry.Type) {
		case Calendar_Type_Meeting:
			printf("meeting\n");
			break;
		case Calendar_Type_Memo:
			printf("memo\n");
			break;
		case Calendar_Type_Call:
			printf("phone call\n");
			break;
		case Calendar_Type_Birthday:
			printf("birthday\n");
			break;
		case Calendar_Type_Reminder:
			printf("reminder\n");
			break;
		}

		RepeatEach 	= -1;
		RepeatDay 	= -1;
		RepeatMonth 	= -1;
		RepeatDOW 	= -1;
		CalSubEntry 	= CalEntry.SubEntries;
		while (CalSubEntry != NULL) {
			switch (CalSubEntry->Type) {
			case Calendar_Text_Text:
				printf("Text         : \"%s\"\n",DecodeUnicodeString(CalSubEntry->Text));
				break;
			case Calendar_Text_Phone:
				printf("Phone number : \"%s\"\n",DecodeUnicodeString(CalSubEntry->Text));
				break;
			case Calendar_Text_Location:
				printf("Location     : \"%s\"\n",DecodeUnicodeString(CalSubEntry->Text));
				break;
			case Calendar_DateTime_Start:
				printf("Start time   : %02i:%02i:%02i %02i-%02i-%04i\n",
					CalSubEntry->DT.Hour,
					CalSubEntry->DT.Minute,
					CalSubEntry->DT.Second,
					CalSubEntry->DT.Day,
					CalSubEntry->DT.Month,
					CalSubEntry->DT.Year);
				break;
			case Calendar_DateTime_End:
				printf("End time     : %02i:%02i:%02i %02i-%02i-%04i\n",
					CalSubEntry->DT.Hour,
					CalSubEntry->DT.Minute,
					CalSubEntry->DT.Second,
					CalSubEntry->DT.Day,
					CalSubEntry->DT.Month,
					CalSubEntry->DT.Year);
				break;
			case Calendar_DateTime_ToneAlarm:
				if (CalEntry.Type == Calendar_Type_Birthday) {
					printf("Tone alarm   : %02i:%02i:%02i %02i-%02i in each year\n",
						CalSubEntry->DT.Hour,
						CalSubEntry->DT.Minute,
						CalSubEntry->DT.Second,
						CalSubEntry->DT.Day,
						CalSubEntry->DT.Month);
				} else {
					printf("Tone alarm   : %02i:%02i:%02i %02i-%02i-%04i\n",
						CalSubEntry->DT.Hour,
						CalSubEntry->DT.Minute,
						CalSubEntry->DT.Second,
						CalSubEntry->DT.Day,
						CalSubEntry->DT.Month,
						CalSubEntry->DT.Year);
				}
				break;
			case Calendar_DateTime_SilentAlarm:
				if (CalEntry.Type == Calendar_Type_Birthday) {
					printf("Silent alarm : %02i:%02i:%02i %02i-%02i in each year\n",
						CalSubEntry->DT.Hour,
						CalSubEntry->DT.Minute,
						CalSubEntry->DT.Second,
						CalSubEntry->DT.Day,
						CalSubEntry->DT.Month);
				} else {
					printf("Silent alarm : %02i:%02i:%02i %02i-%02i-%04i\n",
						CalSubEntry->DT.Hour,
						CalSubEntry->DT.Minute,
						CalSubEntry->DT.Second,
						CalSubEntry->DT.Day,
						CalSubEntry->DT.Month,
						CalSubEntry->DT.Year);
				}
				break;
			case Calendar_DateTime_End_Repeat:
				printf("Repeat end   : %02i:%02i:%02i %02i-%02i-%04i\n",
					CalSubEntry->DT.Hour,
					CalSubEntry->DT.Minute,
					CalSubEntry->DT.Second,
					CalSubEntry->DT.Day,
					CalSubEntry->DT.Month,
					CalSubEntry->DT.Year);
				break;
			case Calendar_Int_Repeat_Frequency:
				RepeatEach = CalSubEntry->IntValue;
				break;
			case Calendar_Int_Repeat_DayOfWeek:
				RepeatDOW = CalSubEntry->IntValue;
				break;			
			case Calendar_Int_Repeat_Day:
				RepeatDay = CalSubEntry->IntValue;
				break;
			case Calendar_Int_Repeat_Month:
				RepeatMonth = CalSubEntry->IntValue;
				break;
			}
			CalSubEntry = CalSubEntry->Next;
		}
		if (RepeatEach != -1 || RepeatDOW != -1 ||
		    RepeatDay != -1 || RepeatMonth != -1) {
			printf("Repeat note  : ");
			if (RepeatEach == 1) printf("each ");
			if (RepeatEach == 2) printf("each second ");
			if (RepeatDOW != -1) {
				switch (RepeatDOW) {
					case 1: printf("Monday ");	break;
					case 2: printf("Tuesday ");	break;
					case 3: printf("Wednesday ");	break;
					case 4: printf("Thursday ");	break;
					case 5: printf("Friday ");	break;
					case 6: printf("Saturday ");	break;
					case 7: printf("Sunday ");	break;
					default:printf(" ");
				}
			}
			if (RepeatDay != -1) {
				printf("%i ",RepeatDay);
				if (RepeatMonth != -1) {
					switch (RepeatMonth) {
						case  1: printf("January ");	break;
						case  2: printf("February ");	break;
						case  3: printf("March ");	break;
						case  4: printf("April ");	break;
						case  5: printf("May ");	break;
						case  6: printf("June ");	break;
						case  7: printf("July ");	break;
						case  8: printf("August ");	break;
						case  9: printf("September ");	break;
						case 10: printf("October ");	break;
						case 11: printf("November ");	break;
						case 12: printf("December ");	break;
						default:printf(" ");
					}
				} else {
					printf("month day ");
				}
			}
			printf("\n");
		}

		GPlusCleanCalendarEntry2(&CalEntry);
		
		Start = FALSE;
	}

//	CalEntry.Type = Calendar_Type_Birthday;
//	CalEntry.SubEntries = new GSM_CalSubEntry2;
//	CalEntry.SubEntries->DT.Year = 2003; 
//	CalEntry.SubEntries->DT.Month  = 12; 
//	CalEntry.SubEntries->DT.Day    = 20;
//	CalEntry.SubEntries->DT.Hour   = 23;   
//	CalEntry.SubEntries->DT.Minute = 59; 
//	CalEntry.SubEntries->DT.Second = 00;
//	CalEntry.SubEntries->Type   = Calendar_DateTime_Start;
//	CalEntry.SubEntries->Next   = NULL;
//	error = GPlusAddCalendar(0,&CalEntry);
//	if (error != GSM_ERR_NONE) return;

	// ------------------------------ SMS ---------------------------------

	SMSStatus.Memory = MEM_SIM;
	error = GPlusGetSMSStatus(0,&SMSStatus);
	if (error != GSM_ERR_NONE) return;
	printf("SIM SMS: Read %i, UnRead %i, Free %i\n",SMSStatus.SMSRead, SMSStatus.SMSUnRead, SMSStatus.SMSFree);

	SMSStatus.Memory = MEM_PHONE;
	error = GPlusGetSMSStatus(0,&SMSStatus);
	if (error == GSM_ERR_NOTSUPPORTED) {
	} else {
		if (error != GSM_ERR_NONE) return;
		printf("PHONE SMS: Read %i, UnRead %i, Templates %i, Free %i\n",SMSStatus.SMSRead, SMSStatus.SMSUnRead, SMSStatus.SMSTemplates, SMSStatus.SMSFree);
	}

	SMSC.Location = 1;
	SMSC.Name = NULL;
	SMSC.SMSCNumber = NULL;
	SMSC.DefaultNumber = NULL;
	error = GPlusGetSMSC(0,&SMSC);
	if (error != GSM_ERR_NONE) return;
	printf("Name                     : \"%s\"\n",DecodeUnicodeString(SMSC.Name));
	printf("SMSC number              : \"%s\"\n",DecodeUnicodeString(SMSC.SMSCNumber));
	printf("Default recipient number : \"%s\"\n",DecodeUnicodeString(SMSC.DefaultNumber));
	printf("Format                   : ");
	switch(SMSC.Format) {
		case SMS_Email : printf("email\n"); break;
		case SMS_Fax   : printf("fax\n");   break;
		case SMS_Pager : printf("pager\n"); break;
		case SMS_Text  : printf("text\n");  break;
	}
	printf("Validity                 : ");
	switch(SMSC.RelativeValidity) {
		case SMS_RelativeValidity_1_Hour	: printf("1 hour\n"); 	break;
		case SMS_RelativeValidity_6_Hours	: printf("6 hours\n"); 	break;
		case SMS_RelativeValidity_1_Day		: printf("1 day\n"); 	break;
		case SMS_RelativeValidity_3_Days	: printf("3 days\n");	break;
		case SMS_RelativeValidity_1_Week	: printf("1 week\n");	break;
		case SMS_RelativeValidity_Max_Time	: printf("max. time\n");break;
		default					: printf("%02x\n",SMSC.RelativeValidity);
	}
	GPlusCleanSMSC2(&SMSC);

	SMSFolders.SubEntries = NULL;
	error = GPlusGetSMSFolders(0,&SMSFolders);
	if (error != GSM_ERR_NONE) return;
	SMSFoldersSubEntry = SMSFolders.SubEntries;
	while (SMSFoldersSubEntry != NULL) {
		printf("Name %s",DecodeUnicodeString(SMSFoldersSubEntry->Name));
		if (SMSFoldersSubEntry->Inbox == TRUE) printf(", inbox");
		if (SMSFoldersSubEntry->Memory == MEM_SIM) printf(", SIM card");
		if (SMSFoldersSubEntry->Memory == MEM_PHONE) printf(", phone memory");
		printf("\n");
		SMSFoldersSubEntry = SMSFoldersSubEntry->Next;
	}
//	it's done later
//	GPlusCleanSMSFoldersEntry2(&SMSFolders);

	SMSList.SubEntries = NULL;
	SMSList.Name = NULL;
	Start = TRUE;
	while (true) {
		error = GPlusGetNextSMS(0,&SMSList,Start);
		if (error == GSM_ERR_EMPTY) break;
		if (error != GSM_ERR_NONE) return;

		Start = FALSE;
		
		if (SMSList.Memory == MEM_SIM) printf("SIM card");
		if (SMSList.Memory == MEM_PHONE) printf("Phone memory");
		SMSFoldersSubEntry = SMSFolders.SubEntries;
//		for (i=0;i<SMSList.Folder;i++) {
//			SMSFoldersSubEntry = SMSFoldersSubEntry->Next;
//		}
//		printf(", folder %s",DecodeUnicodeString(SMSFoldersSubEntry->Name));
		SMSList.Folder = 0; // it must be set to 0
		printf(", location 0/%i, ",SMSList.Location);
		switch (SMSList.Icon) {
			case SMS_Read	: printf("read"); 	break;
			case SMS_UnRead	: printf("unread"); 	break;
			case SMS_Sent	: printf("sent"); 	break;
			case SMS_UnSent	: printf("unsent"); 	break;
		}
		printf("\n  Name %s",DecodeUnicodeString(SMSList.Name));
		if (SMSList.SaveDateTimeAvailable == TRUE) {
			printf("\n  Saved %02i:%02i:%02i %02i-%02i-%04i",
				SMSList.SaveDateTime.Hour,
				SMSList.SaveDateTime.Minute,
				SMSList.SaveDateTime.Second,
				SMSList.SaveDateTime.Day,
				SMSList.SaveDateTime.Month,
				SMSList.SaveDateTime.Year);
		}
		printf("\n");

		SMSListSubEntry = SMSList.SubEntries;

		while (SMSListSubEntry != NULL) {
			switch (GPlusSMSGetType(&SMSListSubEntry->SMS)) {
			case SMS_Deliver:
				printf("  SMS Deliver\n");
				error = GPlusSMSGetPhoneNumber(&SMSListSubEntry->SMS,wtext);
				if (error != GSM_ERR_NONE) return;
				printf("    Phone Number \"%s\"\n",DecodeUnicodeString(wtext));
				error = GPlusSMSGetSMSCNumber(&SMSListSubEntry->SMS,wtext);
				if (error != GSM_ERR_NONE) return;
				printf("    SMSC Number \"%s\"\n",DecodeUnicodeString(wtext));
				error = GPlusSMSGetDateTime(&SMSListSubEntry->SMS,&DT);
				if (error != GSM_ERR_NONE) return;
				printf("    Sending date & time %02i:%02i:%02i %02i-%02i-%04i\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year);
				/* no break */
			case SMS_Submit:
				if (GPlusSMSGetType(&SMSListSubEntry->SMS) == SMS_Submit) printf("    SMS Submit\n");
				switch (GPlusSMSGetCoding(&SMSListSubEntry->SMS)) {
				case SMS_Coding_Unicode_No_Compression:
					error = GPlusSMSGetDecodedText(&SMSListSubEntry->SMS,wtext);
					if (error != GSM_ERR_NONE) return;
					printf("    Unicode, no compression\n%s\n",DecodeUnicodeString(wtext));
					break;
		    		case SMS_Coding_Unicode_Compression:
					printf("    Unicode, compression\n");
					break;
				case SMS_Coding_Default_No_Compression:
					error = GPlusSMSGetDecodedText(&SMSListSubEntry->SMS,wtext);
					if (error != GSM_ERR_NONE) return;
					printf("    Default, no compression\n%s\n",DecodeUnicodeString(wtext));
					break;
				case SMS_Coding_Default_Compression:
					printf("    Default, compression\n");
					break;
				case SMS_Coding_8bit:
					printf("    8 bit\n");
					break;
				}
				break;
			case SMS_Report:
				printf("  SMS report\n");
				error = GPlusSMSGetPhoneNumber(&SMSListSubEntry->SMS,wtext);
				if (error != GSM_ERR_NONE) return;
				printf("    Phone Number \"%s\"\n",DecodeUnicodeString(wtext));
				error = GPlusSMSGetSMSCNumber(&SMSListSubEntry->SMS,wtext);
				if (error != GSM_ERR_NONE) return;
				printf("    SMSC Number \"%s\"\n",DecodeUnicodeString(wtext));
				error = GPlusSMSGetDateTime(&SMSListSubEntry->SMS,&DT);
				if (error != GSM_ERR_NONE) return;
				printf("    Sending date & time %02i:%02i:%02i %02i-%02i-%04i\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year);
				error = GPlusSMSGetSMSCTime(&SMSListSubEntry->SMS,&DT);
				if (error != GSM_ERR_NONE) return;
				printf("    Receiving date & time %02i:%02i:%02i %02i-%02i-%04i\n",
					DT.Hour,DT.Minute,DT.Second,DT.Day,DT.Month,DT.Year);
				break;
			}
			SMSListSubEntry = SMSListSubEntry->Next;
		}		
		GPlusCleanSMSListEntry2(&SMSList);
	}

	GPlusCleanSMSFoldersEntry2(&SMSFolders);

	/* ----------------------------------------------------------------- */

	error = GPlusClose(0);
	if (error != GSM_ERR_NONE) return;
}
