/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

//sms class
//smsc reply

#include <windows.h>

#include "../../cfg/config.h"
#include "../../common/gsmcomon.h"
#include "../../common/gsmstate.h"
#include "../../common/misc/misc.h"
#include "../../common/misc/coding/coding.h"
#include "../../common/service/gsmpbk.h"
#include "../../common/service/gsmcal.h"

typedef struct {
	GSM_StateMachine 			*s;
	GSM_Phone 				*pho;
	list<GSM_Phone_Info>::iterator 		phoinfo;
} GSM_OnePhone;

GSM_OnePhone Phones[10];

GSM_Error WINAPI GPlusOpenFromFile(int numer)
{
	return Phones[numer].s->OpenFromFile();
}

void WINAPI GPlusEnableDebug(int numer, char *FileName)
{
	Phones[numer].s->Debug->SetDebug(NULL,FileName,true);
}

void WINAPI GPlusDisableDebug(int numer)
{
	Phones[numer].s->Debug->SetDebug(NULL,"",false);
}

GSM_Error WINAPI GPlusOpen(int numer, char *device, char *connection, char *model)
{
        return Phones[numer].s->Open(device,connection,model);
}

GSM_Error WINAPI GPlusGetIMEI(int numer, unsigned char *IMEI)
{
	return Phones[numer].s->Phones->Current->GetIMEI(IMEI);
}

GSM_Error WINAPI GPlusGetModel(int numer, unsigned char *Model)
{
	return Phones[numer].s->Phones->Current->GetModel(Model);
}

GSM_Error WINAPI GPlusGetCodeNameModel(int numer, unsigned char *Model)
{
	return Phones[numer].s->Phones->Current->GetCodeNameModel(Model);
}

GSM_Error WINAPI GPlusGetFirmwareVersion(int numer, unsigned char *Firmware)
{
	return Phones[numer].s->Phones->Current->GetFirmwareVersion(Firmware);
}

GSM_Error WINAPI GPlusGetFirmwareDate(int numer, unsigned char *Date)
{
	return Phones[numer].s->Phones->Current->GetFirmwareDate(Date);
}

GSM_Error WINAPI GPlusClose(int numer)
{
	return Phones[numer].s->Phones->Current->Close();
}

GSM_Error WINAPI GPlusGetPBKStatus(int numer, GSM_PBKStatus *Status)
{
	return Phones[numer].s->Phones->Current->GetPBKStatus(Status);
}

void WINAPI GPlusGetGPlusVersion(char *Version)
{
	sprintf(Version,"%s",VERSION);
}

void WINAPI GPlusGetNextSupportedPhoneInfo(BOOLEAN start, char *Model, char *Protocol, char *CodeNameModel)
{
	Protocol[0] = 0;
	if (start) {
	        Phones[0].pho = NULL;
                if (!Phones[0].s->Phones->GetNext(&Phones[0].pho)) return;
		Phones[0].phoinfo=Phones[0].pho->Info.begin();
	} else {
		Phones[0].phoinfo++;
		if (Phones[0].phoinfo == Phones[0].pho->Info.end()) {
	                if (!Phones[0].s->Phones->GetNext(&Phones[0].pho)) return;
			Phones[0].phoinfo=Phones[0].pho->Info.begin();
		}
	}
	strcpy(Model,Phones[0].phoinfo->Model);
	strcpy(Protocol,Phones[0].phoinfo->Protocol);
	strcpy(CodeNameModel,Phones[0].phoinfo->CodeNameModel);
}

char* WINAPI GPlusGetErrorInfo(GSM_Error e)
{
	return GSM_GetErrorInfo(e);
}

typedef struct _GSM_PBKSubEntry2 GSM_PBKSubEntry2;

struct _GSM_PBKSubEntry2 {
	wchar_t		 	*Text;
	GSM_PBKSubEntry2 	*Next;
	GSM_PBK_SubEntryType	Type;
};

typedef struct {
	int 			Location;
	GSM_MemoryType		Memory;
	GSM_PBKSubEntry2	*SubEntries;
} GSM_PBKEntry2;

GSM_Error WINAPI GPlusGetPBK(int numer, GSM_PBKEntry2 *E)
{
	GSM_PBKEntry 		Entry;
	GSM_Error    		error;
	GSM_PBKSubEntry2	*Sub = NULL;
	GSM_PBKSubEntry		*SubEntry;
	int 			len;

	Entry.Location = E->Location;
	Entry.Memory   = E->Memory;

	error = Phones[numer].s->Phones->Current->GetPBK(&Entry);

	if (error == GSM_ERR_NONE) {
		E->SubEntries 	= NULL;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry)) {
			if (Sub == NULL) {
				E->SubEntries = new GSM_PBKSubEntry2;
				Sub = E->SubEntries;
			} else {
				Sub->Next = new GSM_PBKSubEntry2;
				Sub = Sub->Next;
			}
			Sub->Text = NULL;
			Sub->Type = SubEntry->GetType();
			if (SubEntry->GetText()!=NULL) {
				len = UnicodeLength(SubEntry->GetText())+1;
				Sub->Text = (wchar_t *)malloc(len*sizeof(wchar_t));
				CopyUnicodeString(Sub->Text,SubEntry->GetText());
			}
			Sub->Next = NULL;
		}		
	}

	return error;
}

GSM_Error WINAPI GPlusSetPBK(int numer, GSM_PBKEntry2 *E)
{
	GSM_PBKEntry 		Entry;
	GSM_PBKSubEntry2	*Sub;

	Entry.Location = E->Location;
	Entry.Memory   = E->Memory;

	Sub = E->SubEntries;
	while (Sub != NULL) {
		Entry.AddText(Sub->Type,Sub->Text);
		Sub = Sub->Next;
	}

	return Phones[numer].s->Phones->Current->SetPBK(&Entry);
}

void WINAPI GPlusCleanPBKEntry2(GSM_PBKEntry2 *E)
{
	GSM_PBKSubEntry2 *SubEntry;
	
	while (true) {
		if (E->SubEntries == NULL) break;
		if (E->SubEntries->Next == NULL) {
			delete(E->SubEntries);
			E->SubEntries = NULL;
			break;
		}
		SubEntry = E->SubEntries;
		while (true) {
			if (SubEntry->Next->Next == NULL) break;
			SubEntry = SubEntry->Next;
		}
		free(SubEntry->Next);
		SubEntry->Next = NULL;
	}
}

GSM_Error WINAPI GPlusDeletePBK(int numer, GSM_PBKEntry2 *E)
{
	GSM_PBKEntry Entry;

	Entry.Location = E->Location;
	Entry.Memory   = E->Memory;

	return Phones[numer].s->Phones->Current->DeletePBK(&Entry);
}

void WINAPI GPlusSetUserReply(int numer, GSM_Error (__stdcall *UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID))
{
	Phones[numer].s->SetUserReply(UsrReply);	
}

GSM_Error WINAPI GPlusWrite(int numer, unsigned char *buffer,int length, unsigned char type, int time, int request, void *Struct)
{
	return Phones[numer].s->Phones->Current->Write(buffer,length,type,time,request,Struct);
}

char* WINAPI GPlusGetPhoneModuleName(int numer)
{
	return Phones[numer].s->Phones->Current->ModuleName;
}

typedef struct _GSM_CalSubEntry2 GSM_CalSubEntry2;

struct _GSM_CalSubEntry2 {
	wchar_t		 		*Text;
	GSM_DateTime			DT;
	int				IntValue;
	GSM_CalSubEntry2 		*Next;
	GSM_Calendar_SubEntryType       Type;
};

typedef struct {
	int				Location;
	GSM_Calendar_Type		Type;
	GSM_CalSubEntry2		*SubEntries;
} GSM_CalEntry2;

GSM_Error WINAPI GPlusGetNextCalendar(int numer, GSM_CalEntry2 *E, BOOLEAN start)
{
	GSM_CalendarEntry 	Entry;
	GSM_Error    		error;
	GSM_CalSubEntry2	*Sub = NULL;
	GSM_CalendarSubEntry	*SubEntry;
	int			len;

	error = Phones[numer].s->Phones->Current->GetNextCalendar(&Entry,start);

	if (error == GSM_ERR_NONE) {
		E->Type		= Entry.Type;
		E->Location	= Entry.Location;
		E->SubEntries 	= NULL;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry)) {
			if (Sub == NULL) {
				E->SubEntries = new GSM_CalSubEntry2;
				Sub = E->SubEntries;
			} else {
				Sub->Next = new GSM_CalSubEntry2;
				Sub = Sub->Next;
			}
			Sub->Type = SubEntry->GetType();
			Sub->Text = NULL;
			if (SubEntry->GetText()!=NULL) {
				len = UnicodeLength(SubEntry->GetText())+1;
				Sub->Text = (wchar_t *)malloc(len*sizeof(wchar_t));
				CopyUnicodeString(Sub->Text,SubEntry->GetText());
			} 
			Sub->IntValue = SubEntry->GetInt();
			memcpy(&Sub->DT,SubEntry->GetDateTime(),sizeof(GSM_DateTime));
			Sub->Next = NULL;
		}		
	}

	return error;
}

void WINAPI GPlusCleanCalendarEntry2(GSM_CalEntry2 *E)
{
	GSM_CalSubEntry2 *SubEntry;
	
	while (true) {
		if (E->SubEntries == NULL) break;
		if (E->SubEntries->Next == NULL) {
			delete(E->SubEntries);
			E->SubEntries = NULL;
			break;
		}
		SubEntry = E->SubEntries;
		while (true) {
			if (SubEntry->Next->Next == NULL) break;
			SubEntry = SubEntry->Next;
		}
		free(SubEntry->Next);
		SubEntry->Next = NULL;
	}
}

GSM_Error WINAPI GPlusAddCalendar(int numer, GSM_CalEntry2 *E)
{
	GSM_CalendarEntry 	Entry;
	GSM_CalSubEntry2	*Sub;

	Entry.Location 	= E->Location;
	Entry.Type 	= E->Type;

	Sub = E->SubEntries;
	while (Sub != NULL) {
		switch (Sub->Type) {
			case Calendar_Text_Text:
			case Calendar_Text_Location:
			case Calendar_Text_Phone:
				Entry.AddText(Sub->Type,Sub->Text);
				break;
			case Calendar_DateTime_Start:
			case Calendar_DateTime_End:
			case Calendar_DateTime_End_Repeat:
			case Calendar_DateTime_SilentAlarm:
			case Calendar_DateTime_ToneAlarm:
				Entry.AddDateTime(Sub->Type,Sub->DT);
				break;
			case Calendar_Int_Repeat_Frequency:
			case Calendar_Int_Repeat_DayOfWeek:
			case Calendar_Int_Repeat_Day:
			case Calendar_Int_Repeat_Month:
				Entry.AddInt(Sub->Type,Sub->IntValue);
				break;
			default:
				break;
		}
		Sub = Sub->Next;
	}

	return Phones[numer].s->Phones->Current->AddCalendar(&Entry);
}

GSM_Error WINAPI GPlusDeleteCalendar(int numer, GSM_CalEntry2 *E)
{
	GSM_CalendarEntry Entry;

	Entry.Location = E->Location;

	return Phones[numer].s->Phones->Current->DeleteCalendar(&Entry);
}

int WINAPI GPlusGetDayOfWeek(int Year, int Month, int Day)
{
	return DayOfWeek(Year, Month, Day);
}

GSM_Error WINAPI GPlusGetSMSStatus(int numer, GSM_SMSStatus *E)
{
	return Phones[numer].s->Phones->Current->GetSMSStatus(E);
}

typedef struct {
	unsigned char			*UserData;
	int				UserDataLen;
	unsigned char		 	*PhoneNumber;
	int				PhoneNumberLen;
	unsigned char		 	*SMSCNumber;
	int				SMSCNumberLen;
	unsigned char 			TPDCS;
	unsigned char 			DateTime[7];
	unsigned char 			SMSCTime[7];
	unsigned char 			TPStatus;
	unsigned char 			TPUDL;
	unsigned char 			TPVP;
	unsigned char 			firstbyte;
	unsigned char 			TPMR;
	unsigned char 			TPPID;
} GSM_SMSEntry2;

typedef struct _GSM_SMSListSubEntry2 GSM_SMSListSubEntry2;

struct _GSM_SMSListSubEntry2 {
	GSM_SMSEntry2			SMS;
	GSM_SMSListSubEntry2		*Next;
};

typedef struct {
	int				Location;
	int				Folder;
	GSM_MemoryType			Memory;
	SMS_Icon			Icon;
	wchar_t		 		*Name;
	BOOLEAN				SaveDateTimeAvailable;
	GSM_DateTime			SaveDateTime;
	GSM_SMSListSubEntry2		*SubEntries;
} GSM_SMSListEntry2;

void CopySMSEntry2ToSMSEntry(GSM_SMSEntry2 *Entry2, GSM_SMSEntry *Entry)
{
	if (Entry2->UserData!=NULL)    Entry->UserData.append(Entry2->UserData,Entry2->UserDataLen);
	if (Entry2->PhoneNumber!=NULL) Entry->PhoneNumber.append(Entry2->PhoneNumber,Entry2->PhoneNumberLen);
	if (Entry2->SMSCNumber!=NULL)  Entry->SMSCNumber.append(Entry2->SMSCNumber,Entry2->SMSCNumberLen);
	Entry->TPDCS = Entry2->TPDCS;
	memcpy(Entry->DateTime,Entry2->DateTime,7);
	memcpy(Entry->SMSCTime,Entry2->SMSCTime,7);
	Entry->TPStatus = Entry2->TPStatus;
	Entry->TPUDL = Entry2->TPUDL;
	Entry->TPVP = Entry2->TPVP;
	Entry->firstbyte = Entry2->firstbyte;
	Entry->TPMR = Entry2->TPMR;
	Entry->TPPID = Entry2->TPPID;
}

GSM_Error WINAPI GPlusSMSGetDateTime(GSM_SMSEntry2 *Entry2,GSM_DateTime *DT)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetDateTime(DT);
}

GSM_Error WINAPI GPlusSMSGetSMSCTime(GSM_SMSEntry2 *Entry2,GSM_DateTime *DT)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetSMSCTime(DT);
}

GSM_Error WINAPI GPlusSMSGetSMSCNumber(GSM_SMSEntry2 *Entry2,wchar_t *Number)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetSMSCNumber(Number);
}

GSM_Error WINAPI GPlusSMSGetPhoneNumber(GSM_SMSEntry2 *Entry2,wchar_t *Number)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetPhoneNumber(Number);
}

SMS_Type WINAPI GPlusSMSGetType(GSM_SMSEntry2 *Entry2)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetType();	
}

SMS_Coding_Type WINAPI GPlusSMSGetCoding(GSM_SMSEntry2 *Entry2)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetCoding();	
}

GSM_Error WINAPI GPlusSMSGetDecodedText(GSM_SMSEntry2 *Entry2,wchar_t *Text)
{
	GSM_SMSEntry Entry;

	CopySMSEntry2ToSMSEntry(Entry2, &Entry);
	return Entry.GetDecodedText(Text);
}

GSM_Error WINAPI GPlusGetNextSMS(int numer, GSM_SMSListEntry2 *E, BOOLEAN start)
{
	GSM_SMSList		Entry;
	GSM_SMSListSubEntry	*SubEntry;
	GSM_SMSEntry		*SMS;
	GSM_SMSListSubEntry2	*Sub = NULL;
	GSM_Error    		error;
	int			len;
	
	Entry.Location = E->Location;
	Entry.Folder   = E->Folder;
	error = Phones[numer].s->Phones->Current->GetNextSMS(&Entry,start);
	if (error == GSM_ERR_NONE) {
		E->Location	= Entry.Location;
		E->Folder	= Entry.Folder;
		E->Memory	= Entry.Memory;
		E->Icon		= Entry.Icon;
		E->SaveDateTimeAvailable = Entry.SaveDateTimeAvailable;
		if (Entry.SaveDateTimeAvailable) {
			memcpy(&E->SaveDateTime,&Entry.SaveDateTime,sizeof(GSM_DateTime));
		}
		E->Name 	= NULL;
		if (Entry.GetName()!=NULL) {
			len = UnicodeLength(Entry.GetName())+1;
			E->Name = (wchar_t *)malloc(len*sizeof(wchar_t));
			CopyUnicodeString(E->Name,Entry.GetName());
		} 
		E->SubEntries 	= NULL;

		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry)) {
			SMS = SubEntry->GetSMS();
			if (Sub == NULL) {
				E->SubEntries = new GSM_SMSListSubEntry2;
				Sub = E->SubEntries;
			} else {
				Sub->Next = new GSM_SMSListSubEntry2;
				Sub = Sub->Next;
			}
			Sub->SMS.UserData = NULL;
			if (SMS->UserData.size()!=0) {
				Sub->SMS.UserData = (unsigned char *)malloc(SMS->UserData.size());
				Sub->SMS.UserDataLen = SMS->UserData.size();
				memcpy(Sub->SMS.UserData,SMS->UserData.data(),SMS->UserData.size());

			} 
			Sub->SMS.PhoneNumber = NULL;
			if (SMS->PhoneNumber.size()!=0) {
				Sub->SMS.PhoneNumber = (unsigned char *)malloc(SMS->PhoneNumber.size());
				Sub->SMS.PhoneNumberLen = SMS->PhoneNumber.size();
				memcpy(Sub->SMS.PhoneNumber,SMS->PhoneNumber.data(),SMS->PhoneNumber.size());
			} 
			Sub->SMS.SMSCNumber = NULL;
			if (SMS->SMSCNumber.size()!=0) {
				Sub->SMS.SMSCNumber = (unsigned char *)malloc(SMS->SMSCNumber.size());
				Sub->SMS.SMSCNumberLen = SMS->SMSCNumber.size();
				memcpy(Sub->SMS.SMSCNumber,SMS->SMSCNumber.data(),SMS->SMSCNumber.size());
			} 
			Sub->SMS.TPDCS = SMS->TPDCS;
			memcpy(Sub->SMS.DateTime,SMS->DateTime,7);
			memcpy(Sub->SMS.SMSCTime,SMS->SMSCTime,7);
			Sub->SMS.TPStatus = SMS->TPStatus;
			Sub->SMS.TPUDL = SMS->TPUDL;
			Sub->SMS.TPVP = SMS->TPVP;
			Sub->SMS.firstbyte = SMS->firstbyte;
			Sub->SMS.TPMR = SMS->TPMR;
			Sub->SMS.TPPID = SMS->TPPID;

			Sub->Next = NULL;
		}		
	}

	return error;
}

void WINAPI GPlusCleanSMSListEntry2(GSM_SMSListEntry2 *E)
{
	GSM_SMSListSubEntry2 *SubEntry;
	
	while (true) {
		if (E->SubEntries == NULL) break;
		if (E->SubEntries->Next == NULL) {
			delete(E->SubEntries);
			E->SubEntries = NULL;
			break;
		}
		SubEntry = E->SubEntries;
		while (true) {
			if (SubEntry->Next->Next == NULL) break;
			SubEntry = SubEntry->Next;
		}
		free(SubEntry->Next);
		SubEntry->Next = NULL;
	}
	free(E->Name);
	E->Name = NULL;
}

typedef struct _GSM_SMSFoldersSubEntry2 GSM_SMSFoldersSubEntry2;

struct _GSM_SMSFoldersSubEntry2 {
	BOOLEAN				Inbox;
	GSM_MemoryType			Memory;
	wchar_t		 		*Name;
	GSM_SMSFoldersSubEntry2 	*Next;
};

typedef struct {
	GSM_SMSFoldersSubEntry2		*SubEntries;
} GSM_SMSFoldersEntry2;

GSM_Error WINAPI GPlusGetSMSFolders(int numer, GSM_SMSFoldersEntry2 *E)
{
	GSM_SMSFolders 	Entry;
	GSM_Error    		error;
	GSM_SMSFoldersSubEntry2	*Sub = NULL;
	GSM_SMSFoldersSubEntry	*SubEntry;
	int			len;

	error = Phones[numer].s->Phones->Current->GetSMSFolders(&Entry);

	if (error == GSM_ERR_NONE) {
		E->SubEntries 	= NULL;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry)) {
			if (Sub == NULL) {
				E->SubEntries = new GSM_SMSFoldersSubEntry2;
				Sub = E->SubEntries;
			} else {
				Sub->Next = new GSM_SMSFoldersSubEntry2;
				Sub = Sub->Next;
			}
			Sub->Inbox = SubEntry->Inbox;
			Sub->Memory = SubEntry->Memory;
			Sub->Name = NULL;
			if (SubEntry->GetName()!=NULL) {
				len = UnicodeLength(SubEntry->GetName())+1;
				Sub->Name = (wchar_t *)malloc(len*sizeof(wchar_t));
				CopyUnicodeString(Sub->Name,SubEntry->GetName());
			}
			Sub->Next = NULL;
		}		
	}

	return error;
}

void WINAPI GPlusCleanSMSFoldersEntry2(GSM_SMSFoldersEntry2 *E)
{
	GSM_SMSFoldersSubEntry2 *SubEntry;
	
	while (true) {
		if (E->SubEntries == NULL) break;
		if (E->SubEntries->Next == NULL) {
			delete(E->SubEntries);
			E->SubEntries = NULL;
			break;
		}
		SubEntry = E->SubEntries;
		while (true) {
			if (SubEntry->Next->Next == NULL) break;
			SubEntry = SubEntry->Next;
		}
		free(SubEntry->Next);
		SubEntry->Next = NULL;
	}
}

typedef struct {
	int			Location;
	unsigned char		RelativeValidity;
	SMS_Format		Format;
	wchar_t		 	*Name;
	wchar_t		 	*SMSCNumber;
	wchar_t		 	*DefaultNumber;
} GSM_SMSC2;

GSM_Error WINAPI GPlusGetSMSC(int numer, GSM_SMSC2 *E)
{
	GSM_SMSC		Entry;
	GSM_Error    		error;
	int			len;

	Entry.Location = E->Location;
	error = Phones[numer].s->Phones->Current->GetSMSC(&Entry);

	if (error == GSM_ERR_NONE) {
		E->Format = Entry.Format;
		E->RelativeValidity = Entry.RelativeValidity;
		E->Name = NULL;
		if (Entry.GetName()!=NULL) {
			len = UnicodeLength(Entry.GetName())+1;
			E->Name = (wchar_t *)malloc(len*sizeof(wchar_t));
			CopyUnicodeString(E->Name,Entry.GetName());
		}
		E->SMSCNumber = NULL;
		if (Entry.GetSMSCNumber()!=NULL) {
			len = UnicodeLength(Entry.GetSMSCNumber())+1;
			E->SMSCNumber = (wchar_t *)malloc(len*sizeof(wchar_t));
			CopyUnicodeString(E->SMSCNumber,Entry.GetSMSCNumber());
		}
		E->DefaultNumber = NULL;
		if (Entry.GetDefaultNumber()!=NULL) {
			len = UnicodeLength(Entry.GetDefaultNumber())+1;
			E->DefaultNumber = (wchar_t *)malloc(len*sizeof(wchar_t));
			CopyUnicodeString(E->DefaultNumber,Entry.GetDefaultNumber());
		}
	}
	return error;
}

void WINAPI GPlusCleanSMSC2(GSM_SMSC2 *E)
{
	delete(E->Name);
	E->Name = NULL;
	delete(E->SMSCNumber);
	E->SMSCNumber = NULL;
	delete(E->DefaultNumber);
	E->DefaultNumber = NULL;
}

BOOL WINAPI DllMain (HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	int i;

	switch (ul_reason_for_call) {
		case DLL_PROCESS_ATTACH:
			for (i=0;i<10;i++) {
				Phones[i].s = new GSM_StateMachine(NULL,"",false);
			}	
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			for (i=0;i<10;i++) {
				delete(Phones[i].s);
			}
			break;
    	}
 	return TRUE;

}
