/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../cfg/config.h" //msvc2005
#include "../../misc/cfg.h"
#include "../../misc/coding/coding.h"
#include "../gsmpbk.h"
#include "gsmback.h"

GSM_Error GSM_Backup::ReadFromTextFile(char *FileName)
{
	CFG_File 		File;
	CFG_File_Section 	*Section;
	wchar_t			*value, x[200];
	char			x2[100];
	GSM_PBKEntry		*PBKEntry;
	GSM_PBK_SubEntryType	PBKType;
	GSM_CalendarEntry	*CalEntry;
	GSM_Calendar_Type	CalType;
	GSM_DateTime		DT;
	int			i;

	if (!File.ReadFile(FileName)) return GSM_ERR_UNKNOWN;

	EncodeUnicode("Backup",x);
	value = File.GetValue(x,EncodeUnicodeString("Format"));
	if (value == NULL) return GSM_ERR_UNKNOWN;

	EncodeUnicode("PhonePBK",x);
	Section = NULL;
	while (File.GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x,Section->GetName(),8) != 0) continue;

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("Location"));
		if (value == NULL) continue;

		PBKEntry 		= new GSM_PBKEntry;
		PBKEntry->Location 	= atoi(DecodeUnicodeString(value));
		PBKEntry->Memory	= MEM_PHONE;
		for (i=0;i<20;i++) {
			sprintf(x2,"Entry%02iType",i);
			value = File.GetValue(Section->GetName(),EncodeUnicodeString(x2));
			if (value == NULL) continue;

			PBKType = PBK_Not_Assigned;
			if (!wcscmp(value,EncodeUnicodeString("Name"))) 		PBKType = PBK_Text_Name;
			if (!wcscmp(value,EncodeUnicodeString("NumberMobile"))) 	PBKType = PBK_Text_Phone_Mobile;
			if (!wcscmp(value,EncodeUnicodeString("NumberHome"))) 		PBKType = PBK_Text_Phone_Home;
			if (!wcscmp(value,EncodeUnicodeString("NumberWork"))) 		PBKType = PBK_Text_Phone_Work;
			if (!wcscmp(value,EncodeUnicodeString("NumberFax"))) 		PBKType = PBK_Text_Phone_Fax;
			if (!wcscmp(value,EncodeUnicodeString("NumberGeneral"))) 	PBKType = PBK_Text_Phone_General;
			if (!wcscmp(value,EncodeUnicodeString("Postal"))) 		PBKType = PBK_Text_Postal;
			if (!wcscmp(value,EncodeUnicodeString("Note"))) 		PBKType = PBK_Text_Note;
			if (!wcscmp(value,EncodeUnicodeString("Email"))) 		PBKType = PBK_Text_Email;
			if (PBKType == PBK_Not_Assigned) continue;

			sprintf(x2,"Entry%02iText",i);
			value = File.GetValue(Section->GetName(),EncodeUnicodeString(x2));
			if (value == NULL) continue;
			if (UnicodeLength(value)==0) continue;

			value[UnicodeLength(value)-1] = 0;
			PBKEntry->AddText(PBKType,value+1);
		}
		Add_ME_PBK(PBKEntry);
	}

	EncodeUnicode("Calendar",x);
	Section = NULL;
	while (File.GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x,Section->GetName(),8) != 0) continue;

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("Type"));
		if (value == NULL) continue;

		CalType = Calendar_Type_Not_Assigned;
		if (!wcscmp(value,EncodeUnicodeString("Meeting"))) 	CalType = Calendar_Type_Meeting;
		if (!wcscmp(value,EncodeUnicodeString("Memo"))) 	CalType = Calendar_Type_Memo;
		if (!wcscmp(value,EncodeUnicodeString("Call"))) 	CalType = Calendar_Type_Call;
		if (!wcscmp(value,EncodeUnicodeString("Birthday"))) 	CalType = Calendar_Type_Birthday;
		if (!wcscmp(value,EncodeUnicodeString("Reminder"))) 	CalType = Calendar_Type_Reminder;
		if (CalType == Calendar_Type_Not_Assigned) continue;

		CalEntry = new GSM_CalendarEntry;
		CalEntry->Type = CalType;

		// ----------------------- times ------------------------------

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("StartTime"));
		if (value != NULL && ReadVCalendarDateTime(DecodeUnicodeString(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_Start, DT);
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("StopTime"));
		if (value != NULL && ReadVCalendarDateTime(DecodeUnicodeString(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End, DT);
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("AlarmType"));
		if (value != NULL && !strcmp(DecodeUnicodeString(value),"Silent")) {
			value = File.GetValue(Section->GetName(),EncodeUnicodeString("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(DecodeUnicodeString(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_SilentAlarm, DT);
			}
		} else {
			value = File.GetValue(Section->GetName(),EncodeUnicodeString("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(DecodeUnicodeString(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_ToneAlarm, DT);
			}
		}
		
		value = File.GetValue(Section->GetName(),EncodeUnicodeString("RepeatStopDate"));
		if (value != NULL && ReadVCalendarDateTime(DecodeUnicodeString(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End_Repeat, DT);
		}

		// ----------------------- texts ------------------------------

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("EventLocation"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Location, value+1);
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("Text"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Text, value+1);
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("Phone"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Phone, value+1);
		}

		// ------------------------ int -------------------------------

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("RepeatDayOfWeek"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_DayOfWeek, atoi(DecodeUnicodeString(value)));
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("RepeatDay"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Day, atoi(DecodeUnicodeString(value)));
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("RepeatMonth"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Month, atoi(DecodeUnicodeString(value)));
		}

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("RepeatFrequency"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Frequency, atoi(DecodeUnicodeString(value)));
		}

		Add_Cal(CalEntry);
	}

	return GSM_ERR_NONE;
}
