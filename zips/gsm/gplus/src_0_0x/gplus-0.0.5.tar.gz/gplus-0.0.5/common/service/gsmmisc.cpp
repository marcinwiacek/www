/* (C) 2005 by Marcin Wiacek www.mwiacek.com */

#include <string.h>

#include "../misc/coding/coding.h"
#include "gsmmisc.h"

typedef struct {
	char 		*Description;
	GSM_MemoryType	Type;
} GSM_MemoryTypeInfo;

GSM_MemoryTypeInfo GSM_MemoryTypeInfos[] = {
	"ME", 		MEM_PHONE,
	"DC", 		MEM_PHONE_DIALLED,
	"MC", 		MEM_PHONE_MISSED,
	"RC", 		MEM_PHONE_RECEIVED,
	"SM", 		MEM_SIM,
	"ON", 		MEM_SIM_OWN,
	"MT",		MEM_SIM_PHONE,
	"unknown", 	MEM_Unknown
};

GSM_MemoryType GSM_GetMemoryType(char *Buffer)
{
	int i=0;
	
	while(GSM_MemoryTypeInfos[i].Type != MEM_Unknown) {
		if (!strcmp(GSM_MemoryTypeInfos[i].Description,Buffer)) return GSM_MemoryTypeInfos[i].Type;
		i++;
	}
	return MEM_Unknown;
}

char *GSM_GetMemoryName(GSM_MemoryType Type)
{
	int i=0;
	
	while(1) {
		if (GSM_MemoryTypeInfos[i].Type == Type) return GSM_MemoryTypeInfos[i].Description;
		i++;
	}
}

GSM_Error GSM_DecodeSMSNumber(wchar_t *Destination, const unsigned char *Source, int len, BOOLEAN semioctets)
{
	int len2 = Source[0],pos=0;
	
	if (semioctets == TRUE) {
		if (len2 % 2) len2++;
		len2 = len2/2+1;
	}
	len2--;
	if ((Source[1] & 112) == (0xD0 & 112)) {		
		//alphanumeric
		GSM_DecodeSMSText(Destination, Source+2, len2, len2, 0);
		Destination[len2] = 0;
		return GSM_ERR_NONE;
	}
	if ((Source[1] & 112) == (0x91 & 112)) Destination[pos++] = '+';
	DecodeBCD(Destination+pos,Source+2,len2);
	return GSM_ERR_NONE;
}

/* ETSI GSM 03.38, section 6.2.1: Default alphabet for SMS messages */
static unsigned char GSM_DefaultAlphabetUnicode[128+1][2] =
{
	{0x00,0x40},{0x00,0xa3},{0x00,0x24},{0x00,0xA5},
	{0x00,0xE8},{0x00,0xE9},{0x00,0xF9},{0x00,0xEC},/*0x08*/
	{0x00,0xF2},{0x00,0xC7},{0x00,'\n'},{0x00,0xD8},
	{0x00,0xF8},{0x00,'\r'},{0x00,0xC5},{0x00,0xE5},
	{0x03,0x94},{0x00,0x5f},{0x03,0xA6},{0x03,0x93},
	{0x03,0x9B},{0x03,0xA9},{0x03,0xA0},{0x03,0xA8},
	{0x03,0xA3},{0x03,0x98},{0x03,0x9E},{0x00,0xb9},
	{0x00,0xC6},{0x00,0xE6},{0x00,0xDF},{0x00,0xC9},/*0x20*/
	{0x00,' ' },{0x00,'!' },{0x00,'\"'},{0x00,'#' },
	{0x00,0xA4},{0x00,'%' },{0x00,'&' },{0x00,'\''},
	{0x00,'(' },{0x00,')' },{0x00,'*' },{0x00,'+' },
	{0x00,',' },{0x00,'-' },{0x00,'.' },{0x00,'/' },/*0x30*/
	{0x00,'0' },{0x00,'1' },{0x00,'2' },{0x00,'3' },
	{0x00,'4' },{0x00,'5' },{0x00,'6' },{0x00,'7' },
	{0x00,'8' },{0x00,'9' },{0x00,':' },{0x00,';' },
	{0x00,'<' },{0x00,'=' },{0x00,'>' },{0x00,'?' },/*0x40*/
	{0x00,0xA1},{0x00,'A' },{0x00,'B' },{0x00,'C' },
	{0x00,'D' },{0x00,'E' },{0x00,'F' },{0x00,'G' },
	{0x00,'H' },{0x00,'I' },{0x00,'J' },{0x00,'K' },
	{0x00,'L' },{0x00,'M' },{0x00,'N' },{0x00,'O' },
	{0x00,'P' },{0x00,'Q' },{0x00,'R' },{0x00,'S' },
	{0x00,'T' },{0x00,'U' },{0x00,'V' },{0x00,'W' },
	{0x00,'X' },{0x00,'Y' },{0x00,'Z' },{0x00,0xC4},
	{0x00,0xD6},{0x00,0xD1},{0x00,0xDC},{0x00,0xA7},
	{0x00,0xBF},{0x00,'a' },{0x00,'b' },{0x00,'c' },
	{0x00,'d' },{0x00,'e' },{0x00,'f' },{0x00,'g' },
	{0x00,'h' },{0x00,'i' },{0x00,'j' },{0x00,'k' },
	{0x00,'l' },{0x00,'m' },{0x00,'n' },{0x00,'o' },
	{0x00,'p' },{0x00,'q' },{0x00,'r' },{0x00,'s' },
	{0x00,'t' },{0x00,'u' },{0x00,'v' },{0x00,'w' },
	{0x00,'x' },{0x00,'y' },{0x00,'z' },{0x00,0xE4},
	{0x00,0xF6},{0x00,0xF1},{0x00,0xFC},{0x00,0xE0},
	{0x00,0x00}
};

/* ETSI GSM 3.38
 * Some sequences of 2 default alphabet chars (for example,
 * 0x1b, 0x65) are visible as one single additional char (for example,
 * 0x1b, 0x65 gives Euro char saved in Unicode as 0x20, 0xAC)
 * This table contains:
 * 1. two first chars means sequence of chars from GSM default alphabet
 * 2. two second is target (encoded) char saved in Unicode
 */
static unsigned char GSM_DefaultAlphabetCharsExtension[][4] =
{
	{0x1b,0x14,0x00,0x5e},	/* ^	*/
	{0x1b,0x28,0x00,0x7b},	/* {	*/
	{0x1b,0x29,0x00,0x7d},	/* }	*/
	{0x1b,0x2f,0x00,0x5c},	/* \	*/
	{0x1b,0x3c,0x00,0x5b},	/* [	*/
	{0x1b,0x3d,0x00,0x7E},	/* ~	*/
	{0x1b,0x3e,0x00,0x5d},	/* ]	*/
	{0x1b,0x40,0x00,0x7C},	/* |	*/
	{0x1b,0x65,0x20,0xAC},	/* Euro */
	{0x00,0x00,0x00,0x00}
};

GSM_Error GSM_DecodeSMSText(wchar_t *Destination, const unsigned char *Source, int len, int len3, int udhlen)
{
	unsigned int		i = 0,chr,j,z,p,q,r,len2;
	wchar_t			prev;

	i = 0;
	do {
		i+=7;
	} while ((i-udhlen)%i<0);
	len2 = len-(udhlen*8 + (i-udhlen)%i) / 7;
	i = 0;
	j = 1;
	q = 0;
	for (p=0;p<len2;p++) {
		chr = 0;
		for (z=1;z<128;z=z*2) {
			if (Source[i]&j) chr += z;
			if (j == 128) {
				j = 1;
				i++;
				if (i <= (unsigned int)len3) continue;
				return GSM_ERR_GPLUSNOTSUPPORTED;
			}
			j = j * 2;
		}
		Destination[q] = GSM_DefaultAlphabetUnicode[chr][0]*256+GSM_DefaultAlphabetUnicode[chr][1];
		if (p>0) {
			r = 0;
			while (GSM_DefaultAlphabetCharsExtension[r][0] != 0x00) {
				if (prev == GSM_DefaultAlphabetCharsExtension[r][0] &&
				    chr == GSM_DefaultAlphabetCharsExtension[r][1]) {
					q--;
					Destination[q] = GSM_DefaultAlphabetCharsExtension[r][2]*256+
						  GSM_DefaultAlphabetCharsExtension[r][3];
					break;
				}
				r++;
			}
		}
		prev = chr;
		q++;
	}
	Destination[q] = 0;

	return GSM_ERR_NONE;
}
