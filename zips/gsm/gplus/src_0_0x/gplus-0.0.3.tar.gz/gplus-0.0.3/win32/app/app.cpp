/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

#include "dll.h"

// this function is created for easier operating on unicode strings
// (almost) each language has similiar
unsigned int DecodeWithUnicodeAlphabet(wchar_t src, char *dest)
{
	int r = wctomb(dest, src);

	if (r == -1) {
		r = 1;
		*dest = '?';
	}
	return r;
}

// this function is created for easier operating on unicode strings
// (almost) each language has similiar
char *DecodeUnicodeString (wchar_t *src)
{
	int 		pos = 0, pos2 = 0;
	static char 	dst[1000];

	while (src[pos] != 0) {
		pos2+=DecodeWithUnicodeAlphabet(src[pos], dst+pos2);
		pos++;
	}
	dst[pos2] = 0;
	return dst;
}

//example, how to set own reply handler
#define DCT4GetUEM 50000

GSM_Error __stdcall DCT4ReplyGetUEM(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID)
{
	// Struct is pointer to any structure given during frame sending
	char *Buf = (char *)Struct;

	//we must check Type of message
	//and how long it is
	if (MsgType == 0x1B && MsgLength > 4) {
		//message is enough long and now we check subtype
		if (MsgBuffer[3] == 0x08) {
			//if we didn't ask for it return error
			if (RequestID != DCT4GetUEM) return GSM_ERR_FRAME_NOTREQUESTED;
			//we wanted it now and we fill our structure and return
			strcpy(Buf,(const char *)MsgBuffer+10);
			return GSM_ERR_NONE;
		}
	}

	//we must tell Gammu+, that we want to parse this frame by internal
	//module
	return GSM_ERR_FRAME_UNKNOWN;
}

void main(int argc, char *argv[])
{
	GSM_PBKStatus		PBKStatus;
	GSM_PBKEntry2		PBKEntry;
	GSM_PBKSubEntry2        *PBKSubEntry;
	GSM_Error 		error;
	unsigned char 		text[50],text2[50],text3[50];
	BOOLEAN 		Start;

	GPlusGetGPlusVersion((char *)text);
	printf("Gammu+ version: %s\n",text);

	Start = TRUE;
	while (true) {
		GPlusGetNextSupportedPhoneInfo(Start, (char *)text, (char *)text2, (char *)text3);
		if (text2[0] == 0) break;
		Start = FALSE;
		printf("Model %s, codename %s, protocol %s\n",text,text3,text2);
	}

	printf("error description for GSM_ERR_DEVICEREAD is %s\n",GPlusGetErrorInfo(GSM_ERR_DEVICEREAD));

//	GPlusEnableDebug(0, "filename");

	/* now start part requiring phone connection */

//	error = GPlusOpen(0,"com1:","fbus","");
//	error = GPlusOpen(0,"","bluephonet","");
//	error = GPlusOpen(0,"","dku2phonet","");
	error = GPlusOpen(0,"","irdaphonet","");
	if (error != GSM_ERR_NONE) return;

	error = GPlusGetIMEI(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("IMEI: %s\n",text);

//	GPlusDisableDebug(0);

	error = GPlusGetModel(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Model: %s\n",text);

	error = GPlusGetCodeNameModel(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Model CodeName: %s\n",text);

	error = GPlusGetFirmwareVersion(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Firmware version: %s\n",text);

	error = GPlusGetFirmwareDate(0,text);
	if (error != GSM_ERR_NONE) return;
	printf("Firmware date: %s\n",text);

	strcpy(PBKStatus.Memory,"SM");
	error = GPlusGetPBKMemoryStatus(0,&PBKStatus);
	if (error != GSM_ERR_NONE) return;
	printf("SIM phonebook: Used %i, Free %i\n",PBKStatus.Used, PBKStatus.Free);

	strcpy(PBKStatus.Memory,"ME");
	error = GPlusGetPBKMemoryStatus(0,&PBKStatus);
	if (error != GSM_ERR_NONE) return;
	printf("Phone phonebook: Used %i, Free %i\n",PBKStatus.Used, PBKStatus.Free);

	PBKEntry.SubEntries = NULL;
	strcpy(PBKEntry.Memory,"ME");
	PBKEntry.Location = 2;	
	error = GPlusGetPBKMemory(0,&PBKEntry);
	if (error != GSM_ERR_NONE) {
		GPlusCleanPBKEntry2(&PBKEntry);
		return;
	}
	PBKSubEntry = PBKEntry.SubEntries;
	while (PBKSubEntry != NULL) {
		switch (PBKSubEntry->Type) {
		case PBK_Text_Phone_General:
			printf("General number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Mobile:
			printf("Mobile number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Home:
			printf("Home number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Work:
			printf("Work number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Phone_Fax:
			printf("Fax number \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Email:
			printf("Email \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_URL:
			printf("URL \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Postal:
			printf("Postal address \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_UserID:
			printf("User ID \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Note:
			printf("Text note \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		case PBK_Text_Name:
			printf("Name \"%s\"\n",DecodeUnicodeString(PBKSubEntry->Text));
			break;
		}
		PBKSubEntry = PBKSubEntry->Next;
	}

//	PBKEntry.Location = 3;	
//	error = GPlusSetPBKMemory(0,&PBKEntry);
//	if (error != GSM_ERR_NONE) {
//		GPlusCleanPBKEntry2(&PBKEntry);
//		return;
//	}

	GPlusCleanPBKEntry2(&PBKEntry);

	if (!strcmp(GPlusGetPhoneModuleName(0),"n6510")) {
		//we set handler
		GPlusSetUserReply(0,&DCT4ReplyGetUEM);
		error = GPlusWrite(0,(unsigned char *)"\x00\x03\x02\x07\x00\x08",6, 0x1B, 4, DCT4GetUEM, text);
		if (error != GSM_ERR_NONE) return;
		GPlusSetUserReply(0,NULL);
		printf("UEM      : %s\n",text);
	}

	error = GPlusClose(0);
	if (error != GSM_ERR_NONE) return;
}
