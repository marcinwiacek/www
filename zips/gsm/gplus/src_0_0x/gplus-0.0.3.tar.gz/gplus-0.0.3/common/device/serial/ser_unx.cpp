/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "ser_unx.h"

GSM_Error GSM_Device_Serial::Open(char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones)
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Close()
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Read(unsigned char *buf, int *len)
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::Write(const unsigned char *buf, int len)
{
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Device_Serial::SetParameters(int speed, int bits, bool parity, int stopbits)
{
        return GSM_ERR_NONE;
}

GSM_Error GSM_Device_Serial::SetLines(bool dtr, bool rts)
{
        return GSM_ERR_NONE;
}
