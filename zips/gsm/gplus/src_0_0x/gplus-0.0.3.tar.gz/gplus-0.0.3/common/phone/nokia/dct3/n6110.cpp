/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../misc/coding/coding.h"
#include "../../../protocol/gsmprot.h"
#include "../ndct34.h"
#include "n6110.h"
#include "ndct3.h"

GSM_Error GSM_Phone_N6110::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	int		ID2 = DCT3->GetID(), ID3 = DCT34->GetID();
	AnsStruct 	AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

if(Ans("\x03",0x03,0x02,ID_GetPBKEntry+ID,&AS)) return ReplyGetPBKMemory	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x05,ID_SetPBKEntry+ID,&AS)) return ReplySetPBKMemory	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x06,ID_SetPBKEntry+ID,&AS)) return ReplySetPBKMemory	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x08,ID_GetPBKStatus+ID,&AS))return ReplyGetPBKStatus 	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x09,ID_GetPBKStatus+ID,&AS))return ReplyGetPBKStatus 	(msg,Debug,(unsigned char *)Struct);

if(Ans("\x0A",0x03,0x71,ID_IncomingFrame,&AS))  return ReplyNetworkInfo		(msg,Debug,(unsigned char *)Struct);

if(Ans("\x40",0x02,0x64,ID_SetSecurity+ID2,&AS))return DCT3->ReplySetSecurity	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x40",0x02,0x66,ID_GetIMEI+ID2    ,&AS))return DCT3->ReplyGetIMEI    	(msg,Debug,(unsigned char *)Struct);

if(Ans("\xD2",0x02,0x00,ID_GetID+ID3,      &AS))return DCT34->ReplyGetID     	(msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_ERR_FRAME_NOTREQUESTED;
        return GSM_ERR_FRAME_UNKNOWN;
}

GSM_Error GSM_Phone_N6110::GetIMEI(unsigned char *IMEI)
{
	return DCT3->GetIMEI(*Debug,(*Phones)->Current,IMEI);
}

GSM_Error GSM_Phone_N6110::GetCodeNameModel(unsigned char *Model)
{
	return DCT34->GetCodeNameModel(Model,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6110::GetFirmwareVersion(unsigned char *Firm)
{
	return DCT34->GetFirmwareVersion(Firm,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6110::GetFirmwareDate(unsigned char *Dat)
{
	return DCT34->GetFirmwareDate(Dat,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6110::GetManufacturer(unsigned char *Manufacturer)
{
	strcpy((char *)Manufacturer,"Nokia");
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6110::ReplyGetPBKStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKStatus *Status = (GSM_PBKStatus *)S;

	(*Debug)->Deb("RECEIVED: PBK memory status\n");

	if (msg->Buffer.data()[3] == 0x08) {
		Status->Used = msg->Buffer.data()[6];
		Status->Free = msg->Buffer.data()[5];
		(*Debug)->Deb("Used - %i\n",Status->Used);
		(*Debug)->Deb("Free - %i\n",Status->Free);

	        return GSM_ERR_NONE;
	} else if (msg->Buffer.data()[3] == 0x09) {
		(*Debug)->Deb("Error %i\n",msg->Buffer.data()[4]);
	        return GSM_ERR_UNKNOWN;
	}
        return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Phone_N6110::GetPBKMemoryStatus(GSM_PBKStatus *Status)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x07, 0x00};

	Buff[4] = GetMemoryType(Status->Memory);
	if (Buff[4] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: getting status for %s memory\n",Status->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKStatus+ID, Status);
}

unsigned char GSM_Phone_N6110::GetMemoryType(char *Description)
{
	if (!strcmp(Description,"ME")) return 0x02;
	if (!strcmp(Description,"SM")) return 0x03;
	if (!strcmp(Description,"ON")) return 0x05;
	if (!strcmp(Description,"DC")) return 0x07;
	if (!strcmp(Description,"RC")) return 0x08;
	if (!strcmp(Description,"MC")) return 0x09;

	return 0x00;
}

GSM_Error GSM_Phone_N6110::Open(char *FrameID)
{
	GSM_Phone::Open(FrameID);

	if (FrameID[0] != 0) DCT34->SetFrameID(FrameID);

	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6110::ReplyGetPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_DateTime	*DT;
	char		Buff[400];
	int		Pos = 5, len;
	GSM_PBKEntry 	*Entry = (GSM_PBKEntry *)S;

	len = msg->Buffer.data()[Pos];
	Pos++;
	if (len != 0) {
		memcpy(Buff,msg->Buffer.data()+Pos,len);
		Buff[len] = 0;
		Entry->AddText(PBK_Text_Name,EncodeUnicodeString(Buff));
		Pos+=len;
	}

	len = msg->Buffer.data()[Pos];
	Pos++;
	if (len != 0) {
		memcpy(Buff,msg->Buffer.data()+Pos,len);
		Buff[len] = 0;
		Entry->AddText(PBK_Text_Phone_General,EncodeUnicodeString(Buff));
		Pos+=len;
	}

	if (!strcmp(Entry->Memory,"MC") || !strcmp(Entry->Memory,"RC") || !strcmp(Entry->Memory,"DC")) {
		DT = DCT34->NokiaGetDT(msg->Buffer.data()+Pos+2);
		if (DT->Day!=20 || DT->Month !=1 || DT->Year !=2118 ||
		    DT->Hour !=3 || DT->Minute!=14 || DT->Second!=7) {
			Entry->AddDateTime(PBK_DateTime_Call, (*DT));
		}
	}

	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6110::GetPBKMemory(GSM_PBKEntry *Entry)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x01,
		0x00,		//memory type
		0x00,		//location
		0x00};

	Buff[4] = GetMemoryType(Entry->Memory);
	if (Buff[4] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location > 255 || Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[5] = Entry->Location;
	if (!strcmp(Entry->Memory,"MC") || !strcmp(Entry->Memory,"DC") || !strcmp(Entry->Memory,"RC")) Buff[5]--;

	(*Debug)->Deb("SENT: getting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N6110::ReplySetPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	(*Debug)->Deb("RECEIVED: status for setting PBK memory");

	if (msg->Buffer.data()[3] == 0x05) {
		(*Debug)->Deb(" - OK\n");
		return GSM_ERR_NONE;
	} else if (msg->Buffer.data()[3] == 0x06) {
		switch (msg->Buffer.data()[4]) {
		case 0x7D:
			(*Debug)->Deb(" - too high location ?\n");
			return GSM_ERR_INVALIDLOCATION;			
		case 0x90:
			(*Debug)->Deb(" - too long..or other\n");
			return GSM_ERR_NOTSUPPORTED;
		default:
			(*Debug)->Deb(" - unknown %02X error\n",msg->Buffer.data()[4]);
		}
	}

	return GSM_ERR_UNKNOWN;
}

GSM_Error GSM_Phone_N6110::SetPBKMemory(GSM_PBKEntry *Entry)
{
	char			c;
	int			i;
	GSM_PBKSubEntry 	*SubEntry;
	wchar_t			*Name = NULL, *Phone = NULL;
	unsignedstring 		Buffer;
        unsigned char 		Buff[] = {
		NOKIA_FRAME1, 0x04,
		0x00,		// memory type
		0x00};		// location

	Buff[4] = GetMemoryType(Entry->Memory);
	if (Buff[4] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location > 255 || Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[5] = Entry->Location;

	Buffer.append((const unsigned char*)Buff,sizeof(Buff));

	SubEntry  = NULL;
	while (Entry->GetNext(&SubEntry)) {
		switch (SubEntry->GetType()) {
		case PBK_Text_Name:
			if (Name == NULL) Name = SubEntry->GetText();
			break;
		case PBK_Text_Phone_General:
			if (Phone == NULL) Phone = SubEntry->GetText();
			break;
		default:
			break;
		}
	}
	if (Phone == NULL) {
		SubEntry  = NULL;
		while (Entry->GetNext(&SubEntry)) {
			switch (SubEntry->GetType()) {
			case PBK_Text_Name:
				if (Name == NULL) Name = SubEntry->GetText();
				break;
			case PBK_Text_Phone_General:
			case PBK_Text_Phone_Mobile:
			case PBK_Text_Phone_Home:
			case PBK_Text_Phone_Work:
			case PBK_Text_Phone_Fax:
				if (Phone == NULL) Phone = SubEntry->GetText();
				break;
			default:
				break;
			}
		}
	}

	i = 0;
	if (i>256) i = 256;
	if (Name != NULL) i = strlen(DecodeUnicodeString(Name));
	c = i;
	Buffer.push_back(c);
	if (i!=0) Buffer.append((const unsigned char *)DecodeUnicodeString(Name),i);

	i = 0;
	if (i>256) i = 256;
	if (Phone != NULL) i = strlen(DecodeUnicodeString(Phone));
	c = i;
	Buffer.push_back(c);
	if (i!=0) Buffer.append((const unsigned char *)DecodeUnicodeString(Phone),i);
	
	Buffer.push_back(0xff);

	(*Debug)->Deb("SENT: setting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write((unsigned char *)Buffer.data(), Buffer.size(), 0x03, 4, ID_SetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N6110::DeletePBKMemory(GSM_PBKEntry *Entry)
{
	GSM_PBKEntry Entry2;

	Entry2.Location = Entry->Location;
	strcpy(Entry2.Memory,Entry->Memory);

	return SetPBKMemory(&Entry2);
}

GSM_Error GSM_Phone_N6110::ReplyNetworkInfo(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	return GSM_ERR_TIMEOUT;
}
