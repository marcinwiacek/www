/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <list>

#include "../gsmcomon.h"
#include "../misc/misc.h"
#include "../service/gsmpbk.h"

using namespace std;

#ifndef gsmphone_h
#define gsmphone_h

const int ID_None             	 = 1;
const int ID_IncomingFrame       = 2;
const int ID_GetIMEI             = 3;
const int ID_GetPBKStatus 	 = 4;
const int ID_GetPBKEntry	 = 5;
const int ID_SetPBKEntry	 = 6;
const int ID_DelPBKEntry	 = 7;

const int ID_Start		 = 7; //set it to last value above

class GSM_Device;
class GSM_AllDevices;
class GSM_AllProtocols;
class GSM_Protocol_Message;
class GSM_AllPhones;

class GSM_Phone_Info {
public:
        char                    *Protocol;
        char                    *Model;
        char                    *CodeNameModel;
        char                    *DeviceModel;
        char                    *Features;

        GSM_Phone_Info		(char *Mod, char *Code, char *Device, char *Prot, char *Feat);
        ~GSM_Phone_Info		();

	bool 			CompareProtocol(char *Pro);
};

typedef struct {
	int 	RequestID;
	bool 	FrameFound;
} AnsStruct;

class GSM_Phone
{
        friend class            GSM_AllPhones;
public:
        list <GSM_Phone_Info>   Info;
	char			*ModuleName,*ModulesRequired,*ModulesUsed;

        GSM_Phone		(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho);
        virtual 		~GSM_Phone();

	int 			GetID();
	GSM_Error		Read(int RequestID, void *Struct);
	GSM_Error		Write(unsigned char *buffer, int length, unsigned char type, int time, int request, void *Struct);
        virtual GSM_Error       Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID) = 0;
	void 			SetUserReply(GSM_Error(*UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID));

        virtual GSM_Error       Open(char *ID);
        virtual GSM_Error       Close();
        virtual GSM_Error       GetIMEI(unsigned char *IMEI);
	virtual GSM_Error	GetModel(unsigned char *Model);
	virtual GSM_Error	GetManufacturer(unsigned char *Manufacturer);
	virtual GSM_Error	GetFirmwareVersion(unsigned char *Firm);
	virtual GSM_Error	GetFirmwareDate(unsigned char *Date);
	virtual GSM_Error	GetCodeNameModel(unsigned char *CodeNameModel);	
	virtual GSM_Error	GetPBKMemoryStatus(GSM_PBKStatus *Status);	
	virtual GSM_Error	GetPBKMemory(GSM_PBKEntry *Entry);
	virtual GSM_Error	GetNextPBKMemory(void);
	virtual GSM_Error	SetPBKMemory(GSM_PBKEntry *Entry);
	virtual GSM_Error	AddPBKMemory(void);
	virtual GSM_Error	DeletePBKMemory(GSM_PBKEntry *Entry);
	virtual GSM_Error	DeleteAllPBKMemory(void);
protected:
	int			ID;
        GSM_Phone               *Next;

        GSM_Device              **Device;
        GSM_AllProtocols        **Protocols;
        GSM_AllPhones           **Phones;
        DebugInfo               **Debug;
	bool			Opened;
	GSM_Error		(*UserReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID);

	bool			Ans(char *MsgTyp, int SubTypeChar, unsigned char SubType, int Request, AnsStruct *AS);
};

class GSM_AllPhones
{
	friend class		GSM_Phone;
public:
        GSM_Phone               *Current;

        GSM_AllPhones		(DebugInfo **Deb);
        ~GSM_AllPhones		();

        void                    Add                (GSM_Phone *Phone);
        GSM_Error               Switch             (char *Pho, char *Pro);
        GSM_Error               SwitchToDeviceName (char *Pho, char *Pro);
        int                     GetNext            (GSM_Phone **Pho);
	int			GetID		   ();
private:
	int			ID;

        GSM_Phone               *AllPhones;
        DebugInfo               **Debug;

	char			*CFGModel;
	char			*Features;
	char			*Model;
	char			*CodeNameModel;

        unsigned char           ReceivedBuffer[200];
        int                     ReceivedLen, ReceivedPos;

        int                     ReplyNum;
};

#endif
