/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../misc/coding/coding.h"
#include "../../gsmcomon.h"
#include "../gsmphone.h"
#include "ndct34.h"

GSM_Phone_NDCT34::GSM_Phone_NDCT34(int id)
{
	FrameID = NULL;
	ID	= id;
}

int GSM_Phone_NDCT34::GetID()
{
	return ID;
}

GSM_Phone_NDCT34::~GSM_Phone_NDCT34()
{
	free(FrameID);
}

GSM_Error GSM_Phone_NDCT34::ReplyGetID(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident)
{
	int i;

	for (i=0;i<msg->Length;i++) {
		if (msg->Buffer[i] == 0x00) {
			Ident[i] = 32;
		} else {
			Ident[i] = msg->Buffer[i];
		}
	}
	Ident[i] = 0x00;
	(*Debug)->Deb("RECEIVED: phone identification\n");
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::PrivGetID(DebugInfo *Debug, GSM_Phone *Pho)
{
	unsigned char 	Buff[] = {NOKIA_FRAME1, 0x03, 0x00};
	unsigned char	Id[200];
	GSM_Error	error;

	Debug->Deb("SENT: Get identification\n");
	error=Pho->Write(Buff, 5, 0xD1, 2, ID_GetID+ID, Id);
	if (error == GSM_ERR_NONE) SetFrameID((char *)Id);
	return error;
}

GSM_Error GSM_Phone_NDCT34::GetCodeNameModel(unsigned char *Mod, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=5,counter=0;

	if (FrameID == NULL) {
		error = PrivGetID(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Mod[0] = 0x00;
	while(1) {
		if (FrameID[i]==0x0a) {
			if (counter == 2) break;
			counter++;
		} else {
			if (counter == 2) {
				Mod[strlen((const char *)Mod)+1] = 0x00;
				Mod[strlen((const char *)Mod)]   = FrameID[i];
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::GetFirmwareVersion(unsigned char *Firm, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=4,counter=0;

	if (FrameID == NULL) {
		error = PrivGetID(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Firm[0] = 0x00;
	while(1) {
		if (FrameID[i]==0x0a) {
			break;
		} else {
			counter++;
			if (counter >= 3) {
				if (strlen((const char *)Firm) == 0 && FrameID[i]==0x20) {
				} else {
					Firm[strlen((const char *)Firm)+1] = 0x00;
					Firm[strlen((const char *)Firm)]   = FrameID[i];
				}
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::GetFirmwareDate(unsigned char *Dat, DebugInfo *Debug, GSM_Phone *Pho)
{
	GSM_Error 	error;
	int		i=4,counter=0;

	if (FrameID == NULL) {
		error = PrivGetID(Debug,Pho);
		if (error != GSM_ERR_NONE) return error;				
	}
	Dat[0] = 0x00;
	while(1) {
		if (FrameID[i]==0x0a) {
			if (counter == 1) break;
			counter++;
		} else {
			if (counter == 1) {
				Dat[strlen((const char *)Dat)+1] = 0x00;
				Dat[strlen((const char *)Dat)]   = FrameID[i];
			}
		}
		i++;
	}
	return GSM_ERR_NONE;
}

unsigned char GSM_Phone_NDCT34::Get7110DCT4MemoryType(char *Description)
{
	if (!strcmp(Description,"DC")) return 0x01;
	if (!strcmp(Description,"MC")) return 0x02;
	if (!strcmp(Description,"RC")) return 0x03;
	if (!strcmp(Description,"ME")) return 0x05;
	if (!strcmp(Description,"SM")) return 0x06;
	if (!strcmp(Description,"ON")) return 0x17;
	return 0x00;
}

char *GSM_Phone_NDCT34::GetFrameID()
{
	return FrameID;
}

void GSM_Phone_NDCT34::SetFrameID(char *Id)
{
	FrameID = (char *)malloc(strlen((const char *)Id)+1);
	memcpy(FrameID,(const char *)Id,strlen((const char *)Id)+1);
}

GSM_Error GSM_Phone_NDCT34::EncodeEntryToPBK(DebugInfo *Debug, unsignedstring *Buffer, GSM_PBKEntry *Entry, int *Number)
{
	GSM_PBKSubEntry 	*SubEntry;
	int			Type, Type2;
	unsignedstring  	TempBuffer;

	(*Number) = 0;
	SubEntry  = NULL;
	while (Entry->GetNext(&SubEntry)) {
		TempBuffer.clear();
		Type = 0x00;

		switch (SubEntry->GetType()) {
		case PBK_Text_Phone_General:
			Type = NPBK_NUMBER_GENERAL; //no break
		case PBK_Text_Phone_Mobile:
			if (Type == 0x00) Type = NPBK_NUMBER_MOBILE; //no break
		case PBK_Text_Phone_Home:
			if (Type == 0x00) Type = NPBK_NUMBER_HOME; //no break
		case PBK_Text_Phone_Work:
			if (Type == 0x00) Type = NPBK_NUMBER_WORK; //no break
		case PBK_Text_Phone_Fax:
			if (Type == 0x00) Type = NPBK_NUMBER_FAX;
			Type2 = NPBK_NUMBER;
			TempBuffer.push_back(Type);
			TempBuffer.push_back(0x00);
			TempBuffer.push_back(0x00); //voice tag in dct3
			TempBuffer.push_back(((UnicodeLength(SubEntry->GetText())+1)*2)/256);
			TempBuffer.push_back(((UnicodeLength(SubEntry->GetText())+1)*2)%256);
			TempBuffer.append((const unsigned char *)NokiaSetUnicodeString(SubEntry->GetText()),(UnicodeLength(SubEntry->GetText())+1)*2);
			TempBuffer.push_back(0x00);
			break;			
		case PBK_Text_Note:
			Type = NPBK_NOTE; //no break
		case PBK_Text_Postal:
			if (Type == 0x00) Type = NPBK_POSTAL; //no break
		case PBK_Text_Email:
			if (Type == 0x00) Type = NPBK_EMAIL; //no break
		case PBK_Text_Name:
			if (Type == 0x00) Type = NPBK_NAME; //no break
		case PBK_Text_URL:
			if (Type == 0x00) Type = NPBK_URL;
			Type2 = Type;
			TempBuffer.push_back(((UnicodeLength(SubEntry->GetText())+1)*2)%256);
			TempBuffer.append((const unsigned char *)NokiaSetUnicodeString(SubEntry->GetText()),(UnicodeLength(SubEntry->GetText())+1)*2);
			TempBuffer.push_back(0x00);
			break;
		case PBK_Text_UserID:
			break;
		default:
			return GSM_ERR_NOTSUPPORTED;
		}

		if (TempBuffer.size() != 0) {
			Buffer->push_back(Type2);
			Buffer->push_back(0x00);
			Buffer->push_back((TempBuffer.size()+6) / 256);
			Buffer->push_back((TempBuffer.size()+6) % 256);
			Buffer->push_back(++(*Number));
			Buffer->append((const unsigned char*)TempBuffer.data(),TempBuffer.size());
			Buffer->push_back(0x00);
		}
	}

	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::DecodePBKToEntry(DebugInfo *Debug, const unsigned char *Buffer, GSM_PBKEntry *Entry)
{
	int 			i, Pos = 1;
	GSM_PBK_SubEntryType 	Type;

	Debug->Deb("  %i blocks\n",Buffer[0]);
	for (i=0;i<Buffer[0];i++) {
		Debug->Deb("    Block length %i, type %02X\n",Buffer[Pos+3]-6,Buffer[Pos]);
		Type = PBK_Not_Assigned;

		switch (Buffer[Pos]) {
		case NPBK_NUMBER:
			switch (Buffer[Pos+5]) {
			case NPBK_NUMBER_UNKNOWN1:
			case NPBK_NUMBER_UNKNOWN2:
			case NPBK_NUMBER_UNKNOWN3:
			case NPBK_NUMBER_GENERAL:
			case NPBK_NUMBER_BUG:
				Type = PBK_Text_Phone_General;
				Debug->Deb("      General number");
				break;
			case NPBK_NUMBER_MOBILE:
				Type = PBK_Text_Phone_Mobile;
				Debug->Deb("      Mobile number");
				break;
			case NPBK_NUMBER_HOME:
				Type = PBK_Text_Phone_Home;
				Debug->Deb("      Home number");
				break;
			case NPBK_NUMBER_WORK:
				Type = PBK_Text_Phone_Work;
				Debug->Deb("      Work number");
				break;
			case NPBK_NUMBER_FAX:
				Type = PBK_Text_Phone_Fax;
				Debug->Deb("      Fax number");
				break;
			default:
				Debug->Deb("      Unknown number \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+10)));
				return GSM_ERR_UNKNOWN;
			}
			Debug->Deb(" \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+10)));
			Entry->AddText(Type, NokiaGetUnicodeString(Buffer+Pos+10));

			/* ID for voice tags in DCT3 phones like 6210 */
			if (Buffer[Pos+7] != 0) {
			}
			break;
		case NPBK_NOTE:
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_Note;
				Debug->Deb("      Text note");
			}
		case NPBK_POSTAL: //no break;
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_Postal;
				Debug->Deb("      Postal");
			}
		case NPBK_EMAIL: // no break;
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_Email;
				Debug->Deb("      Email");
			}
		case NPBK_NAME: // no break;
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_Name;
				Debug->Deb("      Name");
			}
		case NPBK_URL: // no break;
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_URL;
				Debug->Deb("      URL");
			}
		case NPBK_USER_ID: // no break;
			if (Type == PBK_Not_Assigned) {
				Type = PBK_Text_UserID;
				Debug->Deb("      User ID");
			}
			Debug->Deb(" \"%s\"\n",DecodeUnicodeString(NokiaGetUnicodeString(Buffer+Pos+6)));
			Entry->AddText(Type, NokiaGetUnicodeString(Buffer+Pos+6));
			break;
		case NPBK_DATETIME:
			Debug->Deb("      DateTime\n");
			Entry->AddDateTime(PBK_DateTime_Call, *NokiaGetDT(Buffer+Pos+6));
			break;
		//todo
		case NPBK_SMSLIST_ID:
			Debug->Deb("      SMS list ID\n");
			break;
		case NPBK_PICTURE_ID:
			Debug->Deb("      Picture ID\n");
			break;
		case NPBK_VOICETAG_ID:
			Debug->Deb("      Voice tag ID\n");
			break;
		case NPBK_RINGTONEFILE_ID:
			Debug->Deb("      Ringtone file ID\n");
			break;
		case NPBK_RINGTONE_ID:
			Debug->Deb("      Ringtone ID\n");
			break;
		case NPBK_SIM_SPEEDDIAL:
			Debug->Deb("      Speed dial\n");
			break;
		case NPBK_SPEEDDIAL:
			Debug->Deb("      Speed dial\n");
			break;
		case NPBK_UNKNOWN1:
			Debug->Deb("      Unknown 1\n");
			break;
		case NPBK_UNKNOWN2:
			Debug->Deb("      Unknown 2\n");
			break;
		case NPBK_UNKNOWN3:
			Debug->Deb("      Unknown 3\n");
			break;
		case NPBK_UNKNOWN4:
			Debug->Deb("      Unknown 4\n");
			break;
		default:
			Debug->Deb("      Unknown block\n");
			return GSM_ERR_UNKNOWN;
		}
		Pos+=Buffer[Pos+3];
	}
	return GSM_ERR_NONE;
}

wchar_t *GSM_Phone_NDCT34::NokiaGetUnicodeString(const unsigned char *Buffer)
{
	static 		wchar_t dst[500];
	int 		pos=0;

	while (Buffer[pos*2] != 0 || Buffer[pos*2+1] != 0) {
		dst[pos] = Buffer[pos*2] * 256 + Buffer[pos*2+1];
		pos++;
	}
	dst[pos] = 0;
	return dst;
}

char *GSM_Phone_NDCT34::NokiaSetUnicodeString(wchar_t *Buffer)
{
	static 		char dst[5000];
	int 		pos=0;

	while (Buffer[pos] != 0) {
		dst[pos*2]   = Buffer[pos] / 256;
		dst[pos*2+1] = Buffer[pos] % 256;
		pos++;
	}
	dst[pos*2]   = 0;
	dst[pos*2+1] = 0;
	return dst;
}

GSM_DateTime *GSM_Phone_NDCT34::NokiaGetDT(const unsigned char *Buffer)
{
	static GSM_DateTime DT;

	DT.Year   = Buffer[0] * 256 + Buffer[1];
	DT.Month  = Buffer[2];
	DT.Day    = Buffer[3];
	DT.Hour   = Buffer[4];
	DT.Minute = Buffer[5];
	DT.Second = Buffer[6];

	return &DT;
}

GSM_Error GSM_Phone_NDCT34::ReplySetPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	if (msg->Buffer.data()[6] == 0x0F) {
		(*Debug)->Deb("RECEIVED: error setting PBK entry");
		switch (msg->Buffer.data()[10]) {
		case 0x36:
			(*Debug)->Deb(", too long text in subentry\n");
			return GSM_ERR_NOTSUPPORTED;
		case 0x3C:
			(*Debug)->Deb(", 0 subentries\n");
			return GSM_ERR_NOTSUPPORTED;
		case 0x3d:
			(*Debug)->Deb(", unknown subentry type\n");
			return GSM_ERR_NOTSUPPORTED;
		case 0x3e:
			(*Debug)->Deb(", too much subentries\n");
			return GSM_ERR_NOTSUPPORTED;
		default:
			(*Debug)->Deb(", code %02X\n",msg->Buffer.data()[10]);
		        return GSM_ERR_UNKNOWN;
		}
	}

	(*Debug)->Deb("RECEIVED: PBK entry set OK\n");
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_NDCT34::ReplyDelPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	return GSM_ERR_NONE;
}
