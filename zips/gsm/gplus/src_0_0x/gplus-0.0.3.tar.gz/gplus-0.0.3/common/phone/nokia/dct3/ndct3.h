/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../../gsmcomon.h"
#include "../../../protocol/gsmprot.h"

#ifndef __ndct3
#define __ndct3

const int ID_SetSecurity = 1 + ID_Start;

class GSM_Phone_NDCT3
{
public:
	GSM_Phone_NDCT3(int id);

	GSM_Error 	SetSecurity	(DebugInfo *Debug, GSM_Phone *Pho, unsigned char status);
	GSM_Error 	GetIMEI		(DebugInfo *Debug, GSM_Phone *Pho, unsigned char *IMEI);

	GSM_Error 	ReplySetSecurity(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Ident);
	GSM_Error 	ReplyGetIMEI	(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);

	int		GetID		();
private:
	int ID;
};

#endif
