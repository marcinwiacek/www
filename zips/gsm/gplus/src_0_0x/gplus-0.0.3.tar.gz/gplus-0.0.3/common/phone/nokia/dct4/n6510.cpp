/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../protocol/gsmprot.h"
#include "../ndct34.h"
#include "n6510.h"

GSM_Error GSM_Phone_N6510::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	int		ID3 = DCT34->GetID();
	AnsStruct 	AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

if(Ans("\x03",0x03,0x04,ID_GetPBKStatus+ID,&AS))return ReplyGetPBKStatus 		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x08,ID_GetPBKEntry+ID, &AS))return ReplyGetPBKMemory 		(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x0C,ID_SetPBKEntry+ID, &AS))return DCT34->ReplySetPBKMemory 	(msg,Debug,(unsigned char *)Struct);
if(Ans("\x03",0x03,0x10,ID_DelPBKEntry+ID, &AS))return DCT34->ReplyDelPBKMemory 	(msg,Debug,(unsigned char *)Struct);

if(Ans("\x1B",0x03,0x01,ID_GetIMEI+ID,     &AS))return ReplyGetIMEI      		(msg,Debug,(unsigned char *)Struct);

if (msg->Type==0xD0) return GSM_ERR_TIMEOUT; //Bluetooth

if(Ans("\xD2",0x02,0x00,ID_GetID+ID3,      &AS))return DCT34->ReplyGetID 		(msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_ERR_FRAME_NOTREQUESTED;
        return GSM_ERR_FRAME_UNKNOWN;
}

GSM_Error GSM_Phone_N6510::ReplyGetIMEI(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI)
{
	memcpy(IMEI,msg->Buffer.data()+10, 16);
	(*Debug)->Deb("IMEI %s\n",IMEI);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::GetIMEI(unsigned char *IMEI)
{
	unsigned char Buff[] = {NOKIA_FRAME1, 0x00, 0x41};

//	(*Phones)->Switch("auto","irdaphonet");
//	(*Phones)->Current->GetIMEI(IMEI);
//	(*Phones)->Switch("6510","irdaphonet");
//	(*Debug)->Deb("Getting IMEI2\n");

	(*Debug)->Deb("SENT: getting IMEI\n");
	return Write(Buff, sizeof(Buff), 0x1B, 2, ID_GetIMEI+ID, IMEI);
}

GSM_Error GSM_Phone_N6510::GetCodeNameModel(unsigned char *Model)
{
	return DCT34->GetCodeNameModel(Model,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6510::GetFirmwareVersion(unsigned char *Firm)
{
	return DCT34->GetFirmwareVersion(Firm,(*Debug),(*Phones)->Current);
}

GSM_Error GSM_Phone_N6510::GetManufacturer(unsigned char *Manufacturer)
{
	strcpy((char *)Manufacturer,"Nokia");
	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::ReplyGetPBKStatus(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKStatus *Status = (GSM_PBKStatus *)S;

	(*Debug)->Deb("RECEIVED: PBK memory status\n");

	if (msg->Buffer.data()[14] == 0x10) {
		Status->Free = msg->Buffer.data()[18] * 256 + msg->Buffer.data()[19];
	} else {
		Status->Free = msg->Buffer.data()[17];
	}
	(*Debug)->Deb("Size - %i\n",Status->Free);

	Status->Used = msg->Buffer.data()[20] * 256 + msg->Buffer.data()[21];
	Status->Free -= Status->Used;
	(*Debug)->Deb("Used - %i\n",Status->Used);
	(*Debug)->Deb("Free - %i\n",Status->Free);

        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::GetPBKMemoryStatus(GSM_PBKStatus *Status)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x03, 0x02, 
		0x00, 			// memory type
		0x55, 0x55, 0x55, 0x00};

	Buff[5] = DCT34->Get7110DCT4MemoryType(Status->Memory);
	if (Buff[5] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: getting status for %s memory\n",Status->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKStatus+ID, Status);
}

GSM_Error GSM_Phone_N6510::Open(char *FrameID)
{
	GSM_Phone::Open(FrameID);

	if (FrameID[0] != 0) DCT34->SetFrameID(FrameID);

	return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::ReplyGetPBKMemory(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_PBKEntry *Entry = (GSM_PBKEntry *)S;

	if (msg->Buffer.data()[6] == 0x0F) {
		(*Debug)->Deb("RECEIVED: error %i receiving PBK entry\n",0);
	        return GSM_ERR_UNKNOWN;
	}

	(*Debug)->Deb("RECEIVED: PBK entry received\n");
	DCT34->DecodePBKToEntry(*Debug, msg->Buffer.data()+21, Entry);
        return GSM_ERR_NONE;
}

GSM_Error GSM_Phone_N6510::GetPBKMemory(GSM_PBKEntry *Entry)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x07, 0x01, 0x01, 0x00, 0x01, 0xFE,
		0x00, 			// memory type
		0x00, 0x00, 0x00, 0x00,
		0x00, 0x01, 		// memory location
		0x00, 0x00, 0x01};

	Buff[9] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[9] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[14] = Entry->Location / 256;
	Buff[15] = Entry->Location % 256;

	(*Debug)->Deb("SENT: getting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_GetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N6510::SetPBKMemory(GSM_PBKEntry *Entry)
{
	unsignedstring 		Buffer, Buffer2;
	GSM_Error		error;
	int			Number;
	unsigned char		Buff[] = {
		NOKIA_FRAME1, 0x0b, 0x00, 0x01, 0x01, 0x00, 0x00, 0x10, 0x02, 
		0x00,  			// memory type
		0x00, 0x00,  		// location
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

	Buff[11] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[11] == 0x00) return GSM_ERR_UNKNOWN;

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[12] = Entry->Location / 256;
	Buff[13] = Entry->Location % 256;

	error = DCT34->EncodeEntryToPBK(*Debug, &Buffer, Entry, &Number);
	if (error != GSM_ERR_NONE) return error;

	Buffer2.append((const unsigned char*)Buff,sizeof(Buff));
	Buffer2.push_back(Number);
	Buffer2.append((const unsigned char*)Buffer.data(),Buffer.size());

	(*Debug)->Deb("SENT: setting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write((unsigned char *)Buffer2.data(), Buffer2.size(), 0x03, 4, ID_SetPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N6510::DeletePBKMemory(GSM_PBKEntry *Entry)
{
	unsigned char Buff[] = {
		NOKIA_FRAME1, 0x0f, 0x55, 0x01, 0x04, 0x55, 0x00, 0x10, 0xFF, 0x02,
		0x00, 0x00,		// location
		0x00, 0x00, 0x00, 0x00,
		0x00,			// memory type
		0x55, 0x55, 0x55};

	if (Entry->Location==0x00) return GSM_ERR_INVALIDLOCATION;
	Buff[12] = Entry->Location / 256;
	Buff[13] = Entry->Location % 256;

	Buff[18] = DCT34->Get7110DCT4MemoryType(Entry->Memory);
	if (Buff[18] == 0x00) return GSM_ERR_UNKNOWN;

	(*Debug)->Deb("SENT: deleting entry %i in memory %s\n",Entry->Location,Entry->Memory);
	return Write(Buff, sizeof(Buff), 0x03, 4, ID_DelPBKEntry+ID, Entry);
}

GSM_Error GSM_Phone_N6510::GetFirmwareDate(unsigned char *Dat)
{
	return DCT34->GetFirmwareDate(Dat,(*Debug),(*Phones)->Current);
}
