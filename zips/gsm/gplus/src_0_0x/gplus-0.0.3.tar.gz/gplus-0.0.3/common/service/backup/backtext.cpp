/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../misc/cfg.h"
#include "../../misc/coding/coding.h"
#include "../gsmpbk.h"
#include "gsmback.h"

GSM_Error GSM_Backup::ReadFromTextFile(char *FileName)
{
	CFG_File 		File;
	CFG_File_Section 	*Section;
	wchar_t			*value, x[200];
	char			x2[100];
	GSM_PBKEntry		*PBKEntry;
	GSM_PBK_SubEntryType	PBKType;
	int						i;

	if (!File.ReadFile(FileName)) return GSM_ERR_UNKNOWN;

	EncodeUnicode("Backup",x);
	value = File.GetValue(x,EncodeUnicodeString("Format"));
	if (value == NULL) return GSM_ERR_UNKNOWN;

	EncodeUnicode("PhonePBK",x);
	Section = NULL;
	while (File.GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x,Section->GetName(),8) != 0) continue;

		value = File.GetValue(Section->GetName(),EncodeUnicodeString("Location"));
		if (value == NULL) continue;

		PBKEntry 		= new GSM_PBKEntry;
		PBKEntry->Location 	= atoi(DecodeUnicodeString(value));
		sprintf(PBKEntry->Memory,"ME");
		for (i=0;i<20;i++) {
			sprintf(x2,"Entry%02iType",i);
			value = File.GetValue(Section->GetName(),EncodeUnicodeString(x2));
			if (value == NULL) continue;

			PBKType = PBK_Not_Assigned;
			if (!wcscmp(value,EncodeUnicodeString("Name"))) 		PBKType = PBK_Text_Name;
			if (!wcscmp(value,EncodeUnicodeString("NumberMobile"))) 	PBKType = PBK_Text_Phone_Mobile;
			if (!wcscmp(value,EncodeUnicodeString("NumberHome"))) 		PBKType = PBK_Text_Phone_Home;
			if (!wcscmp(value,EncodeUnicodeString("NumberWork"))) 		PBKType = PBK_Text_Phone_Work;
			if (!wcscmp(value,EncodeUnicodeString("NumberFax"))) 		PBKType = PBK_Text_Phone_Fax;
			if (!wcscmp(value,EncodeUnicodeString("NumberGeneral"))) 	PBKType = PBK_Text_Phone_General;
			if (!wcscmp(value,EncodeUnicodeString("Postal"))) 		PBKType = PBK_Text_Postal;
			if (!wcscmp(value,EncodeUnicodeString("Note"))) 		PBKType = PBK_Text_Note;
			if (!wcscmp(value,EncodeUnicodeString("Email"))) 		PBKType = PBK_Text_Email;
			if (PBKType == PBK_Not_Assigned) continue;

			sprintf(x2,"Entry%02iText",i);
			value = File.GetValue(Section->GetName(),EncodeUnicodeString(x2));
			if (value == NULL) continue;

			value[UnicodeLength(value)-1] = 0;
			PBKEntry->AddText(PBKType,value+1);
		}
		Add_ME_PBK(PBKEntry);
	}
	return GSM_ERR_NONE;
}
