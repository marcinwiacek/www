/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */


#include <ctype.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

#ifndef gsm_comon_h
#define gsm_comon_h

typedef enum {
        /* Internal errors */
        GSM_ERR_NEWMESSAGE = 1,
        GSM_ERR_FRAME_NOTREQUESTED,
	GSM_ERR_FRAME_UNKNOWN,

	/* Device layer errors */
	GSM_ERR_DRIVERNOTAVAILABLE,

        /* Other errors returned to user */
	GSM_ERR_DEVICEWRITE,
	GSM_ERR_DEVICEREAD,
	GSM_ERR_DEVICEOPEN,
	GSM_ERR_DEVICECLOSE,
        GSM_ERR_NONE,
        GSM_ERR_UNKNOWN,
        GSM_ERR_SOURCENOTCOMPILED,
        GSM_ERR_UNKNOWNPROTOCOLSTRING,
        GSM_ERR_UNKNOWNPHONESTRING,
        GSM_ERR_OTHERPROTOCOL,
        GSM_ERR_TIMEOUT,
        GSM_ERR_EMPTY,
	GSM_ERR_NOTSUPPORTED,
	GSM_ERR_INVALIDLOCATION
} GSM_Error;

char *GSM_GetErrorInfo(GSM_Error e);

#endif
