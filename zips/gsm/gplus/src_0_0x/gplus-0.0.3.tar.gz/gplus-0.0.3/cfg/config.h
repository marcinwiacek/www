
#define VERSION "0.0.3"
#define VERSION_WIN "0,0,3,0"

#define BLUETOOTH_RF_SEARCHING 1
