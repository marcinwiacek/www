//---------------------------------------------------------------------------
//
// Name:        PhoneFrm.h
// Author:      Marcinello
// Created:     2007-01-25 19:28:55
// Description: PhoneFrm class declaration
//
//---------------------------------------------------------------------------

#ifndef __PHONEFRM_h__
#define __PHONEFRM_h__

#include "mainfrm.h"

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/frame.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/menu.h>
#include <wx/checkbox.h>
#include <wx/calctrl.h>
#include <wx/mediactrl.h>
#include <wx/listbox.h>
#include <wx/splitter.h>
#include <wx/textctrl.h>
#include <wx/combobox.h>
#include <wx/button.h>
#include <wx/listctrl.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/sizer.h>
////Header Include End

////Dialog Style Start
#undef PhoneFrm_STYLE
#define PhoneFrm_STYLE wxCAPTION | wxSYSTEM_MENU | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class PhoneFrm : public wxMDIChildFrame
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		PhoneFrm(BOOLEAN Phone2, GSM_Backup *Backup2, MainFrm *parent2, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style, const wxString& name, GSM_StateMachine *s2, unsigned char *Man, unsigned char *Model, unsigned char *Firm);
		virtual ~PhoneFrm();
		
	private:
		//Do not add custom control declarations between
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxMenu *SMSSingleUpWxPopupMenu;
		wxMenu *MMSSingleUpWxPopupMenu;
		wxListCtrl *CalendarDownWxListCtrl;
		wxGridSizer *WxGridSizer10;
		wxPanel *WxPanel15;
		wxListCtrl *CalendarUpWxListCtrl;
		wxGridSizer *WxGridSizer9;
		wxPanel *WxPanel14;
		wxSplitterWindow *WxSplitterWindow4;
		wxCheckBox *CalendarWxCheckBox;
		wxCalendarCtrl *WxCalendarCtrl1;
		wxButton *WxButton2;
		wxButton *WxButton1;
		wxPanel *WxPanel13;
		wxBoxSizer *WxBoxSizer11;
		wxButton *CalendarSearchWxButton;
		wxTextCtrl *CalendarSearchWxEdit;
		wxButton *CalendarGetWxButton;
		wxPanel *WxPanel12;
		wxBoxSizer *WxBoxSizer8;
		wxPanel *CalendarWxNoteBookPage;
		wxListCtrl *MMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer7;
		wxPanel *WxNoteBookPage4;
		wxMediaCtrl *MMSFileWxMediaCtrl;
		wxTextCtrl *MMSFileWxMemo;
		wxBoxSizer *WxBoxSizer10;
		wxButton *MMSSaveWxButton;
		wxComboBox *MMFilesWxComboBox;
		wxPanel *WxPanel11;
		wxBoxSizer *WxBoxSizer9;
		wxPanel *WxNoteBookPage3;
		wxNotebook *WxNotebook3;
		wxGridSizer *WxGridSizer8;
		wxPanel *WxPanel10;
		wxListCtrl *MMSUpWxListCtrl;
		wxGridSizer *WxGridSizer7;
		wxPanel *WxPanel9;
		wxSplitterWindow *WxSplitterWindow3;
		wxButton *MMSSearchWxButton;
		wxTextCtrl *MMSSearchWxEdit;
		wxButton *MMSGetWxButton;
		wxComboBox *MMSWxComboBox;
		wxPanel *WxPanel8;
		wxBoxSizer *WxBoxSizer6;
		wxPanel *MMSWxNoteBookPage;
		wxListCtrl *SMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer5;
		wxPanel *WxNoteBookPage2;
		wxTextCtrl *SMSTextWxMemo;
		wxListBox *SMSNumbersWxListBox;
		wxBoxSizer *WxBoxSizer4;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook2;
		wxGridSizer *WxGridSizer6;
		wxPanel *WxPanel7;
		wxListCtrl *SMSUpWxListCtrl;
		wxGridSizer *WxGridSizer5;
		wxPanel *WxPanel6;
		wxSplitterWindow *WxSplitterWindow2;
		wxButton *SMSSearchWxButton;
		wxButton *SMSSendWxButton;
		wxTextCtrl *SMSWxEdit;
		wxButton *SMSGetWxButton;
		wxComboBox *SMSWxComboBox;
		wxPanel *WxPanel5;
		wxBoxSizer *WxBoxSizer3;
		wxPanel *SMSWxNoteBookPage;
		wxListCtrl *PBKDownWxListCtrl;
		wxGridSizer *WxGridSizer4;
		wxPanel *WxPanel4;
		wxListCtrl *PBKUpWxListCtrl;
		wxGridSizer *WxGridSizer3;
		wxPanel *WxPanel3;
		wxSplitterWindow *WxSplitterWindow1;
		wxButton *PbkSearchWxButton;
		wxTextCtrl *PbkWxEdit;
		wxComboBox *PBKWxComboBox;
		wxButton *PbkGetWxButton;
		wxPanel *WxPanel2;
		wxBoxSizer *WxBoxSizer2;
		wxPanel *PhoneBookWxNoteBookPage;
		wxListCtrl *FilesWxListCtrl;
		wxButton *FilesGetWxButton;
		wxPanel *WxPanel1;
		wxBoxSizer *WxBoxSizer1;
		wxPanel *FilesWxNoteBookPage;
		wxListCtrl *InfoWxListCtrl;
		wxGridSizer *WxGridSizer2;
		wxPanel *WxPanel16;
		wxBoxSizer *WxBoxSizer12;
		wxPanel *InfoWxNoteBookPage;
		wxNotebook *WxNotebook1;
		wxGridSizer *WxGridSizer1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_MNU_FORWARD_1095 = 1095,
			ID_MNU_SENDNEWSMSTOSMSNUMBERS_1144 = 1144,
			
			ID_MNU_SAVETOFILE_1104 = 1104,
			
			ID_CALENDARDOWNWXLISTCTRL = 1127,
			ID_WXPANEL15 = 1119,
			ID_CALENDARUPWXLISTCTRL2 = 1126,
			ID_WXPANEL14 = 1118,
			ID_WXSPLITTERWINDOW4 = 1110,
			ID_CALENDARWXCHECKBOX = 1117,
			ID_WXCALENDARCTRL1 = 1116,
			ID_WXBUTTON2 = 1115,
			ID_WXBUTTON1 = 1114,
			ID_WXPANEL13 = 1109,
			ID_CALENDARSEARCHWXBUTTON = 1141,
			ID_CALENDARSEARCHWXEDIT = 1140,
			ID_CALENDARGETWXBUTTON = 1120,
			ID_WXPANEL12 = 1105,
			ID_CALENDARWXNOTEBOOKPAGE = 1090,
			ID_MMSDOWNWXLISTCTRL = 1089,
			ID_WXNOTEBOOKPAGE4 = 1085,
			ID_MMSFILEWXMEDIACTRL = 1103,
			ID_MMSFILEWXMEMO = 1102,
			ID_MMSSAVEWXBUTTON = 1101,
			ID_MMFILESWXCOMBOBOX = 1099,
			ID_WXPANEL11 = 1098,
			ID_WXNOTEBOOKPAGE3 = 1084,
			ID_WXNOTEBOOK3 = 1083,
			ID_WXPANEL10 = 1077,
			ID_MMSUPWXLISTCTRL = 1079,
			ID_WXPANEL9 = 1076,
			ID_WXSPLITTERWINDOW3 = 1075,
			ID_MMSSEARCHWXBUTTON = 1143,
			ID_MMSSEARCHWXEDIT = 1142,
			ID_MMSGETWXBUTTON = 1074,
			ID_MMSWXCOMBOBOX = 1073,
			ID_WXPANEL8 = 1072,
			ID_MMSWXNOTEBOOKPAGE = 1070,
			ID_SMSDETAILSWXLISTCTRL = 1065,
			ID_WXNOTEBOOKPAGE2 = 1063,
			ID_SMSTEXTWXMEMO = 1081,
			ID_SMSNUMBERSWXLISTBOX = 1080,
			ID_WXNOTEBOOKPAGE1 = 1059,
			ID_WXNOTEBOOK2 = 1058,
			ID_WXPANEL7 = 1067,
			ID_SMSUPWXLISTCTRL = 1056,
			ID_WXPANEL6 = 1066,
			ID_WXSPLITTERWINDOW2 = 1054,
			ID_SMSSEARCHWXBUTTON = 1096,
			ID_SMSSENDWXBUTTON = 1094,
			ID_SMSWXEDIT = 1091,
			ID_SMSGETWXBUTTON = 1069,
			ID_SMSWXCOMBOBOX = 1068,
			ID_WXPANEL5 = 1053,
			ID_SMSWXNOTEBOOKPAGE = 1046,
			ID_PBKDOWNWXLISTCTRL2 = 1043,
			ID_WXPANEL4 = 1039,
			ID_PBKUPWXLISTCTRL2 = 1042,
			ID_WXPANEL3 = 1037,
			ID_WXSPLITTERWINDOW1 = 1022,
			ID_PBKSEARCHWXBUTTON = 1139,
			ID_PBKWXEDIT = 1138,
			ID_PBKWXCOMBOBOX = 1045,
			ID_PBKGETWXBUTTON = 1044,
			ID_WXPANEL2 = 1021,
			ID_PHONEBOOKWXNOTEBOOKPAGE = 1018,
			ID_FILESWXLISTCTRL = 1016,
			ID_FILESGETWXBUTTON = 1017,
			ID_WXPANEL1 = 1015,
			ID_FILESWXNOTEBOOKPAGE = 1006,
			ID_INFOWXLISTCTRL = 1137,
			ID_WXPANEL16 = 1134,
			ID_INFOWXNOTEBOOKPAGE = 1003,
			ID_WXNOTEBOOK1 = 1002,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};

    public:		
        GSM_StateMachine                    *s;
        
		void FilesWxListCtrlItemActivated(wxListEvent& event);
		void WxNotebook1PageChanged(wxNotebookEvent& event);
		void FilesGetWxButtonClick(wxCommandEvent& event);
		void PbkGetWxButtonClick(wxCommandEvent& event);
		void PBKWxComboBoxSelected(wxCommandEvent& event );
		void PBKUpWxListCtrlColLeftClick(wxListEvent& event);
		void SMSGetWxButtonClick(wxCommandEvent& event);
		void SMSWxComboBoxSelected(wxCommandEvent& event );
		void SMSUpWxListCtrlSelected(wxListEvent& event);
		void MMSGetWxButtonClick(wxCommandEvent& event);
		void MMSWxComboBoxSelected(wxCommandEvent& event );
		void MMSUpWxListCtrlItemActivated(wxListEvent& event);
		void PBKUpWxListCtrlSelected(wxListEvent& event);
		void SMSSendWxButtonClick(wxCommandEvent& event);
	void Mnuforward1095Click(wxCommandEvent& event);
		void SMSUpWxListCtrlRightClick(wxListEvent& event);
		void SMSSearchWxButtonClick(wxCommandEvent& event);
		void WxNoteBookPage3UpdateUI(wxUpdateUIEvent& event);
		void MMFilesWxComboBoxSelected(wxCommandEvent& event );
		void MMSFileWxMediaCtrlMediaLoaded(wxMediaEvent& event);
		void MMSSaveWxButtonClick(wxCommandEvent& event);
		void MMSUpWxListCtrlSelected(wxListEvent& event);
	void Mnusavetofile1104Click(wxCommandEvent& event);
		void MMSUpWxListCtrlRightClick(wxListEvent& event);
		void CalendarGetWxButtonClick(wxCommandEvent& event);
		void WxCalendarCtrl1SelChanged(wxCalendarEvent& event);
		void CalendarWxCheckBoxClick(wxCommandEvent& event);
		void CalendarUPWxListCtrlSelected(wxListEvent& event);

    public:
        GSM_Backup                          *Backup;
		void PbkSearchWxButtonClick(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
	void Mnusendnewsmstosmsnumbers1144Click(wxCommandEvent& event);
		void MMSSearchWxButtonClick(wxCommandEvent& event);
		void CalendarSearchWxButtonClick(wxCommandEvent& event);
        
	private:
        BOOLEAN                             Phone;
		MainFrm                             *parent;
        wchart                              StatusStr[10], StatusStr2[10];

        //files
        wchar_t                             FileFolderID[500], FileFolderID0[500];
        wchart                              ParentFolderID[20];
        int                                 ParentFolderIDNum;
        wchart                              CurrentFolderName, CurrentFolderName0;
        int                                 FileSystemNum;
        GSM_FileFolderInfoLists             Folders;
        GSM_FileFolderInfoListsSubEntry     *En2;
        
        //pbk
        wchart                              PBKMemoryName[10];
        GSM_MemoryType                      PBKMemoryNum[10];
        int                                 PBKMemoryLen;
        bool                                SortPBKReverse;
        //int                               SortPBK = 0;
        //bool                              FirstPBK = true;

        //sms,mms
        GSM_SMSMMSFolders                   SMSFolders;
        bool                                FirstSMS;
        bool                                FirstMMS;
        unsignedint                         ReadSMSMMS;
        GSM_MMSDecodedFile                  Decoded;
        
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void DeleteP(wxString Str);
		int FindPage(wxString Str);
		
		BOOLEAN EnterFolder();
		
        BOOLEAN GetPbkMemories();
        void DisplayPBK(GSM_MemoryType Mem, long *PbkNum,long *ReceivedSec,long *DialledSec);
        void ReadPBKMemory(GSM_MemoryType Mem); 
        void FindNumber(wchar_t *Number);
        
        BOOLEAN ReadSMSMMSFolder(int Num2, GSM_SMSMMSFoldersSubEntry *SubFolder);
        BOOLEAN ReadSMSMMSFolders(BOOLEAN SMS);       
        void DisplaySMSFolder();
        void ClearSMSView();    
        void ClearMMSView();
        void FindMMSFile(GSM_Backup_MMSEntry **En);  
        
        void DisplayCalendar();
        BOOLEAN CheckCalendar();        
};

#endif
