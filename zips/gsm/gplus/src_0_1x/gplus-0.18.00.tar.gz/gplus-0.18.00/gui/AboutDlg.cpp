//---------------------------------------------------------------------------
//
// Name:        AboutDlg.cpp
// Author:      Marcinello
// Created:     2006-12-05 00:38:26
// Description: AboutDlg class implementation
//
//---------------------------------------------------------------------------

#include "AboutDlg.h"
#include "../cfg/config.h"
#include "../common/misc/misc.h"
#include "../common/service/gsmmisc.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// AboutDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(AboutDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(AboutDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON2,AboutDlg::WxButton2Click)
	EVT_BUTTON(ID_WXBUTTON1,AboutDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

AboutDlg::AboutDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

AboutDlg::~AboutDlg()
{
} 

void AboutDlg::CreateGUIControls()
{
	//Do not add custom code here
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("About..."));
	SetIcon(wxNullIcon);
	SetSize(8,8,415,288);
	Center();
	

	WxStaticLine2 = new wxStaticLine(this, ID_WXSTATICLINE2, wxPoint(15,72), wxSize(373,-1), wxLI_HORIZONTAL);

	WxStaticText12 = new wxStaticText(this, ID_WXSTATICTEXT12, wxT("You can help by giving donations (money, hardware, ...) or job to developers."), wxPoint(15,165), wxDefaultSize, 0, wxT("WxStaticText12"));

	WxStaticText11 = new wxStaticText(this, ID_WXSTATICTEXT11, wxT("More info:"), wxPoint(15,198), wxDefaultSize, 0, wxT("WxStaticText11"));

	WxStaticLine1 = new wxStaticLine(this, ID_WXSTATICLINE1, wxPoint(15,184), wxSize(373,-1), wxLI_HORIZONTAL);

	WxStaticText6 = new wxStaticText(this, ID_WXSTATICTEXT6, wxT("This is project given for free. Writing it need some resources and time."), wxPoint(15,149), wxDefaultSize, 0, wxT("WxStaticText6"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Check for update"), wxPoint(242,230), wxSize(157,25), 0, wxDefaultValidator, wxT("WxButton2"));

	WxStaticText9 = new wxStaticText(this, ID_WXSTATICTEXT9, wxT("Ready for many OS (Linux, MacOS, ...) and phones."), wxPoint(15,38), wxDefaultSize, 0, wxT("WxStaticText9"));

	WxStaticText8 = new wxStaticText(this, ID_WXSTATICTEXT8, wxT("Available for free (full source + win32 packages)."), wxPoint(15,22), wxDefaultSize, 0, wxT("WxStaticText8"));

	WxHyperLinkCtrl2 = new wxHyperlinkCtrl(this, ID_WXHYPERLINKCTRL2, wxT("Donation page for Marcin Wi�cek"), wxT("http://www.mwiacek.com/gsm/money/money.htm"), wxPoint(91,198), wxSize(261, 17), wxNO_BORDER | wxHL_CONTEXTMENU, wxT("WxHyperLinkCtrl2"));
	WxHyperLinkCtrl2->SetNormalColour(*wxBLUE);
	WxHyperLinkCtrl2->SetFont(wxFont(8, wxSWISS, wxNORMAL,wxNORMAL, TRUE));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("&OK"), wxPoint(122,230), wxSize(101,25), 0, wxDefaultValidator, wxT("WxButton1"));

	WxHyperLinkCtrl1 = new wxHyperlinkCtrl(this, ID_WXHYPERLINKCTRL1, wxT("Gammu+ section on www.gammu.org "), wxT("http://www.gammu.org/wiki/index.php?title=GPlus:Main_Page"), wxPoint(91,103), wxSize(196, 17), wxNO_BORDER | wxHL_CONTEXTMENU, wxT("WxHyperLinkCtrl1"));
	WxHyperLinkCtrl1->SetNormalColour(*wxBLUE);
	WxHyperLinkCtrl1->SetFont(wxFont(8, wxSWISS, wxNORMAL,wxNORMAL, TRUE));

	WxStaticText4 = new wxStaticText(this, ID_WXSTATICTEXT4, wxT("Online info:"), wxPoint(15,103), wxDefaultSize, 0, wxT("WxStaticText4"));

	WxStaticText3 = new wxStaticText(this, ID_WXSTATICTEXT3, wxT("GPL/LGPL for free, commercial on request"), wxPoint(91,86), wxDefaultSize, 0, wxT("WxStaticText3"));

	WxStaticText2 = new wxStaticText(this, ID_WXSTATICTEXT2, wxT("License:"), wxPoint(15,86), wxDefaultSize, 0, wxT("WxStaticText2"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("Written mainly in C++ using free compilators/tools (like wxWidgets) only."), wxPoint(15,54), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxStaticBox2 = new wxStaticBox(this, ID_WXSTATICBOX2, wxT("Donations and job"), wxPoint(6,134), wxSize(394,87));

	WxStaticBox1 = new wxStaticBox(this, ID_WXSTATICBOX1, wxT("Gammu+ GUI"), wxPoint(6,6), wxSize(394,119));
	////GUI Items Creation End
}

void AboutDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void AboutDlg::WxButton1Click(wxCommandEvent& event)
{
    EndModal(wxID_OK);
}

/*
 * WxButton2Click
 */
void AboutDlg::WxButton2Click(wxCommandEvent& event)
{
	unsignedstring Stable,Test;
	char buff[200],buffer[200];
	GSM_Error error;

    error = CheckRSS(&Stable, &Test);
    if (error.Code != GSM_ERR_NONE) {
        wxMessageBox(wxT("Getting info not possible now"),"Error",
               wxICON_WARNING | wxOK);
        return;
    }

    buff[0] = 0;    
    if (Test.length()!=0) {
        sprintf(buff+strlen(buff),"Available test version: %s",Test.data());
    }
    if (Stable.length()!=0) {
        if (strlen(buff)!=0) sprintf(buff+strlen(buff),"\n");
        sprintf(buff+strlen(buff),"Available stable version: %s",Stable.data());
    }
    if (strlen(buff)!=0) {
        sprintf(buffer,"Currently used version: %s\n\n%s",VERSION,buff);
        wxMessageBox(buffer,"Update available",
               wxICON_INFORMATION | wxOK);
    } else {
        wxMessageBox(wxT("You're using latest version"),"No update available",
               wxICON_INFORMATION | wxOK);        
    }
}
