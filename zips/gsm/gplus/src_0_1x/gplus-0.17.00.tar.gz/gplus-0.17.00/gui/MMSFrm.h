//---------------------------------------------------------------------------
//
// Name:        MMSFrm.h
// Author:      Marcinello
// Created:     2007-02-06 18:25:05
// Description: MMSFrm class declaration
//
//---------------------------------------------------------------------------

#ifndef __MMSFRM_h__
#define __MMSFRM_h__

#include "mainfrm.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/frame.h>
#else
	#include <wx/wxprec.h>
#endif

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/filedlg.h>
#include <wx/listctrl.h>
#include <wx/mediactrl.h>
#include <wx/textctrl.h>
#include <wx/button.h>
#include <wx/combobox.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/sizer.h>
////Header Include End

////Dialog Style Start
#undef MMSFrm_STYLE
#define MMSFrm_STYLE wxCAPTION | wxSYSTEM_MENU | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class MMSFrm : public wxMDIChildFrame
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		MMSFrm(MainFrm *parent2, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style, const wxString& name, char *FileName);
		virtual ~MMSFrm();
		void WxComboBox1Selected(wxCommandEvent& event );
		void WxMediaCtrl1MediaLoaded(wxMediaEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		
	private:
		//Do not add custom control declarations between
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxFileDialog *WxSaveFileDialog1;
		wxListCtrl *WxListCtrl1;
		wxBoxSizer *WxBoxSizer1;
		wxPanel *WxNoteBookPage2;
		wxMediaCtrl *WxMediaCtrl1;
		wxTextCtrl *WxMemo1;
		wxBoxSizer *WxBoxSizer3;
		wxButton *WxButton1;
		wxComboBox *WxComboBox1;
		wxPanel *WxPanel1;
		wxBoxSizer *WxBoxSizer2;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook1;
		wxGridSizer *WxGridSizer1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXLISTCTRL1 = 1010,
			ID_WXNOTEBOOKPAGE2 = 1008,
			ID_WXMEDIACTRL1 = 1031,
			ID_WXMEMO1 = 1028,
			ID_WXBUTTON1 = 1027,
			ID_WXCOMBOBOX1 = 1026,
			ID_WXPANEL1 = 1018,
			ID_WXNOTEBOOKPAGE1 = 1007,
			ID_WXNOTEBOOK1 = 1006,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
		
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		
        GSM_File File;
};

#endif
