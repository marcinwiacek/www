//---------------------------------------------------------------------------
//
// Name:        CfgDlg.h
// Author:      Marcinello
// Created:     2007-01-25 22:01:44
// Description: CfgDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __CFGDLG_h__
#define __CFGDLG_h__

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/combobox.h>
#include <wx/button.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef CfgDlg_STYLE
#define CfgDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxCLOSE_BOX
////Dialog Style End

class CfgDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		CfgDlg(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = CfgDlg_STYLE);
		virtual ~CfgDlg();
	
	private:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxComboBox *WxComboBox2;
		wxComboBox *WxComboBox1;
		wxButton *WxButton3;
		wxButton *WxButton2;
		wxStaticText *WxStaticText3;
		wxStaticText *WxStaticText2;
		wxStaticText *WxStaticText1;
		wxTextCtrl *WxEdit1;
		wxStaticBox *WxStaticBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXCOMBOBOX2 = 1014,
			ID_WXCOMBOBOX1 = 1013,
			ID_WXBUTTON3 = 1010,
			ID_WXBUTTON2 = 1009,
			ID_WXSTATICTEXT3 = 1008,
			ID_WXSTATICTEXT2 = 1007,
			ID_WXSTATICTEXT1 = 1006,
			ID_WXEDIT1 = 1003,
			ID_WXSTATICBOX1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
		public:
            void SetConfig(char *Conn, char *Dev, char *Mod, GSM_StateMachine *s2);
void CfgDlg::GetConfig(char *Conn, char *Dev, char *Mod);
		void WxComboBox1Selected(wxCommandEvent& event );
		void WxComboBox2Selected(wxCommandEvent& event );
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void WxChoice2Selected(wxCommandEvent& event );
		void CfgDlg::SelectChoice2();
		void CfgDlg::SelectChoice1();
GSM_StateMachine *s;
char *Connection;
char *Device;
char *Model;
		void WxChoice1Selected(wxCommandEvent& event );
		void WxButton2Click(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);

            
};

#endif
