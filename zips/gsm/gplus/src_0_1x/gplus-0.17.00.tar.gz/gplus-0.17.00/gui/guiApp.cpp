//---------------------------------------------------------------------------
//
// Name:        guiApp.cpp
// Author:      Marcinello
// Created:     2007-01-25 18:04:29
// Description: 
//
//---------------------------------------------------------------------------

#include "guiApp.h"
#include "MainFrm.h"

IMPLEMENT_APP(MainFrmApp)

bool MainFrmApp::OnInit()
{
    MainFrm* frame = new MainFrm(NULL,-1,"ala",wxDefaultPosition, wxDefaultSize, MainFrm_STYLE, "frame");

    setlocale( LC_ALL, "" );

    SetTopWindow(frame);
    frame->Show();
    return true;
}
 
int MainFrmApp::OnExit()
{
	return 0;
}
