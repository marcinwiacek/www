
#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#include <wx/msgdlg.h>
#include <wx/listctrl.h>
#include <wx/combobox.h>

BOOLEAN PrintError (GSM_Error error)
{
    unsigned char buffer[2000];

    if (error.Code == GSM_ERR_NONE) return FALSE;
    sprintf((char *)buffer,"%s",GSM_GetErrorInfo(error));
    wxMessageBox(buffer,
            wxT("Error"),
            wxICON_WARNING | wxOK);
    return TRUE;
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
    switch (DayOfWeek(Year,Month,Day)) {
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
        case 7: return "Sun";
        default:return "";
    }
}

void PrintDT(GSM_DateTime *DT, char *Buffer)
{
    sprintf(Buffer, "%s %02i-%02i-%04i %02i:%02i:%02i",
            DayOfWeekStr(
                    DT->Year,
                    DT->Month,
                    DT->Day),
            DT->Day,
            DT->Month,
            DT->Year,
            DT->Hour,
            DT->Minute,
            DT->Second);
}

void ViewMMSFile(GSM_File *File, wxListCtrl *List, wxComboBox *FilesList)
{
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
	GSM_Error                   error;
    long                        tmp,EntryNum=0;
    wchar_t                     Buffer[200];
	char                        buff[200];
    BOOLEAN                     Found;
        wchart Name;

    List->DeleteAllItems();
    FilesList->Clear();

    error = Decoded.Read(File);
    PrintError(error);

    tmp = List->InsertItem(EntryNum++, "ID", 0);
    List->SetItemData(tmp, 0);
    List->SetItem(tmp, 1, File->Info.GetID());

    SubDecoded = NULL;
    while (Decoded.GetNext(&SubDecoded)) {
        Found = false;
        switch (SubDecoded->Type) {
        case MMS_Address_Phone_Source:
            tmp = List->InsertItem(EntryNum++, "From (phone)", 0); Found = true;
            break;
    	case MMS_Address_Unknown_Source:
            tmp = List->InsertItem(EntryNum++, "From", 0); Found = true;
            break;
        case MMS_Address_Phone_Destination:
            tmp = List->InsertItem(EntryNum++, "To (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_Destination:
            tmp = List->InsertItem(EntryNum++, "To", 0); Found = true;
            break;
        case MMS_Address_Phone_CC:
            tmp = List->InsertItem(EntryNum++, "CC (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_CC:
            tmp = List->InsertItem(EntryNum++, "CC", 0); Found = true;
            break;
        case MMS_Address_Phone_BCC:
            tmp = List->InsertItem(EntryNum++, "BCC (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_BCC:
            tmp = List->InsertItem(EntryNum++, "BCC", 0); Found = true;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
//            FindSMSNumber(Buffer);
            List->SetItem(tmp, 1, Buffer);
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_Text_TransactionID:
            tmp = List->InsertItem(EntryNum++, "Transaction ID", 0); Found = TRUE;
            break;
        case MMS_Text_Subject:
            tmp = List->InsertItem(EntryNum++, "Subject", 0); Found = TRUE;
            break;
        case MMS_Text_ContentLocation:
            tmp = List->InsertItem(EntryNum++, "Content location", 0); Found = TRUE;
            break;
        case MMS_Text_ContentType:
            tmp = List->InsertItem(EntryNum++, "Content type", 0); Found = TRUE;
            break;
        case MMS_Text_MessageType:
            tmp = List->InsertItem(EntryNum++, "Message type", 0); Found = TRUE;
            break;
        case MMS_Text_MessageID:
            tmp = List->InsertItem(EntryNum++, "Message ID", 0); Found = TRUE;
            break;
        case MMS_Text_MessageClass:
            tmp = List->InsertItem(EntryNum++, "Message class", 0); Found = TRUE;
            break;
        case MMS_Text_Priority:
            tmp = List->InsertItem(EntryNum++, "Priority", 0); Found = TRUE;
            break;
        case MMS_Text_Version:
            tmp = List->InsertItem(EntryNum++, "MMS version", 0); Found = TRUE;
            break;
        case MMS_Text_Response_Status:
            tmp = List->InsertItem(EntryNum++, "Response status", 0); Found = TRUE;
            break;
        case MMS_Text_Status:
            tmp = List->InsertItem(EntryNum++, "Status", 0); Found = TRUE;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_Bool_Report:
            tmp = List->InsertItem(EntryNum++, "Delivery report", 0); Found = TRUE;
            break;
        case MMS_Bool_Read_Reply:
            tmp = List->InsertItem(EntryNum++, "Read reply", 0); Found = TRUE;
            break;
        case MMS_Bool_Report_Allowed:
            tmp = List->InsertItem(EntryNum++, "Report allowed", 0); Found = TRUE;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            if (SubDecoded->Bool) {
                List->SetItem(tmp, 1, "yes");
            } else {
                List->SetItem(tmp, 1, "no");
            }
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_DT_DateTime:
            tmp = List->InsertItem(EntryNum++, "Sent", 0);
            List->SetItemData(tmp, 0);
            PrintDT(&SubDecoded->DT, buff);
            List->SetItem(tmp, 1, buff);
            break;
    	case MMS_DT_Expiry:
            tmp = List->InsertItem(EntryNum++, "Expiry", 0);
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            break;
        case MMS_File:
            tmp = List->InsertItem(EntryNum++, "File", 0);
            List->SetItemData(tmp, 0);
            tmp = List->InsertItem(EntryNum++, "  Content type", 0);
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            if (UnicodeLength(SubDecoded->File.Info.GetName())!=0) {
                tmp = List->InsertItem(EntryNum++, "  Name", 0);
                List->SetItemData(tmp, 0);
                List->SetItem(tmp, 1, SubDecoded->File.Info.GetName());
            }
            if (SubDecoded->Text2.length()!=0) {
                tmp = List->InsertItem(EntryNum++, "  SMIL CID", 0);
                List->SetItemData(tmp, 0);
                List->SetItem(tmp, 1, SubDecoded->Text2.data());
            }
            tmp = List->InsertItem(EntryNum++, "  Size", 0);
            List->SetItemData(tmp, 0);
            sprintf(buff,"%i bytes",SubDecoded->File.Info.Size);
            List->SetItem(tmp, 1, buff);
            
            Name.clear();
            Name.append(SubDecoded->File.Info.GetName(),UnicodeLength(SubDecoded->File.Info.GetName()));
            Name.push_back(' ');
            Name.push_back('(');
            Name.append(SubDecoded->Text.data(),UnicodeLength((wchar_t *)SubDecoded->Text.data()));
            Name.push_back(')');
            FilesList->Append(Name.data());
            
            break;
        }
    }
}
