
#ifndef yyy
#define yyy

#include <wx/listctrl.h>

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

BOOLEAN PrintError (GSM_Error error);
char *DayOfWeekStr(int Year, int Month, int Day);
void PrintDT(GSM_DateTime *DT, char *Buffer);
void ViewMMSFile(GSM_File *File, wxListCtrl *List, wxComboBox *FilesList);

#endif
