/* (C) 2007 by Marcin Wiacek www.mwiacek.com */

#include "../../cfg/config.h"
#include "gsmdata.h"
#include "../misc/coding/coding.h"

GSM_MMSDecodedFileSubEntry::GSM_MMSDecodedFileSubEntry()
{
	Next = NULL;
}

GSM_MMSDecodedFileSubEntry::~GSM_MMSDecodedFileSubEntry()
{
	delete(Next);
}

GSM_MMSDecodedFileSubEntry *GSM_MMSDecodedFileSubEntry::GetNext()
{
	return Next;
}

void GSM_MMSDecodedFileSubEntry::SetNext(GSM_MMSDecodedFileSubEntry *Nxt)
{
	Next = Nxt;
}

/* ------------------------------------------------------------------------ */

GSM_MMSDecodedFile::GSM_MMSDecodedFile()
{
	Entries = NULL;
}


GSM_MMSDecodedFile::~GSM_MMSDecodedFile()
{
	delete(Entries);
}

BOOLEAN GSM_MMSDecodedFile::GetNext(GSM_MMSDecodedFileSubEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Entries;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

GSM_Error GSM_MMSDecodedFile::Add(GSM_MMSDecodedFileSubEntry *En)
{
	GSM_MMSDecodedFileSubEntry	*Entry2;
	GSM_Error			error;

	if (Entries == NULL) {
		Entries = En;
	} else {
		Entry2 = Entries;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(En);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}

void GSM_MMSDecodedFile::ClearAll()
{
	delete(Entries);
	Entries = NULL;
}

long GSM_MMSDecodedFile::DecodeLonginteger(unsignedstring *Buff, long *Pos)
{
	int i, len = Buff->data()[(*Pos)++];
	long ret=0;

	for (i=0;i<len;i++) {
		ret = ret << 8;
		ret += Buff->data()[(*Pos)++];
	}

	return ret;
}

int GSM_MMSDecodedFile::DecodeShortinteger(unsignedstring *Buff, long *Pos)
{
	return Buff->data()[(*Pos)++] & 0x7f;
}

long GSM_MMSDecodedFile::DecodeInteger(unsignedstring *Buff, long *Pos)
{
	if (Buff->data()[(*Pos)] < 31) return DecodeLonginteger(Buff,Pos);
	if (Buff->data()[(*Pos)] > 127) return DecodeShortinteger(Buff,Pos);
	return 0;
}

long GSM_MMSDecodedFile::DecodeUintvar(unsignedstring *Buff, long *Pos)
{
	long ret=0;
	BOOLEAN found = FALSE;

	while (1) {
		if (!(Buff->data()[(*Pos)] & 0x80)) found = TRUE;
		ret = ret << 7;
		ret |= Buff->data()[(*Pos)++] & 0x7F;
		if (found) break;
	}
	return ret;
}

int GSM_MMSDecodedFile::DecodeValuelength(unsignedstring *Buff, long *Pos)
{
	if (Buff->data()[(*Pos)] < 31) return Buff->data()[(*Pos)++];
	if (Buff->data()[(*Pos)] == 31) {
		(*Pos)++;
		return DecodeUintvar(Buff,Pos);
	}
	return 0;
}

void GSM_MMSDecodedFile::DecodeText(unsignedstring *Buff, long *Pos, unsignedstring *Dest)
{
	Dest->clear();
	if (Buff->data()[(*Pos)] == 127) (*Pos)++;
	for (;;) {
		Dest->push_back(Buff->data()[(*Pos)]);
		if (Buff->data()[(*Pos)]==0) break;
		(*Pos)++;
	}	
	(*Pos)++;
}

void GSM_MMSDecodedFile::DecodeEncodedString(unsignedstring *Buff, long *Pos, unsignedstring *Dest)
{
	int len,i;

	Dest->clear();
	if (Buff->data()[(*Pos)] < 32) {
		len = DecodeValuelength(Buff,Pos);
		(*Pos)++;//charset?
		for (i=1;i<len;i++) {
			Dest->push_back(Buff->data()[(*Pos)++]);
		}
		return;
	}
	DecodeText(Buff, Pos, Dest);
}

void GSM_MMSDecodedFile::DecodeVersion(unsignedstring *Buff, long *Pos, unsignedstring *Dest, float *Version)
{
	long value;
	char buff[20];

	value = Buff->data()[(*Pos)] & 0x7F;
	(*Version) = ((value & 0x70) >> 4) + (value & 0x0f) / 10;
	sprintf(buff,"%i.%i", (value & 0x70) >> 4, value & 0x0f);
	Dest->clear();
	Dest->append((unsigned char *)buff,strlen(buff));
	
	(*Pos)++;
}

void GSM_AddWAPMIMEType(int type, char *buffer)
{
	switch (type) {
	case  1:sprintf(buffer,"%stext/*",buffer);					break;
	case  2:sprintf(buffer,"%stext/html",buffer);					break;
	case  3:sprintf(buffer,"%stext/plain",buffer);					break;
	case  4:sprintf(buffer,"%stext/x-hdml",buffer);					break;
	case  5:sprintf(buffer,"%stext/x-ttml",buffer);					break;
	case  6:sprintf(buffer,"%stext/x-vCalendar",buffer);				break;
	case  7:sprintf(buffer,"%stext/x-vCard",buffer);				break;
	case  8:sprintf(buffer,"%stext/vnd.wap.wml",buffer);				break;
	case  9:sprintf(buffer,"%stext/vnd.wap.wmlscript",buffer);			break;
	case 10:sprintf(buffer,"%stext/vnd.wap.wta-event",buffer);			break;
	case 11:sprintf(buffer,"%smultipart/*",buffer);					break;
	case 12:sprintf(buffer,"%smultipart/mixed",buffer);				break;
	case 13:sprintf(buffer,"%smultipart/form-data",buffer);				break;
	case 14:sprintf(buffer,"%smultipart/byterantes",buffer);			break;
	case 15:sprintf(buffer,"%smultipart/alternative",buffer);			break;
	case 16:sprintf(buffer,"%sapplication/*",buffer);				break;
	case 17:sprintf(buffer,"%sapplication/java-vm",buffer);				break;
	case 18:sprintf(buffer,"%sapplication/x-www-form-urlencoded",buffer);		break;
	case 19:sprintf(buffer,"%sapplication/x-hdmlc",buffer);				break;
	case 20:sprintf(buffer,"%sapplication/vnd.wap.wmlc",buffer);			break;
	case 21:sprintf(buffer,"%sapplication/vnd.wap.wmlscriptc",buffer);		break;
	case 22:sprintf(buffer,"%sapplication/vnd.wap.wta-eventc",buffer);		break;
	case 23:sprintf(buffer,"%sapplication/vnd.wap.uaprof",buffer);			break;
	case 24:sprintf(buffer,"%sapplication/vnd.wap.wtls-ca-certificate",buffer);	break;
	case 25:sprintf(buffer,"%sapplication/vnd.wap.wtls-user-certificate",buffer);	break;
	case 26:sprintf(buffer,"%sapplication/x-x509-ca-cert",buffer);			break;
	case 27:sprintf(buffer,"%sapplication/x-x509-user-cert",buffer);		break;
	case 28:sprintf(buffer,"%simage/*",buffer);					break;
	case 29:sprintf(buffer,"%simage/gif",buffer);					break;
	case 30:sprintf(buffer,"%simage/jpeg",buffer);					break;
	case 31:sprintf(buffer,"%simage/tiff",buffer);					break;
	case 32:sprintf(buffer,"%simage/png",buffer);					break;
	case 33:sprintf(buffer,"%simage/vnd.wap.wbmp",buffer);				break;
	case 34:sprintf(buffer,"%sapplication/vnd.wap.multipart.*",buffer);		break;
	case 35:sprintf(buffer,"%sapplication/vnd.wap.multipart.mixed",buffer);		break;
	case 36:sprintf(buffer,"%sapplication/vnd.wap.multipart.form-data",buffer);	break;
	case 37:sprintf(buffer,"%sapplication/vnd.wap.multipart.byteranges",buffer);	break;
	case 38:sprintf(buffer,"%sapplication/vnd.wap.multipart.alternative",buffer);	break;
	case 39:sprintf(buffer,"%sapplication/xml",buffer);				break;
	case 40:sprintf(buffer,"%stext/xml",buffer);					break;
	case 41:sprintf(buffer,"%sapplication/vnd.wap.wbxml",buffer);			break;
	case 42:sprintf(buffer,"%sapplication/x-x968-cross-cert",buffer);		break;
	case 43:sprintf(buffer,"%sapplication/x-x968-ca-cert",buffer);			break;
	case 44:sprintf(buffer,"%sapplication/x-x968-user-cert",buffer);		break;
	case 45:sprintf(buffer,"%stext/vnd.wap.si",buffer);				break;
	case 46:sprintf(buffer,"%sapplication/vnd.wap.sic",buffer);			break;
	case 47:sprintf(buffer,"%stext/vnd.wap.sl",buffer);				break;
	case 48:sprintf(buffer,"%sapplication/vnd.wap.slc",buffer);			break;
	case 49:sprintf(buffer,"%stext/vnd.wap.co",buffer);				break;
	case 50:sprintf(buffer,"%sapplication/vnd.wap.coc",buffer);			break;
	case 51:sprintf(buffer,"%sapplication/vnd.wap.multipart.related",buffer); 	break;
	case 52:sprintf(buffer,"%sapplication/vnd.wap.sia",buffer); 			break;
	case 53:sprintf(buffer,"%stext/vnd.wap.connectivity-xml",buffer); 		break;
	case 54:sprintf(buffer,"%sapplication/vnd.wap.connectivity-wbxml",buffer); 	break;
	case 55:sprintf(buffer,"%sapplication/pkcs7-mime",buffer); 			break;
	case 56:sprintf(buffer,"%sapplication/vnd.wap.hashed-certificate",buffer); 	break;
	case 57:sprintf(buffer,"%sapplication/vnd.wap.signed-certificate",buffer); 	break;
	case 58:sprintf(buffer,"%sapplication/vnd.wap.cert-response",buffer); 		break;
	case 59:sprintf(buffer,"%sapplication/xhtml+xml",buffer); 			break;
	case 60:sprintf(buffer,"%sapplication/wml+xml",buffer); 			break;
	case 61:sprintf(buffer,"%stext/css",buffer); 					break;
	case 62:sprintf(buffer,"%sapplication/vnd.wap.mms-message",buffer); 		break;
	case 63:sprintf(buffer,"%sapplication/vnd.wap.rollover-certificate",buffer); 	break;
	case 64:sprintf(buffer,"%sapplication/vnd.wap.locc+wbxml",buffer); 		break;
	case 65:sprintf(buffer,"%sapplication/vnd.wap.loc+xml",buffer); 		break;
	case 66:sprintf(buffer,"%sapplication/vnd.syncml.dm+wbxml",buffer); 		break;
	case 67:sprintf(buffer,"%sapplication/vnd.syncml.dm+xml",buffer); 		break;
	case 68:sprintf(buffer,"%sapplication/vnd.syncml.notification",buffer); 	break;
	case 69:sprintf(buffer,"%sapplication/vnd.wap.xhtml+xml",buffer); 		break;
	case 70:sprintf(buffer,"%sapplication/vnd.wv.csp.cir",buffer); 			break;
	case 71:sprintf(buffer,"%sapplication/vnd.oma.dd+xml",buffer); 			break;
	case 72:sprintf(buffer,"%sapplication/vnd.oma.drm.message",buffer); 		break;
	case 73:sprintf(buffer,"%sapplication/vnd.oma.drm.content",buffer); 		break;
	case 74:sprintf(buffer,"%sapplication/vnd.oma.drm.rights+xml",buffer); 		break;
	case 75:sprintf(buffer,"%sapplication/vnd.oma.drm.rights+wbxml",buffer); 	break;
	default:sprintf(buffer,"%sMIME %i",buffer,type);				break;
	}
}

int GSM_MMSDecodedFile::DecodeContentType(unsignedstring *Buff, long *Pos, unsignedstring *Dest, float Version)
{
	unsignedstring		buff3;
	 char 			buff[20000];
	long			type=0,val2;
float ver;
	BOOLEAN			Found = TRUE;

	buff[0] = 0;
	if (Buff->data()[(*Pos)] <= 31) {
		type = DecodeValuelength(Buff, Pos);
		if (Buff->data()[(*Pos)] > 31 && Buff->data()[(*Pos)] < 128) {
			DecodeText(Buff, Pos, &buff3);
			sprintf(buff,"%s",buff3.data());
		} else {
			type = DecodeInteger(Buff,Pos);
			GSM_AddWAPMIMEType(type, buff);
		}
	} else if (Buff->data()[(*Pos)] <= 128) {
		DecodeText(Buff, Pos, &buff3);
		sprintf(buff,"%s",buff3.data());				
	} else {
		type = DecodeShortinteger(Buff, Pos);
		GSM_AddWAPMIMEType(type, buff);
	}
	while (1) {
		if (!(Buff->data()[(*Pos)] & 0x80)) break;
		//WAP-230-WSP-20010705-a
		//Table 38. Well-Known Parameter Assignments
//		sprintf(buff,"%s; %02x %02x",buff,Buff->data()[(*Pos)] & 0x7F,Buff->data()[(*Pos)]);
		switch (Buff->data()[(*Pos)++] & 0x7F) {
		case 0x00:
			Dest->clear();
			Dest->append((unsigned char *)buff,strlen(buff));
			return -1;

		case 0x01:
			Dest->clear();
			Dest->append((unsigned char *)buff,strlen(buff));
			return -1;
			//charset
			if (Buff->data()[(*Pos)]==128) {
				(*Pos)++;
			} else {
				val2 = DecodeInteger(Buff,Pos);
			}
			break;
		case 0x02:
			Dest->clear();
			Dest->append((unsigned char *)buff,strlen(buff));
			return -1;
			DecodeVersion(Buff, Pos, &buff3, &ver);
			sprintf(buff,"%s; level=%s",buff,buff3.data());
			break;
		case 0x03:
//			Dest->clear();
//			Dest->append((unsigned char *)buff,strlen(buff));
//			return -1;
			val2 = DecodeInteger(Buff,Pos);
			sprintf(buff,"%s; type=%i",buff,val2);
			break;
		case 0x05:
			DecodeText(Buff, Pos, &buff3);
			sprintf(buff,"%s; name=%s",buff,buff3.data());
			break;
		case 0x06:
			DecodeText(Buff, Pos, &buff3);
			sprintf(buff,"%s; filename=%s",buff,buff3.data());
			break;
		case 0x07:
		case 0x08:
			Dest->clear();
			Dest->append((unsigned char *)buff,strlen(buff));
			return -1;
		case 0x09:
			DecodeText(Buff, Pos, &buff3);
			sprintf(buff,"%s; type=%s",buff,buff3.data());
//		sprintf(buff,"%s; %02x %02x %02x",buff,Buff->data()[(*Pos)] & 0x7F,Buff->data()[(*Pos)],Buff->data()[(*Pos)] & 0x80);
//		if (!(Buff->data()[(*Pos)] & 0x80)) Found = FALSE;
			break;
		case 0x0A:
			sprintf(buff,"%s; start=",buff);
			if (Buff->data()[(*Pos)]<128) {
				DecodeText(Buff, Pos, &buff3);
				sprintf(buff,"%s%s",buff,buff3.data());
			} else {
				type = DecodeShortinteger(Buff, Pos);
				GSM_AddWAPMIMEType(type, buff);
			}
			break;
		case 0x0B:
			return -1;
		case 0x0C:
		case 0x0D:
		case 0x0E:
		case 0x0F:
		case 0x10:
		case 0x11:
		case 0x12:
		case 0x13:
		case 0x14:
		case 0x15:
		case 0x16:
		case 0x17:
		case 0x18:
		case 0x19:
		case 0x1A:
		case 0x1B:
		case 0x1C:
		case 0x1D:
			if (Version < 1.3) {
				Found = FALSE;
				break;
			}
			Dest->clear();
			Dest->append((unsigned char *)buff,strlen(buff));
			return -1;
		default:
			Found = FALSE;
		}
		if (!Found) {
//				sprintf(buff,"%swychodzi",buff);
			(*Pos)--;
			break;
		}
	}
//if (type ==-1) sprintf(buff,"%szle",buff);
	Dest->clear();
	Dest->append((unsigned char *)buff,strlen(buff));

	return type;
}

void GSM_MMSDecodedFile::DecodeAddress(unsignedstring *buffer, GSM_MMS_Types *Type)
{
	unsignedstring buff2;

	if (strstr((char *)buffer->data(),"/TYPE=PLMN")!=NULL) {
		buff2.append(buffer->data(),strlen((char *)buffer->data())-10);
		buffer->clear();
		buffer->append(buff2.data(),strlen((char *)buff2.data()));
	} else {
		Type++;
	}
}

GSM_Error GSM_MMSDecodedFile::Read(GSM_File *File)
{
	long type=0,headlen,datalen,oldpos,z,pos=0;
	int 				parts,j;
	float version=1.0;
	time_t 				timet;
	GSM_DateTime 			Date;
	char				buff[20000];
	unsignedstring			buff3;
	GSM_MMSDecodedFileSubEntry 	*SubEntry;

int i,len2,len3,len4;
long value;
	char				buff2[200];


	ClearAll();

	//header
	while(1) {
		if (pos > File->Buffer.size()) break;
		if (!(File->Buffer.data()[pos] & 0x80)) break;
		SubEntry=new GSM_MMSDecodedFileSubEntry;
		switch (File->Buffer.data()[pos++] & 0x7F) {
		case 0x01:
			SubEntry->Type = MMS_Address_Phone_BCC;
			DecodeEncodedString(&File->Buffer, &pos, &buff3);
			DecodeAddress(&buff3, &SubEntry->Type);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x02:
			SubEntry->Type = MMS_Address_Phone_CC;
			DecodeEncodedString(&File->Buffer, &pos, &buff3);
			DecodeAddress(&buff3, &SubEntry->Type);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x03:
			SubEntry->Type = MMS_Text_ContentLocation;
			DecodeText(&File->Buffer, &pos, &buff3);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x04:
			SubEntry->Type = MMS_Text_ContentType;
			type = DecodeContentType(&File->Buffer, &pos, &buff3, version);
			if (type == -1) return GSM_Return_Error(GSM_ERR_UNKNOWN);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x05:
			SubEntry->Type = MMS_DT_DateTime;
			timet = DecodeLonginteger(&File->Buffer, &pos);
			Date=TimeT2GSMDateTime(&timet);
			memcpy(&SubEntry->DT,&Date,sizeof(GSM_DateTime));
			break;
		case 0x06:
			SubEntry->Type = MMS_Bool_Report;
			switch(File->Buffer.data()[pos++]) {
				case 0x80: SubEntry->Bool = TRUE;  break;
				case 0x81: SubEntry->Bool = FALSE; break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			break;
		case 0x08:			
			SubEntry->Type = MMS_DT_Expiry;
			z = DecodeLonginteger(&File->Buffer, &pos);
			sprintf(buff,"%i",z);
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x09:
			SubEntry->Type = MMS_Address_Phone_Source;
			DecodeEncodedString(&File->Buffer, &pos, &buff3);
			DecodeAddress(&buff3, &SubEntry->Type);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x0A:
			SubEntry->Type = MMS_Text_MessageClass;
			switch (File->Buffer.data()[pos++]) {
				case 0x80: sprintf(buff,"personal");  	   	break;
				case 0x81: sprintf(buff,"advertisement"); 	break;
				case 0x82: sprintf(buff,"informational"); 	break;
				case 0x83: sprintf(buff,"auto");   		break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x0B:
			SubEntry->Type = MMS_Text_MessageID;
			DecodeText(&File->Buffer, &pos, &buff3);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x0C:
			SubEntry->Type=MMS_Text_MessageType;
			switch (File->Buffer.data()[pos++]) {
				case 0x80: sprintf(buff,"m-send-req");  	   	break;
				case 0x81: sprintf(buff,"m-send-conf"); 	   	break;
				case 0x82: sprintf(buff,"m-notification-ind"); 		break;
				case 0x83: sprintf(buff,"m-notifyresp-ind");   		break;
				case 0x84: sprintf(buff,"m-retrieve-conf");		break;
				case 0x85: sprintf(buff,"m-acknowledge-ind");  		break;
				case 0x86: sprintf(buff,"m-delivery-ind");		break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x0D:
			SubEntry->Type = MMS_Text_Version;
			DecodeVersion(&File->Buffer, &pos, &buff3, &version);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;			
		case 0x0E:
			printf("  Message size      : not done yet\n");
			return GSM_Return_Error(GSM_ERR_UNKNOWN);
		case 0x0F:
			SubEntry->Type=MMS_Text_Priority;
			switch (File->Buffer.data()[pos++]) {
				case 0x80: sprintf(buff,"low");  	   	break;
				case 0x81: sprintf(buff,"normal"); 	   	break;
				case 0x82: sprintf(buff,"high"); 		break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x10:
			SubEntry->Type = MMS_Bool_Read_Reply;
			switch(File->Buffer.data()[pos++]) {
				case 0x80: SubEntry->Bool = TRUE;  break;
				case 0x81: SubEntry->Bool = FALSE; break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			break;
		case 0x11:
			SubEntry->Type = MMS_Bool_Report_Allowed;
			switch(File->Buffer.data()[pos++]) {
				case 0x80: SubEntry->Bool = TRUE;  break;
				case 0x81: SubEntry->Bool = FALSE; break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			break;
		case 0x12:
			switch (File->Buffer.data()[pos++]) {
				case 128:sprintf(buff,"OK");  	   				break;
				case 129:sprintf(buff,"error unspecified"); 	   		break;
				case 130:sprintf(buff,"error service denied"); 			break;
				case 131:sprintf(buff,"error message format corrupt");   	break;
				case 132:sprintf(buff,"error sending address unresolved");	break;
				case 133:sprintf(buff,"error message not found");  		break;
				case 134:sprintf(buff,"error network problem");			break;
				case 135:sprintf(buff,"error content not accepted");		break;
				case 136:sprintf(buff,"error unsupported message");		break;
				default :return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x13:
			printf("  Response text     : not done yet\n");
			return GSM_Return_Error(GSM_ERR_UNKNOWN);
		case 0x14:
			printf("  Sender visibility : not done yet\n");
			return GSM_Return_Error(GSM_ERR_UNKNOWN);
		case 0x15:
			SubEntry->Type=MMS_Text_Status;
			switch (File->Buffer.data()[pos++]) {
				case 0x80: sprintf(buff,"expired");  	   	break;
				case 0x81: sprintf(buff,"retrieved"); 	   	break;
				case 0x82: sprintf(buff,"rejected"); 		break;
				case 0x83: sprintf(buff,"deferred");   		break;
				case 0x84: sprintf(buff,"unrecognised");		break;
				default  : return GSM_Return_Error(GSM_ERR_UNKNOWN);
			}
			SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
			break;
		case 0x16:
			SubEntry->Type=	MMS_Text_Subject;
			DecodeEncodedString(&File->Buffer, &pos, &buff3);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x17:
			SubEntry->Type = MMS_Address_Phone_Destination;
			DecodeEncodedString(&File->Buffer, &pos, &buff3);
			DecodeAddress(&buff3, &SubEntry->Type);
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		case 0x18:
			DecodeText(&File->Buffer, &pos, &buff3);
			SubEntry->Type = MMS_Text_TransactionID;
			SubEntry->Text.append(StringToUnicodeReturn((char *)buff3.data()),UnicodeLength(StringToUnicodeReturn((char *)buff3.data())));
			break;
		default:
			delete(SubEntry);
			return GSM_Return_Error(GSM_ERR_UNKNOWN);
		}
		Add(SubEntry);
	}

	//if we don't have any parts, we exit
	if (type != 35 && type != 51) return GSM_Return_Error(GSM_ERR_NONE);

	parts = DecodeUintvar(&File->Buffer, &pos);

//return GSM_Return_Error(GSM_ERR_EMPTY);

	for (j=0;j<parts;j++) {
		SubEntry=new GSM_MMSDecodedFileSubEntry;
		SubEntry->Type=MMS_File;

		value = 0;
		while (true) {
			value = value << 7;
			value |= File->Buffer.data()[pos] & 0x7F;
			pos++;
			if (!(File->Buffer.data()[pos-1] & 0x80)) break;
		}
		printf("    Header len: %li",value);
		len2 = value;

		value = 0;
		while (true) {
			value = value << 7;
			value |= File->Buffer.data()[pos] & 0x7F;
			pos++;
			if (!(File->Buffer.data()[pos-1] & 0x80)) break;
		}
		printf(", data len: %li\n",value);
		len3 = value;

		//content type
		i 	= 0;
		buff[0] = 0;
		printf("    Content type    : ");
		if (File->Buffer.data()[pos] >= 0x80) {
			type = File->Buffer.data()[pos] & 0x7f;
			GSM_AddWAPMIMEType(type, buff);
		} else if (File->Buffer.data()[pos+i] == 0x1F) {
			i++;
			buff[0] = 0;
			len4 	= File->Buffer.data()[pos+i];
			i++;
			if (!(File->Buffer.data()[pos+i] & 0x80)) {
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				i++;
			} else {
				value = File->Buffer.data()[pos+i] & 0x7F;
				GSM_AddWAPMIMEType(value, buff);
				i++;
			}
		} else if (File->Buffer.data()[pos+i] < 0x1F) {
			i++;
			if (File->Buffer.data()[pos+i] & 0x80) {
				type = File->Buffer.data()[pos+i] & 0x7f;
				GSM_AddWAPMIMEType(type, buff);
				i++;
			} else {
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				i++;
			}
		} else {
			while (File->Buffer.data()[pos+i]!=0x00) {
				buff[strlen(buff)+1] = 0;
				buff[strlen(buff)]   = File->Buffer.data()[pos+i];
				i++;
			}
		}
		printf("%s\n",buff);
		SubEntry->Text.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));

		pos+=i;
		len2-=i;

		i=0;
		while (i<len2) {
//			printf("%02x\n",File->Buffer.data()[pos+i]);
			switch (File->Buffer.data()[pos+i]) {
			case 0x81:
				i++;
				break;
			case 0x83:
				break;
			case 0x85:
				//mms 1.0 file from GSM operator
				buff2[0] = 0;
				i++;
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff2[strlen(buff2)+1] = 0;
					buff2[strlen(buff2)]   = File->Buffer.data()[pos+i];
					i++;
				}
				SubEntry->File.Info.SetName(StringToUnicodeReturn(buff2));
//				i++;
				break;
			case 0x86:
				while (File->Buffer.data()[pos+i]!=0x00) i++;
				break;
			case 0x89:
				buff[0] = 0;
				sprintf(buff,"%s; type=",buff);
				i++;
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				i++;
				break;
			case 0x8A:
				buff[0] = 0;
				sprintf(buff,"%s; start=",buff);
				i++;
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				i++;
				break;
			case 0x8E:
				i++;
				buff[0] = 0;
				printf("      Name          : ");
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				printf("%s\n",buff);
				SubEntry->File.Info.SetName(StringToUnicodeReturn(buff));
				break;
			case 0xAE:
				while (File->Buffer.data()[pos+i]!=0x00) i++;
				break;
			case 0xC0:
				i++;
				i++;
				buff[0] = 0;
				printf("      SMIL CID      : ");
				while (File->Buffer.data()[pos+i]!=0x00) {
					buff[strlen(buff)+1] = 0;
					buff[strlen(buff)]   = File->Buffer.data()[pos+i];
					i++;
				}
				printf("%s\n",buff);
				SubEntry->Text2.append(StringToUnicodeReturn(buff),UnicodeLength(StringToUnicodeReturn(buff)));
				break;
			default:
				printf("unknown3 %02x\n",File->Buffer.data()[pos+i]);
			}
			i++;
		}
		pos+=i;

		//data
		SubEntry->File.Buffer.append(File->Buffer.data()+pos,len3);
		SubEntry->File.Info.Size=len3;
		Add(SubEntry);

		pos+=len3;
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}
