
This is source of project Gammu+. 

It can be compiled with GCC (but please note, that in some distributions like
Mandrake you have to install separate RPM modules to have C++ support in GCC) 
and MS Visual C++.

For more see www.mwiacek.com and www.gammu.org
