/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../cfg/config.h"
#include "gsmstate.h"
#include "misc/coding/coding.h"
#include "misc/ini.h"

#ifdef WIN32
#  include "device/serial/ser_w32.h"
#  include "device/bluetoth/blue_w32.h"
#else
#  include "device/serial/ser_unx.h"
#endif
#include "device/irda/irda.h"

#include "protocol/nokia/fbus2.h"
#include "protocol/nokia/phonet.h"
#include "protocol/obex/obex.h"

#include "phone/nokia/dct3/n6110.h"
#include "phone/nokia/dct3/n7110.h"
#include "phone/nokia/dct4s40/n6510.h"
#include "phone/nokia/nauto.h"

GSM_StateMachine::GSM_StateMachine(FILE *deb_file, char *FileName, bool enable)
{
	Debug = new DebugInfo;

	Debug->SetDebug(deb_file,FileName,enable);

        Devices         = new GSM_AllDevices(&Debug);
        Protocols       = new GSM_AllProtocols(&Debug);
        Phones          = new GSM_AllPhones(&Debug);

	Debug->Deb("[GAMMU+    : %s built %s %s",VERSION,__TIME__,__DATE__);
	if (strlen(GetCompiler()) != 0) {
		Debug->Deb(" in %s]\n",GetCompiler());
	} else {
		Debug->Deb("]\n");
	}
	if (strlen(GetOS()) != 0) Debug->Deb("[RUN ON    : %s]\n",GetOS());

        Devices->Add(new GSM_Device_Infrared(&Debug));
        Devices->Add(new GSM_Device_Serial(&Debug));
#ifdef WIN32
        Devices->Add(new GSM_Device_Bluetooth(&Debug));
#endif

        Protocols->Add(new GSM_Protocol_FBUS2(&(Devices->Current),&Debug));
        Protocols->Add(new GSM_Protocol_PHONET(&(Devices->Current),&Debug));
        Protocols->Add(new GSM_Protocol_OBEX(&(Devices->Current),&Debug));
  
        Phones->Add(new GSM_Phone_N6110(&Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_N7110(&Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_N6510(&Debug,&(Devices->Current),&Protocols,&Phones));
        Phones->Add(new GSM_Phone_NAUTO(&Debug,&(Devices->Current),&Protocols,&Phones));
}

GSM_StateMachine::~GSM_StateMachine()
{
	Close();

	delete(Phones);
	delete(Protocols);
	delete(Devices);

	delete(Debug);
}

GSM_Error GSM_StateMachine::Close()
{
        GSM_Error error;

        if (Phones->Current != NULL) {
		Debug->Deb("[CLOSING PHONES]\n");
                error=Phones->Current->Close();
                if (error.Code != GSM_ERR_NONE) return error;
        }

        if (Protocols->Current != NULL) {
		Debug->Deb("[CLOSING PROTOCOLS]\n");
                error=Protocols->Current->Close();
                if (error.Code != GSM_ERR_NONE) return error;
        }

        if (Devices->Current != NULL) {
		Debug->Deb("[CLOSING DEVICES]\n");
	        error=Devices->Current->Close();
                if (error.Code != GSM_ERR_NONE) return error;
        }

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_StateMachine::Open(char *Dev, char *Prot, char *Pho, char *Comp)
{
        GSM_Error       			error;
        char            			*DeviceName = NULL;
	unsigned char   			Buff[100];
	list<GSM_Protocol_Info>::iterator 	proinfo;
	unsignedstring				Prot2,Pho2;
	int					i;

	for (i=0;i<(int)strlen(Prot);i++) Prot2.push_back(tolower(Prot[i]));
	for (i=0;i<(int)strlen(Pho);i++) Pho2.push_back(tolower(Pho[i]));

	Debug->Deb("[STARTUP   : device \"%s\", protocol \"%s\", phone \"%s\"]\n",Dev,Prot,Pho);

        error=Devices->Switch((char *)Prot2.data(),Protocols,Phones,Dev);
        if (error.Code != GSM_ERR_NONE) return error;

        error=Protocols->Switch((char *)Prot2.data(),Phones);
        if (error.Code != GSM_ERR_NONE) return error;

        error=Devices->Current->Open(Dev,(char *)Prot2.data(),(char *)Pho2.data(),&DeviceName,Phones);
        if (error.Code != GSM_ERR_NONE) return error;

        error=Protocols->Current->Open((char *)Prot2.data());
        if (error.Code != GSM_ERR_NONE) return error;

	for (proinfo=Protocols->Current->Info.begin(); proinfo!=Protocols->Current->Info.end(); ++proinfo) {
		if (!strcmp((char *)Prot2.data(),(*proinfo).Protocol)) break;
        }

        if (Pho[0] == 0 && (*proinfo).CanUseDeviceName) {
		error=Phones->SwitchToDeviceName(DeviceName,(char *)Prot2.data(),Comp);
	} else {
                error=Phones->Switch((char *)Pho2.data(),(char *)Prot2.data(),Comp);
	}
	if (error.Code != GSM_ERR_NONE) return error;

        error=Phones->Current->Open("");
        if (error.Code != GSM_ERR_NONE) return error;

	/* We will get now phone info */
        error=Phones->Current->GetCodeNameModel(Buff);
        if (error.Code != GSM_ERR_NONE) return error;

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_StateMachine::OpenFromCfgFile(INI_File *File)
{
	char 		Device[200], Protocol[200], Phone[200], Compatibility[200];
	wchar_t		*value, x[200];
#ifndef WIN32
	char		tmp[500];
#endif

	strcpy(Device,"com2:");
#ifndef WIN32
	strcpy(Device,"/dev/ttyS1");
#endif
	strcpy(Protocol,"fbus");
	Phone[0] = 0;
	Compatibility[0] = 0;

	StringToUnicode("gammu",x);

	value = File->GetValue(x,StringToUnicodeReturn("port"));
	if (value != NULL) sprintf(Device,"%s",UnicodeToStringReturn(value));

	value = File->GetValue(x,StringToUnicodeReturn("connection"));
	if (value != NULL) sprintf(Protocol,"%s",UnicodeToStringReturn(value));

	value = File->GetValue(x,StringToUnicodeReturn("model"));
	if (value != NULL) sprintf(Phone,"%s",UnicodeToStringReturn(value));

	value = File->GetValue(x,StringToUnicodeReturn("compatibility"));
	if (value != NULL) sprintf(Compatibility,"%s",UnicodeToStringReturn(value));

	return Open(Device, Protocol, Phone, Compatibility);
}

void GSM_StateMachine::ReadCfgFile(INI_File *File)
{
	BOOLEAN		read = FALSE;
#ifndef WIN32
	char		tmp[500];
#endif

	if (read==FALSE && File->ReadFile("gammurc")==TRUE) read = TRUE;
#ifndef WIN32
	strcpy(tmp,getenv("HOME"));
	strcat(tmp,"/.gammurc");
	if (read==FALSE && File->ReadFile(tmp)==TRUE) read = TRUE;
	if (read==FALSE && File->ReadFile("/etc/gammurc")==TRUE) read = TRUE;
#endif
}

void GSM_StateMachine::SetUserReply(GSM_Error(*UsrReply)(int MsgLength, unsigned char MsgType, unsigned char *MsgBuffer, void *Struct, int RequestID))
{
        if (Phones->Current != NULL) Phones->Current->SetUserReply(UsrReply);
}

void GSM_StateMachine::SetSMSSendReply(void(*SMSSndReply)(int TPMR))
{
        if (Phones->Current != NULL) Phones->Current->SetSMSSendReply(SMSSndReply);
}

int GSM_StateMachine::GetRSSVersion(char *Buffer)
{
	int retval = 0, pos = 0;

	retval = atoi(Buffer) * 10000;
	while (Buffer[pos] != '.') {
		pos++;
		if (pos == strlen(Buffer)) return retval;
	}
	pos++;
	retval += atoi(Buffer+pos) * 100;
	while (Buffer[pos] != '.') {
		pos++;
		if (pos == strlen(Buffer)) return retval;
	}
	pos++;
	return retval + atoi(Buffer+pos);
}

GSM_Error GSM_StateMachine::CheckRSS(unsignedstring *StableStr, unsignedstring *TestStr)
{
	GSM_File 	File;
	GSM_Error	error;
	unsigned int	pos=0,oldpos=0,i;
	char		buff[200];
	unsignedstring	X;
	
	X.push_back(0x00);

	error = File.ReadFromWWW("www.mwiacek.com","gsm/soft/gplus.rss");
	if (error.Code!=GSM_ERR_NONE) return error;

	StableStr->clear();
	TestStr->clear();

	while (pos < File.Buffer.size()) {
		if (File.Buffer.data()[pos] != 10) {
			pos++;
			continue;
		}
		File.Buffer.replace(pos,1,X);
		if (strstr((char *)File.Buffer.data()+oldpos,"<title>") == NULL ||
		    strstr((char *)File.Buffer.data()+oldpos,"</title>")== NULL ||
		    strstr((char *)File.Buffer.data()+oldpos,"win32")   != NULL) {
			pos++;
			oldpos = pos;
			continue;
		}
		if (StableStr->length() == 0 && strstr((char *)File.Buffer.data()+oldpos,"stable version")!=NULL) {
			sprintf(buff,strstr((char *)File.Buffer.data()+oldpos,"stable version")+15);
			for (i=0;i<strlen(buff);i++) {
				if (buff[i] == '<') {
					buff[i] = 0;
					break;
				}
			}
			if (GetRSSVersion(buff)>GetRSSVersion(VERSION)) {
				StableStr->append((const unsigned char *)buff,strlen(buff));				
			}
		}
		if (TestStr->length() == 0 && strstr((char *)File.Buffer.data()+oldpos,"test version")!=NULL) {
			sprintf(buff,strstr((char *)File.Buffer.data()+oldpos,"test version")+13);
			for (i=0;i<strlen(buff);i++) {
				if (buff[i] == '<') {
					buff[i] = 0;
					break;
				}
			}
			if (GetRSSVersion(buff)>GetRSSVersion(VERSION)) {
				TestStr->append((const unsigned char *)buff,strlen(buff));				
			}
		}
		pos++;
		oldpos = pos;
		if (StableStr->length() != 0 && TestStr->length() != 0) break;
	}

	if (StableStr->length() != 0 && TestStr->length() != 0 &&
	    GetRSSVersion((char *)StableStr->data()) > GetRSSVersion((char *)TestStr->data())) {
		TestStr->clear();
	}

        return GSM_Return_Error(GSM_ERR_NONE);
}
