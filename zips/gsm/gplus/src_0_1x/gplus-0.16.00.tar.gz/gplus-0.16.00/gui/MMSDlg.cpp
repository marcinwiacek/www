//---------------------------------------------------------------------------
//
// Name:        MMSDlg.cpp
// Author:      Marcinello
// Created:     2007-01-03 19:54:36
// Description: MMSDlg class implementation
//
//---------------------------------------------------------------------------

#include "MMSDlg.h"
#include "mainfrm.h"

#include "../cfg/config.h"
#include "../common/misc/coding/coding.h"
#include "../common/service/gsmfiles.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// MMSDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(MMSDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(MMSDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,MMSDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

MMSDlg::MMSDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

MMSDlg::~MMSDlg()
{
} 

void MMSDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("MMS viewer"));
	SetIcon(wxNullIcon);
	SetSize(8,8,619,364);
	Center();
	

	WxOpenFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxOPEN);

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("Open file"), wxPoint(6,7), wxSize(68,20), 0, wxDefaultValidator, wxT("WxButton1"));

	WxListCtrl1 = new wxListCtrl(this, ID_WXLISTCTRL1, wxPoint(6,36), wxSize(602,289), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,300 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,200 );
	////GUI Items Creation End
}

void MMSDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void MMSDlg::WxButton1Click(wxCommandEvent& event)
{
    char buff[2000];
    GSM_File File;

    if (WxOpenFileDialog1->ShowModal()!=wxID_OK) return;
    File.ReadFromDisk(StringToUnicodeReturn((char *)WxOpenFileDialog1->GetPath().c_str()));
    ViewMMSFile(&File, WxListCtrl1);
    
    sprintf(buff, "%s - MMS viewer",(char *)WxOpenFileDialog1->GetPath().c_str());
 	SetTitle(wxT(buff));    
}
