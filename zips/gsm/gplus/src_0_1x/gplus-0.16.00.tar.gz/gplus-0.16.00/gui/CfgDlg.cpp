//---------------------------------------------------------------------------
//
// Name:        CfgDlg.cpp
// Author:      Marcinello
// Created:     2006-12-13 11:38:12
// Description: CfgDlg class implementation
//
//---------------------------------------------------------------------------

#include "CfgDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// CfgDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(CfgDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(CfgDlg::OnClose)
	EVT_INIT_DIALOG(CfgDlg::CfgDlgInitDialog)
END_EVENT_TABLE()
////Event Table End

CfgDlg::CfgDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

CfgDlg::~CfgDlg()
{
} 

void CfgDlg::CreateGUIControls()
{
	//Do not add custom code here
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("CfgDlg"));
	SetIcon(wxNullIcon);
	SetSize(8,8,347,149);
	Center();
	

	WxButton3 = new wxButton(this, ID_WXBUTTON3, wxT("&Select"), wxPoint(246,49), wxSize(78,22), 0, wxDefaultValidator, wxT("WxButton3"));

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, wxT("WxEdit1"), wxPoint(99,50), wxSize(143,21), 0, wxDefaultValidator, wxT("WxEdit1"));

	wxArrayString arrayStringFor_WxComboBox1;
	WxComboBox1 = new wxComboBox(this, ID_WXCOMBOBOX1, wxT("WxComboBox1"), wxPoint(100,25), wxSize(223,21), arrayStringFor_WxComboBox1, 0, wxDefaultValidator, wxT("WxComboBox1"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("&Cancel"), wxPoint(240,91), wxSize(93,25), 0, wxDefaultValidator, wxT("WxButton2"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("&OK"), wxPoint(141,91), wxSize(93,25), 0, wxDefaultValidator, wxT("WxButton1"));

	WxStaticText2 = new wxStaticText(this, ID_WXSTATICTEXT2, wxT("Device:"), wxPoint(14,51), wxDefaultSize, 0, wxT("WxStaticText2"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("Connection type:"), wxPoint(13,27), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxStaticBox1 = new wxStaticBox(this, ID_WXSTATICBOX1, wxT("WxStaticBox1"), wxPoint(7,4), wxSize(326,78));
	////GUI Items Creation End
}

void CfgDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * CfgDlgInitDialog
 */
void CfgDlg::CfgDlgInitDialog(wxInitDialogEvent& event)
{
//            pro = NULL;
//        while(1) {
//                if (!s->Protocols->GetNext(&pro)) break;
//		for (proinfo=pro->Info.begin(); proinfo!=pro->Info.end(); ++proinfo) {
//                        printf("  \"%s\" dev \"%s\"\n",(*proinfo).Protocol,(*proinfo).Device);
//	        }
//        }

	// insert your code here
}
