//---------------------------------------------------------------------------
//
// Name:        MainFrm.h
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: MainFrm class declaration
//
//---------------------------------------------------------------------------

#ifndef __MainFrm_h__
#define __MainFrm_h__

#ifdef __BORLANDC__
        #pragma hdrstop
#endif

#ifndef WX_PRECOMP
        #include <wx/wx.h>
        #include <wx/frame.h>
#else
        #include <wx/wxprec.h>
#endif

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
#include <wx/dirdlg.h>
#include <wx/menu.h>
#include <wx/filedlg.h>
#include <wx/checkbox.h>
#include <wx/calctrl.h>
#include <wx/bmpbuttn.h>
#include <wx/listbox.h>
#include <wx/listctrl.h>
#include <wx/textctrl.h>
#include <wx/choice.h>
#include <wx/button.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/sizer.h>
#include <wx/statusbr.h>
////Header Include End
#include <wx/progdlg.h>

#include "../common/service/gsmmisc.h"
#include "../common/service/gsmfiles.h"

////Dialog Style Start
#undef MainFrm_STYLE
#define MainFrm_STYLE wxCAPTION | wxRESIZE_BORDER | wxSYSTEM_MENU | wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class MainFrm : public wxFrame
{
        private:
                DECLARE_EVENT_TABLE();
                
        public:
                MainFrm(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Project2"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = MainFrm_STYLE);
                virtual ~MainFrm();
                void Mnuexit1017Click1(wxCommandEvent& event);
                void WxListCtrl1ItemActivated(wxListEvent& event);
                void WxListCtrl1RightClick(wxListEvent& event);
                void WxListCtrl1BeginDrag(wxListEvent& event);
                void PBKGetWxButtonClick(wxCommandEvent& event);
                void PBKUpWxListCtrlItemActivated(wxListEvent& event);
                void SMSGetWxButtonClick(wxCommandEvent& event);
                void Mnuabout1019Click(wxCommandEvent& event);
                void SMSWxChoiceSelected(wxCommandEvent& event );
                void SMSUpWxListCtrlItemActivated(wxListEvent& event);
                void WxButton2Click(wxCommandEvent& event);
                void wxNotebook1PageChanged(wxNotebookEvent& event);
        		void WxCalendarCtrl1SelChanged(wxCalendarEvent& event);
        		void WxCheckBox1Click(wxCommandEvent& event);
        		void WxListCtrl6ItemActivated(wxListEvent& event);
            	void Mnuconfiguration1147Click(wxCommandEvent& event);
           		void PBKUpWxListCtrlColLeftClick(wxListEvent& event);
            	void Mnumenuitem11020Click(wxCommandEvent& event);
            	void Mnuproperties1026Click(wxCommandEvent& event);
            	void Mnurename1024Click(wxCommandEvent& event);
            	void Mnuaddfile1027Click(wxCommandEvent& event);
            	void Mnuaddfolder1022Click(wxCommandEvent& event);
            	void Mnudelete1023Click(wxCommandEvent& event);
            	void Mnuforward1148Click(wxCommandEvent& event);
        		void SMSUpWxListCtrlRightClick(wxListEvent& event);
        		void PBKWxChoiceSelected(wxCommandEvent& event );
		void FileGetWxButtonClick(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
		void MMSGetWxButtonClick(wxCommandEvent& event);
		void MMSWxChoiceSelected(wxCommandEvent& event );
		void MMSUpWxListCtrlItemActivated(wxListEvent& event);
		void MMSDetailsWxListCtrlItemActivated(wxListEvent& event);
	void Mnuopenmmsfile1201Click(wxCommandEvent& event);
	void Mnuopenmmsfile1201Click1(wxCommandEvent& event);
	void Mnuconnect1203Click(wxCommandEvent& event);
		void WxChoice1Selected(wxCommandEvent& event );
        private:
                //Do not add custom control declarations
                //wxDev-C++ will remove them. Add custom code after the block.
                ////GUI Control Declaration Start
		wxMenu *WxPopupMenu2;
		wxDirDialog *WxDirDialog1;
		wxFileDialog *WxOpenFileDialog1;
		wxMenuBar *WxMenuBar1;
		wxMenu *WxPopupMenu1;
		wxFileDialog *WxSaveFileDialog1;
		wxListCtrl *WxListCtrl1;
		wxButton *FileGetWxButton;
		wxPanel *WxPanel3;
		wxBoxSizer *WxBoxSizer1;
		wxPanel *FilesWxNoteBookPage;
		wxPanel *NotesWxNoteBookPage;
		wxPanel *ToDoWxNoteBookPage;
		wxListCtrl *WxListCtrl7;
		wxListCtrl *WxListCtrl6;
		wxGridSizer *WxGridSizer4;
		wxCheckBox *WxCheckBox1;
		wxCalendarCtrl *WxCalendarCtrl1;
		wxPanel *WxPanel5;
		wxBoxSizer *WxBoxSizer6;
		wxButton *WxButton2;
		wxPanel *WxPanel4;
		wxBoxSizer *WxBoxSizer5;
		wxPanel *CalendarWxNoteBookPage;
		wxTextCtrl *WxMemo1;
		wxBitmapButton *WxBitmapButton1;
		wxGridSizer *WxGridSizer6;
		wxButton *WxButton1;
		wxChoice *WxChoice1;
		wxPanel *WxPanel7;
		wxBoxSizer *WxBoxSizer9;
		wxPanel *MMSSummaryWxNoteBookPage;
		wxListCtrl *MMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer10;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook3;
		wxListCtrl *MMSUpWxListCtrl;
		wxGridSizer *WxGridSizer5;
		wxButton *MMSSearchWxButton;
		wxTextCtrl *WxEdit2;
		wxButton *MMSGetWxButton;
		wxChoice *MMSWxChoice;
		wxPanel *WxPanel6;
		wxBoxSizer *WxBoxSizer8;
		wxPanel *WxNoteBookPage8;
		wxListCtrl *SMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer4;
		wxPanel *SMSDetailsWxNoteBookPage;
		wxTextCtrl *SMSWxMemo;
		wxListBox *SMSNumbersWxListBox;
		wxBoxSizer *WxBoxSizer7;
		wxPanel *SMSSummaryWxNoteBookPage;
		wxNotebook *WxNotebook2;
		wxListCtrl *SMSUpWxListCtrl;
		wxGridSizer *WxGridSizer3;
		wxButton *WxButton3;
		wxTextCtrl *WxEdit3;
		wxChoice *SMSWxChoice;
		wxButton *SMSGetWxButton;
		wxPanel *WxPanel2;
		wxBoxSizer *WxBoxSizer3;
		wxPanel *SMSWxNoteBookPage;
		wxListCtrl *PBKDownWxListCtrl;
		wxListCtrl *PBKUpWxListCtrl;
		wxGridSizer *WxGridSizer2;
		wxButton *PBKSearchWxButton;
		wxTextCtrl *PBKSearchWxEdit;
		wxChoice *PBKWxChoice;
		wxButton *PBKGetWxButton;
		wxPanel *WxPanel1;
		wxBoxSizer *WxBoxSizer2;
		wxPanel *PBKWxNoteBookPage;
		wxNotebook *wxNotebook1;
		wxGridSizer *WxGridSizer1;
		wxStatusBar *WxStatusBar1;
                ////GUI Control Declaration End
                
        private:
                //Note: if you receive any error with these enum IDs, then you need to
                //change your old form code that are based on the #define control IDs.
                //#defines may replace a numeric value for the enum names.
                //Try copy and pasting the below block in your old form header files.
                enum
                {
                        ////GUI Enum Control ID Start
			ID_MNU_FORWARD_1148 = 1148,
			
			ID_MNU_MENUITEM1_1016 = 1016,
			ID_MNU_OPENMMSFILE_1201 = 1201,
			ID_MNU_EXIT_1017 = 1017,
			ID_MNU_TOOLS_1146 = 1146,
			ID_MNU_CONNECT_1203 = 1203,
			ID_MNU_CONFIGURATION_1147 = 1147,
			ID_MNU_HELP_1018 = 1018,
			ID_MNU_ABOUT_1019 = 1019,
			
			ID_MNU_MENUITEM1_1020 = 1020,
			ID_MNU_DELETE_1023 = 1023,
			ID_MNU_ADDFOLDER_1022 = 1022,
			ID_MNU_ADDFILE_1027 = 1027,
			ID_MNU_RENAME_1024 = 1024,
			ID_MNU_PROPERTIES_1026 = 1026,
			
			ID_WXLISTCTRL1 = 1015,
			ID_FILEGETWXBUTTON3 = 1153,
			ID_WXPANEL3 = 1115,
			ID_FILESWXNOTEBOOKPAGE = 1013,
			ID_NOTESWXNOTEBOOKPAGE = 1143,
			ID_TODOWXNOTEBOOKPAGE = 1142,
			ID_WXLISTCTRL7 = 1141,
			ID_WXLISTCTRL6 = 1140,
			ID_WXCHECKBOX1 = 1139,
			ID_WXCALENDARCTRL1 = 1138,
			ID_WXPANEL5 = 1136,
			ID_WXBUTTON2 = 1145,
			ID_WXPANEL4 = 1118,
			ID_CALENDARWXNOTEBOOKPAGE = 1116,
			ID_WXMEMO1 = 1200,
			ID_WXBITMAPBUTTON1 = 1199,
			ID_WXBUTTON1 = 1205,
			ID_WXCHOICE1 = 1187,
			ID_WXPANEL7 = 1186,
			ID_MMSSUMMARYWXNOTEBOOKPAGE = 1175,
			ID_MMSDETAILSWXLISTCTRL = 1183,
			ID_WXNOTEBOOKPAGE1 = 1180,
			ID_WXNOTEBOOK3 = 1174,
			ID_MMSUPWXLISTCTRL = 1173,
			ID_MMSSEARCHWXBUTTON = 1170,
			ID_WXEDIT2 = 1169,
			ID_MMSGETWXBUTTON = 1168,
			ID_MMSWXCHOICE = 1167,
			ID_WXPANEL6 = 1165,
			ID_WXNOTEBOOKPAGE8 = 1152,
			ID_SMSDETAILSWXLISTCTRL = 1114,
			ID_SMSDETAILSWXNOTEBOOKPAGE = 1110,
			ID_SMSWXMEMO = 1163,
			ID_SMSNUMBERSWXLISTBOX = 1162,
			ID_SMSSUMMARYWXNOTEBOOKPAGE = 1154,
			ID_WXNOTEBOOK2 = 1109,
			ID_SMSUPWXLISTCTRL = 1103,
			ID_WXBUTTON3 = 1161,
			ID_WXEDIT3 = 1160,
			ID_SMSWXCHOICE = 1108,
			ID_SMSGETWXBUTTON = 1106,
			ID_WXPANEL2 = 1101,
			ID_SMSWXNOTEBOOKPAGE = 1099,
			ID_PBKDOWNWXLISTCTRL = 1096,
			ID_PBKUPWXLISTCTRL = 1095,
			ID_PBKSEARCHWXBUTTON = 1171,
			ID_PBKSEARCHWXEDIT = 1151,
			ID_PBKWXCHOICE = 1150,
			ID_PBKGETWXBUTTON = 1097,
			ID_WXPANEL1 = 1070,
			ID_PBKWXNOTEBOOKPAGE = 1029,
			ID_WXNOTEBOOK1 = 1012,
			ID_WXSTATUSBAR1 = 1006,
                        ////GUI Enum Control ID End
                        ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
                };
                
        private:
                void OnClose(wxCloseEvent& event);
                void CreateGUIControls();
                void EnterFolder();
                void DisplayCalendar();
        		void ReadPBKMemory(GSM_MemoryType Mem);
        		void DisplayPBK(GSM_MemoryType Mem, long *PbkNum,long *ReceivedSec,long *DialledSec);
                BOOLEAN MainFrm::ReadSMSFolder(int Num2, GSM_SMSMMSFoldersSubEntry *SubFolder);
                void DisplaySMSEntry();
                void DisplaySMSFolder();
                void FindSMSNumber(wchar_t *Number);
                void AddAllPBKMemories();     
                void ReadSMSMMSFolders(BOOLEAN SMS);                                           
};

void ViewMMSFile(GSM_File *File, wxListCtrl *List);

#endif
