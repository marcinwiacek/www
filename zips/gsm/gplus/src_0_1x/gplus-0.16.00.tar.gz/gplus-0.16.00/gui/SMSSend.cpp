//---------------------------------------------------------------------------
//
// Name:        SMSSend.cpp
// Author:      Marcinello
// Created:     2006-12-16 11:27:22
// Description: SMSSend class implementation
//
//---------------------------------------------------------------------------

#include "SMSSend.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// SMSSend
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(SMSSend,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(SMSSend::OnClose)
END_EVENT_TABLE()
////Event Table End

SMSSend::SMSSend(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

SMSSend::~SMSSend()
{
} 

void SMSSend::CreateGUIControls()
{
	//Do not add custom code here
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("SMSSend"));
	SetIcon(wxNullIcon);
	SetSize(8,8,377,490);
	Center();
	

	WxButton5 = new wxButton(this, ID_WXBUTTON5, wxT("Add"), wxPoint(267,213), wxSize(82,22), 0, wxDefaultValidator, wxT("WxButton5"));

	WxButton4 = new wxButton(this, ID_WXBUTTON4, wxT("Add"), wxPoint(267,169), wxSize(82,24), 0, wxDefaultValidator, wxT("WxButton4"));

	WxStaticLine1 = new wxStaticLine(this, ID_WXSTATICLINE1, wxPoint(14,196), wxSize(336,-1), wxLI_HORIZONTAL);

	wxArrayString arrayStringFor_WxListBox3;
	WxListBox3 = new wxListBox(this, ID_WXLISTBOX3, wxPoint(20,332), wxSize(243,90), arrayStringFor_WxListBox3, wxLB_SINGLE);

	wxArrayString arrayStringFor_WxListBox2;
	WxListBox2 = new wxListBox(this, ID_WXLISTBOX2, wxPoint(19,239), wxSize(243,88), arrayStringFor_WxListBox2, wxLB_SINGLE);

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, wxT("WxEdit1"), wxPoint(20,170), wxSize(241,21), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxButton3 = new wxButton(this, ID_WXBUTTON3, wxT("Delete"), wxPoint(270,19), wxSize(81,22), 0, wxDefaultValidator, wxT("WxButton3"));

	wxArrayString arrayStringFor_WxListBox1;
	WxListBox1 = new wxListBox(this, ID_WXLISTBOX1, wxPoint(18,18), wxSize(243,109), arrayStringFor_WxListBox1, wxLB_SINGLE);

	wxArrayString arrayStringFor_WxComboBox1;
	WxComboBox1 = new wxComboBox(this, ID_WXCOMBOBOX1, wxT("WxComboBox1"), wxPoint(20,213), wxSize(242,21), arrayStringFor_WxComboBox1, 0, wxDefaultValidator, wxT("WxComboBox1"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Close"), wxPoint(186,435), wxSize(95,24), 0, wxDefaultValidator, wxT("WxButton2"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("Send"), wxPoint(70,435), wxSize(92,24), 0, wxDefaultValidator, wxT("WxButton1"));

	WxStaticBox2 = new wxStaticBox(this, ID_WXSTATICBOX2, wxT("New recipient"), wxPoint(10,145), wxSize(349,284));

	WxStaticBox1 = new wxStaticBox(this, ID_WXSTATICBOX1, wxT("Recipients"), wxPoint(10,4), wxSize(349,133));
	////GUI Items Creation End
}

void SMSSend::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}
