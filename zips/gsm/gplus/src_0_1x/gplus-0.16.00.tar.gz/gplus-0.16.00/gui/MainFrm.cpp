//---------------------------------------------------------------------------
//
// Name:        MainFrm.cpp
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: MainFrm class implementation
//
//---------------------------------------------------------------------------

#include "MainFrm.h"
#include "AboutDlg.h"
#include "MMSDlg.h"
#include "CfgDlg.h"

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

FILE                      *DebFile;
bool                      UseDeb;
GSM_StateMachine          *s;
INI_File                  CFG;
wchart                    StatusStr[7];
wchart                    StatusStr2[7];

wchar_t                   FileFolderID[500], FileFolderID0[500];
wchart                    ParentFolderID[20];
int                       ParentFolderIDNum = 1;
wchart                    CurrentFolderName, CurrentFolderName0;
int                       FileSystemNum = 0;

GSM_Backup                Backup;
bool                      SortPBKReverse = false;
int                       SortPBK = 0;
bool                      FirstPBK = true;

GSM_SMSMMSFolders         SMSFolders;
bool                      FirstSMS = true;
bool                      FirstMMS = true;

GSM_FileFolderInfoLists   Folders;
GSM_FileFolderInfoListsSubEntry   *En2;

//----------------------------------------------------------------------------
// MainFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(MainFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(MainFrm::OnClose)
	EVT_MENU(ID_MNU_FORWARD_1148 , MainFrm::Mnuforward1148Click)
	EVT_MENU(ID_MNU_OPENMMSFILE_1201, MainFrm::Mnuopenmmsfile1201Click1)
	EVT_MENU(ID_MNU_EXIT_1017, MainFrm::Mnuexit1017Click1)
	EVT_MENU(ID_MNU_CONNECT_1203, MainFrm::Mnuconnect1203Click)
	EVT_MENU(ID_MNU_CONFIGURATION_1147, MainFrm::Mnuconfiguration1147Click)
	EVT_MENU(ID_MNU_ABOUT_1019, MainFrm::Mnuabout1019Click)
	EVT_MENU(ID_MNU_MENUITEM1_1020 , MainFrm::Mnumenuitem11020Click)
	EVT_MENU(ID_MNU_DELETE_1023 , MainFrm::Mnudelete1023Click)
	EVT_MENU(ID_MNU_ADDFOLDER_1022 , MainFrm::Mnuaddfolder1022Click)
	EVT_MENU(ID_MNU_ADDFILE_1027 , MainFrm::Mnuaddfile1027Click)
	EVT_MENU(ID_MNU_RENAME_1024 , MainFrm::Mnurename1024Click)
	EVT_MENU(ID_MNU_PROPERTIES_1026 , MainFrm::Mnuproperties1026Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL1,MainFrm::WxListCtrl1ItemActivated)
	EVT_LIST_ITEM_RIGHT_CLICK(ID_WXLISTCTRL1,MainFrm::WxListCtrl1RightClick)
	EVT_BUTTON(ID_FILEGETWXBUTTON3,MainFrm::FileGetWxButtonClick)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL6,MainFrm::WxListCtrl6ItemActivated)
	EVT_CHECKBOX(ID_WXCHECKBOX1,MainFrm::WxCheckBox1Click)
	
	EVT_CALENDAR_SEL_CHANGED(ID_WXCALENDARCTRL1,MainFrm::WxCalendarCtrl1SelChanged)
	EVT_BUTTON(ID_WXBUTTON2,MainFrm::WxButton2Click)
	EVT_CHOICE(ID_WXCHOICE1,MainFrm::WxChoice1Selected)
	
	EVT_LIST_ITEM_ACTIVATED(ID_MMSDETAILSWXLISTCTRL,MainFrm::MMSDetailsWxListCtrlItemActivated)
	
	EVT_LIST_ITEM_ACTIVATED(ID_MMSUPWXLISTCTRL,MainFrm::MMSUpWxListCtrlItemActivated)
	EVT_BUTTON(ID_MMSGETWXBUTTON,MainFrm::MMSGetWxButtonClick)
	EVT_CHOICE(ID_MMSWXCHOICE,MainFrm::MMSWxChoiceSelected)
	
	EVT_LIST_ITEM_ACTIVATED(ID_SMSUPWXLISTCTRL,MainFrm::SMSUpWxListCtrlItemActivated)
	EVT_LIST_ITEM_RIGHT_CLICK(ID_SMSUPWXLISTCTRL,MainFrm::SMSUpWxListCtrlRightClick)
	EVT_BUTTON(ID_WXBUTTON3,MainFrm::WxButton3Click)
	EVT_CHOICE(ID_SMSWXCHOICE,MainFrm::SMSWxChoiceSelected)
	EVT_BUTTON(ID_SMSGETWXBUTTON,MainFrm::SMSGetWxButtonClick)
	
	EVT_LIST_ITEM_ACTIVATED(ID_PBKUPWXLISTCTRL,MainFrm::PBKUpWxListCtrlItemActivated)
	EVT_LIST_COL_CLICK(ID_PBKUPWXLISTCTRL,MainFrm::PBKUpWxListCtrlColLeftClick)
	EVT_CHOICE(ID_PBKWXCHOICE,MainFrm::PBKWxChoiceSelected)
	EVT_BUTTON(ID_PBKGETWXBUTTON,MainFrm::PBKGetWxButtonClick)
	
	EVT_NOTEBOOK_PAGE_CHANGED(ID_WXNOTEBOOK1,MainFrm::wxNotebook1PageChanged)
END_EVENT_TABLE()
////Event Table End

BOOLEAN PrintError (GSM_Error error)
{
    unsigned char buffer[2000];

    if (error.Code == GSM_ERR_NONE) return FALSE;
    sprintf((char *)buffer,"%s",GSM_GetErrorInfo(error));
    wxMessageBox(buffer,
            wxT("Error"),
            wxICON_WARNING | wxOK);
    return TRUE;
}

void FixBuffer(wchar_t *Buffer)
{
    int i;

    for (i=0;i<UnicodeLength(Buffer);i++) {
        if (Buffer[i] == 242) Buffer[i] = ' ';
    }
}

MainFrm::MainFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
    GSM_Error error;
    char buff[200];
    unsigned char Model[50];
    unsigned char Firm[50];
    unsigned char Man[50];

    CreateGUIControls();

    DebFile = NULL;
    UseDeb = false;
    s = new GSM_StateMachine(DebFile,"",UseDeb);
    s->ReadCfgFile(&CFG);

    error = s->OpenFromCfgFile(&CFG);
    if (PrintError(error)) {
        wxNotebook1->Hide();
        sprintf(buff, "Gammu+ %s",VERSION);
    	SetTitle(wxT(buff));
    } else {
    	error = s->Phones->Current->GetManufacturer(Man);
	    PrintError(error);

    	error = s->Phones->Current->GetModel(Model);
    	PrintError(error);

    	error = s->Phones->Current->GetFirmwareVersion(Firm);
    	PrintError(error);
    
        sprintf(buff, "%s %s %s - Gammu+ %s",Man,Model,Firm,VERSION);
    	SetTitle(wxT(buff));
    }
}

MainFrm::~MainFrm()
{
}

void MainFrm::CreateGUIControls()
{    
    //Do not add custom code here
    //wxDev-C++ designer will remove them.
    //Add the custom code before or after the blocks
    ////GUI Items Creation Start

	WxStatusBar1 = new wxStatusBar(this, ID_WXSTATUSBAR1);

	WxGridSizer1 = new wxGridSizer(1, 1, 0, 0);
	this->SetSizer(WxGridSizer1);
	this->SetAutoLayout(true);

	wxNotebook1 = new wxNotebook(this, ID_WXNOTEBOOK1, wxPoint(0,0),wxSize(624,470));
	WxGridSizer1->Add(wxNotebook1,1,wxEXPAND | 0,0);

	PBKWxNoteBookPage = new wxPanel(wxNotebook1, ID_PBKWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(PBKWxNoteBookPage, wxT("Contacts and logs"));

	WxBoxSizer2 = new wxBoxSizer(wxVERTICAL);
	PBKWxNoteBookPage->SetSizer(WxBoxSizer2);
	PBKWxNoteBookPage->SetAutoLayout(true);

	WxPanel1 = new wxPanel(PBKWxNoteBookPage, ID_WXPANEL1, wxPoint(0,0), wxSize(533,31));
	WxBoxSizer2->Add(WxPanel1,0,wxALIGN_TOP | 0,5);

	PBKGetWxButton = new wxButton(WxPanel1, ID_PBKGETWXBUTTON, wxT("Get from phone"), wxPoint(238,5), wxSize(86,21), 0, wxDefaultValidator, wxT("PBKGetWxButton"));

	wxArrayString arrayStringFor_PBKWxChoice;
	PBKWxChoice = new wxChoice(WxPanel1, ID_PBKWXCHOICE, wxPoint(5,5), wxSize(225,21), arrayStringFor_PBKWxChoice, 0, wxDefaultValidator, wxT("PBKWxChoice"));
	PBKWxChoice->SetSelection(-1);

	PBKSearchWxEdit = new wxTextCtrl(WxPanel1, ID_PBKSEARCHWXEDIT, wxT(""), wxPoint(333,5), wxSize(83,21), 0, wxDefaultValidator, wxT("PBKSearchWxEdit"));

	PBKSearchWxButton = new wxButton(WxPanel1, ID_PBKSEARCHWXBUTTON, wxT("Search"), wxPoint(426,5), wxSize(86,21), 0, wxDefaultValidator, wxT("PBKSearchWxButton"));

	WxGridSizer2 = new wxGridSizer(1, 1, 0, 0);
	WxBoxSizer2->Add(WxGridSizer2, 1, wxEXPAND | 0, 5);

	PBKUpWxListCtrl = new wxListCtrl(PBKWxNoteBookPage, ID_PBKUPWXLISTCTRL, wxPoint(5,6), wxSize(170,159), wxLC_REPORT);
	PBKUpWxListCtrl->InsertColumn(0,wxT("Time"),wxLIST_FORMAT_LEFT,400 );
	PBKUpWxListCtrl->InsertColumn(0,wxT("Default number"),wxLIST_FORMAT_LEFT,140 );
	PBKUpWxListCtrl->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,250 );
	PBKUpWxListCtrl->InsertColumn(0,wxT("Location"),wxLIST_FORMAT_LEFT,50 );
	WxGridSizer2->Add(PBKUpWxListCtrl,1,wxEXPAND | wxALL,5);

	PBKDownWxListCtrl = new wxListCtrl(PBKWxNoteBookPage, ID_PBKDOWNWXLISTCTRL, wxPoint(9,177), wxSize(162,162), wxLC_REPORT);
	PBKDownWxListCtrl->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,400 );
	PBKDownWxListCtrl->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,100 );
	WxGridSizer2->Add(PBKDownWxListCtrl,1,wxEXPAND | wxALL,5);

	SMSWxNoteBookPage = new wxPanel(wxNotebook1, ID_SMSWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(SMSWxNoteBookPage, wxT("SMS"));

	WxBoxSizer3 = new wxBoxSizer(wxVERTICAL);
	SMSWxNoteBookPage->SetSizer(WxBoxSizer3);
	SMSWxNoteBookPage->SetAutoLayout(true);

	WxPanel2 = new wxPanel(SMSWxNoteBookPage, ID_WXPANEL2, wxPoint(0,0), wxSize(611,31));
	WxBoxSizer3->Add(WxPanel2,0,wxALIGN_TOP | wxALL,0);

	SMSGetWxButton = new wxButton(WxPanel2, ID_SMSGETWXBUTTON, wxT("Get from phone"), wxPoint(238,5), wxSize(86,21), 0, wxDefaultValidator, wxT("SMSGetWxButton"));

	wxArrayString arrayStringFor_SMSWxChoice;
	SMSWxChoice = new wxChoice(WxPanel2, ID_SMSWXCHOICE, wxPoint(5,5), wxSize(225,21), arrayStringFor_SMSWxChoice, 0, wxDefaultValidator, wxT("SMSWxChoice"));
	SMSWxChoice->SetSelection(-1);

	WxEdit3 = new wxTextCtrl(WxPanel2, ID_WXEDIT3, wxT(""), wxPoint(333,5), wxSize(83,21), 0, wxDefaultValidator, wxT("WxEdit3"));

	WxButton3 = new wxButton(WxPanel2, ID_WXBUTTON3, wxT("Search"), wxPoint(426,5), wxSize(86,21), 0, wxDefaultValidator, wxT("WxButton3"));

	WxGridSizer3 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer3->Add(WxGridSizer3, 1, wxEXPAND | wxALL, 0);

	SMSUpWxListCtrl = new wxListCtrl(SMSWxNoteBookPage, ID_SMSUPWXLISTCTRL, wxPoint(21,5), wxSize(223,182), wxLC_REPORT);
	SMSUpWxListCtrl->InsertColumn(0,wxT("Parts"),wxLIST_FORMAT_LEFT,50 );
	SMSUpWxListCtrl->InsertColumn(0,wxT("Text"),wxLIST_FORMAT_LEFT,300 );
	SMSUpWxListCtrl->InsertColumn(0,wxT("Sender"),wxLIST_FORMAT_LEFT,200 );
	SMSUpWxListCtrl->InsertColumn(0,wxT("Sent"),wxLIST_FORMAT_LEFT,140 );
	WxGridSizer3->Add(SMSUpWxListCtrl,1,wxEXPAND | wxALL,5);

	WxNotebook2 = new wxNotebook(SMSWxNoteBookPage, ID_WXNOTEBOOK2, wxPoint(5,201),wxSize(256,174));
	WxGridSizer3->Add(WxNotebook2,1,wxEXPAND | wxALL,5);

	SMSSummaryWxNoteBookPage = new wxPanel(WxNotebook2, ID_SMSSUMMARYWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(248,146));
	WxNotebook2->AddPage(SMSSummaryWxNoteBookPage, wxT("Summary"));

	WxBoxSizer7 = new wxBoxSizer(wxVERTICAL);
	SMSSummaryWxNoteBookPage->SetSizer(WxBoxSizer7);
	SMSSummaryWxNoteBookPage->SetAutoLayout(true);

	wxArrayString arrayStringFor_SMSNumbersWxListBox;
	SMSNumbersWxListBox = new wxListBox(SMSSummaryWxNoteBookPage, ID_SMSNUMBERSWXLISTBOX, wxPoint(0,0), wxSize(239,44), arrayStringFor_SMSNumbersWxListBox, wxLB_SINGLE | wxCLIP_CHILDREN | wxNO_BORDER);
	SMSNumbersWxListBox->SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE));
	WxBoxSizer7->Add(SMSNumbersWxListBox,0,wxALIGN_TOP | 0,5);

	SMSWxMemo = new wxTextCtrl(SMSSummaryWxNoteBookPage, ID_SMSWXMEMO, wxT(""), wxPoint(71,44), wxSize(96,44), wxTE_MULTILINE, wxDefaultValidator, wxT("SMSWxMemo"));
	SMSWxMemo->SetMaxLength(0);
	SMSWxMemo->SetFocus();
	SMSWxMemo->SetInsertionPointEnd();
	WxBoxSizer7->Add(SMSWxMemo,1,wxEXPAND | wxALL,0);

	SMSDetailsWxNoteBookPage = new wxPanel(WxNotebook2, ID_SMSDETAILSWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(248,146));
	WxNotebook2->AddPage(SMSDetailsWxNoteBookPage, wxT("Details"));

	WxBoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
	SMSDetailsWxNoteBookPage->SetSizer(WxBoxSizer4);
	SMSDetailsWxNoteBookPage->SetAutoLayout(true);

	SMSDetailsWxListCtrl = new wxListCtrl(SMSDetailsWxNoteBookPage, ID_SMSDETAILSWXLISTCTRL, wxPoint(0,0), wxSize(160,83), wxLC_REPORT);
	SMSDetailsWxListCtrl->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,300 );
	SMSDetailsWxListCtrl->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	WxBoxSizer4->Add(SMSDetailsWxListCtrl,1,wxEXPAND | wxALL,0);

	WxNoteBookPage8 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE8, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(WxNoteBookPage8, wxT("MMS"));

	WxBoxSizer8 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage8->SetSizer(WxBoxSizer8);
	WxNoteBookPage8->SetAutoLayout(true);

	WxPanel6 = new wxPanel(WxNoteBookPage8, ID_WXPANEL6, wxPoint(0,0), wxSize(604,31));
	WxBoxSizer8->Add(WxPanel6,0,wxALIGN_TOP | wxALL,0);

	wxArrayString arrayStringFor_MMSWxChoice;
	MMSWxChoice = new wxChoice(WxPanel6, ID_MMSWXCHOICE, wxPoint(5,5), wxSize(225,21), arrayStringFor_MMSWxChoice, 0, wxDefaultValidator, wxT("MMSWxChoice"));
	MMSWxChoice->SetSelection(-1);

	MMSGetWxButton = new wxButton(WxPanel6, ID_MMSGETWXBUTTON, wxT("Get from phone"), wxPoint(238,5), wxSize(86,21), 0, wxDefaultValidator, wxT("MMSGetWxButton"));

	WxEdit2 = new wxTextCtrl(WxPanel6, ID_WXEDIT2, wxT(""), wxPoint(333,5), wxSize(83,21), 0, wxDefaultValidator, wxT("WxEdit2"));

	MMSSearchWxButton = new wxButton(WxPanel6, ID_MMSSEARCHWXBUTTON, wxT("Search"), wxPoint(426,5), wxSize(86,21), 0, wxDefaultValidator, wxT("MMSSearchWxButton"));

	WxGridSizer5 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer8->Add(WxGridSizer5, 1, wxEXPAND | wxALL, 0);

	MMSUpWxListCtrl = new wxListCtrl(WxNoteBookPage8, ID_MMSUPWXLISTCTRL, wxPoint(63,10), wxSize(225,168), wxLC_REPORT);
	MMSUpWxListCtrl->InsertColumn(0,wxT("Size"),wxLIST_FORMAT_LEFT,70 );
	MMSUpWxListCtrl->InsertColumn(0,wxT("Files"),wxLIST_FORMAT_LEFT,50 );
	MMSUpWxListCtrl->InsertColumn(0,wxT("Text"),wxLIST_FORMAT_LEFT,300 );
	MMSUpWxListCtrl->InsertColumn(0,wxT("Sender"),wxLIST_FORMAT_LEFT,200 );
	MMSUpWxListCtrl->InsertColumn(0,wxT("Sent"),wxLIST_FORMAT_LEFT,140 );
	WxGridSizer5->Add(MMSUpWxListCtrl,1,wxEXPAND | wxALL,5);

	WxNotebook3 = new wxNotebook(WxNoteBookPage8, ID_WXNOTEBOOK3, wxPoint(5,193),wxSize(341,178));
	WxGridSizer5->Add(WxNotebook3,1,wxEXPAND | wxALL,5);

	WxNoteBookPage1 = new wxPanel(WxNotebook3, ID_WXNOTEBOOKPAGE1, wxPoint(4,24), wxSize(333,150));
	WxNotebook3->AddPage(WxNoteBookPage1, wxT("Details"));

	WxBoxSizer10 = new wxBoxSizer(wxHORIZONTAL);
	WxNoteBookPage1->SetSizer(WxBoxSizer10);
	WxNoteBookPage1->SetAutoLayout(true);

	MMSDetailsWxListCtrl = new wxListCtrl(WxNoteBookPage1, ID_MMSDETAILSWXLISTCTRL, wxPoint(5,5), wxSize(192,131), wxLC_REPORT);
	MMSDetailsWxListCtrl->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,300 );
	MMSDetailsWxListCtrl->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,200 );
	WxBoxSizer10->Add(MMSDetailsWxListCtrl,1,wxEXPAND | wxALL,5);

	MMSSummaryWxNoteBookPage = new wxPanel(WxNotebook3, ID_MMSSUMMARYWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(333,150));
	WxNotebook3->AddPage(MMSSummaryWxNoteBookPage, wxT("Summary"));

	WxBoxSizer9 = new wxBoxSizer(wxVERTICAL);
	MMSSummaryWxNoteBookPage->SetSizer(WxBoxSizer9);
	MMSSummaryWxNoteBookPage->SetAutoLayout(true);

	WxPanel7 = new wxPanel(MMSSummaryWxNoteBookPage, ID_WXPANEL7, wxPoint(5,5), wxSize(330,31));
	WxBoxSizer9->Add(WxPanel7,0,wxALIGN_TOP | wxALL,5);

	wxArrayString arrayStringFor_WxChoice1;
	WxChoice1 = new wxChoice(WxPanel7, ID_WXCHOICE1, wxPoint(8,5), wxSize(203,21), arrayStringFor_WxChoice1, 0, wxDefaultValidator, wxT("WxChoice1"));
	WxChoice1->SetSelection(-1);

	WxButton1 = new wxButton(WxPanel7, ID_WXBUTTON1, wxT("Save"), wxPoint(222,6), wxSize(75,21), 0, wxDefaultValidator, wxT("WxButton1"));

	WxGridSizer6 = new wxGridSizer(2, 2, 0, 0);
	WxBoxSizer9->Add(WxGridSizer6, 1, wxEXPAND | wxALL, 5);

	wxBitmap WxBitmapButton1_BITMAP (wxNullBitmap);
	WxBitmapButton1 = new wxBitmapButton(MMSSummaryWxNoteBookPage, ID_WXBITMAPBUTTON1, WxBitmapButton1_BITMAP, wxPoint(5,7), wxSize(63,53), wxBU_AUTODRAW, wxDefaultValidator, wxT("WxBitmapButton1"));
	WxGridSizer6->Add(WxBitmapButton1, 1, wxEXPAND | wxALL, 5);

	WxMemo1 = new wxTextCtrl(MMSSummaryWxNoteBookPage, ID_WXMEMO1, wxT(""), wxPoint(81,5), wxSize(56,57), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo1"));
	WxMemo1->SetMaxLength(0);
	WxMemo1->AppendText(wxT("WxMe"));
	WxMemo1->AppendText(wxT("mo"));
	WxMemo1->AppendText(wxT("1"));
	WxMemo1->SetFocus();
	WxMemo1->SetInsertionPointEnd();
	WxGridSizer6->Add(WxMemo1,1,wxEXPAND | wxALL,5);

	CalendarWxNoteBookPage = new wxPanel(wxNotebook1, ID_CALENDARWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(CalendarWxNoteBookPage, wxT("Calendar"));

	WxBoxSizer5 = new wxBoxSizer(wxVERTICAL);
	CalendarWxNoteBookPage->SetSizer(WxBoxSizer5);
	CalendarWxNoteBookPage->SetAutoLayout(true);

	WxPanel4 = new wxPanel(CalendarWxNoteBookPage, ID_WXPANEL4, wxPoint(0,0), wxSize(545,31));
	WxBoxSizer5->Add(WxPanel4,0,wxALIGN_TOP | wxALL,0);

	WxButton2 = new wxButton(WxPanel4, ID_WXBUTTON2, wxT("Get from phone"), wxPoint(7,5), wxSize(86,21), 0, wxDefaultValidator, wxT("WxButton2"));

	WxBoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
	WxBoxSizer5->Add(WxBoxSizer6, 1, wxEXPAND | wxALL, 0);

	WxPanel5 = new wxPanel(CalendarWxNoteBookPage, ID_WXPANEL5, wxPoint(0,10), wxSize(183,202));
	WxBoxSizer6->Add(WxPanel5,0,wxALIGN_LEFT | wxALL,0);

	WxCalendarCtrl1 = new wxCalendarCtrl(WxPanel5, ID_WXCALENDARCTRL1, wxDateTime(6,(wxDateTime::Month)12,2006),wxPoint(5,2), wxSize(172,147), wxCAL_SUNDAY_FIRST | wxCAL_SHOW_HOLIDAYS | wxCAL_NO_MONTH_CHANGE | wxCAL_SHOW_SURROUNDING_WEEKS | wxCAL_SEQUENTIAL_MONTH_SELECTION);

	WxCheckBox1 = new wxCheckBox(WxPanel5, ID_WXCHECKBOX1, wxT("Show all events"), wxPoint(7,157), wxSize(160,21), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxGridSizer4 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer6->Add(WxGridSizer4, 1, wxEXPAND | wxALL, 0);

	WxListCtrl6 = new wxListCtrl(CalendarWxNoteBookPage, ID_WXLISTCTRL6, wxPoint(7,5), wxSize(146,101), wxLC_REPORT);
	WxListCtrl6->InsertColumn(0,wxT("Text"),wxLIST_FORMAT_LEFT,150 );
	WxListCtrl6->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,100 );
	WxListCtrl6->InsertColumn(0,wxT("Date"),wxLIST_FORMAT_LEFT,140 );
	WxGridSizer4->Add(WxListCtrl6,1,wxEXPAND | wxALL,5);

	WxListCtrl7 = new wxListCtrl(CalendarWxNoteBookPage, ID_WXLISTCTRL7, wxPoint(5,118), wxSize(150,97), wxLC_REPORT);
	WxListCtrl7->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,200 );
	WxListCtrl7->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	WxGridSizer4->Add(WxListCtrl7,1,wxEXPAND | wxALL,5);

	ToDoWxNoteBookPage = new wxPanel(wxNotebook1, ID_TODOWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(ToDoWxNoteBookPage, wxT("ToDo"));

	NotesWxNoteBookPage = new wxPanel(wxNotebook1, ID_NOTESWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(NotesWxNoteBookPage, wxT("Notes"));

	FilesWxNoteBookPage = new wxPanel(wxNotebook1, ID_FILESWXNOTEBOOKPAGE, wxPoint(4,24), wxSize(616,442));
	wxNotebook1->AddPage(FilesWxNoteBookPage, wxT("FileSystem and Java"));

	WxBoxSizer1 = new wxBoxSizer(wxVERTICAL);
	FilesWxNoteBookPage->SetSizer(WxBoxSizer1);
	FilesWxNoteBookPage->SetAutoLayout(true);

	WxPanel3 = new wxPanel(FilesWxNoteBookPage, ID_WXPANEL3, wxPoint(24,0), wxSize(545,31));
	WxBoxSizer1->Add(WxPanel3,0,wxALIGN_TOP | wxALL,0);

	FileGetWxButton = new wxButton(WxPanel3, ID_FILEGETWXBUTTON3, wxT("Get from phone"), wxPoint(5,5), wxSize(86,21), 0, wxDefaultValidator, wxT("FileGetWxButton"));

	WxListCtrl1 = new wxListCtrl(FilesWxNoteBookPage, ID_WXLISTCTRL1, wxPoint(5,36), wxSize(583,311), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Attribs"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Modified"),wxLIST_FORMAT_LEFT,170 );
	WxListCtrl1->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Size"),wxLIST_FORMAT_LEFT,80 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,170 );
	WxBoxSizer1->Add(WxListCtrl1,1,wxEXPAND | wxALL,5);

	WxSaveFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxSAVE);

	WxPopupMenu1 = new wxMenu(wxT(""));WxPopupMenu1->Append(ID_MNU_MENUITEM1_1020, wxT("Read selected"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_DELETE_1023, wxT("Delete selected"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_ADDFOLDER_1022, wxT("Add folder to current dir"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_ADDFILE_1027, wxT("Add file to current dir"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_RENAME_1024, wxT("Rename"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_PROPERTIES_1026, wxT("Properties"), wxT(""), wxITEM_NORMAL);

	WxMenuBar1 = new wxMenuBar();
	wxMenu *ID_MNU_MENUITEM1_1016_Mnu_Obj = new wxMenu(0);
	ID_MNU_MENUITEM1_1016_Mnu_Obj->Append(ID_MNU_OPENMMSFILE_1201, wxT("MMS files viewer"), wxT(""), wxITEM_NORMAL);
	ID_MNU_MENUITEM1_1016_Mnu_Obj->AppendSeparator();
	ID_MNU_MENUITEM1_1016_Mnu_Obj->Append(ID_MNU_EXIT_1017, wxT("&Exit"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_MENUITEM1_1016_Mnu_Obj, wxT("&File"));
	
	wxMenu *ID_MNU_TOOLS_1146_Mnu_Obj = new wxMenu(0);
	ID_MNU_TOOLS_1146_Mnu_Obj->Append(ID_MNU_CONNECT_1203, wxT("Connect"), wxT(""), wxITEM_NORMAL);
	ID_MNU_TOOLS_1146_Mnu_Obj->AppendSeparator();
	ID_MNU_TOOLS_1146_Mnu_Obj->Append(ID_MNU_CONFIGURATION_1147, wxT("Configuration"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_TOOLS_1146_Mnu_Obj, wxT("Tools"));
	
	wxMenu *ID_MNU_HELP_1018_Mnu_Obj = new wxMenu(0);
	ID_MNU_HELP_1018_Mnu_Obj->Append(ID_MNU_ABOUT_1019, wxT("&About"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_HELP_1018_Mnu_Obj, wxT("&Help"));
	SetMenuBar(WxMenuBar1);

	WxOpenFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxOPEN);

	WxDirDialog1 =  new wxDirDialog(this, wxT("Choose a directory"), wxT(""));

	WxPopupMenu2 = new wxMenu(wxT(""));WxPopupMenu2->Append(ID_MNU_FORWARD_1148, wxT("Forward"), wxT(""), wxITEM_NORMAL);

	SetStatusBar(WxStatusBar1);
	SetTitle(wxT("Gammu+ GUI"));
	SetIcon(wxNullIcon);
	
	GetSizer()->Fit(this);
	GetSizer()->SetSizeHints(this);
	Center();
	
    ////GUI Items Creation End
}

void MainFrm::OnClose(wxCloseEvent& event)
{
    Destroy();
}

/*
 * Mnuexit1017Click1
 */
void MainFrm::Mnuexit1017Click1(wxCommandEvent& event)
{
    Close();
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
    switch (DayOfWeek(Year,Month,Day)) {
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
        case 7: return "Sun";
        default:return "";
    }
}

void MainFrm::EnterFolder()
{
    wchart                            x;
    wxProgressDialog                  *Dialog;
    bool                              skip;
    BOOLEAN                           Start2;
    wchar_t                           name[20];
    char                              buff[1000];
    GSM_MemoryType                    Mem;
    unsignedstring                    Buffer2;
    GSM_Error                         error;
    GSM_FileFolderInfo                FInfo,*FInfo2;
    GSM_FileFolderInfoListSubEntry    *SubEntry;
    int                               i,num=0;
    long                              tmp,size=0,filesnum=0,foldersnum=0;
    GSM_FileFolderInfoListsSubEntry   *En;
    BOOLEAN                           Found = FALSE;
    
    En2 = NULL;
    while (Folders.GetNext(&En2)) {
        if (!wcscmp(En2->Info.Info.GetID(),FileFolderID)) {
            Found = TRUE;
            break;
        }
    }
    
    if (!Found) {
        En2 = new GSM_FileFolderInfoListsSubEntry;
        if (ParentFolderIDNum == 1) {
            //root
            name[0] = 0;
            En2->Info.Info.SetID(name);
            
            while (true) {
                error = s->Phones->Current->GetNextRootFolderID(name,&Mem);
                if (error.Code == GSM_ERR_EMPTY) break;
                if (error.Code != GSM_ERR_MEMORY && error.Code != GSM_ERR_NONE) return;

                FInfo2 = new GSM_FileFolderInfo;
                if (Mem == MEM_PHONE) {
                        sprintf(buff,"Phone memory (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
                } else {
                        sprintf(buff,"Memory card (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
                }
                FInfo2->SetName(StringToUnicodeReturn(buff));
                FInfo2->Folder = TRUE;
                FInfo2->SetID(name);
                En2->Info.AddSubEntry(FInfo2);
            }
        } else {
            Dialog=NULL;
            Start2=TRUE;
            En2->Info.Info.SetID(FileFolderID);
            Found = false;
            while (1) {
                error = s->Phones->Current->GetFolderInfoList(&En2->Info,Start2);
            
                if (error.Code == GSM_ERR_MEMORY) {
                    wxMessageBox("Folder not available in this moment",
                           wxT("Error"),
                           wxICON_WARNING | wxOK);
                    //go into parent
                    for (i=CurrentFolderName.length(); i > 0; i--) {
                            if (CurrentFolderName.data()[i]=='\\') break;
                    }
                    x.append(CurrentFolderName.data(),i);
                    CurrentFolderName.clear();
                    CurrentFolderName.append(x.data());
                    ParentFolderID[ParentFolderIDNum-1].clear();
                    ParentFolderIDNum--;
                    CopyUnicode(FileFolderID0,FileFolderID);

                    En = NULL;
                    while (Folders.GetNext(&En)) {
                        if (!wcscmp(En->Info.Info.GetID(),FileFolderID)) {
                            Found = TRUE;
                            break;
                        }
                    }
                    if (Found) {
                        delete(En2);
                        En2=En;
                        break;
                    }              
                    En2->Info.Info.SetID(FileFolderID);
                    continue;
                } else {
                    if (Dialog==NULL) {
                        Dialog = new wxProgressDialog(CurrentFolderName.data(), "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
                    }
                }
                Start2 = FALSE;                
                if (error.Code == GSM_ERR_FOLDER_MORE) {
                    sprintf(buff,"Reading folder content: %i",num++);
                    Dialog->Pulse(buff,&skip);
                    continue;
                }
                if (error.Code == GSM_ERR_FOLDER_PART) {
                    wxMessageBox("There was read only folder part (it's phone firmware problem)",
                        wxT("Error"),
                        wxICON_WARNING | wxOK);
                    break;
                }
                if (error.Code == GSM_ERR_EMPTY) break;
                if (error.Code != GSM_ERR_NONE) PrintError(error);
                break;
            }
            delete (Dialog);
        }
        if (!Found) Folders.AddSubEntry(En2);
    }
    WxListCtrl1->DeleteAllItems();
    FileSystemNum = 0;

    if (ParentFolderIDNum != 1) {
        tmp = WxListCtrl1->InsertItem(FileSystemNum++, _T(".."), 0);
        WxListCtrl1->SetItemData(tmp, 0);
        WxListCtrl1->SetItem(tmp, 1, _T(""));
        WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
        WxListCtrl1->SetItem(tmp, 3, _T(""));
        WxListCtrl1->SetItem(tmp, 4, _T(""));
    }        
  
    SubEntry = NULL;
    while (En2->Info.GetNext(&SubEntry) == TRUE) {
        if (!En2->Info.SubEntryFullData) {
            error = s->Phones->Current->GetFileFolderInfo(&SubEntry->Info);
            PrintError(error);
        }

        sprintf(buff,"%s",UnicodeToStringReturn(SubEntry->Info.GetName()));
        tmp = WxListCtrl1->InsertItem(FileSystemNum++, buff, 0);
        if (SubEntry->Info.Folder) {
            WxListCtrl1->SetItem(tmp, 1, _T(""));
            WxListCtrl1->SetItem(tmp, 2, _T("Folder"));

            foldersnum++;
        } else {
            size+=SubEntry->Info.Size;
            filesnum++;

            sprintf(buff, "%i",SubEntry->Info.Size);
            WxListCtrl1->SetItem(tmp, 1, buff);
            WxListCtrl1->SetItem(tmp, 2, _T("File"));
        }
        if (ParentFolderIDNum == 1) continue;
        if (SubEntry->Info.ModificationDateTimeAvailable) {
            sprintf(buff, "%s %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            SubEntry->Info.ModificationDateTime.Year,
                            SubEntry->Info.ModificationDateTime.Month,
                            SubEntry->Info.ModificationDateTime.Day),
                    SubEntry->Info.ModificationDateTime.Day,
                    SubEntry->Info.ModificationDateTime.Month,
                    SubEntry->Info.ModificationDateTime.Year,                                       
                    SubEntry->Info.ModificationDateTime.Hour,
                    SubEntry->Info.ModificationDateTime.Minute,
                    SubEntry->Info.ModificationDateTime.Second);
        } else {
            sprintf(buff, "");
        }
        WxListCtrl1->SetItem(tmp, 3, buff);
        
        sprintf(buff,"    ");   
        if (SubEntry->Info.DRMForwardLock) buff[0] = 'P';
        if (SubEntry->Info.ReadOnly) buff[1] = 'R';
        if (SubEntry->Info.Hidden) buff[2] = 'H';
        if (SubEntry->Info.System) buff[3] = 'S';
        WxListCtrl1->SetItem(tmp, 4, buff);
    }
    
    StatusStr[6].clear();
    StatusStr[6].append(CurrentFolderName.data());
    sprintf(buff," (%i folders, %i bytes in %i files)",foldersnum,size,filesnum);
    StatusStr[6].append(StringToUnicodeReturn(buff));
    WxStatusBar1->SetStatusText(StatusStr[6].data(),0);
}

/*
 * WxListCtrl1ItemActivated
 */
void MainFrm::WxListCtrl1ItemActivated(wxListEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
    GSM_File                        ReadSaveFile;
    GSM_FileFolderInfoListSubEntry  *SubEntry;
    int                             i;
    wchart                          x;
    long                            item;

    item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    if (WxListCtrl1->GetItemText(item)== "..") {
        for (i=CurrentFolderName.length(); i > 0; i--) {
                if (CurrentFolderName.data()[i]=='\\') break;
        }
        x.append(CurrentFolderName.data(),i);
        CurrentFolderName.clear();
        CurrentFolderName.append(x.data());

        ParentFolderID[ParentFolderIDNum-1].clear();
        ParentFolderIDNum--;
        CopyUnicode((wchar_t *)ParentFolderID[ParentFolderIDNum-1].data(),FileFolderID);
        EnterFolder();
        return;
    }
    if (WxListCtrl1->GetItemText(0)== "..") item--;    
    SubEntry = NULL;
    for (i=0;i<=item;i++) En2->Info.GetNext(&SubEntry);
    CopyUnicode(FileFolderID,FileFolderID0);
    CopyUnicode(SubEntry->Info.GetID(),FileFolderID);
    if (SubEntry->Info.Folder) {
        CurrentFolderName.push_back('\\');
        CurrentFolderName.append(SubEntry->Info.GetName());
        ParentFolderID[ParentFolderIDNum].append(FileFolderID);
        ParentFolderIDNum++;

        EnterFolder();
        return;
    }

    Dialog = new wxProgressDialog("Reading file", SubEntry->Info.GetName(), 100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
    ReadSaveFile.Info.SetID(FileFolderID);
    while(true) {
        error = s->Phones->Current->GetFilePart(&ReadSaveFile);
        if (error.Code!=GSM_ERR_NONE) {
              PrintError(error);
        }

        if (!Dialog->Update((int)ReadSaveFile.Buffer.size()*100/ReadSaveFile.Info.Size,"",&skip)) break;
        if (ReadSaveFile.Info.Size == ReadSaveFile.Buffer.size()) break;
    }               
    delete Dialog;
    WxSaveFileDialog1->SetFilename(SubEntry->Info.GetName());
    if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
    ReadSaveFile.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
}          

/*
 * WxListCtrl1RightClick
 */
void MainFrm::WxListCtrl1RightClick(wxListEvent& event)
{
    PopupMenu(WxPopupMenu1, wxDefaultPosition);
}

bool FindPBKEntry(GSM_Backup_PBKEntry **PBKEntry, GSM_PBKSubEntry **SubEntry, int Num2, int item1)
{
    int Num;

    *PBKEntry = NULL;
    Num = 0;
    while (Backup.GetNext_PBK(PBKEntry)) {
        *SubEntry = NULL;
        while ((*PBKEntry)->GetEntry()->GetNext(SubEntry)) {
            Num++;
            if (Num == item1) return true;
        }
    }
    return false;
}

int wxCALLBACK PBKUpWxListCtrlCompareFunction(long item1, long item2, long sortData)
{
    GSM_Backup_PBKEntry *PBKEntry, *PBKEntry2;
    GSM_PBKSubEntry     *SubEntry, *SubEntry2;
    int                 retval;
    time_t              One,Two;
    bool                found;
    int                 sort, Num2;
    wchar_t             buff[400],buff2[400],Last[400],First[400];
    
    sort = sortData % 100;
    Num2 = sortData / 100;

    if (sort == 2) return 0; //number
    if (sort == 3 && sortData<100) return 0; //date when no date available
    if (sort == 0) { //location
        StatusStr2[0].clear();
        StatusStr2[0].append(StringToUnicodeReturn(" sorted by location"));
        retval = 0;
        if (item1 < item2) retval = -1;
        if (item1 > item2) retval = 1;
        if (SortPBKReverse) {
            retval = (-1)*retval;
            StatusStr2[0].append(StringToUnicodeReturn(" (reverse)"));
        }
        return retval;
    }
    if (sort == 1) { //name
        FindPBKEntry(&PBKEntry, &SubEntry, Num2, item1);
        Last[0] = 0;
        First[0] = 0;
        buff[0] = 0;
        SubEntry = NULL;
        while (PBKEntry->GetEntry()->GetNext(&SubEntry) == TRUE) {
            switch (SubEntry->GetType()) {
            case PBK_Text_Name: CopyUnicode(SubEntry->GetText(),buff); break;
            case PBK_Text_Name_First: CopyUnicode(SubEntry->GetText(),First); break;
            case PBK_Text_Name_Last: CopyUnicode(SubEntry->GetText(),Last); break;
            default: break;
            }
        }
        if (Last[0] != 0 || First[0] != 0) {
            CopyUnicode(Last,buff);
            buff[UnicodeLength(buff)+1] = 0;
            buff[UnicodeLength(buff)] = ' ';
            CopyUnicode(First,buff+UnicodeLength(buff));
        }
        if (buff[0] == 0) {
            found = false;
            SubEntry = NULL;
            while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    CopyUnicode(SubEntry->GetText(),buff);
                    found = true;
                    break;
                }
                if (found) break;
            }
            if (!found) return -1;            
        }    

        FindPBKEntry(&PBKEntry2, &SubEntry2, Num2, item2);
        Last[0] = 0;
        First[0] = 0;
        buff2[0] = 0;
        SubEntry2 = NULL;
        while (PBKEntry2->GetEntry()->GetNext(&SubEntry2) == TRUE) {
            switch (SubEntry2->GetType()) {
            case PBK_Text_Name: CopyUnicode(SubEntry2->GetText(),buff2); break;
            case PBK_Text_Name_First: CopyUnicode(SubEntry2->GetText(),First); break;
            case PBK_Text_Name_Last: CopyUnicode(SubEntry2->GetText(),Last); break;
            default: break;
            }
        }
        if (Last[0] != 0 || First[0] != 0) {
            CopyUnicode(Last,buff2);
            buff2[UnicodeLength(buff2)+1] = 0;
            buff2[UnicodeLength(buff2)] = ' ';
            CopyUnicode(First,buff2+UnicodeLength(buff2));
        }
        if (buff2[0] == 0) {
            SubEntry2 = NULL;
            while (PBKEntry2->GetEntry()->GetNext(&SubEntry2)) {
                switch (SubEntry2->GetType()) {
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    CopyUnicode(SubEntry2->GetText(),buff2);                    
                    found = true;
                    break;
                }
                if (found) break;
            }
            if (!found) return 1;
        }

        retval = wcscoll(buff,buff2);
        if (retval == 0) {
            retval = -1;
            if (item1 > item2) retval = 1;
        }
        StatusStr2[0].clear();
        StatusStr2[0].append(StringToUnicodeReturn(" sorted by name, number, location"));
        if (SortPBKReverse) {
            retval = (-1) * retval;
            StatusStr2[0].append(StringToUnicodeReturn(" (reverse)"));            
        }
        return retval;
    }
    //date & time
    FindPBKEntry(&PBKEntry, &SubEntry, Num2, item1);
    FindPBKEntry(&PBKEntry2, &SubEntry2, Num2, item2);

    One = GSMDateTime2TimeT(SubEntry->GetDateTime());
    Two = GSMDateTime2TimeT(SubEntry2->GetDateTime());
    retval = 0;
    if (One>Two) retval = 1;
    if (One<Two) retval = -1;
    StatusStr2[0].clear();
    StatusStr2[0].append(StringToUnicodeReturn(" sorted by time"));
    if (SortPBKReverse) {
        retval = (-1)*retval;
        StatusStr2[0].append(StringToUnicodeReturn(" (reverse)"));
    }
    return retval;
}

void MainFrm::ReadPBKMemory(GSM_MemoryType Mem)
{
    char                buff[100];
    GSM_Error           error;
    GSM_PBKStatus       Status;
    int                 i = 0,Pos=1;
    GSM_PBKEntry        *Entry;
    BOOLEAN             newe = TRUE;
    bool                skip;
    wxProgressDialog    *Dialog;

    wxString Name;

    switch (Mem) {
    case MEM_PHONE: Name = "phone phonebook"; break;
    case MEM_SIM: Name = "SIM phonebook"; break;
    case MEM_SIM_OWN: Name = "own numbers"; break;
    case MEM_PHONE_DIALLED: Name = "dialled calls"; break;
    case MEM_PHONE_RECEIVED: Name = "received calls";   break;
    case MEM_PHONE_MISSED: Name="missed calls";     break;
    case MEM_PHONE_SMS_LOGS: Name="sent SMS list";   break;    
    }
       
    switch (Mem) {
    case MEM_PHONE:
    case MEM_SIM:
    case MEM_SIM_OWN:
        Status.Memory = Mem;
        error = s->Phones->Current->GetPBKStatus(&Status);

        Dialog = new wxProgressDialog("Reading "+Name,"" , Status.Used, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
        while (i!=Status.Used) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            }
            Entry->Location= Pos;
            Entry->Memory = Status.Memory;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            newe = true;
            i++;
            sprintf(buff,"%i %% (%i/%i)",i*100/Status.Used,i,Status.Used);
            Dialog->Update((int)i,buff,&skip);
            Backup.Add_PBK(Entry);
        }
        break;
    default: 
        Dialog = new wxProgressDialog("Reading "+Name, "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
        error.Code = GSM_ERR_NONE;
        while (error.Code != GSM_ERR_EMPTY) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            } else {
                Entry->ClearAll();
            }
            Entry->Location= Pos;
            Entry->Memory=Mem;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            sprintf(buff,"%i",Pos);
            Dialog->Pulse(buff,&skip);
            newe=true;
            Backup.Add_PBK(Entry);
        }
    }
    delete Dialog;   
}

void MainFrm::DisplayPBK(GSM_MemoryType Mem, long *PbkNum,long *ReceivedSec,long *DialledSec)
{
    GSM_PBKEntry        *Entry,*Entry2;
    GSM_Backup_PBKEntry *PBKEntry;
    wchar_t             buff[400],buff2[40];
    wchar_t             Last[400],First[400];
    char                buff3[200];
    char                buff0[40];
    long                tmp,Num2=0;
    GSM_PBKSubEntry     *SubEntry;
    time_t              DT1;
    GSM_DateTime        DT2;
    BOOLEAN             newe2;

    PBKEntry = NULL;
    while(Backup.GetNext_PBK(&PBKEntry)) {
        Entry = PBKEntry->GetEntry();
        if (Entry->Memory != Mem) {
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry)) Num2++;            
            continue;
        }
        Last[0] = 0;
        First[0] = 0;
        buff[0] = 0;
        SubEntry = NULL;
        while (Entry->GetNext(&SubEntry) == TRUE) {
            switch (SubEntry->GetType()) {
            case PBK_Text_Name:
                CopyUnicode(SubEntry->GetText(),buff);
                break;
            case PBK_Text_Name_First:
                CopyUnicode(SubEntry->GetText(),First);
                break;
            case PBK_Text_Name_Last:
                CopyUnicode(SubEntry->GetText(),Last);
                break;
            default:
                break;
            }
        }
        if (Last[0] != 0 || First[0] != 0) {
            CopyUnicode(Last,buff);
            buff[UnicodeLength(buff)+1] = 0;
            buff[UnicodeLength(buff)] = ' ';            
            CopyUnicode(First,buff+UnicodeLength(buff));
        }
        switch (Mem) {
        case MEM_PHONE:
        case MEM_SIM:
        case MEM_SIM_OWN:
            sprintf(buff0,"%i",Entry->Location);
            tmp = PBKUpWxListCtrl->InsertItem((*PbkNum)++, buff0, 0);
            buff3[0] = 0;
            newe2 = true;
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                Num2++;                
                if (newe2) {
                    PBKUpWxListCtrl->SetItemData(tmp, Num2);
                    newe2 = false;
                }
            }
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Phone_General:
                    sprintf(buff3,"%s",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Mobile:
                    sprintf(buff3,"%s (mobile)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Home:
                    sprintf(buff3,"%s (home)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Work:
                    sprintf(buff3,"%s (work)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Fax:
                    sprintf(buff3,"%s (fax)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                default:
                    break;
                }
                if (buff3[0] != 0) break;
            }
            PBKUpWxListCtrl->SetItem(tmp, 1, buff);
            PBKUpWxListCtrl->SetItem(tmp, 2, buff3);
            PBKUpWxListCtrl->SetItem(tmp, 3, "");
            break;
        default:
            buff2[0] = 0;
            buff3[0] = 0;
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    CopyUnicode(SubEntry->GetText(),buff2);
                    break;
                default:
                    break;
                }
            }
            SubEntry = NULL;
            newe2 = true;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                Num2++;
                if (SubEntry->GetType()!=PBK_DateTime_Call_Length) continue;
                sprintf(buff3,"%s %02i-%02i-%04i %02i:%02i:%02i",
                                DayOfWeekStr(
                                        SubEntry->GetDateTime()->Year,
                                        SubEntry->GetDateTime()->Month,
                                        SubEntry->GetDateTime()->Day),
                        SubEntry->GetDateTime()->Day,
                        SubEntry->GetDateTime()->Month,
                        SubEntry->GetDateTime()->Year,
                        SubEntry->GetDateTime()->Hour,
                        SubEntry->GetDateTime()->Minute,
                        SubEntry->GetDateTime()->Second);
                if (SubEntry->Length!=-1) {
                    if (Mem == MEM_PHONE_DIALLED) *DialledSec += SubEntry->Length;
                    if (Mem == MEM_PHONE_RECEIVED) *ReceivedSec += SubEntry->Length;
                    DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
                    DT1 += SubEntry->Length;
                    memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
                    sprintf(buff3+strlen(buff3)," - %s %02i-%02i-%04i %02i:%02i:%02i (%02i:%02i:%02i)",
                                    DayOfWeekStr(
                                            DT2.Year,
                                            DT2.Month,
                                            DT2.Day),
                            DT2.Day,
                            DT2.Month,
                            DT2.Year,
                            DT2.Hour,
                            DT2.Minute,
                            DT2.Second,SubEntry->Length/(60*60),SubEntry->Length/60,SubEntry->Length%60);
                }

                buff0[0] = 0;
                if (Mem == MEM_PHONE_DIALLED) sprintf(buff0,"D ");
                if (Mem == MEM_PHONE_RECEIVED) sprintf(buff0,"R ");
                if (Mem == MEM_PHONE_MISSED) sprintf(buff0,"M ");
                sprintf(buff0+strlen(buff0),"%i",Entry->Location);
                tmp = PBKUpWxListCtrl->InsertItem((*PbkNum)++, buff0, 0);
                PBKUpWxListCtrl->SetItemData(tmp, Num2);
                PBKUpWxListCtrl->SetItem(tmp, 1, buff);
                PBKUpWxListCtrl->SetItem(tmp, 2, buff2);
                PBKUpWxListCtrl->SetItem(tmp, 3, buff3);
            }
            break;
        } 
    }
}

void MainFrm::AddAllPBKMemories()
{
    PBKWxChoice->Clear();
    PBKWxChoice->Append("Phone phonebook");
    PBKWxChoice->Append("SIM phonebook");
    PBKWxChoice->Append("Own numbers");
    PBKWxChoice->Append("Dialled calls");
    PBKWxChoice->Append("Received calls");
    PBKWxChoice->Append("Missed calls");
    PBKWxChoice->Append("Call logs (dialled + received + missed)");
    PBKWxChoice->Append("Sent SMS list");

    PBKUpWxListCtrl->DeleteAllItems();
    PBKDownWxListCtrl->DeleteAllItems();
    Backup.Delete_PBK();
    SortPBKReverse = false;
    FirstPBK = false;
}

/*
 * WxButton1Click
 */
void MainFrm::PBKGetWxButtonClick(wxCommandEvent& event)
{
    AddAllPBKMemories();
}

/*
 * PBKWxChoiceSelected
 */
void MainFrm::PBKWxChoiceSelected(wxCommandEvent& event )
{
    GSM_Error           error;
    long                PbkNum = 0;
    char                buff3[200];
    wxArrayString       choices;
    long                ReceivedSec=-1,DialledSec=-1;
    GSM_MemoryType      Mem;
    BOOLEAN             Found = FALSE;
    GSM_Backup_PBKEntry *PBKEntry;

    StatusStr[0].clear();
//    StatusStr[0].append(StringToUnicodeReturn((char *)PBKWxChoice->GetLabel().c_str()));

    PBKUpWxListCtrl->DeleteAllItems();
    PBKDownWxListCtrl->DeleteAllItems();
    
    switch (PBKWxChoice->GetSelection()) {
    case 0: Mem = MEM_PHONE;            break;
    case 1: Mem = MEM_SIM;              break;
    case 2: Mem = MEM_SIM_OWN;          break;
    case 3: Mem = MEM_PHONE_DIALLED;    break;
    case 4: Mem = MEM_PHONE_RECEIVED;   break;
    case 5: Mem = MEM_PHONE_MISSED;     break;
    case 7: Mem = MEM_PHONE_SMS_LOGS;   break;
    case 6:
        Mem = MEM_PHONE_DIALLED;
        Found = FALSE;
        PBKEntry = NULL;
        while(Backup.GetNext_PBK(&PBKEntry)) {
            if (PBKEntry->GetEntry()->Memory == Mem) {
                Found = TRUE;
                break;
            }
        }
        if (!Found) ReadPBKMemory(Mem);
        Mem = MEM_PHONE_RECEIVED;
        Found = FALSE;
        PBKEntry = NULL;
        while(Backup.GetNext_PBK(&PBKEntry)) {
            if (PBKEntry->GetEntry()->Memory == Mem) {
                Found = TRUE;
                break;
            }
        }
        if (!Found) ReadPBKMemory(Mem);
        Mem = MEM_PHONE_MISSED;
        break;
    }

    Found = FALSE;
    PBKEntry = NULL;
    while(Backup.GetNext_PBK(&PBKEntry)) {
        if (PBKEntry->GetEntry()->Memory == Mem) {
            Found = TRUE;
            break;
        }
    }
    if (!Found) ReadPBKMemory(Mem);

    PbkNum = 0;
    //display
    if (PBKWxChoice->GetSelection()<3) {
        DisplayPBK(Mem, &PbkNum, &ReceivedSec, &DialledSec);
        sprintf(buff3,"%i entries",PbkNum);
        StatusStr[0].append(StringToUnicodeReturn(buff3));
        PBKUpWxListCtrl->SortItems(PBKUpWxListCtrlCompareFunction,1+PBKWxChoice->GetSelection()*100);
        WxStatusBar1->SetStatusText(wxString(StatusStr[0].data())+wxString(StatusStr2[0].data()),0);
        return;
    }

    if (PBKWxChoice->GetSelection()==6) {
        DisplayPBK(MEM_PHONE_DIALLED, &PbkNum, &ReceivedSec, &DialledSec);
        DisplayPBK(MEM_PHONE_RECEIVED, &PbkNum, &ReceivedSec, &DialledSec);
        DisplayPBK(MEM_PHONE_MISSED, &PbkNum, &ReceivedSec, &DialledSec);
    } else {
        DisplayPBK(Mem, &PbkNum, &ReceivedSec, &DialledSec);
    }

    sprintf(buff3,"%i entries",PbkNum);
    StatusStr[0].append(StringToUnicodeReturn(buff3));
    if (DialledSec != -1) {
        sprintf(buff3," (dialled %02i:%02i:%02i",DialledSec/(60*60),DialledSec/60,DialledSec%60);
        StatusStr[0].append(StringToUnicodeReturn(buff3));
    }
    if (ReceivedSec != -1) {
        if (DialledSec == -1) {
            sprintf(buff3," (");      
        } else {
            sprintf(buff3,", ");            
        }
        StatusStr[0].append(StringToUnicodeReturn(buff3));
        sprintf(buff3,"received %02i:%02i:%02i",ReceivedSec/(60*60),ReceivedSec/60,ReceivedSec%60);
        StatusStr[0].append(StringToUnicodeReturn(buff3));
    }
    if (DialledSec != -1 || ReceivedSec != -1) {    
        sprintf(buff3,")");
        StatusStr[0].append(StringToUnicodeReturn(buff3));
    }
    PBKUpWxListCtrl->SortItems(PBKUpWxListCtrlCompareFunction,3+PBKWxChoice->GetSelection()*100);
    WxStatusBar1->SetStatusText(wxString(StatusStr[0].data())+wxString(StatusStr2[0].data()),0);
}

/*
 * PBKUpWxListCtrlColLeftClick
 */
void MainFrm::PBKUpWxListCtrlColLeftClick(wxListEvent& event)
{
    SortPBKReverse = !SortPBKReverse;
    PBKUpWxListCtrl->SortItems(PBKUpWxListCtrlCompareFunction,event.GetColumn()+PBKWxChoice->GetSelection()*100);
    WxStatusBar1->SetStatusText(wxString(StatusStr[0].data())+wxString(StatusStr2[0].data()),0);
}

/*
 * PBKUpWxListCtrlItemActivated
 */
void MainFrm::PBKUpWxListCtrlItemActivated(wxListEvent& event)
{
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_PBKSubEntry         *SubEntry;
    int                     EntryNum=0;
    wchart                  x;
    long                    item,tmp;
    GSM_Backup_PBKEntry     *PBKEntry;
    char                    type[50],buff[100];
    wchar_t                 Value[500];
    time_t                  DT1;
    GSM_DateTime            DT2;

    item = PBKUpWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);      
        
    PBKDownWxListCtrl->DeleteAllItems();

    FindPBKEntry(&PBKEntry, &SubEntry, PBKWxChoice->GetSelection(), PBKUpWxListCtrl->GetItemData(item));

    tmp = PBKDownWxListCtrl->InsertItem(EntryNum++, "Location", 0);
    PBKDownWxListCtrl->SetItemData(tmp, 0);
    PBKDownWxListCtrl->SetItem(tmp, 1, PBKUpWxListCtrl->GetItemText(item));
        
    SubEntry = NULL;
    while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
        switch (SubEntry->GetType()) {
        case PBK_Text_Phone_General:
            sprintf(type,"General number");
            CopyUnicode(SubEntry->GetText(),Value);
            break;
        case PBK_Text_Phone_Mobile:
            sprintf(type,"Mobile number");                
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Phone_Home:
            sprintf(type,"Home number");           
            CopyUnicode(SubEntry->GetText(),Value);                     
            break;
        case PBK_Text_Phone_Work:
            sprintf(type,"Work number");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Phone_Fax:
            sprintf(type,"Fax number");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Email:
            sprintf(type,"Email address");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_URL:
            sprintf(type,"URL link");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Postal:
            sprintf(type,"Postal address");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_UserID:
            sprintf(type,"User ID");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Note:
            sprintf(type,"Text note");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Name:
            sprintf(type,"Name");
            CopyUnicode(SubEntry->GetText(),Value);
            break;
        case PBK_Text_Name_First:
            sprintf(type,"First name");
            CopyUnicode(SubEntry->GetText(),Value);
            break;
        case PBK_Text_Name_Last:
            sprintf(type,"Last name");
            CopyUnicode(SubEntry->GetText(),Value);
            break;            
        case PBK_DateTime_Call_Length:
            sprintf(type,"Date & time");
            sprintf(buff,"%s %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            SubEntry->GetDateTime()->Year,
                            SubEntry->GetDateTime()->Month,
                            SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,
                    SubEntry->GetDateTime()->Month,
                    SubEntry->GetDateTime()->Year,                                  
                    SubEntry->GetDateTime()->Hour,
                    SubEntry->GetDateTime()->Minute,
                    SubEntry->GetDateTime()->Second);
            if (SubEntry->Length!=-1) {
                DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
                DT1 += SubEntry->Length;
                memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
                sprintf(buff+strlen(buff)," - %s %02i-%02i-%04i %02i:%02i:%02i (%02i:%02i:%02i)",
                                DayOfWeekStr(
                                        DT2.Year,
                                        DT2.Month,
                                        DT2.Day),
                        DT2.Day,
                        DT2.Month,
                        DT2.Year,
                        DT2.Hour,
                        DT2.Minute,
                        DT2.Second,SubEntry->Length/(60*60),SubEntry->Length/60,SubEntry->Length%60);
            }
            StringToUnicode(buff,Value);
            break;
        }
        tmp = PBKDownWxListCtrl->InsertItem(EntryNum++, type, 0);
        PBKDownWxListCtrl->SetItemData(tmp, 0);
        PBKDownWxListCtrl->SetItem(tmp, 1, Value);
    }
}

void MainFrm::ReadSMSMMSFolders(BOOLEAN SMS)
{
    GSM_SMSMMSFoldersSubEntry  *SubFolder;
    GSM_Error                  error,preverror;
    char                       buff[200];
    int                        FolderMax=0;

    SMSFolders.ClearAll();
    error = s->Phones->Current->GetSMSMMSFolders(&SMSFolders);
    PrintError(error);
    FolderMax = 0;
    SubFolder = NULL;
    while (SMSFolders.GetNext(&SubFolder) == TRUE) FolderMax ++;

    if (SMS || FirstSMS) {
        Backup.Delete_SMS();
        SMSWxChoice->Clear();
        SMSUpWxListCtrl->DeleteAllItems();
        SMSDetailsWxListCtrl->DeleteAllItems();
        SMSWxChoice->Append("(all SMS folders)");
    }
    if (!SMS || FirstMMS) {
        Backup.Delete_MMS();
        MMSWxChoice->Clear();
        MMSUpWxListCtrl->DeleteAllItems();
        MMSDetailsWxListCtrl->DeleteAllItems();
        MMSWxChoice->Append("(all MMS folders)");
    }

    SubFolder = NULL;
    while (SMSFolders.GetNext(&SubFolder) == TRUE) {
        buff[0] = 0;
        if (SubFolder->MMS) {
            if (!SMS || FirstMMS) {
                if (SubFolder->Memory == MEM_PHONE) sprintf(buff,"%s (phone)",UnicodeToStringReturn(SubFolder->GetName()));
                MMSWxChoice->Append(buff);
            }
        } else {
            if (SMS || FirstSMS) {
                if (SubFolder->Memory == MEM_PHONE) sprintf(buff,"%s (phone)",UnicodeToStringReturn(SubFolder->GetName()));
                if (SubFolder->Memory == MEM_SIM) sprintf(buff,"%s (SIM)",UnicodeToStringReturn(SubFolder->GetName()));
                SMSWxChoice->Append(buff);
            }
        }
    }
    FirstSMS = FALSE;
    FirstMMS = FALSE;
}

/*
 * SMSGetWxButtonClick
 */
void MainFrm::SMSGetWxButtonClick(wxCommandEvent& event)
{
    ReadSMSMMSFolders(TRUE);
}

/*
 * Mnuabout1019Click
 */
void MainFrm::Mnuabout1019Click(wxCommandEvent& event)
{
    AboutDlg *dialog = new AboutDlg(this,-1,"About...",wxDefaultPosition,wxDefaultSize,AboutDlg_STYLE);
    
    dialog->ShowModal();
    
    dialog->Destroy();
}

BOOLEAN MainFrm::ReadSMSFolder(int Num2, GSM_SMSMMSFoldersSubEntry *SubFolder)
{
    bool                        skip;
    wxProgressDialog            *Dialog = NULL;
    GSM_Backup_SMSEntry         *En;
    GSM_Backup_MMSEntry         *En2;
    int                         i = 1, mmsfiles=0;
    int                         opernum=1;
    int                         Current, MaxInFolder;
    GSM_Error                   error,preverror;
    char                        buff[200];
    GSM_SMSList                 *Entry;
    GSM_MMSFile                 *Entry2;
    boolean                     wasmore = false;
    int                         EntryNum=0,Entry2Num=0;
    BOOLEAN                     start = TRUE, found=FALSE,first=TRUE;
    GSM_FileFolderInfoListsSubEntry   *En4;
    GSM_FileFolderInfoList *En3;
    
    if (SubFolder->MMS) {
        En2 = NULL;
        while (Backup.GetNext_MMS(&En2)) {
            if (En2->GetEntry()->Folder==Num2) {
                start = FALSE;
                break;
            }
        }
    } else {
        En = NULL;
        while (Backup.GetNext_SMS(&En)) {
            if (En->GetEntry()->Folder==Num2) {
                start = FALSE;
                break;
            }
        }
    }
    
    if (start) {
        if (SubFolder->FileSystem) {
            found = FALSE;
            En4 = NULL;
            while (Folders.GetNext(&En4)) {
                first = FALSE;
                if (!wcscmp(En4->Info.Info.GetID(),SubFolder->ID.data())) {
                    found = TRUE;
                    break;
                }
            }
            if (first) EnterFolder();
            if (!found) {
                En4 = new GSM_FileFolderInfoListsSubEntry;
            }
        }
        if (SubFolder->MMS) opernum++;
        i = 0;
        preverror.Code = GSM_ERR_UNKNOWN;
        Entry = new GSM_SMSList;
        Entry2 = new GSM_MMSFile;
        while (true) {
            error = s->Phones->Current->GetNextSMSMMSIDFromFolder(start, SubFolder,&En4->Info,Entry,Entry2,&Current, &MaxInFolder);
            if (error.Code == GSM_ERR_EMPTY) break;
            start = FALSE;
            if (error.Code == GSM_ERR_FOLDER_MORE) {
                if (Dialog == NULL) {
                    if (SubFolder->MMS) {
                        sprintf(buff,"Reading from '%s' MMS folder",UnicodeToStringReturn(SubFolder->GetName()));
                    } else {
                        sprintf(buff,"Reading from '%s' SMS folder",UnicodeToStringReturn(SubFolder->GetName()));
                    }
                    Dialog = new wxProgressDialog(buff, "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
                    opernum++;
                }
                i++;
                sprintf(buff,"Part 1/2 - reading folder content: %i",i);
                Dialog->Pulse(buff,&skip);
                wasmore = TRUE;
                continue;
            }
            if (wasmore) {
                wasmore = FALSE;
                delete(Dialog);
                Dialog = NULL;
            }
            if (error.Code == GSM_ERR_FOLDER_PART) {
                wxMessageBox("There was read only folder part (it's phone firmware problem)",
                        wxT("Error"),
                        wxICON_WARNING | wxOK);
                continue;
            }
            PrintError(error);

            if (Dialog == NULL) {
                if (SubFolder->MMS) {
                    sprintf(buff,"Reading from '%s' MMS folder",UnicodeToStringReturn(SubFolder->GetName()));
                } else {
                    sprintf(buff,"Reading from '%s' SMS folder",UnicodeToStringReturn(SubFolder->GetName()));
                }
                Dialog = new wxProgressDialog(buff, "", MaxInFolder, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
            } else {
                if (SubFolder->MMS) {
                    sprintf(buff,"Part %i/%i - reading MMS info: %i %% (%i/%i)",2,opernum,Current*100/MaxInFolder,Current,MaxInFolder);
                } else {
                    sprintf(buff,"Part %i/%i - reading SMS: %i %% (%i/%i)",opernum,opernum,Current*100/MaxInFolder,Current,MaxInFolder);
                }
                Dialog->Update((int)Current,buff,&skip);
            }
    		if (Entry->Folder == 0) {
                if (!SubFolder->MMS) {
                    if (Entry2Num==0) {
                        Entry2Num = -1;                    
                        En2 = NULL;
                        while (Backup.GetNext_MMS(&En2)) {
                            if (En2->GetEntry()->Folder==Entry2->Folder) {
                                Entry2Num = Entry2->Folder;
                                break;
                            }
                        }
                    }        
                } else {
                    Entry2Num = -1;
                }
                if (Entry2Num < 0) {
                    Backup.Add_MMS(Entry2);//sprawdzic, czy nie ma folderu
                } else {
                    delete (Entry2);
                }
                Entry2 = new GSM_MMSFile;
            } else {
                if (SubFolder->MMS) {
                    if (EntryNum==0) {
                        EntryNum = -1;
                        En = NULL;
                        while (Backup.GetNext_SMS(&En)) {
                            if (En->GetEntry()->Folder==Entry->Folder) {
                                EntryNum = Entry->Folder;
                                break;
                            }
                        }
                    }
                } else {
                    EntryNum = -1;
                }
                if (EntryNum < 0) {
                    Backup.Add_SMS(Entry);//sprawdzic, czy nie ma folderu
                } else {
                    delete (Entry);
                }
                Entry = new GSM_SMSList;                
            }            
        }
        delete (Dialog);
        delete (Entry);
        delete (Entry2);
        start = TRUE;
        if (EntryNum<0) {
            Dialog = new wxProgressDialog("Linking SMS", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
            Backup.LinkSMS();
            delete (Dialog);
        }
        if (SubFolder->FileSystem && !found) {
            Folders.AddSubEntry(En4);
        }
    }
    if (SubFolder->MMS) {
        mmsfiles = 0;
        En2 = NULL;
        while (Backup.GetNext_MMS(&En2)) {
            if (En2->GetEntry()->Folder!=Num2) continue;
            if (En2->GetEntry()->File.Buffer.size()==0) mmsfiles++;
        }
        if (mmsfiles != 0) {
            sprintf(buff,"Reading from '%s' MMS folder",UnicodeToStringReturn(SubFolder->GetName()));
            Dialog = new wxProgressDialog(buff, "", mmsfiles*100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
            En2 = NULL;
            i=0;
            while (Backup.GetNext_MMS(&En2)) {
                if (En2->GetEntry()->Folder!=Num2) continue;
//                if (En2->GetEntry()->File.Buffer.size()!=0) continue;
                while(true) {
                    error = s->Phones->Current->GetMMSFilePart(&En2->GetEntry()->File);
                    if (error.Code!=GSM_ERR_NONE) {
                          PrintError(error);
                    }
                    sprintf(buff,"Part %i/%i - reading MMS files: %i %% (%i/%i)",3,opernum,(i*100+En2->GetEntry()->File.Buffer.size()*100/En2->GetEntry()->File.Info.Size)*100/(mmsfiles*100),i+1,mmsfiles);
                    Dialog->Update((int)(i*100+En2->GetEntry()->File.Buffer.size()*100/En2->GetEntry()->File.Info.Size),buff,&skip);
        
                    if (En2->GetEntry()->File.Info.Size == En2->GetEntry()->File.Buffer.size()) break;
                }
                i++;
            }
            delete (Dialog);
        }
    }
    
    return start;
}

void MainFrm::FindSMSNumber(wchar_t *Number)
{
   wxProgressDialog            *Dialog = NULL;
    GSM_Backup_SMSEntry         *En;
    GSM_SMSListSubEntry         *SubEntry;
    GSM_SMSEntry                *SMS;
    boolean                     wrong;
    wchar_t                     Buffer[500],Buffer2[500],Last[500],First[500];
    long                        tmp;
    int                         i = 1,j,z;
    int                         EntryNum = 0, Num, Num2;
	int                         SequencesNum=0,PartsNum=0;
    GSM_DateTime                DT;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error,preverror;
    char                        buff[200];
    GSM_MMSFile                 Entry2;
    boolean                     wasmore = false;
	BOOLEAN                     was = FALSE, Found;    
    GSM_PBKSubEntry             *PBKSubEntry;
    GSM_Backup_PBKEntry         *PBKEntry;
	
//	return;
	
    if (UnicodeLength(Buffer) == 0) return;

    Found = FALSE;
    PBKEntry = NULL;
    while(Backup.GetNext_PBK(&PBKEntry)) {
        if (PBKEntry->GetEntry()->Memory == MEM_PHONE) {
            Found = TRUE;
            break;
        }
    }
    if (!Found) {
        if (FirstPBK) AddAllPBKMemories();
        ReadPBKMemory(MEM_PHONE);
    }
    
    buff[0]=0;
    Buffer2[0] = 0;
    PBKEntry = NULL;
    while (Backup.GetNext_PBK(&PBKEntry)) {
        if (PBKEntry->GetEntry()->Memory != MEM_PHONE) continue;
    
        PBKSubEntry = NULL;
        while (PBKEntry->GetEntry()->GetNext(&PBKSubEntry)) {
            switch (PBKSubEntry->GetType()) {
            case PBK_Text_Phone_General:
                if (UnicodeCaseCmp(PBKSubEntry->GetText(),Number,-1)) {
                    sprintf(buff,"general");
                }
                break;
            case PBK_Text_Phone_Mobile:
                if (UnicodeCaseCmp(PBKSubEntry->GetText(),Number,-1)) {
                    sprintf(buff,"mobile");
                }
                break;
            case PBK_Text_Phone_Home:
                if (UnicodeCaseCmp(PBKSubEntry->GetText(),Number,-1)) {
                    sprintf(buff,"home");
                }
                break;
            case PBK_Text_Phone_Work:
                if (UnicodeCaseCmp(PBKSubEntry->GetText(),Number,-1)) {
                    sprintf(buff,"work");
                }
                break;
            case PBK_Text_Phone_Fax:
                if (UnicodeCaseCmp(PBKSubEntry->GetText(),Number,-1)) {
                    sprintf(buff,"fax");
                }
                break;
            default:
                break;
            }
            if (buff[0] != 0) break;
        }
        if (buff[0] != 0) {
            Last[0] = 0;
            First[0] = 0;
            PBKSubEntry = NULL;
            while (PBKEntry->GetEntry()->GetNext(&PBKSubEntry) == TRUE) {
                switch (PBKSubEntry->GetType()) {
                case PBK_Text_Name: CopyUnicode(PBKSubEntry->GetText(),Buffer2); break;
                case PBK_Text_Name_First: CopyUnicode(PBKSubEntry->GetText(),First); break;
                case PBK_Text_Name_Last: CopyUnicode(PBKSubEntry->GetText(),Last); break;
                default: break;
                }
            }
            if (Last[0] != 0 || First[0] != 0) {
                CopyUnicode(Last,Buffer2);
                buff[UnicodeLength(Buffer2)+1] = 0;
                buff[UnicodeLength(Buffer2)] = ' ';
                CopyUnicode(First,Buffer2+UnicodeLength(Buffer2));
            }
            CopyUnicode(StringToUnicodeReturn(" ("),Buffer2+UnicodeLength(Buffer2));
            CopyUnicode(StringToUnicodeReturn(buff),Buffer2+UnicodeLength(Buffer2));
            CopyUnicode(StringToUnicodeReturn(", "),Buffer2+UnicodeLength(Buffer2));
            CopyUnicode(Number,Buffer2+UnicodeLength(Buffer2));
            CopyUnicode(StringToUnicodeReturn(")"),Buffer2+UnicodeLength(Buffer2));
            CopyUnicode(Buffer2,Number);
            return;
        }
    }
}

void MainFrm::DisplaySMSFolder()
{
    wxProgressDialog            *Dialog = NULL;
    GSM_Backup_SMSEntry         *En;
    GSM_SMSListSubEntry         *SubEntry;
    GSM_SMSEntry                *SMS;
    boolean                     wrong;
    wchar_t                     Buffer[500],Buffer2[500],Last[500],First[500];
    long                        tmp;
    int                         i = 1,j,z;
    int                         EntryNum = 0, Num, Num2;
	int                         SequencesNum=0,PartsNum=0;
    GSM_DateTime                DT;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error,preverror;
    char                        buff[200];
    GSM_MMSFile                 Entry2;
    boolean                     wasmore = false;
	GSM_SMSNumbersSubEntry      *Number;
	BOOLEAN                     was = FALSE, Found, Found2;

    SMSUpWxListCtrl->DeleteAllItems();
    SMSDetailsWxListCtrl->DeleteAllItems();

    if (SMSWxChoice->GetSelection()==0) {
        Num2=0;
        SubFolder = NULL;
        while (SMSFolders.GetNext(&SubFolder)) {
            Num2++;
            if (SubFolder->MMS) continue;
            if (!was) {
                was = ReadSMSFolder(Num2,SubFolder);
            } else {
                ReadSMSFolder(Num2,SubFolder);
            }
        }
    } else {
        Num = 0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=SMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (SubFolder->MMS) continue;
            Num++;
        }
        was = ReadSMSFolder(Num2,SubFolder);
    }

//    if (was) {
//        Dialog = new wxProgressDialog("Linking SMS", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME);
//        Backup.LinkSMS();
//        delete (Dialog);
//    }

    En = NULL;
    while (Backup.GetNext_SMS(&En)) {
        wrong = false;
        SubEntry = NULL;
        if (!En->GetEntry()->GetNext(&SubEntry)) continue;
        if (SMSWxChoice->GetSelection()!=0) {
            if (En->GetEntry()->Folder != Num2) {
                continue;
            }
        }
        if (WxEdit3->GetValue()!="") {
            Found2 = FALSE;
            SMSWxMemo->Clear();
            SubEntry = NULL;
            while (En->GetEntry()->GetNext(&SubEntry)) {
                SMS = SubEntry->GetSMS();

            		Number = NULL;
            		while (SMS->PhoneNumbers.GetNext(&Number)) {
            			error = Number->GetPhoneNumber(Buffer);
                        PrintError(error);
                        if (UnicodeLength(Buffer)!=0) {
                            FindSMSNumber(Buffer);
                            if (wcsstr((const wchar_t *)Buffer,(wchar_t *)StringToUnicodeReturn((char *)WxEdit3->GetValue().c_str()))!=NULL) {
                                Found2=TRUE;
                                break;
                            }
                        }
                    }

                if (Found2) break;
                switch (SMS->GetCoding()) {
                case SMS_Coding_Unicode_No_Compression:
                case SMS_Coding_Default_No_Compression:
                    error = SMS->GetDecodedText(Buffer);
                    PrintError(error);
                    FixBuffer(Buffer);
                    SMSWxMemo->AppendText(Buffer);
                    break;
                default:
                    break;
                }
            }
            if (!Found2 && wcsstr((const wchar_t *)SMSWxMemo->GetValue().fn_str(),(wchar_t *)StringToUnicodeReturn((char *)WxEdit3->GetValue().c_str()))!=NULL) {
                Found2=TRUE;
            }
            if (!Found2) continue;
            SubEntry = NULL;
            if (!En->GetEntry()->GetNext(&SubEntry)) continue;
        }
        SequencesNum++;
        PartsNum++;

        SMS = SubEntry->GetSMS();
        if (SMS->GetType()!=SMS_Submit) {
            SMS->GetDateTime(&DT);
            sprintf(buff,"%s %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            DT.Year,
                            DT.Month,
                            DT.Day),
                    DT.Day,
                    DT.Month,
                    DT.Year,
                    DT.Hour,
                    DT.Minute,
                    DT.Second);
            StringToUnicode(buff,Buffer);
            tmp = SMSUpWxListCtrl->InsertItem(EntryNum++, Buffer, 0);
        } else {
            tmp = SMSUpWxListCtrl->InsertItem(EntryNum++, "", 0);
        }
        SMSUpWxListCtrl->SetItemData(tmp, 0);
        j=0;
		Number = NULL;
		while (SMS->PhoneNumbers.GetNext(&Number)) j++;
		if (j>1) {
            SMSUpWxListCtrl->SetItem(tmp, 1, "(many recipients)");
            PartsNum+=j-1;
            SequencesNum+=j-1;
        } else if (j==1) {
    		Number = NULL;
    		SMS->PhoneNumbers.GetNext(&Number);
            Number->GetPhoneNumber(Buffer);
            FindSMSNumber(Buffer);
            SMSUpWxListCtrl->SetItem(tmp, 1, Buffer);
        } else {
            Buffer[0] = 0;
            SMSUpWxListCtrl->SetItem(tmp, 1, Buffer);
        }

        if (SMS->GetType()!=SMS_Report && (SMS->GetCoding()==SMS_Coding_Unicode_No_Compression || SMS->GetCoding()==SMS_Coding_Default_No_Compression)) {
            SMS->GetDecodedText(Buffer);
            FixBuffer(Buffer);
            SMSUpWxListCtrl->SetItem(tmp, 2, Buffer);
        } else {
            SMSUpWxListCtrl->SetItem(tmp, 2, "");
        }
        i=0;
        SubEntry=NULL;
        while (En->GetEntry()->GetNext(&SubEntry)) i++;
        if (i>1) PartsNum+=i-1;
        sprintf(buff,"%i",i);
        StringToUnicode(buff,Buffer);
        SMSUpWxListCtrl->SetItem(tmp, 3, Buffer);
    }

    sprintf(buff,"%i parts in %i sequences",PartsNum,SequencesNum);
    StatusStr[1].clear();
    StatusStr[1].append(StringToUnicodeReturn(buff));
    WxStatusBar1->SetStatusText(wxString(StatusStr[1].data())+wxString(StatusStr2[1].data()),0);
}

/*
 * SMSWxChoiceSelected
 */
void MainFrm::SMSWxChoiceSelected(wxCommandEvent& event )
{
    DisplaySMSFolder();
}

void MainFrm::DisplaySMSEntry()
{
    GSM_Error                   error;
    GSM_File                    ReadSaveFile;
    int                         EntryNum=0,j,Num,Num2,NumbersNum=0,Parts=-1,PartNum=-1;
    wchart                      x;
    long                        item,tmp,item2=0;
    GSM_Backup_SMSEntry         *En;
    GSM_SMSListSubEntry         *SubEntry;
    GSM_SMSEntry                *SMS;
    boolean                     wrong,display;
    wchar_t                     Buffer[500],Buffer2[500],Last[500],First[500];
    char                        buff[200];
    GSM_DateTime                DT;
    unsignedstring              UDH;
    UDHList                     UDH2;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
	GSM_SMSNumbersSubEntry      *Number;
    GSM_PBKSubEntry             *PBKSubEntry;
    GSM_Backup_PBKEntry         *PBKEntry;
    BOOLEAN                     Found2,FirstEntry;

    item = SMSUpWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    SMSDetailsWxListCtrl->DeleteAllItems();

    if (SMSWxChoice->GetSelection()!=0) {
        Num=0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=SMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (SubFolder->MMS) continue;
            Num++;
        }
    }

    En = NULL;
    while (Backup.GetNext_SMS(&En)) {
        wrong = false;
        SubEntry = NULL;
        if (!En->GetEntry()->GetNext(&SubEntry)) continue;
        if (SMSWxChoice->GetSelection()!=0) {
            if (En->GetEntry()->Folder != Num2) {
                continue;
            }
        }
        if (WxEdit3->GetValue()!="") {
            Found2 = FALSE;
            SMSWxMemo->Clear();
            SubEntry = NULL;
            while (En->GetEntry()->GetNext(&SubEntry)) {
                SMS = SubEntry->GetSMS();

            		Number = NULL;
            		while (SMS->PhoneNumbers.GetNext(&Number)) {
            			error = Number->GetPhoneNumber(Buffer);
                        PrintError(error);
                        if (UnicodeLength(Buffer)!=0) {
                            FindSMSNumber(Buffer);
                            if (wcsstr((const wchar_t *)Buffer,(wchar_t *)StringToUnicodeReturn((char *)WxEdit3->GetValue().c_str()))!=NULL) {
                                Found2=TRUE;
                                break;
                            }
                        }
                    }

                if (Found2) break;
                switch (SMS->GetCoding()) {
                case SMS_Coding_Unicode_No_Compression:
                case SMS_Coding_Default_No_Compression:
                    error = SMS->GetDecodedText(Buffer);
                    PrintError(error);
                    FixBuffer(Buffer);
                    SMSWxMemo->AppendText(Buffer);
                    break;
                default:
                    break;
                }
            }
            if (!Found2 && wcsstr((const wchar_t *)SMSWxMemo->GetValue().fn_str(),(wchar_t *)StringToUnicodeReturn((char *)WxEdit3->GetValue().c_str()))!=NULL) {
                Found2=TRUE;
            }
            if (!Found2) continue;
            SubEntry = NULL;
            if (!En->GetEntry()->GetNext(&SubEntry)) continue;
        }        
        item2++;
        if (item != item2-1) continue;
        break;
    }
    SMSWxMemo->Clear();  
    SMSNumbersWxListBox->Clear();
    FirstEntry = TRUE;  
    while (true) {
        SMS = SubEntry->GetSMS();
        switch (SMS->GetType()) {
        case SMS_Deliver:
            tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "SMS Deliver", 0);
            SMSDetailsWxListCtrl->SetItemData(tmp, 0);

            error = SMS->GetSMSCNumber(Buffer);
            PrintError(error);
            tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   SMSC Number", 0);
            SMSDetailsWxListCtrl->SetItemData(tmp, 0);
            SMSDetailsWxListCtrl->SetItem(tmp, 1, UnicodeToStringReturn(Buffer));

            SMS->GetDateTime(&DT);
            tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   Sending date & time", 0);
            SMSDetailsWxListCtrl->SetItemData(tmp, 0);
            sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(DT.Year,DT.Month,DT.Day),
                    DT.Day,DT.Month,DT.Year,
                    DT.Hour,DT.Minute,DT.Second);
            SMSDetailsWxListCtrl->SetItem(tmp, 1, buff);
            /* no break */
        case SMS_Submit:
            if (SMS->GetType() == SMS_Submit) {
                tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "SMS Submit", 0);
                SMSDetailsWxListCtrl->SetItemData(tmp, 0);
            }
    		Number = NULL;
    		while (SMS->PhoneNumbers.GetNext(&Number)) {
    			error = Number->GetPhoneNumber(Buffer);
                PrintError(error);
                if (UnicodeLength(Buffer)!=0) {
                    tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   Phone number", 0);
                    SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                    FindSMSNumber(Buffer);
                    SMSDetailsWxListCtrl->SetItem(tmp, 1, Buffer);
                    if (FirstEntry) {
                        SMSNumbersWxListBox->Append(Buffer);
                        NumbersNum++;
                    }
                }
            }
            if (SMS->GetClass() != -1) {
                tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   SMS class", 0);
                sprintf(buff,"%i",SMS->GetClass());
                SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                SMSDetailsWxListCtrl->SetItem(tmp, 1, buff);
            }
            if (SMS->SenderSMSCReply() == TRUE) {
                tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   SMSC reply", 0);
                SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "yes");
            }

            error = SMS->GetUDH(&UDH);
            PrintError(error);
            if (UDH.size()!=0) {
                error = SMS->DecodeUDH(&UDH2);
                if (error.Code == GSM_ERR_NONE) {
                    for (j=0;j<UDH2.size();j++) {
                        tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   UDH", 0);
                        switch (UDH2.data()[j].Type) {
                        case SMS_UDH_Linked_Short:
                            sprintf(buff,"linked (short, ID %i, part %i/%i)",UDH2.data()[j].ID8bit,UDH2.data()[j].PartNumber8bit,UDH2.data()[j].AllParts8bit);
                            SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                            SMSDetailsWxListCtrl->SetItem(tmp, 1, buff);
                            if (FirstEntry && UDH2.data()[j].PartNumber8bit!=1) {
                                SMSWxMemo->AppendText("(PART MISSED) ");
                            }
                            Parts = UDH2.data()[j].AllParts8bit;
                            PartNum = UDH2.data()[j].PartNumber8bit;
                            break;
                        case SMS_UDH_Linked_Long:
                            sprintf(buff,"linked (long, ID %i, part %i/%i)",UDH2.data()[j].ID16bit,UDH2.data()[j].PartNumber8bit,UDH2.data()[j].AllParts8bit);
                            SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                            SMSDetailsWxListCtrl->SetItem(tmp, 1, buff);
                            if (FirstEntry && UDH2.data()[j].PartNumber8bit!=1) {
                                SMSWxMemo->AppendText("(PART MISSED) ");
                            }
                            Parts = UDH2.data()[j].AllParts8bit;                            
                            PartNum = UDH2.data()[j].PartNumber8bit;
                            break;
                        }
                    }
                }
            }

            tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   Coding", 0);
            SMSDetailsWxListCtrl->SetItemData(tmp, 0);
            switch (SMS->GetCoding()) {
            case SMS_Coding_Unicode_No_Compression:
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "Unicode, no compression");
                error = SMS->GetDecodedText(Buffer);
                PrintError(error);
                tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   Text", 0);
                SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                FixBuffer(Buffer);
                SMSWxMemo->AppendText(Buffer);
                SMSDetailsWxListCtrl->SetItem(tmp, 1, Buffer);
                break;
            case SMS_Coding_Unicode_Compression:
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "Unicode, compression, no support from Gammu+ now");
                break;
            case SMS_Coding_Default_No_Compression:
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "Default, no compression");
                error = SMS->GetDecodedText(Buffer);
                PrintError(error);
                tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "   Text", 0);
                SMSDetailsWxListCtrl->SetItemData(tmp, 0);
                FixBuffer(Buffer);
                SMSWxMemo->AppendText(Buffer);                    
                SMSDetailsWxListCtrl->SetItem(tmp, 1, Buffer);
                break;
            case SMS_Coding_Default_Compression:
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "Default, compression, no support from Gammu+ now");
                break;
            case SMS_Coding_8bit:
                SMSDetailsWxListCtrl->SetItem(tmp, 1, "8 bit");
                break;
            }
            break;
        case SMS_Report:
            tmp = SMSDetailsWxListCtrl->InsertItem(EntryNum++, "SMS report", 0);
        }

        if (!En->GetEntry()->GetNext(&SubEntry)) {
            if (Parts != -1 && Parts != PartNum) {
                SMSWxMemo->AppendText(" (PART MISSED)");
            }
            break;
        }
        FirstEntry = FALSE;
    }
    SMSNumbersWxListBox->SetSizeHints(300,NumbersNum*15);
    WxBoxSizer7->Layout(); 
}

/*
 * SMSUpWxListCtrlItemActivated
 */
void MainFrm::SMSUpWxListCtrlItemActivated(wxListEvent& event)
{
    DisplaySMSEntry();
}

/*
 * WxButton2Click
 */
void MainFrm::WxButton2Click(wxCommandEvent& event)
{
    bool                newe = TRUE, Start = TRUE, skip;
    GSM_Error           error;    
    GSM_CalendarEntry   *Entry;
    int                 Current,Max;
    wxProgressDialog    *Dialog = NULL;
    
    while (1) {
        if (newe) {
            Entry = new GSM_CalendarEntry;
            newe = false;
        }
        error = s->Phones->Current->GetNextCalendar(Entry,Start,&Current,&Max);
        if (error.Code == GSM_ERR_EMPTY) break;
        PrintError(error);
        if (Dialog == NULL) {
            if (Max != -1) {
                Dialog = new wxProgressDialog("Reading calendar", "", Max, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);                
            } else {
                Dialog = new wxProgressDialog("Reading calendar", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
            }
        } else {
            if (Max != -1) {
                Dialog->Update((int)Current,"",&skip);
            } else {
                Dialog->Pulse("",&skip);
            }
        }
        
        Backup.Add_Cal(Entry);
        newe = true;
        Start = false;
    }
    delete Dialog;
    DisplayCalendar();
}

/*
 * wxNotebook1PageChanged
 */
void MainFrm::wxNotebook1PageChanged(wxNotebookEvent& event)
{
    WxStatusBar1->SetStatusText(StatusStr[wxNotebook1->GetSelection()].data(),0);
}

void MainFrm::DisplayCalendar()
{
    GSM_Backup_CalEntry     *CalEntry;
    GSM_CalendarEntry       *CalEntry2;
    wchart                  Text;
    GSM_DateTime            DT;
    GSM_CalendarSubEntry    *SubEntry;
    long                    EntryNum = 0, tmp;
    char                    buff[200];

    if (WxCheckBox1->GetValue()) {
        sprintf(buff,"All calendar notes");
    } else {
        sprintf(buff,"Calendar for %s %02i-%02i-%04i",
            DayOfWeekStr(
                WxCalendarCtrl1->GetDate().GetYear(),
                WxCalendarCtrl1->GetDate().GetMonth(),
                WxCalendarCtrl1->GetDate().GetDay()),
            WxCalendarCtrl1->GetDate().GetDay(),
            WxCalendarCtrl1->GetDate().GetMonth(),
            WxCalendarCtrl1->GetDate().GetYear());        
    }
    StatusStr[2].clear();
    StatusStr[2].append(StringToUnicodeReturn(buff));
    WxStatusBar1->SetStatusText(StatusStr[2].data(),0);
    
    WxListCtrl6->DeleteAllItems();
    WxListCtrl7->DeleteAllItems();
    
    CalEntry = NULL;
    while (Backup.GetNext_Cal(&CalEntry)) {
        CalEntry2 = CalEntry->GetEntry();
        Text.clear();

        SubEntry = NULL;
        while (CalEntry2->GetNext(&SubEntry)) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                Text.append(SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                memcpy(&DT,SubEntry->GetDateTime(),sizeof(GSM_DateTime));
                break;
            default:
                break;
            }
        }
        if (!WxCheckBox1->GetValue() && (WxCalendarCtrl1->GetDate().GetYear()!=DT.Year ||
            WxCalendarCtrl1->GetDate().GetMonth()!=DT.Month ||
            WxCalendarCtrl1->GetDate().GetDay()!=DT.Day)) {
                continue;
        }

        sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                DayOfWeekStr(DT.Year,DT.Month,DT.Day),
                DT.Day,DT.Month,DT.Year,
                DT.Hour,DT.Minute,DT.Second);
        
        tmp = WxListCtrl6->InsertItem(EntryNum++, buff, 0);
        WxListCtrl6->SetItemData(tmp, 0);
        
        switch(CalEntry2->Type) {
        case Calendar_Type_Meeting:
            WxListCtrl6->SetItem(tmp, 1, "meeting");
            break;
        case Calendar_Type_Memo:
            WxListCtrl6->SetItem(tmp, 1, "memo");
            break;
        case Calendar_Type_Call:
            WxListCtrl6->SetItem(tmp, 1, "phone call");
            break;
        case Calendar_Type_Birthday:
            WxListCtrl6->SetItem(tmp, 1, "birthday");
            break;
        case Calendar_Type_Reminder:
            WxListCtrl6->SetItem(tmp, 1, "reminder");
            break;
        }
        
        WxListCtrl6->SetItem(tmp, 2, Text.data());        
    }    
}


/*
 * WxCalendarCtrl1SelChanged
 */
void MainFrm::WxCalendarCtrl1SelChanged(wxCalendarEvent& event)
{
    DisplayCalendar();
}

/*
 * WxCheckBox1Click
 */
void MainFrm::WxCheckBox1Click(wxCommandEvent& event)
{
    WxCalendarCtrl1->Enable(!WxCheckBox1->GetValue());
    DisplayCalendar();
}

/*
 * WxListCtrl6ItemActivated
 */
void MainFrm::WxListCtrl6ItemActivated(wxListEvent& event)
{
    GSM_Backup_CalEntry     *CalEntry;
    GSM_CalendarEntry       *CalEntry2;
    wchart                  Text;
    GSM_DateTime            DT;
    GSM_CalendarSubEntry    *SubEntry;
    long                    EntryNum = 0, tmp, item, item2=0;
    char                    buff[200];
    int                     RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;

    WxListCtrl7->DeleteAllItems();
    
    item = WxListCtrl6->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    
    CalEntry = NULL;
    while (Backup.GetNext_Cal(&CalEntry)) {
        CalEntry2 = CalEntry->GetEntry();
        Text.clear();

        SubEntry = NULL;
        while (CalEntry2->GetNext(&SubEntry)) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                Text.append(SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                memcpy(&DT,SubEntry->GetDateTime(),sizeof(GSM_DateTime));
                break;
            default:
                break;
            }
        }
        if (!WxCheckBox1->GetValue() && (WxCalendarCtrl1->GetDate().GetYear()!=DT.Year ||
            WxCalendarCtrl1->GetDate().GetMonth()!=DT.Month ||
            WxCalendarCtrl1->GetDate().GetDay()!=DT.Day)) {
                continue;
        }
        item2++;
        if (item2-1 != item) continue;
        
        tmp = WxListCtrl7->InsertItem(EntryNum++, "Note type", 0);
        WxListCtrl7->SetItemData(tmp, 0);

        switch(CalEntry2->Type) {
        case Calendar_Type_Meeting:
            WxListCtrl7->SetItem(tmp, 1, "meeting");
            break;
        case Calendar_Type_Memo:
            WxListCtrl7->SetItem(tmp, 1, "memo");
            break;
        case Calendar_Type_Call:
            WxListCtrl7->SetItem(tmp, 1, "phone call");
            break;
        case Calendar_Type_Birthday:
            WxListCtrl7->SetItem(tmp, 1, "birthday");
            break;
        case Calendar_Type_Reminder:
            WxListCtrl7->SetItem(tmp, 1, "reminder");
            break;
        }

        RepeatEach      = -1;
        RepeatDay       = -1;
        RepeatMonth     = -1;
        RepeatDOW       = -1;
        SubEntry        = NULL;
        while (CalEntry2->GetNext(&SubEntry) == TRUE) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Text", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_Text_Phone:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Phone number", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_Text_Location:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Location", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Start", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(SubEntry->GetDateTime()->Year,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Year,
                    SubEntry->GetDateTime()->Hour,SubEntry->GetDateTime()->Minute,SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_End:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "End", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(SubEntry->GetDateTime()->Year,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Year,
                    SubEntry->GetDateTime()->Hour,SubEntry->GetDateTime()->Minute,SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_SilentAlarm:
            case Calendar_DateTime_ToneAlarm:
                if (SubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
                    tmp = WxListCtrl7->InsertItem(EntryNum++, "Silent alarm", 0);
                } else {
                    tmp = WxListCtrl7->InsertItem(EntryNum++, "Tone alarm", 0);
                }
                WxListCtrl7->SetItemData(tmp, 0);
                if (CalEntry2->Type == Calendar_Type_Birthday) {
                    sprintf(buff,"%02i:%02i:%02i %02i-%02i in each year",
                            SubEntry->GetDateTime()->Hour,
                            SubEntry->GetDateTime()->Minute,
                            SubEntry->GetDateTime()->Second,
                            SubEntry->GetDateTime()->Day,
                            SubEntry->GetDateTime()->Month);
                } else {
                    sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                            DayOfWeekStr(
                                    SubEntry->GetDateTime()->Year,
                                    SubEntry->GetDateTime()->Month,
                                    SubEntry->GetDateTime()->Day),                    
                            SubEntry->GetDateTime()->Day,
                            SubEntry->GetDateTime()->Month,
                            SubEntry->GetDateTime()->Year,
                            SubEntry->GetDateTime()->Hour,
                            SubEntry->GetDateTime()->Minute,
                            SubEntry->GetDateTime()->Second);
                }
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_End_Repeat:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Repeat end", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                        DayOfWeekStr(
                                SubEntry->GetDateTime()->Year,
                                SubEntry->GetDateTime()->Month,
                                SubEntry->GetDateTime()->Day),
                        SubEntry->GetDateTime()->Day,
                        SubEntry->GetDateTime()->Month,
                        SubEntry->GetDateTime()->Year,
                        SubEntry->GetDateTime()->Hour,
                        SubEntry->GetDateTime()->Minute,
                        SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_Int_Repeat_Frequency:
                RepeatEach = SubEntry->GetInt();
                break;
            case Calendar_Int_Repeat_DayOfWeek:
                RepeatDOW = SubEntry->GetInt();
                break;                  
            case Calendar_Int_Repeat_Day:
                RepeatDay = SubEntry->GetInt();
                break;
            case Calendar_Int_Repeat_Month:
                RepeatMonth = SubEntry->GetInt();
                break;
            }
        }

        if (RepeatEach != -1 || RepeatDOW != -1 ||
            RepeatDay != -1 || RepeatMonth != -1) {
            tmp = WxListCtrl7->InsertItem(EntryNum++, "Repeat", 0);
            WxListCtrl7->SetItemData(tmp, 0);
            buff[0] = 0;
            if (RepeatEach == 1) sprintf(buff+strlen(buff),"each ");
            if (RepeatEach == 2) sprintf(buff+strlen(buff),"each second ");
            if (RepeatDOW != -1) {
                switch (RepeatDOW) {
                    case 1: sprintf(buff+strlen(buff),"Monday ");      break;
                    case 2: sprintf(buff+strlen(buff),"Tuesday ");     break;
                    case 3: sprintf(buff+strlen(buff),"Wednesday ");   break;
                    case 4: sprintf(buff+strlen(buff),"Thursday ");    break;
                    case 5: sprintf(buff+strlen(buff),"Friday ");      break;
                    case 6: sprintf(buff+strlen(buff),"Saturday ");    break;
                    case 7: sprintf(buff+strlen(buff),"Sunday ");      break;
                    default:sprintf(buff+strlen(buff)," ");
                }
            }
            if (RepeatDay != -1) {
                sprintf(buff+strlen(buff),"%i ",RepeatDay);
                if (RepeatMonth != -1) {
                    switch (RepeatMonth) {
                        case  1: sprintf(buff+strlen(buff),"January ");    break;
                        case  2: sprintf(buff+strlen(buff),"February ");   break;
                        case  3: sprintf(buff+strlen(buff),"March ");      break;
                        case  4: sprintf(buff+strlen(buff),"April ");      break;
                        case  5: sprintf(buff+strlen(buff),"May ");        break;
                        case  6: sprintf(buff+strlen(buff),"June ");       break;
                        case  7: sprintf(buff+strlen(buff),"July ");       break;
                        case  8: sprintf(buff+strlen(buff),"August ");     break;
                        case  9: sprintf(buff+strlen(buff),"September ");  break;
                        case 10: sprintf(buff+strlen(buff),"October ");    break;
                        case 11: sprintf(buff+strlen(buff),"November ");   break;
                        case 12: sprintf(buff+strlen(buff),"December ");   break;
                        default:sprintf(buff+strlen(buff)," ");
                    }
                } else {
                    sprintf(buff+strlen(buff),"month day ");
                }
            }
            WxListCtrl7->SetItem(tmp, 1, buff);
        }
    }
}

/*
 * Mnuconfiguration1147Click
 */
void MainFrm::Mnuconfiguration1147Click(wxCommandEvent& event)
{
    CfgDlg *dialog = new CfgDlg(this,-1,"Configuration",wxDefaultPosition,wxDefaultSize,AboutDlg_STYLE);

    dialog->ShowModal();

    dialog->Destroy();
}

/*
 * Mnumenuitem11020Click
 */
void MainFrm::Mnumenuitem11020Click(wxCommandEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
    GSM_File                        ReadSaveFile;
    GSM_FileFolderInfoListSubEntry  *SubEntry;
    int                             i,Num=0;
    wchart                          x;
    long                            item=-1,item2;
    bool                            Multiple = FALSE;

    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
    return;
            
    for (;;) {
        item = WxListCtrl1->GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
        if (item == -1) break;
        item2 = item;
        
        if (WxListCtrl1->GetItemText(item2)== "..") {
            Multiple = TRUE;
            break;
        }
        if (WxListCtrl1->GetItemText(0)== "..") item2--;
        SubEntry = NULL;
        for (i=0;i<=item2;i++) En2->Info.GetNext(&SubEntry);
        if (SubEntry->Info.Folder) {
            Multiple = TRUE;
            break;
        }
        Num++;
        if (Num==2) {
            Multiple = TRUE;
            break;
        }
    }
    if (Multiple) {
        WxDirDialog1->ShowModal();
        wxMessageBox("Not implemented",
                wxT("Error"),
                wxICON_WARNING | wxOK);
        return;
    }

    item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    if (WxListCtrl1->GetItemText(0)== "..") item--;
    SubEntry = NULL;
    for (i=0;i<=item;i++) En2->Info.GetNext(&SubEntry);
    CopyUnicode(FileFolderID,FileFolderID0);
    CopyUnicode(SubEntry->Info.GetID(),FileFolderID);

    Dialog = new wxProgressDialog("Reading file", SubEntry->Info.GetName(), 100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
    ReadSaveFile.Info.SetID(FileFolderID);
    while(true) {
        error = s->Phones->Current->GetFilePart(&ReadSaveFile);
        if (error.Code!=GSM_ERR_NONE) {
              PrintError(error);
        }

        if (!Dialog->Update((int)ReadSaveFile.Buffer.size()*100/ReadSaveFile.Info.Size,"",&skip)) break;
        if (ReadSaveFile.Info.Size == ReadSaveFile.Buffer.size()) break;
    }
    delete Dialog;
    WxSaveFileDialog1->SetFilename(SubEntry->Info.GetName());
    if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
    ReadSaveFile.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
}

/*
 * Mnuproperties1026Click
 */
void MainFrm::Mnuproperties1026Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnurename1024Click
 */
void MainFrm::Mnurename1024Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuaddfile1027Click
 */
void MainFrm::Mnuaddfile1027Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuaddfolder1022Click
 */
void MainFrm::Mnuaddfolder1022Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnudelete1023Click
 */
void MainFrm::Mnudelete1023Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuforward1148Click
 */
void MainFrm::Mnuforward1148Click(wxCommandEvent& event)
{
	// insert your code here
}

/*
 * SMSUpWxListCtrlRightClick
 */
void MainFrm::SMSUpWxListCtrlRightClick(wxListEvent& event)
{
    PopupMenu(WxPopupMenu2, wxDefaultPosition);
}


/*
 * FileGetWxButtonClick
 */
void MainFrm::FileGetWxButtonClick(wxCommandEvent& event)
{
    Folders.ClearAll();
    EnterFolder();
}

/*
 * WxButton3Click
 */
void MainFrm::WxButton3Click(wxCommandEvent& event)
{
    DisplaySMSFolder();
}

/*
 * MMSGetWxButtonClick
 */
void MainFrm::MMSGetWxButtonClick(wxCommandEvent& event)
{
    ReadSMSMMSFolders(FALSE);
}

/*
 * MMSWxChoiceSelected
 */
void MainFrm::MMSWxChoiceSelected(wxCommandEvent& event )
{
    wxProgressDialog            *Dialog = NULL;
    GSM_Backup_MMSEntry         *En;
    GSM_SMSListSubEntry         *SubEntry;
    GSM_SMSEntry                *SMS;
    boolean                     wrong;
    wchar_t                     Buffer[500],Buffer2[500],Last[500],First[500];
    long                        tmp;
    int                         i = 1,j,z,num5=0;
    int                         EntryNum = 0, Num, Num2;
	int                         SequencesNum=0,PartsNum=0;
    GSM_DateTime                DT;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error,preverror;
    char                        buff[200];
    GSM_MMSFile                 Entry2;
    boolean                     wasmore = false;
	GSM_SMSNumbersSubEntry      *Number;
	BOOLEAN                     was = FALSE, Found, Found2;
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
	boolean                     found;

    MMSUpWxListCtrl->DeleteAllItems();
    MMSDetailsWxListCtrl->DeleteAllItems();

    if (MMSWxChoice->GetSelection()==0) {
        Num2=0;
        SubFolder = NULL;
        while (SMSFolders.GetNext(&SubFolder)) {
            Num2++;
            if (!SubFolder->MMS) continue;
            if (!was) {
                was = ReadSMSFolder(Num2,SubFolder);
            } else {
                ReadSMSFolder(Num2,SubFolder);
            }
        }
    } else {
        Num = 0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=MMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (!SubFolder->MMS) continue;
            Num++;
        }
        was = ReadSMSFolder(Num2,SubFolder);
    }
    En = NULL;
    while (Backup.GetNext_MMS(&En)) {
        num5++;
        if (En->GetEntry()->Folder!=Num2) continue;
        error = Decoded.Read(&En->GetEntry()->File);
        PrintError(error);
        found = false;
        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type == MMS_DT_DateTime) {
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                        DayOfWeekStr(
                                SubDecoded->DT.Year,
                                SubDecoded->DT.Month,
                                SubDecoded->DT.Day),
                        SubDecoded->DT.Day,
                        SubDecoded->DT.Month,
                        SubDecoded->DT.Year,
                        SubDecoded->DT.Hour,
                        SubDecoded->DT.Minute,
                        SubDecoded->DT.Second);
                tmp = MMSUpWxListCtrl->InsertItem(EntryNum++, buff, 0);
                found = TRUE;
                break;                
            }
        }
        if (!found) {
            tmp = MMSUpWxListCtrl->InsertItem(EntryNum++, "", 0);
        }
        MMSUpWxListCtrl->SetItemData(tmp, num5);
        found = false;
        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type ==  MMS_Address_Phone_Source ||
                SubDecoded->Type ==  MMS_Address_Unknown_Source) {

                memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
                FindSMSNumber(Buffer);

                MMSUpWxListCtrl->SetItem(tmp, 1, Buffer);
                found = true;
                break;
            }
        }
        if (!found) {
            SubDecoded = NULL;
            while (Decoded.GetNext(&SubDecoded)) {
                if (SubDecoded->Type ==  MMS_Address_Phone_Destination ||
                    SubDecoded->Type ==  MMS_Address_Unknown_Destination) {

                    memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
                    FindSMSNumber(Buffer);

                    MMSUpWxListCtrl->SetItem(tmp, 1, Buffer);
                    found = true;
                    break;
                }
            }
        }
        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type !=  MMS_File) continue;
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/plain"))) {
                MMSUpWxListCtrl->SetItem(tmp, 2, SubDecoded->File.Buffer.data());
            }            
        }
        i=0;
        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type ==  MMS_File) i++;
        }
        sprintf(buff,"%i",i);
        MMSUpWxListCtrl->SetItem(tmp, 3, buff);
        sprintf(buff,"%i",En->GetEntry()->File.Info.Size);
        MMSUpWxListCtrl->SetItem(tmp, 4, buff);
    }    
}

void ViewMMSFile(GSM_File *File, wxListCtrl *List)
{
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
	GSM_Error                   error;
    long                        item,item2=0,tmp,EntryNum=0;
    wchar_t                     Buffer[200];
	char                        buff[200];
	int                         Num,Num2;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    BOOLEAN                     Found;
	
    List->DeleteAllItems();

    error = Decoded.Read(File);
    PrintError(error);
    
    tmp = List->InsertItem(EntryNum++, "ID", 0);
    List->SetItemData(tmp, 0);
    List->SetItem(tmp, 1, File->Info.GetID());
    
    SubDecoded = NULL;
    while (Decoded.GetNext(&SubDecoded)) {
        Found = false;
        switch (SubDecoded->Type) {
        case MMS_Address_Phone_Source:
            tmp = List->InsertItem(EntryNum++, "From (phone)", 0); Found = true;
            break;
    	case MMS_Address_Unknown_Source:
            tmp = List->InsertItem(EntryNum++, "From", 0); Found = true;
            break;
        case MMS_Address_Phone_Destination:
            tmp = List->InsertItem(EntryNum++, "To (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_Destination:
            tmp = List->InsertItem(EntryNum++, "To", 0); Found = true;
            break;
        case MMS_Address_Phone_CC:
            tmp = List->InsertItem(EntryNum++, "CC (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_CC:
            tmp = List->InsertItem(EntryNum++, "CC", 0); Found = true;
            break;
        case MMS_Address_Phone_BCC:
            tmp = List->InsertItem(EntryNum++, "BCC (phone)", 0); Found = true;
            break;
        case MMS_Address_Unknown_BCC:
            tmp = List->InsertItem(EntryNum++, "BCC", 0); Found = true;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            memcpy(Buffer,SubDecoded->Text.data(),(SubDecoded->Text.length()+1)*sizeof(wchar_t));
//            FindSMSNumber(Buffer);
            List->SetItem(tmp, 1, Buffer);
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_Text_TransactionID:
            tmp = List->InsertItem(EntryNum++, "Transaction ID", 0); Found = TRUE;
            break;
        case MMS_Text_Subject:
            tmp = List->InsertItem(EntryNum++, "Subject", 0); Found = TRUE;
            break;
        case MMS_Text_ContentLocation:
            tmp = List->InsertItem(EntryNum++, "Content location", 0); Found = TRUE;
            break;
        case MMS_Text_ContentType:
            tmp = List->InsertItem(EntryNum++, "Content type", 0); Found = TRUE;
            break;
        case MMS_Text_MessageType:
            tmp = List->InsertItem(EntryNum++, "Message type", 0); Found = TRUE;
            break;
        case MMS_Text_MessageID:
            tmp = List->InsertItem(EntryNum++, "Message ID", 0); Found = TRUE;
            break;
        case MMS_Text_MessageClass:
            tmp = List->InsertItem(EntryNum++, "Message class", 0); Found = TRUE;
            break;
        case MMS_Text_Priority:
            tmp = List->InsertItem(EntryNum++, "Priority", 0); Found = TRUE;
            break;
        case MMS_Text_Version:
            tmp = List->InsertItem(EntryNum++, "MMS version", 0); Found = TRUE;
            break;
        case MMS_Text_Response_Status:
            tmp = List->InsertItem(EntryNum++, "Response status", 0); Found = TRUE;
            break;
        case MMS_Text_Status:
            tmp = List->InsertItem(EntryNum++, "Status", 0); Found = TRUE;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_Bool_Report:
            tmp = List->InsertItem(EntryNum++, "Delivery report", 0); Found = TRUE;
            break;
        case MMS_Bool_Read_Reply:
            tmp = List->InsertItem(EntryNum++, "Read reply", 0); Found = TRUE;
            break;
        case MMS_Bool_Report_Allowed:
            tmp = List->InsertItem(EntryNum++, "Report allowed", 0); Found = TRUE;
            break;
        }
        if (Found) {
            List->SetItemData(tmp, 0);
            if (SubDecoded->Bool) {
                List->SetItem(tmp, 1, "yes");
            } else {
                List->SetItem(tmp, 1, "no");
            }
            continue;
        }
        switch (SubDecoded->Type) {
        case MMS_DT_DateTime:
            tmp = List->InsertItem(EntryNum++, "Sent", 0);
            List->SetItemData(tmp, 0);
            sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            SubDecoded->DT.Year,
                            SubDecoded->DT.Month,
                            SubDecoded->DT.Day),
                    SubDecoded->DT.Day,
                    SubDecoded->DT.Month,
                    SubDecoded->DT.Year,
                    SubDecoded->DT.Hour,
                    SubDecoded->DT.Minute,
                    SubDecoded->DT.Second);
            List->SetItem(tmp, 1, buff);
            break;
    	case MMS_DT_Expiry:
            tmp = List->InsertItem(EntryNum++, "Expiry", 0);
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            break;
        case MMS_File:
            tmp = List->InsertItem(EntryNum++, "File", 0);
            List->SetItemData(tmp, 0);
            tmp = List->InsertItem(EntryNum++, "  Content type", 0);
            List->SetItemData(tmp, 0);
            List->SetItem(tmp, 1, SubDecoded->Text.data());
            if (UnicodeLength(SubDecoded->File.Info.GetName())!=0) {
                tmp = List->InsertItem(EntryNum++, "  Name", 0);
                List->SetItemData(tmp, 0);
                List->SetItem(tmp, 1, SubDecoded->File.Info.GetName());
            }
            if (SubDecoded->Text2.length()!=0) {
                tmp = List->InsertItem(EntryNum++, "  SMIL CID", 0);
                List->SetItemData(tmp, 0);
                List->SetItem(tmp, 1, SubDecoded->Text2.data());
            }
            tmp = List->InsertItem(EntryNum++, "  Size", 0);
            List->SetItemData(tmp, 0);
            sprintf(buff,"%i bytes",SubDecoded->File.Info.Size);
            List->SetItem(tmp, 1, buff);
            break;
        }
    }    
}
/*
 * MMSUpWxListCtrlItemActivated
 */
void MainFrm::MMSUpWxListCtrlItemActivated(wxListEvent& event)
{
    long                        item,item2=0,tmp,EntryNum=0;
    wchar_t                     Buffer[200];
    GSM_Backup_MMSEntry         *En;
	char                        buff[200];
	int                         Num,Num2;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error;
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
    BOOLEAN Found;
    wchart Name;

    item = MMSUpWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    if (MMSWxChoice->GetSelection()!=0) {
        Num=0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=MMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (!SubFolder->MMS) continue;
            Num++;
        }
    }

    En = NULL;
    while (Backup.GetNext_MMS(&En)) {
        if (En->GetEntry()->Folder!=Num2) continue;
        item2++;
        if (item2-1!=item) continue;
            
        ViewMMSFile(&En->GetEntry()->File, MMSDetailsWxListCtrl);
        
        error = Decoded.Read(&En->GetEntry()->File);
        PrintError(error);
        
        WxChoice1->Clear();
        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type !=  MMS_File) continue;
            Name.clear();
            Name.append(SubDecoded->File.Info.GetName(),UnicodeLength(SubDecoded->File.Info.GetName()));
            Name.push_back(' ');
            Name.push_back('(');
            Name.append(SubDecoded->Text.data(),UnicodeLength((wchar_t *)SubDecoded->Text.data()));
            Name.push_back(')');
            WxChoice1->Append(Name.data());
        }
        
    }
}

/*
 * MMSDetailsWxListCtrlItemActivated
 */
void MainFrm::MMSDetailsWxListCtrlItemActivated(wxListEvent& event)
{
    long                        item,item2=0,tmp,EntryNum=0;
    wchar_t                     Buffer[200];
    GSM_Backup_MMSEntry         *En;
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
	char                        buff[200];
	int                         Num,Num2;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error;

    item = MMSUpWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    if (MMSWxChoice->GetSelection()!=0) {
        Num=0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=MMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (!SubFolder->MMS) continue;
            Num++;
        }
    }

    En = NULL;
    while (Backup.GetNext_MMS(&En)) {
        if (En->GetEntry()->Folder!=Num2) continue;
        item2++;
        if (item2-1!=item) continue;
        
        WxSaveFileDialog1->SetFilename(En->GetEntry()->File.Info.GetName());
        if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
        En->GetEntry()->File.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());        
    }    
}

/*
 * Mnuopenmmsfile1201Click
 */
void MainFrm::Mnuopenmmsfile1201Click(wxCommandEvent& event)
{
	// insert your code here
}

/*
 * Mnuopenmmsfile1201Click1
 */
void MainFrm::Mnuopenmmsfile1201Click1(wxCommandEvent& event)
{
    MMSDlg *dialog = new MMSDlg(this,-1,"MMS viewer",wxDefaultPosition,wxDefaultSize,MMSDlg_STYLE);

    dialog->ShowModal();

    dialog->Destroy();
}

/*
 * Mnuconnect1203Click
 */
void MainFrm::Mnuconnect1203Click(wxCommandEvent& event)
{
	// insert your code here
}

/*
 * WxChoice1Selected
 */
void MainFrm::WxChoice1Selected(wxCommandEvent& event )
{
    wxProgressDialog            *Dialog = NULL;
    GSM_Backup_MMSEntry         *En;
    GSM_SMSListSubEntry         *SubEntry;
    GSM_SMSEntry                *SMS;
    boolean                     wrong;
    wchar_t                     Buffer[500],Buffer2[500],Last[500],First[500];
    long                        tmp;
    int                         i = 1,j,z,num5=0;
    int                         EntryNum = 0, Num, Num2;
	int                         SequencesNum=0,PartsNum=0;
    GSM_DateTime                DT;
    GSM_SMSMMSFoldersSubEntry   *SubFolder;
    GSM_Error                   error,preverror;
    char                        buff[200];
    GSM_MMSFile                 Entry2;
    boolean                     wasmore = false;
	GSM_SMSNumbersSubEntry      *Number;
	BOOLEAN                     was = FALSE, Found, Found2;
	GSM_MMSDecodedFile          Decoded;
	GSM_MMSDecodedFileSubEntry  *SubDecoded;
	boolean                     found;
	wxImage newImage ;
	wxBitmap *newBitmap;
	long item,item2=0;

    item = MMSUpWxListCtrl->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    if (MMSWxChoice->GetSelection()!=0) {
        Num=0;
        Num2=0;
        SubFolder = NULL;
        while (Num!=MMSWxChoice->GetSelection()) {
            SMSFolders.GetNext(&SubFolder);
            Num2++;
            if (!SubFolder->MMS) continue;
            Num++;
        }
    }

    En = NULL;
    while (Backup.GetNext_MMS(&En)) {
        if (En->GetEntry()->Folder!=Num2) continue;
        item2++;
        if (item2-1!=item) continue;

        error = Decoded.Read(&En->GetEntry()->File);
        PrintError(error);

        SubDecoded = NULL;
        while (Decoded.GetNext(&SubDecoded)) {
            if (SubDecoded->Type !=  MMS_File) continue;
            num5++;
            if (num5-1!=WxChoice1->GetSelection()) continue;

            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("text/plain"))) {
                WxMemo1->Show();
                WxBitmapButton1->Hide();
                WxMemo1->Clear();
                WxMemo1->AppendText(SubDecoded->File.Buffer.data());
                break;
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("application/smil"))) {
                WxMemo1->Show();
                WxBitmapButton1->Hide();
                WxMemo1->Clear();
                WxMemo1->AppendText(SubDecoded->File.Buffer.data());
                break;
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/jpeg"))) {
                WxMemo1->Hide();
                WxBitmapButton1->Show();
                wxInitAllImageHandlers();
                SubDecoded->File.SaveToDisk("tmpbitmap");
                newImage.LoadFile("tmpbitmap",wxBITMAP_TYPE_JPEG);
                newBitmap = new wxBitmap(newImage);
                WxBitmapButton1->SetBitmapLabel(*newBitmap);
                delete(newBitmap);                
            }
            if (!wcscmp(SubDecoded->Text.data(),StringToUnicodeReturn("image/gif"))) {
                WxMemo1->Hide();
                WxBitmapButton1->Show();                
                wxInitAllImageHandlers();
                SubDecoded->File.SaveToDisk("tmpbitmap");
                newImage.LoadFile("tmpbitmap",wxBITMAP_TYPE_GIF);
                newBitmap = new wxBitmap(newImage);
                WxBitmapButton1->SetBitmapLabel(*newBitmap);
                delete(newBitmap);
            }
        }
    }
}
