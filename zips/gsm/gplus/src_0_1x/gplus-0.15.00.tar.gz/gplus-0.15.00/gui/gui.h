//---------------------------------------------------------------------------
//
// Name:        gui.h
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __MainApp_h__
#define __MainApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class MainApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
