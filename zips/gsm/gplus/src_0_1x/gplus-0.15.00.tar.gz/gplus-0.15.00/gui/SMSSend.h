//---------------------------------------------------------------------------
//
// Name:        SMSSend.h
// Author:      Marcinello
// Created:     2006-12-16 11:27:22
// Description: SMSSend class declaration
//
//---------------------------------------------------------------------------

#ifndef __SMSSEND_h__
#define __SMSSEND_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
#include <wx/statline.h>
#include <wx/textctrl.h>
#include <wx/listbox.h>
#include <wx/combobox.h>
#include <wx/button.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef SMSSend_STYLE
#define SMSSend_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class SMSSend : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		SMSSend(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("SMSSend"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = SMSSend_STYLE);
		virtual ~SMSSend();
	
	private:
		//Do not add custom control declarations
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxButton *WxButton5;
		wxButton *WxButton4;
		wxStaticLine *WxStaticLine1;
		wxListBox *WxListBox3;
		wxListBox *WxListBox2;
		wxTextCtrl *WxEdit1;
		wxButton *WxButton3;
		wxListBox *WxListBox1;
		wxComboBox *WxComboBox1;
		wxButton *WxButton2;
		wxButton *WxButton1;
		wxStaticBox *WxStaticBox2;
		wxStaticBox *WxStaticBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXBUTTON5 = 1013,
			ID_WXBUTTON4 = 1012,
			ID_WXSTATICLINE1 = 1011,
			ID_WXLISTBOX3 = 1010,
			ID_WXLISTBOX2 = 1009,
			ID_WXEDIT1 = 1008,
			ID_WXBUTTON3 = 1007,
			ID_WXLISTBOX1 = 1006,
			ID_WXCOMBOBOX1 = 1005,
			ID_WXBUTTON2 = 1004,
			ID_WXBUTTON1 = 1003,
			ID_WXSTATICBOX2 = 1002,
			ID_WXSTATICBOX1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
};

#endif
