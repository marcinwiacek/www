//---------------------------------------------------------------------------
//
// Name:        GUI.cpp
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: 
//
//---------------------------------------------------------------------------

#include "GUI.h"
#include "MainFrm.h"

IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
    MainFrm* frame = new MainFrm(NULL);
    SetTopWindow(frame);
    setlocale( LC_ALL, "" );
    frame->Show();
    
    return true;
}
 
int MainApp::OnExit()
{
	return 0;
}
