//---------------------------------------------------------------------------
//
// Name:        Config.h
// Author:      Marcinello
// Created:     2006-12-13 11:32:31
// Description: Config class declaration
//
//---------------------------------------------------------------------------

#ifndef __CONFIG_h__
#define __CONFIG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
#include <wx/stattext.h>
#include <wx/choice.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef Config_STYLE
#define Config_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class Config : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		Config(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Config"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = Config_STYLE);
		virtual ~Config();
		void WxStaticText1Selected(void);
	
	private:
		//Do not add custom control declarations
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxStaticText *WxStaticText1;
		wxChoice *WxChoice1;
		wxRadioBox *WxRadioBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXSTATICTEXT1 = 1010,
			ID_WXCHOICE1 = 1009,
			ID_WXRADIOBOX1 = 1006,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
};

#endif
