//---------------------------------------------------------------------------
//
// Name:        MainFrm.cpp
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: MainFrm class implementation
//
//---------------------------------------------------------------------------

#include "MainFrm.h"
#include "AboutDlg.h"
#include "CfgDlg.h"

#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

FILE                      *DebFile;
bool                      UseDeb;
GSM_StateMachine          *s;
INI_File                  CFG;
wchart                    StatusStr[7];
wchart                    StatusStr2[7];

wchar_t                   FileFolderID[500], FileFolderID0[500];
wchart                    ParentFolderID[20];
int                       ParentFolderIDNum = 1;
wchart                    CurrentFolderName, CurrentFolderName0;
int                       FileSystemNum = 0;
GSM_FileFolderInfoList    List;

GSM_Backup                Backup;
int                       PhonePBK = 7;
bool                      SortPBKReverse = false;
int                       SortPBK = 0;

//----------------------------------------------------------------------------
// MainFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(MainFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(MainFrm::OnClose)
	EVT_MENU(ID_MNU_MENUITEM1_1020 , MainFrm::Mnumenuitem11020Click)
	EVT_MENU(ID_MNU_DELETE_1023 , MainFrm::Mnudelete1023Click)
	EVT_MENU(ID_MNU_ADDFOLDER_1022 , MainFrm::Mnuaddfolder1022Click)
	EVT_MENU(ID_MNU_ADDFILE_1027 , MainFrm::Mnuaddfile1027Click)
	EVT_MENU(ID_MNU_RENAME_1024 , MainFrm::Mnurename1024Click)
	EVT_MENU(ID_MNU_PROPERTIES_1026 , MainFrm::Mnuproperties1026Click)
	EVT_MENU(ID_MNU_FORWARD_1148 , MainFrm::Mnuforward1148Click)
	EVT_MENU(ID_MNU_EXIT_1017, MainFrm::Mnuexit1017Click1)
	EVT_MENU(ID_MNU_CONFIGURATION_1147, MainFrm::Mnuconfiguration1147Click)
	EVT_MENU(ID_MNU_ABOUT_1019, MainFrm::Mnuabout1019Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL6,MainFrm::WxListCtrl6ItemActivated)
	EVT_CHECKBOX(ID_WXCHECKBOX1,MainFrm::WxCheckBox1Click)
	
	EVT_CALENDAR_SEL_CHANGED(ID_WXCALENDARCTRL1,MainFrm::WxCalendarCtrl1SelChanged)
	EVT_BUTTON(ID_WXBUTTON2,MainFrm::WxButton2Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL4,MainFrm::WxListCtrl4ItemActivated)
	EVT_LIST_ITEM_RIGHT_CLICK(ID_WXLISTCTRL4,MainFrm::WxListCtrl4RightClick)
	EVT_CHOICE(ID_WXCHOICE1,MainFrm::WxChoice1Selected)
	EVT_BUTTON(ID_WXBUTTON3,MainFrm::WxButton3Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL2,MainFrm::WxListCtrl2ItemActivated)
	EVT_LIST_COL_CLICK(ID_WXLISTCTRL2,MainFrm::WxListCtrl2ColLeftClick)
	EVT_BUTTON(ID_WXBUTTON1,MainFrm::WxButton1Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL1,MainFrm::WxListCtrl1ItemActivated)
	EVT_LIST_ITEM_RIGHT_CLICK(ID_WXLISTCTRL1,MainFrm::WxListCtrl1RightClick)
	
	EVT_NOTEBOOK_PAGE_CHANGED(ID_WXNOTEBOOK1,MainFrm::wxNotebook1PageChanged)
END_EVENT_TABLE()
////Event Table End

boolean PrintError (GSM_Error error)
{
    unsigned char buffer[2000];

    if (error.Code == GSM_ERR_NONE) return false;
    sprintf((char *)buffer,"%s",GSM_GetErrorInfo(error));
    wxMessageBox(buffer,
            wxT("Error"),
            wxICON_WARNING | wxOK);
            return true;
}

MainFrm::MainFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
    GSM_Error error;

    CreateGUIControls();

    DebFile = NULL;
    UseDeb = false;
    s = new GSM_StateMachine(DebFile,"",UseDeb);
    s->ReadCfgFile(&CFG);

    error = s->OpenFromCfgFile(&CFG);
    if (PrintError(error)) exit(0);
    EnterFolder();      
}

MainFrm::~MainFrm()
{
}

void MainFrm::CreateGUIControls()
{
    //Do not add custom code here
    //wxDev-C++ designer will remove them.
    //Add the custom code before or after the blocks
    ////GUI Items Creation Start

	WxStatusBar1 = new wxStatusBar(this, ID_WXSTATUSBAR1);

	WxGridSizer1 = new wxGridSizer(1, 1, 0, 0);
	this->SetSizer(WxGridSizer1);
	this->SetAutoLayout(true);

	wxNotebook1 = new wxNotebook(this, ID_WXNOTEBOOK1, wxPoint(0,0),wxSize(568,470));
	WxGridSizer1->Add(wxNotebook1,1,wxEXPAND | 0,0);

	WxNoteBookPage2 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE2, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage2, wxT("FileSystem and Java"));

	WxBoxSizer1 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage2->SetSizer(WxBoxSizer1);
	WxNoteBookPage2->SetAutoLayout(true);

	WxPanel3 = new wxPanel(WxNoteBookPage2, ID_WXPANEL3, wxPoint(14,5), wxSize(564,25));
	WxBoxSizer1->Add(WxPanel3,0,wxALIGN_TOP | wxALL,5);

	WxListCtrl1 = new wxListCtrl(WxNoteBookPage2, ID_WXLISTCTRL1, wxPoint(5,40), wxSize(583,311), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Attribs"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Modified"),wxLIST_FORMAT_LEFT,170 );
	WxListCtrl1->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Size"),wxLIST_FORMAT_LEFT,80 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,170 );
	WxBoxSizer1->Add(WxListCtrl1,1,wxEXPAND | wxALL,5);

	WxNoteBookPage1 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE1, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage1, wxT("Contacts and logs"));

	WxBoxSizer2 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage1->SetSizer(WxBoxSizer2);
	WxNoteBookPage1->SetAutoLayout(true);

	WxPanel1 = new wxPanel(WxNoteBookPage1, ID_WXPANEL1, wxPoint(0,0), wxSize(533,31));
	WxBoxSizer2->Add(WxPanel1,0,wxALIGN_TOP | 0,0);

	WxButton1 = new wxButton(WxPanel1, ID_WXBUTTON1, wxT("Get from phone"), wxPoint(8,5), wxSize(86,20), 0, wxDefaultValidator, wxT("WxButton1"));

	WxGridSizer2 = new wxGridSizer(1, 1, 0, 0);
	WxBoxSizer2->Add(WxGridSizer2, 1, wxEXPAND | 0, 0);

	WxListCtrl2 = new wxListCtrl(WxNoteBookPage1, ID_WXLISTCTRL2, wxPoint(11,6), wxSize(149,159), wxLC_REPORT);
	WxListCtrl2->InsertColumn(0,wxT("Time"),wxLIST_FORMAT_LEFT,400 );
	WxListCtrl2->InsertColumn(0,wxT("Default number"),wxLIST_FORMAT_LEFT,140 );
	WxListCtrl2->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,250 );
	WxListCtrl2->InsertColumn(0,wxT("Location"),wxLIST_FORMAT_LEFT,50 );
	WxGridSizer2->Add(WxListCtrl2,1,wxEXPAND | wxALL,5);

	WxListCtrl3 = new wxListCtrl(WxNoteBookPage1, ID_WXLISTCTRL3, wxPoint(5,177), wxSize(162,162), wxLC_REPORT);
	WxListCtrl3->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,400 );
	WxListCtrl3->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,100 );
	WxGridSizer2->Add(WxListCtrl3,1,wxEXPAND | wxALL,5);

	WxNoteBookPage3 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE3, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage3, wxT("SMS"));

	WxBoxSizer3 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage3->SetSizer(WxBoxSizer3);
	WxNoteBookPage3->SetAutoLayout(true);

	WxPanel2 = new wxPanel(WxNoteBookPage3, ID_WXPANEL2, wxPoint(5,5), wxSize(523,36));
	WxBoxSizer3->Add(WxPanel2,0,wxALIGN_TOP | wxALL,5);

	WxButton3 = new wxButton(WxPanel2, ID_WXBUTTON3, wxT("Get from phone"), wxPoint(167,8), wxSize(86,22), 0, wxDefaultValidator, wxT("WxButton3"));

	WxButton4 = new wxButton(WxPanel2, ID_WXBUTTON4, wxT("Send"), wxPoint(259,8), wxSize(86,22), 0, wxDefaultValidator, wxT("WxButton4"));

	wxArrayString arrayStringFor_WxChoice1;
	WxChoice1 = new wxChoice(WxPanel2, ID_WXCHOICE1, wxPoint(7,9), wxSize(152,21), arrayStringFor_WxChoice1, 0, wxDefaultValidator, wxT("WxChoice1"));
	WxChoice1->SetSelection(-1);

	WxGridSizer3 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer3->Add(WxGridSizer3, 1, wxEXPAND | wxALL, 5);

	WxListCtrl4 = new wxListCtrl(WxNoteBookPage3, ID_WXLISTCTRL4, wxPoint(5,6), wxSize(174,172), wxLC_REPORT);
	WxListCtrl4->InsertColumn(0,wxT("Parts"),wxLIST_FORMAT_LEFT,50 );
	WxListCtrl4->InsertColumn(0,wxT("Text"),wxLIST_FORMAT_LEFT,100 );
	WxListCtrl4->InsertColumn(0,wxT("Sender"),wxLIST_FORMAT_LEFT,200 );
	WxListCtrl4->InsertColumn(0,wxT("Sent"),wxLIST_FORMAT_LEFT,140 );
	WxGridSizer3->Add(WxListCtrl4,1,wxEXPAND | wxALL,5);

	WxNotebook2 = new wxNotebook(WxNoteBookPage3, ID_WXNOTEBOOK2, wxPoint(6,189),wxSize(172,174));
	WxGridSizer3->Add(WxNotebook2,1,wxEXPAND | wxALL,5);

	WxNoteBookPage4 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE4, wxPoint(4,24), wxSize(164,146));
	WxNotebook2->AddPage(WxNoteBookPage4, wxT("SMS parts"));

	WxBoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
	WxNoteBookPage4->SetSizer(WxBoxSizer4);
	WxNoteBookPage4->SetAutoLayout(true);

	WxListCtrl5 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL5, wxPoint(5,5), wxSize(150,135), wxLC_REPORT);
	WxListCtrl5->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,300 );
	WxListCtrl5->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	WxBoxSizer4->Add(WxListCtrl5,1,wxEXPAND | wxALL,5);

	WxNoteBookPage5 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE5, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage5, wxT("Calendar"));

	WxBoxSizer5 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage5->SetSizer(WxBoxSizer5);
	WxNoteBookPage5->SetAutoLayout(true);

	WxPanel4 = new wxPanel(WxNoteBookPage5, ID_WXPANEL4, wxPoint(5,5), wxSize(545,28));
	WxBoxSizer5->Add(WxPanel4,0,wxALIGN_TOP | wxALL,5);

	WxButton2 = new wxButton(WxPanel4, ID_WXBUTTON2, wxT("Get from phone"), wxPoint(7,3), wxSize(91,22), 0, wxDefaultValidator, wxT("WxButton2"));

	WxBoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
	WxBoxSizer5->Add(WxBoxSizer6, 1, wxEXPAND | wxALL, 5);

	WxPanel5 = new wxPanel(WxNoteBookPage5, ID_WXPANEL5, wxPoint(5,15), wxSize(183,202));
	WxBoxSizer6->Add(WxPanel5,0,wxALIGN_LEFT | wxALL,5);

	WxCalendarCtrl1 = new wxCalendarCtrl(WxPanel5, ID_WXCALENDARCTRL1, wxDateTime(6,(wxDateTime::Month)12,2006),wxPoint(5,2), wxSize(172,147), wxCAL_SUNDAY_FIRST | wxCAL_SHOW_HOLIDAYS | wxCAL_NO_MONTH_CHANGE | wxCAL_SHOW_SURROUNDING_WEEKS | wxCAL_SEQUENTIAL_MONTH_SELECTION);

	WxCheckBox1 = new wxCheckBox(WxPanel5, ID_WXCHECKBOX1, wxT("Show all events"), wxPoint(7,157), wxSize(160,21), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxGridSizer4 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer6->Add(WxGridSizer4, 1, wxEXPAND | wxALL, 5);

	WxListCtrl6 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL6, wxPoint(7,5), wxSize(146,101), wxLC_REPORT);
	WxListCtrl6->InsertColumn(0,wxT("Text"),wxLIST_FORMAT_LEFT,150 );
	WxListCtrl6->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,100 );
	WxListCtrl6->InsertColumn(0,wxT("Date"),wxLIST_FORMAT_LEFT,140 );
	WxGridSizer4->Add(WxListCtrl6,1,wxEXPAND | wxALL,5);

	WxListCtrl7 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL7, wxPoint(5,118), wxSize(150,97), wxLC_REPORT);
	WxListCtrl7->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,200 );
	WxListCtrl7->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,150 );
	WxGridSizer4->Add(WxListCtrl7,1,wxEXPAND | wxALL,5);

	WxNoteBookPage6 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE6, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage6, wxT("ToDo"));

	WxNoteBookPage7 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE7, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage7, wxT("Notes"));

	WxNoteBookPage8 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE8, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage8, wxT("MMS"));

	WxMenuBar1 = new wxMenuBar();
	wxMenu *ID_MNU_MENUITEM1_1016_Mnu_Obj = new wxMenu(0);
	ID_MNU_MENUITEM1_1016_Mnu_Obj->Append(ID_MNU_EXIT_1017, wxT("&Exit"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_MENUITEM1_1016_Mnu_Obj, wxT("&File"));
	
	wxMenu *ID_MNU_TOOLS_1146_Mnu_Obj = new wxMenu(0);
	ID_MNU_TOOLS_1146_Mnu_Obj->Append(ID_MNU_CONFIGURATION_1147, wxT("Configuration"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_TOOLS_1146_Mnu_Obj, wxT("Tools"));
	
	wxMenu *ID_MNU_HELP_1018_Mnu_Obj = new wxMenu(0);
	ID_MNU_HELP_1018_Mnu_Obj->Append(ID_MNU_ABOUT_1019, wxT("&About"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_HELP_1018_Mnu_Obj, wxT("&Help"));
	SetMenuBar(WxMenuBar1);

	WxSaveFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxSAVE);

	WxOpenFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxOPEN);

	WxPopupMenu2 = new wxMenu(wxT(""));WxPopupMenu2->Append(ID_MNU_FORWARD_1148, wxT("Forward"), wxT(""), wxITEM_NORMAL);

	WxDirDialog1 =  new wxDirDialog(this, wxT("Choose a directory"), wxT(""));

	WxPopupMenu1 = new wxMenu(wxT(""));WxPopupMenu1->Append(ID_MNU_MENUITEM1_1020, wxT("Read selected"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_DELETE_1023, wxT("Delete selected"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_ADDFOLDER_1022, wxT("Add folder to current dir"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_ADDFILE_1027, wxT("Add file to current dir"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_RENAME_1024, wxT("Rename"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_PROPERTIES_1026, wxT("Properties"), wxT(""), wxITEM_NORMAL);

	SetStatusBar(WxStatusBar1);
	SetTitle(wxT("Gammu+ GUI"));
	SetIcon(wxNullIcon);
	
	GetSizer()->Fit(this);
	GetSizer()->SetSizeHints(this);
	Center();
	
    ////GUI Items Creation End
}

void MainFrm::OnClose(wxCloseEvent& event)
{
    Destroy();
}

/*
 * Mnuexit1017Click1
 */
void MainFrm::Mnuexit1017Click1(wxCommandEvent& event)
{
    Close();
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
    switch (DayOfWeek(Year,Month,Day)) {
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
        case 7: return "Sun";
        default:return "";
    }
}

void MainFrm::EnterFolder()
{
    wchart                            x;
    wxProgressDialog                  *Dialog;
    bool                              skip;
    BOOLEAN                           Start2;
    wchar_t                           name[20];
    char                              buff[200];
    GSM_MemoryType                    Mem;
    unsignedstring                    Buffer2;
    BOOLEAN                           Found;
    GSM_Error                         error;
    GSM_FileFolderInfo                FInfo,*FInfo2;
    GSM_FileFolderInfoListSubEntry    *SubEntry;
    int                               j = 0,i;
    long                              tmp;

    Dialog = new wxProgressDialog("Reading folder", CurrentFolderName.data(), 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
    if (ParentFolderIDNum == 1) {
        error.Code = GSM_ERR_MEMORY;
    } else {
        List.Info.SetID(FileFolderID);
        Start2 = TRUE;
        while (1) {
            error = s->Phones->Current->GetFolderInfoList(&List,Start2);
            if (error.Code == GSM_ERR_MEMORY) {
                wxMessageBox("Folder not available",
                        wxT("Error"),
                        wxICON_WARNING | wxOK);
                        
                for (i=CurrentFolderName.length(); i > 0; i--) {
                        if (CurrentFolderName.data()[i]=='\\') break;
                }
                x.append(CurrentFolderName.data(),i);
                CurrentFolderName.clear();
                CurrentFolderName.append(x.data());

                ParentFolderID[ParentFolderIDNum-1].clear();
                ParentFolderIDNum--;
                                        
                CopyUnicode(FileFolderID0,FileFolderID);
                break;
            }
            if (Start2) {
                WxListCtrl1->DeleteAllItems();
                FileSystemNum = 0;
    
                StatusStr[0].clear();
                StatusStr[0].append(CurrentFolderName.data());
                WxStatusBar1->SetStatusText(StatusStr[0].data(),0);
    
                tmp = WxListCtrl1->InsertItem(FileSystemNum++, _T(".."), 0);
                WxListCtrl1->SetItemData(tmp, 0);
                WxListCtrl1->SetItem(tmp, 1, _T(""));
                WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
                WxListCtrl1->SetItem(tmp, 3, _T(""));
                WxListCtrl1->SetItem(tmp, 4, _T(""));
            }
            Start2 = FALSE;
            if (error.Code == GSM_ERR_FOLDER_MORE) {
                if (!Dialog->UpdatePulse("",&skip)) break;
                continue;
            }
            if (error.Code == GSM_ERR_FOLDER_PART) {
                wxMessageBox("There was read only folder part (it's phone firmware problem)",
                    wxT("Error"),
                    wxICON_WARNING | wxOK);
                break;
            }
            if (error.Code == GSM_ERR_EMPTY) {
                    break;
            }
            if (error.Code != GSM_ERR_NONE) {
                    break;
            }
            break;
        }
    }
    delete Dialog;

    if (error.Code == GSM_ERR_MEMORY) {
        WxListCtrl1->DeleteAllItems();
        FileSystemNum = 0;

        StatusStr[0].clear();
        StatusStr[0].append(CurrentFolderName.data());
        WxStatusBar1->SetStatusText(StatusStr[0].data(),0);

        name[0] = 0;
        List.ClearAll();
        while (true) {
            error = s->Phones->Current->GetNextRootFolderID(name,&Mem);
            if (error.Code == GSM_ERR_EMPTY) break;
            if (error.Code != GSM_ERR_MEMORY && error.Code != GSM_ERR_NONE) return;

            FInfo2 = new GSM_FileFolderInfo;
            if (Mem == MEM_PHONE) {
                    sprintf(buff,"Phone memory (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
            } else {
                    sprintf(buff,"Memory card (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
            }
            tmp = WxListCtrl1->InsertItem(FileSystemNum++, buff, 0);
            FInfo2->SetName(StringToUnicodeReturn(buff));
            WxListCtrl1->SetItemData(tmp, 0);
            WxListCtrl1->SetItem(tmp, 1, _T(""));
            FInfo2->Folder = TRUE;
            WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
            WxListCtrl1->SetItem(tmp, 3, _T(""));
            WxListCtrl1->SetItem(tmp, 4, _T(""));

            FInfo2->SetID(name);
            List.AddSubEntry(FInfo2);
        }
        return;
    }
        
    SubEntry = NULL;
    while (List.GetNext(&SubEntry) == TRUE) {
        if (!List.SubEntryFullData) {
            error = s->Phones->Current->GetFileFolderInfo(&SubEntry->Info);
        }

        sprintf(buff,"%s",UnicodeToStringReturn(SubEntry->Info.GetName()));
        tmp = WxListCtrl1->InsertItem(FileSystemNum++, buff, 0);
        if (SubEntry->Info.Folder) {
            WxListCtrl1->SetItem(tmp, 1, _T(""));
            WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
        } else {
            sprintf(buff, "%i",SubEntry->Info.Size);
            WxListCtrl1->SetItem(tmp, 1, buff);
            WxListCtrl1->SetItem(tmp, 2, _T("File"));
        }
        if (SubEntry->Info.ModificationDateTimeAvailable) {
            sprintf(buff, "%s %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            SubEntry->Info.ModificationDateTime.Year,
                            SubEntry->Info.ModificationDateTime.Month,
                            SubEntry->Info.ModificationDateTime.Day),
                    SubEntry->Info.ModificationDateTime.Day,
                    SubEntry->Info.ModificationDateTime.Month,
                    SubEntry->Info.ModificationDateTime.Year,                                       
                    SubEntry->Info.ModificationDateTime.Hour,
                    SubEntry->Info.ModificationDateTime.Minute,
                    SubEntry->Info.ModificationDateTime.Second);
        } else {
            sprintf(buff, "");
        }
        WxListCtrl1->SetItem(tmp, 3, buff);
        
        sprintf(buff,"    ");   
        if (SubEntry->Info.DRMForwardLock) buff[0] = 'P';
        if (SubEntry->Info.ReadOnly) buff[1] = 'R';
        if (SubEntry->Info.Hidden) buff[2] = 'H';
        if (SubEntry->Info.System) buff[3] = 'S';
        WxListCtrl1->SetItem(tmp, 4, buff);
    }
}

/*
 * WxListCtrl1ItemActivated
 */
void MainFrm::WxListCtrl1ItemActivated(wxListEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
    GSM_File                        ReadSaveFile;
    GSM_FileFolderInfoListSubEntry  *SubEntry;
    int                             i;
    wchart                          x;
    long                            item;

    item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    if (WxListCtrl1->GetItemText(item)== "..") {
        for (i=CurrentFolderName.length(); i > 0; i--) {
                if (CurrentFolderName.data()[i]=='\\') break;
        }
        x.append(CurrentFolderName.data(),i);
        CurrentFolderName.clear();
        CurrentFolderName.append(x.data());

        ParentFolderID[ParentFolderIDNum-1].clear();
        ParentFolderIDNum--;
        CopyUnicode((wchar_t *)ParentFolderID[ParentFolderIDNum-1].data(),FileFolderID);
        EnterFolder();
        return;
    }
    if (WxListCtrl1->GetItemText(0)== "..") item--;    
    SubEntry = NULL;
    for (i=0;i<=item;i++) List.GetNext(&SubEntry);
    CopyUnicode(FileFolderID,FileFolderID0);
    CopyUnicode(SubEntry->Info.GetID(),FileFolderID);
    if (SubEntry->Info.Folder) {
        CurrentFolderName.push_back('\\');
        CurrentFolderName.append(SubEntry->Info.GetName());
        ParentFolderID[ParentFolderIDNum].append(FileFolderID);
        ParentFolderIDNum++;

        EnterFolder();
        return;
    }

    Dialog = new wxProgressDialog("Reading file", SubEntry->Info.GetName(), 100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
    ReadSaveFile.Info.SetID(FileFolderID);
    while(true) {
        error = s->Phones->Current->GetFilePart(&ReadSaveFile);
        if (error.Code!=GSM_ERR_NONE) {
              PrintError(error);
        }

        if (!Dialog->Update((int)ReadSaveFile.Buffer.size()*100/ReadSaveFile.Info.Size,"",&skip)) break;
        if (ReadSaveFile.Info.Size == ReadSaveFile.Buffer.size()) break;
    }               
    delete Dialog;
    WxSaveFileDialog1->SetFilename(SubEntry->Info.GetName());
    if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
    ReadSaveFile.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
}          

/*
 * WxListCtrl1RightClick
 */
void MainFrm::WxListCtrl1RightClick(wxListEvent& event)
{
    PopupMenu(WxPopupMenu1, wxDefaultPosition);
}

int wxCALLBACK WxListCtrl2CompareFunction(long item1, long item2, long sortData)
{
    GSM_Backup_PBKEntry *PBKEntry, *PBKEntry2;
    GSM_PBKSubEntry     *SubEntry, *SubEntry2;
    int                 Num, retval,i;
    time_t              One,Two;
    bool                found;

    if (sortData == 2) return 0; //number
    if (sortData == 3 && PhonePBK < 3) return 0; //date when no date available
    if (sortData == 0) { //location
        StatusStr2[1].clear();
        StatusStr2[1].append(StringToUnicodeReturn(" sorted by location"));
        retval = 0;
        if (item1 < item2) retval = -1;
        if (item1 > item2) retval = 1;
        if (SortPBKReverse) {
            retval = (-1)*retval;
            StatusStr2[1].append(StringToUnicodeReturn(" (reverse)"));
        }
        return retval;
    }
    if (sortData == 1) { //name
        PBKEntry = NULL;
        Num = 0;
        while (true) {
            Backup.GetNext_ME_PBK(&PBKEntry);
            if (PhonePBK < 3) {
                if (PBKEntry->GetEntry()->Location==item1) break;
            } else {
                SubEntry = NULL;
                while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
                    if (SubEntry->GetType() == PBK_DateTime_Call_Length) Num++;
                    if (Num == item1) break;
                }
                if (Num == item1) break;
            }
        }
        SubEntry = NULL;
        found = false;
        while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
            if (SubEntry->GetType() == PBK_Text_Name) {
                found = true;
                break;
            }
        }
        if (!found) {
            SubEntry = NULL;
            while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    found = true;
                    break;
                }
                if (found) break;
            }
            if (!found) return -1;            
        }    
        Num = 0;
        PBKEntry2 = NULL;
        while (true) {
            Backup.GetNext_ME_PBK(&PBKEntry2);
            if (PhonePBK < 3) {
                if (PBKEntry2->GetEntry()->Location==item2) break;
            } else {
                SubEntry2 = NULL;
                while (PBKEntry2->GetEntry()->GetNext(&SubEntry2)) {
                    if (SubEntry2->GetType() == PBK_DateTime_Call_Length) Num++;
                    if (Num == item2) break;
                }
                if (Num == item2) break;
            }
        }
        SubEntry2 = NULL;
        found = false;
        while (PBKEntry2->GetEntry()->GetNext(&SubEntry2)) {
            if (SubEntry2->GetType() == PBK_Text_Name) {
                found = true;
                break;
            }
        }
        if (!found) {
            SubEntry2 = NULL;
            while (PBKEntry2->GetEntry()->GetNext(&SubEntry2)) {
                switch (SubEntry2->GetType()) {
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    found = true;
                    break;
                }
                if (found) break;
            }
            if (!found) return 1;
        }

        retval = wcscoll(SubEntry->GetText(),SubEntry2->GetText());
        if (retval == 0) {
            retval = -1;
            if (item1 > item2) retval = 1;
        }
        StatusStr2[1].clear();
        StatusStr2[1].append(StringToUnicodeReturn(" sorted by name, number, location"));
        if (SortPBKReverse) {
            retval = (-1) * retval;
            StatusStr2[1].append(StringToUnicodeReturn(" (reverse)"));            
        }
        return retval;
    }
    //date & time
    PBKEntry2 = NULL;
    Num = 0;
    while (true) {
        Backup.GetNext_ME_PBK(&PBKEntry2);
        SubEntry2 = NULL;
        while (PBKEntry2->GetEntry()->GetNext(&SubEntry2)) {
            if (SubEntry2->GetType() == PBK_DateTime_Call_Length) Num++;
            if (Num == item2) break;
        }
        if (Num == item2) break;
    }
    PBKEntry = NULL;
    Num = 0;
    while (true) {
        Backup.GetNext_ME_PBK(&PBKEntry);
        SubEntry = NULL;
        while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
            if (SubEntry->GetType() == PBK_DateTime_Call_Length) Num++;
            if (Num == item1) break;
        }
        if (Num == item1) break;
    }
    One = GSMDateTime2TimeT(SubEntry->GetDateTime());
    Two = GSMDateTime2TimeT(SubEntry2->GetDateTime());
    retval = 0;
    if (One>Two) retval = 1;
    if (One<Two) retval = -1;
    StatusStr2[1].clear();
    StatusStr2[1].append(StringToUnicodeReturn(" sorted by time"));
    if (SortPBKReverse) {
        retval = (-1)*retval;
        StatusStr2[1].append(StringToUnicodeReturn(" (reverse)"));
    }
    return retval;
}

void MainFrm::ReadPhonebook(int Num, wxString Name)
{
    GSM_PBKEntry        *Entry,*Entry2;
    boolean             newe = true,newe2;
    GSM_PBKStatus       Status;
    GSM_Error           error;
    int                 i=0,Pos=1,Pass=0;
    int                 PbkNum = 0, Num2 = 1;    
    wxProgressDialog    *Dialog;
    bool                skip;
    long                tmp;
    wchar_t             buff[40],buff2[40];
    char                buff3[100];
    char                buff0[40];
    GSM_PBKSubEntry     *SubEntry;
    wxArrayString       choices;
    long                ReceivedSec=-1,DialledSec=-1;
    time_t              DT1;
    GSM_DateTime        DT2;

    StatusStr[1].clear();
    StatusStr[1].append(StringToUnicodeReturn("All "));    
    StatusStr[1].append(StringToUnicodeReturn((char *)Name.c_str()));

    WxListCtrl2->DeleteAllItems();
    WxListCtrl3->DeleteAllItems();
    PbkNum = 0;
    Backup.Delete_ME_PBK();
    PhonePBK = Num;
    SortPBKReverse = false;
    
    switch (Num) {
    case 0:
    case 1:
    case 2:
        if (Num==0) Status.Memory=MEM_PHONE;
        if (Num==1) Status.Memory=MEM_SIM;
        if (Num==2) Status.Memory=MEM_SIM_OWN;
        error = s->Phones->Current->GetPBKStatus(&Status);
        Dialog = new wxProgressDialog("Reading "+Name,"" , Status.Used, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
        while (i!=Status.Used) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            }
            Entry->Location= Pos;
            Entry->Memory = Status.Memory;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            newe = true;
            i++;
            Dialog->Update((int)i,"",&skip);
            Backup.Add_ME_PBK(Entry);

            sprintf(buff0,"%i",Pos-1);
            tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
            WxListCtrl2->SetItemData(tmp, Pos-1);
            buff[0] = 0;
            buff3[0] = 0;
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Name:
                    CopyUnicode(SubEntry->GetText(),buff);
                    break;
                case PBK_Text_Phone_General:
                    sprintf(buff3,"%s",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Mobile:
                    sprintf(buff3,"%s (mobile)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Home:
                    sprintf(buff3,"%s (home)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Work:
                    sprintf(buff3,"%s (work)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                case PBK_Text_Phone_Fax:
                    sprintf(buff3,"%s (fax)",UnicodeToStringReturn(SubEntry->GetText()));
                    break;
                default:
                    break;
                }
                if (buff3[0] != 0) break;
            }
            WxListCtrl2->SetItem(tmp, 1, buff);
            WxListCtrl2->SetItem(tmp, 2, buff3);
            WxListCtrl2->SetItem(tmp, 3, "");
        }
        delete Dialog;
        sprintf(buff3," (%i entries)",PbkNum);
        StatusStr[1].append(StringToUnicodeReturn(buff3));
        WxListCtrl2->SortItems(WxListCtrl2CompareFunction,1);
        break;
    case 3:
    case 4:
    case 5:
    case 7:
        Dialog = new wxProgressDialog("Reading "+Name, "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
        error.Code = GSM_ERR_NONE;
        while (error.Code != GSM_ERR_EMPTY) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            } else {
                Entry->ClearAll();
            }
            Entry->Location= Pos;
            if (Num==3) Entry->Memory=MEM_PHONE_DIALLED;
            if (Num==4) Entry->Memory=MEM_PHONE_RECEIVED;
            if (Num==5) Entry->Memory=MEM_PHONE_MISSED;
            if (Num==7) Entry->Memory=MEM_PHONE_SMS_LOGS;
            error = s->Phones->Current->GetPBK(Entry);
            Pos++;
            if (error.Code != GSM_ERR_NONE) continue;
            Dialog->UpdatePulse("",&skip);
            buff[0] = 0;
            buff2[0] = 0;
            buff3[0] = 0;
            SubEntry = NULL;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_Text_Name:
                    CopyUnicode(SubEntry->GetText(),buff);
                    break;
                case PBK_Text_Phone_General:
                case PBK_Text_Phone_Mobile:
                case PBK_Text_Phone_Home:
                case PBK_Text_Phone_Work:
                case PBK_Text_Phone_Fax:
                    CopyUnicode(SubEntry->GetText(),buff2);
                    break;
                default:
                    break;
                }
            }
            SubEntry = NULL;
            newe2 = true;
            while (Entry->GetNext(&SubEntry) == TRUE) {
                switch (SubEntry->GetType()) {
                case PBK_DateTime_Call_Length:
                    sprintf(buff3,"%s %02i-%02i-%04i %02i:%02i:%02i",
                                    DayOfWeekStr(
                                            SubEntry->GetDateTime()->Year,
                                            SubEntry->GetDateTime()->Month,
                                            SubEntry->GetDateTime()->Day),
                            SubEntry->GetDateTime()->Day,
                            SubEntry->GetDateTime()->Month,
                            SubEntry->GetDateTime()->Year,
                            SubEntry->GetDateTime()->Hour,
                            SubEntry->GetDateTime()->Minute,
                            SubEntry->GetDateTime()->Second);
                    if (SubEntry->Length!=-1) {
                        if (Num==3) DialledSec += SubEntry->Length;
                        if (Num==4) ReceivedSec += SubEntry->Length;
                        DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
                        DT1 += SubEntry->Length;
                        memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
                        sprintf(buff3+strlen(buff3)," - %s %02i-%02i-%04i %02i:%02i:%02i (%02i:%02i:%02i)",
                                        DayOfWeekStr(
                                                DT2.Year,
                                                DT2.Month,
                                                DT2.Day),
                                DT2.Day,
                                DT2.Month,
                                DT2.Year,
                                DT2.Hour,
                                DT2.Minute,
                                DT2.Second,SubEntry->Length/(60*60),SubEntry->Length/60,SubEntry->Length%60);
                    }                            
                    if (newe2) {
                        Entry2 = new GSM_PBKEntry;
                        newe2 = false;
                        Entry2->Location= Pos-1;
                        if (Num==3) Entry2->Memory=MEM_PHONE_DIALLED;
                        if (Num==4) Entry2->Memory=MEM_PHONE_RECEIVED;
                        if (Num==5) Entry2->Memory=MEM_PHONE_MISSED;
                        error = s->Phones->Current->GetPBK(Entry2);
                        Backup.Add_ME_PBK(Entry2);
                    }

                    sprintf(buff0,"%i",Pos-1);
                    tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
                    WxListCtrl2->SetItemData(tmp, Num2++);
                    WxListCtrl2->SetItem(tmp, 1, buff);
                    WxListCtrl2->SetItem(tmp, 2, buff2);
                    WxListCtrl2->SetItem(tmp, 3, buff3);
                    break;
                default:
                    break;
                }
            }
        }
        delete Dialog;
        sprintf(buff3," (%i entries",PbkNum);
        StatusStr[1].append(StringToUnicodeReturn(buff3));
        if (DialledSec != -1) {
            sprintf(buff3,", dialling time %02i:%02i:%02i",DialledSec/(60*60),DialledSec/60,DialledSec%60);
            StatusStr[1].append(StringToUnicodeReturn(buff3));
        }
        if (ReceivedSec != -1) {
            sprintf(buff3,", receiving time %02i:%02i:%02i",ReceivedSec/(60*60),ReceivedSec/60,ReceivedSec%60);
            StatusStr[1].append(StringToUnicodeReturn(buff3));
        }
        sprintf(buff3,")");
        StatusStr[1].append(StringToUnicodeReturn(buff3));
        WxListCtrl2->SortItems(WxListCtrl2CompareFunction,3);
        break;
    case 6:
        Dialog = new wxProgressDialog("Reading "+Name, "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
        for (Pass=0;Pass<3;Pass++) {
            Pos=1;
            error.Code = GSM_ERR_NONE;
            while (error.Code != GSM_ERR_EMPTY) {
                if (newe) {
                    Entry = new GSM_PBKEntry;
                    newe = false;
                } else {
                    Entry->ClearAll();
                }
                Entry->Location= Pos;
                if (Pass==0) Entry->Memory=MEM_PHONE_DIALLED;
                if (Pass==1) Entry->Memory=MEM_PHONE_RECEIVED;
                if (Pass==2) Entry->Memory=MEM_PHONE_MISSED;
                error = s->Phones->Current->GetPBK(Entry);
                Pos++;
                if (error.Code != GSM_ERR_NONE) continue;
                Dialog->UpdatePulse("",&skip);
                buff[0] = 0;
                buff2[0] = 0;
                buff3[0] = 0;
                SubEntry = NULL;
                while (Entry->GetNext(&SubEntry) == TRUE) {
                    switch (SubEntry->GetType()) {
                    case PBK_Text_Name:
                        CopyUnicode(SubEntry->GetText(),buff);
                        break;
                    case PBK_Text_Phone_General:
                    case PBK_Text_Phone_Mobile:
                    case PBK_Text_Phone_Home:
                    case PBK_Text_Phone_Work:
                    case PBK_Text_Phone_Fax:
                        CopyUnicode(SubEntry->GetText(),buff2);
                        break;
                    default:
                        break;
                    }
                }
                SubEntry = NULL;
                newe2=true;
                while (Entry->GetNext(&SubEntry) == TRUE) {
                    switch (SubEntry->GetType()) {
                    case PBK_DateTime_Call_Length:
                        sprintf(buff3,"%s %02i-%02i-%04i %02i:%02i:%02i",
                                DayOfWeekStr(
                                        SubEntry->GetDateTime()->Year,
                                        SubEntry->GetDateTime()->Month,
                                        SubEntry->GetDateTime()->Day),
                                SubEntry->GetDateTime()->Day,
                                SubEntry->GetDateTime()->Month,
                                SubEntry->GetDateTime()->Year,
                                SubEntry->GetDateTime()->Hour,
                                SubEntry->GetDateTime()->Minute,
                                SubEntry->GetDateTime()->Second);
                        if (SubEntry->Length!=-1) {
                            if (Pass==0) DialledSec += SubEntry->Length;
                            if (Pass==1) ReceivedSec += SubEntry->Length;
                            DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
                            DT1 += SubEntry->Length;
                            memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
                            sprintf(buff3+strlen(buff3)," - %s %02i-%02i-%04i %02i:%02i:%02i (%02i:%02i:%02i)",
                                            DayOfWeekStr(
                                                    DT2.Year,
                                                    DT2.Month,
                                                    DT2.Day),
                                    DT2.Day,
                                    DT2.Month,
                                    DT2.Year,
                                    DT2.Hour,
                                    DT2.Minute,
                                    DT2.Second,SubEntry->Length/(60*60),SubEntry->Length/60,SubEntry->Length%60);
                        }
                        if (newe2) {
                            Entry2 = new GSM_PBKEntry;
                            newe2 = false;
                            Entry2->Location= Pos-1;
                            if (Pass==0) Entry2->Memory=MEM_PHONE_DIALLED;
                            if (Pass==1) Entry2->Memory=MEM_PHONE_RECEIVED;
                            if (Pass==2) Entry2->Memory=MEM_PHONE_MISSED;
                            error = s->Phones->Current->GetPBK(Entry2);
                            Backup.Add_ME_PBK(Entry2);
                        }

                        if (Pass==0) sprintf(buff0,"D %i",Pos-1);
                        if (Pass==1) sprintf(buff0,"R %i",Pos-1);
                        if (Pass==2) sprintf(buff0,"M %i",Pos-1);

                        tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
                        WxListCtrl2->SetItemData(tmp, Num2++);
                        WxListCtrl2->SetItem(tmp, 1, buff);
                        WxListCtrl2->SetItem(tmp, 2, buff2);
                        WxListCtrl2->SetItem(tmp, 3, buff3);

                        break;
                    default:
                        break;
                    }
                }
            }
        }
        delete Dialog;
        sprintf(buff3," (%i entries",PbkNum);
        StatusStr[1].append(StringToUnicodeReturn(buff3));
        if (DialledSec != -1) {
            sprintf(buff3,", dialling time %02i:%02i:%02i",DialledSec/(60*60),DialledSec/60,DialledSec%60);
            StatusStr[1].append(StringToUnicodeReturn(buff3));
        }
        if (ReceivedSec != -1) {
            sprintf(buff3,", receiving time %02i:%02i:%02i",ReceivedSec/(60*60),ReceivedSec/60,ReceivedSec%60);
            StatusStr[1].append(StringToUnicodeReturn(buff3));
        }
        sprintf(buff3,")");
        StatusStr[1].append(StringToUnicodeReturn(buff3));
        WxListCtrl2->SortItems(WxListCtrl2CompareFunction,3);
        break;
    }
}

/*
 * WxButton1Click
 */
void MainFrm::WxButton1Click(wxCommandEvent& event)
{
    GSM_PBKEntry        *Entry;
    boolean             newe = true;
    GSM_PBKStatus       Status;
    GSM_Error           error;
    int                 i=0,Pos=1,Pass=0;
    wxProgressDialog    *Dialog;
    bool                skip;
    long                tmp;
    wchar_t             buff[40],buff2[40];
    char                buff3[50];
    char                buff0[40];
    GSM_PBKSubEntry     *SubEntry;
    wxArrayString       choices;
    int                 PbkNum = 0;
    
    choices.Add(wxT("phone phonebook"));
    choices.Add(wxT("SIM phonebook"));
    choices.Add(wxT("own numbers"));
    choices.Add(wxT("dialled calls"));
    choices.Add(wxT("received calls"));
    choices.Add(wxT("missed calls"));
    choices.Add(wxT("call lists (dialled + received + missed)"));
    choices.Add(wxT("sent SMS list"));

    wxSingleChoiceDialog dialog2(this,
        wxT("Here are possible to read memories (phone or Gammu+)"),
                wxT("Please select a value"),
                choices);
    dialog2.SetSelection(0);

    if (dialog2.ShowModal() != wxID_OK) return;
            
    ReadPhonebook(dialog2.GetSelection(),dialog2.GetStringSelection());
    WxStatusBar1->SetStatusText(wxString(StatusStr[1].data())+wxString(StatusStr2[1].data()),0);
}

/*
 * WxListCtrl2ColLeftClick
 */
void MainFrm::WxListCtrl2ColLeftClick(wxListEvent& event)
{
    SortPBKReverse = !SortPBKReverse;
    WxListCtrl2->SortItems(WxListCtrl2CompareFunction,event.GetColumn());
    WxStatusBar1->SetStatusText(wxString(StatusStr[1].data())+wxString(StatusStr2[1].data()),0);
}

/*
 * WxListCtrl2ItemActivated
 */
void MainFrm::WxListCtrl2ItemActivated(wxListEvent& event)
{
    bool                    skip;
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    GSM_PBKSubEntry         *SubEntry;
    int                     i,EntryNum=0,Num=0;
    wchart                  x;
    long                    item,tmp;
    GSM_Backup_PBKEntry     *PBKEntry;
    char                    type[50],buff[100];
    wchar_t                 Value[500];
    time_t                  DT1;
    GSM_DateTime            DT2;
        
    item = WxListCtrl2->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);      
        
    WxListCtrl3->DeleteAllItems();

    PBKEntry = NULL;
    while(Backup.GetNext_ME_PBK(&PBKEntry)) {
        if (PhonePBK < 3) {
            if (PBKEntry->GetEntry()->Location == WxListCtrl2->GetItemData(item)) break;
        } else {
            SubEntry = NULL;
            while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
                if (SubEntry->GetType() == PBK_DateTime_Call_Length) Num++;
                if (Num == WxListCtrl2->GetItemData(item)) break;
            }
            if (Num == WxListCtrl2->GetItemData(item)) break;            
        }
    }

    tmp = WxListCtrl3->InsertItem(EntryNum++, "Location", 0);
    WxListCtrl3->SetItemData(tmp, 0);
    WxListCtrl3->SetItem(tmp, 1, WxListCtrl2->GetItemText(item));
        
    SubEntry = NULL;
    while (PBKEntry->GetEntry()->GetNext(&SubEntry)) {
        switch (SubEntry->GetType()) {
        case PBK_Text_Phone_General:
            sprintf(type,"General number");
            CopyUnicode(SubEntry->GetText(),Value);
            break;
        case PBK_Text_Phone_Mobile:
            sprintf(type,"Mobile number");                
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Phone_Home:
            sprintf(type,"Home number");           
            CopyUnicode(SubEntry->GetText(),Value);                     
            break;
        case PBK_Text_Phone_Work:
            sprintf(type,"Work number");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Phone_Fax:
            sprintf(type,"Fax number");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Email:
            sprintf(type,"Email address");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_URL:
            sprintf(type,"URL link");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Postal:
            sprintf(type,"Postal address");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_UserID:
            sprintf(type,"User ID");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Note:
            sprintf(type,"Text note");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_Text_Name:
            sprintf(type,"Name");
            CopyUnicode(SubEntry->GetText(),Value);                
            break;
        case PBK_DateTime_Call_Length:
            sprintf(type,"Date & time");
            sprintf(buff,"%s %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(
                            SubEntry->GetDateTime()->Year,
                            SubEntry->GetDateTime()->Month,
                            SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,
                    SubEntry->GetDateTime()->Month,
                    SubEntry->GetDateTime()->Year,                                  
                    SubEntry->GetDateTime()->Hour,
                    SubEntry->GetDateTime()->Minute,
                    SubEntry->GetDateTime()->Second);
            if (SubEntry->Length!=-1) {
                DT1 = GSMDateTime2TimeT(SubEntry->GetDateTime());
                DT1 += SubEntry->Length;
                memcpy(&DT2,&TimeT2GSMDateTime(&DT1),sizeof(GSM_DateTime));
                sprintf(buff+strlen(buff)," - %s %02i-%02i-%04i %02i:%02i:%02i (%02i:%02i:%02i)",
                                DayOfWeekStr(
                                        DT2.Year,
                                        DT2.Month,
                                        DT2.Day),
                        DT2.Day,
                        DT2.Month,
                        DT2.Year,
                        DT2.Hour,
                        DT2.Minute,
                        DT2.Second,SubEntry->Length/(60*60),SubEntry->Length/60,SubEntry->Length%60);
            }
            StringToUnicode(buff,Value);
            break;
        }
        tmp = WxListCtrl3->InsertItem(EntryNum++, type, 0);
        WxListCtrl3->SetItemData(tmp, 0);
        WxListCtrl3->SetItem(tmp, 1, Value);
    }
}

/*
 * WxButton3Click
 */
void MainFrm::WxButton3Click(wxCommandEvent& event)
{
    wxProgressDialog           *Dialog = NULL;
    bool                       skip;
    GSM_SMSMMSFolders          Folders;
    GSM_SMSMMSFoldersSubEntry  *SubFolder;
    GSM_Error                  error,preverror;
    char                       buff[200];
    GSM_SMSList                *Entry;
    BOOLEAN                    start = TRUE;
    int                        i, j=0, smsnum=0, smsparts=0, z=0, lastfolder=0;
    int                        Folder, Current, MaxInFolder, FolderMax=0;
        
    error = s->Phones->Current->GetSMSFolders(&Folders);
    PrintError(error);
    FolderMax = 0;
    SubFolder = NULL;
    while (Folders.GetNext(&SubFolder) == TRUE) FolderMax ++;
    
    Backup.Delete_SMS();
    WxChoice1->Clear();
    WxListCtrl4->DeleteAllItems();
    WxListCtrl5->DeleteAllItems();
    
    SubFolder = NULL;
    while (Folders.GetNext(&SubFolder) == TRUE) {
        buff[0] = 0;
        if (SubFolder->Memory == MEM_PHONE) sprintf(buff,"%s (phone)",UnicodeToStringReturn(SubFolder->GetName()));
        if (SubFolder->Memory == MEM_SIM) sprintf(buff,"%s (SIM)",UnicodeToStringReturn(SubFolder->GetName()));        
        WxChoice1->Append(buff);
    }    

    preverror.Code = GSM_ERR_UNKNOWN;   
    Entry = new GSM_SMSList;
    while (true) {
        error = s->Phones->Current->GetNextSMS(Entry,start, &Folder, &Current, &MaxInFolder);
        start = FALSE;
        if (error.Code == GSM_ERR_EMPTY) break;
        if (error.Code == GSM_ERR_FOLDER_MORE) {
            if (lastfolder != Folder) {
                lastfolder = Folder;
                SubFolder = NULL;
                for (i=0;i<Folder;i++) Folders.GetNext(&SubFolder);
                if (Dialog != NULL) delete(Dialog);
                sprintf(buff,"Reading content of %s SMS folder (folder %i of %i)",UnicodeToStringReturn(SubFolder->GetName()),Folder,FolderMax);
                Dialog = new wxProgressDialog(buff, "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);  
            }
            Dialog->UpdatePulse("",&skip);
            preverror.Code = error.Code;
            continue;
        } else {
            if (Dialog != NULL && (preverror.Code == GSM_ERR_FOLDER_MORE || lastfolder != Folder)) {
                lastfolder = Folder;
                delete(Dialog);
                Dialog = NULL;
            }
        }
        if (error.Code == GSM_ERR_FOLDER_PART) {
            wxMessageBox("There was read only folder part (it's phone firmware problem)",
                    wxT("Error"),
                    wxICON_WARNING | wxOK);
            preverror.Code = error.Code;
            continue;
        }
        if (error.Code != GSM_ERR_NONE) {
                PrintError(error);
        }
        preverror.Code = error.Code;

        SubFolder = NULL;
        for (i=0;i<Folder;i++) Folders.GetNext(&SubFolder);

        if (Dialog == NULL) {
            sprintf(buff,"Reading SMS");
            if (Folder!=-1) sprintf(buff+strlen(buff)," from %s SMS folder (folder %i of %i)",UnicodeToStringReturn(SubFolder->GetName()),Folder,FolderMax);
            Dialog = new wxProgressDialog(buff, "", MaxInFolder, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
        } else {
            Dialog->Update((int)Current,"",&skip);
        }

        Backup.Add_SMS(Entry);

        Entry = new GSM_SMSList;
    }
    delete (Dialog);
    delete (Entry);

    Backup.LinkSMS();
    Backup.SortSMSByFolderDT();     
}

/*
 * Mnuabout1019Click
 */
void MainFrm::Mnuabout1019Click(wxCommandEvent& event)
{
    AboutDlg *dialog = new AboutDlg(this,-1,"About...",wxDefaultPosition,wxDefaultSize,AboutDlg_STYLE);
    
    dialog->ShowModal();
    
    dialog->Destroy();
}

/*
 * WxChoice1Selected
 */
void MainFrm::WxChoice1Selected(wxCommandEvent& event )
{
    GSM_Backup_SMSEntry     *En;
    GSM_SMSListSubEntry     *SubEntry;
    GSM_SMSEntry            *SMS;   
    boolean                 wrong;
    wchar_t                 Buffer[500],Buffer2[500];
    long                    tmp;
    int                     i = 1;
    char                    buff[100];
    int                     EntryNum = 0;
    GSM_DateTime            DT;
    GSM_PBKSubEntry         *PBKSubEntry;
    GSM_Backup_PBKEntry     *PBKEntry;
                
    WxListCtrl4->DeleteAllItems();
    WxListCtrl5->DeleteAllItems();
        
    En = NULL;
    while (Backup.GetNext_SMS(&En)) {
        wrong = false;
        SubEntry = NULL;
        if (En->GetEntry()->GetNext(&SubEntry) == TRUE) {
            if (En->GetEntry()->Folder != WxChoice1->GetSelection()+1) {
                    continue;
            }
            SMS = SubEntry->GetSMS();            
            if (SMS->GetType()!=SMS_Submit) {
                SMS->GetDateTime(&DT);
                sprintf(buff,"%s %02i-%02i-%04i %02i:%02i:%02i",
                        DayOfWeekStr(
                                DT.Year,
                                DT.Month,
                                DT.Day),
                        DT.Day,
                        DT.Month,
                        DT.Year,
                        DT.Hour,
                        DT.Minute,
                        DT.Second);
                StringToUnicode(buff,Buffer);
                tmp = WxListCtrl4->InsertItem(EntryNum++, Buffer, 0);
                WxListCtrl4->SetItemData(tmp, 0);
            } else {
                tmp = WxListCtrl4->InsertItem(EntryNum++, "", 0);
                WxListCtrl4->SetItemData(tmp, 0);
            }
            SMS->GetPhoneNumber(Buffer);
            if (UnicodeLength(Buffer) != 0) {
                if (PhonePBK!=0) ReadPhonebook(0,"Phone phonebook");
                buff[0]=0;
                Buffer2[0] = 0;                
                PBKEntry = NULL;
                while (Backup.GetNext_ME_PBK(&PBKEntry)) {
                    PBKSubEntry = NULL;
                    while (PBKEntry->GetEntry()->GetNext(&PBKSubEntry)) {
                        switch (PBKSubEntry->GetType()) {
                        case PBK_Text_Phone_General:
                            if (UnicodeCaseCmp(PBKSubEntry->GetText(),Buffer,-1)) {
                                sprintf(buff,"general");
                            }
                            break;
                        case PBK_Text_Phone_Mobile:
                            if (UnicodeCaseCmp(PBKSubEntry->GetText(),Buffer,-1)) {
                                sprintf(buff,"mobile");
                            }
                            break;
                        case PBK_Text_Phone_Home:
                            if (UnicodeCaseCmp(PBKSubEntry->GetText(),Buffer,-1)) {
                                sprintf(buff,"home");
                            }
                            break;
                        case PBK_Text_Phone_Work:
                            if (UnicodeCaseCmp(PBKSubEntry->GetText(),Buffer,-1)) {
                                sprintf(buff,"work");
                            }
                            break;
                        case PBK_Text_Phone_Fax:
                            if (UnicodeCaseCmp(PBKSubEntry->GetText(),Buffer,-1)) {
                                sprintf(buff,"fax");
                            }
                            break;
                        case PBK_Text_Name:
                            CopyUnicode(PBKSubEntry->GetText(),Buffer2);
                            break;
                        default:
                            break;
                        }
                    }
                    if (buff[0] != 0 && Buffer2==0) {
                        PBKSubEntry = NULL;
                        while (PBKEntry->GetEntry()->GetNext(&PBKSubEntry)) {
                            switch (PBKSubEntry->GetType()) {
                            case PBK_Text_Name:
                                CopyUnicode(PBKSubEntry->GetText(),Buffer2);
                                break;
                            default:
                                break;
                            }
                        }
                    }
                    if (buff[0] != 0) break;
                }
                if (buff[0] != 0) {
                    CopyUnicode(StringToUnicodeReturn(" ("),Buffer2+UnicodeLength(Buffer2));
                    CopyUnicode(StringToUnicodeReturn(buff),Buffer2+UnicodeLength(Buffer2));
                    CopyUnicode(StringToUnicodeReturn(", "),Buffer2+UnicodeLength(Buffer2));
                    CopyUnicode(Buffer,Buffer2+UnicodeLength(Buffer2));
                    CopyUnicode(StringToUnicodeReturn(")"),Buffer2+UnicodeLength(Buffer2));
                    WxListCtrl4->SetItem(tmp, 1, Buffer2);
                } else {
                    WxListCtrl4->SetItem(tmp, 1, Buffer);                        
                }
            }
            if (SMS->GetType()!=SMS_Report && (SMS->GetCoding()==SMS_Coding_Unicode_No_Compression || SMS->GetCoding()==SMS_Coding_Default_No_Compression)) {
                SMS->GetDecodedText(Buffer);
                WxListCtrl4->SetItem(tmp, 2, Buffer);
            } else {
                WxListCtrl4->SetItem(tmp, 2, "");
            }
            i=1;
            while (En->GetEntry()->GetNext(&SubEntry)) i++;
            sprintf(buff,"%i",i);
            StringToUnicode(buff,Buffer);
            WxListCtrl4->SetItem(tmp, 3, Buffer);
        }               
    }
}

/*
 * WxListCtrl4ItemActivated
 */
void MainFrm::WxListCtrl4ItemActivated(wxListEvent& event)
{
    bool                    skip;
    GSM_Error               error;
    GSM_File                ReadSaveFile;
    int                     i,EntryNum=0,j;
    wchart                  x;
    long                    item,tmp,item2=0;
    GSM_Backup_PBKEntry     *PBKEntry;
    char                    type[50];
    wchar_t                 Value[500];
    GSM_Backup_SMSEntry     *En;
    GSM_SMSListSubEntry     *SubEntry;
    GSM_SMSEntry            *SMS;
    boolean                 wrong;
    wchar_t                 Buffer[500];
    char                    buff[100];
    GSM_DateTime            DT;
    unsignedstring          UDH;
    UDHList                 UDH2;
    
    item = WxListCtrl4->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

    WxListCtrl5->DeleteAllItems();

    En = NULL;
    while (Backup.GetNext_SMS(&En)) {
        wrong = false;
        SubEntry = NULL;
        if (!En->GetEntry()->GetNext(&SubEntry)) continue;
        if (En->GetEntry()->Folder != WxChoice1->GetSelection()+1) {
            continue;
        }
        item2++;
        if (item != item2-1) continue;
        while (true) {  
            SMS = SubEntry->GetSMS();
            switch (SMS->GetType()) {
            case SMS_Deliver:
                tmp = WxListCtrl5->InsertItem(EntryNum++, "SMS Deliver", 0);
                WxListCtrl5->SetItemData(tmp, 0);
                    
                error = SMS->GetSMSCNumber(Buffer);
                PrintError(error);                              
                tmp = WxListCtrl5->InsertItem(EntryNum++, "   SMSC Number", 0);
                WxListCtrl5->SetItemData(tmp, 0);
                WxListCtrl5->SetItem(tmp, 1, UnicodeToStringReturn(Buffer));
                
                SMS->GetDateTime(&DT);
                tmp = WxListCtrl5->InsertItem(EntryNum++, "   Sending date & time", 0);
                WxListCtrl5->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                        DayOfWeekStr(DT.Year,DT.Month,DT.Day),
                        DT.Day,DT.Month,DT.Year,
                        DT.Hour,DT.Minute,DT.Second);
                WxListCtrl5->SetItem(tmp, 1, buff);
                /* no break */
            case SMS_Submit:
                if (SMS->GetType() == SMS_Submit) {
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "SMS Submit", 0);
                    WxListCtrl5->SetItemData(tmp, 0);
                }
                error = SMS->GetPhoneNumber(Buffer);
                PrintError(error);
                if (UnicodeLength(Buffer)!=0) {
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "   Phone number", 0);
                    WxListCtrl5->SetItemData(tmp, 0);
                    WxListCtrl5->SetItem(tmp, 1, Buffer);
                }
                if (SMS->GetClass() != -1) {
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "   SMS class", 0);
                    sprintf(buff,"%i",SMS->GetClass());
                    WxListCtrl5->SetItemData(tmp, 0);
                    WxListCtrl5->SetItem(tmp, 1, buff);                                         
                }
                if (SMS->SenderSMSCReply() == TRUE) {
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "   SMSC reply", 0);
                    WxListCtrl5->SetItemData(tmp, 0);
                    WxListCtrl5->SetItem(tmp, 1, "yes");
                }
        
                error = SMS->GetUDH(&UDH);
                PrintError(error);
                if (UDH.size()!=0) {
                    error = SMS->DecodeUDH(&UDH2);
                    if (error.Code == GSM_ERR_NONE) {
                        for (j=0;j<UDH2.size();j++) {
                            tmp = WxListCtrl5->InsertItem(EntryNum++, "   UDH", 0);
                            switch (UDH2.data()[j].Type) {
                            case SMS_UDH_Linked_Short:
                                sprintf(buff,"linked (short, ID %i, part %i/%i)",UDH2.data()[j].ID8bit,UDH2.data()[j].PartNumber8bit,UDH2.data()[j].AllParts8bit);
                                WxListCtrl5->SetItemData(tmp, 0);
                                WxListCtrl5->SetItem(tmp, 1, buff);
                                break;
                            case SMS_UDH_Linked_Long:
                                sprintf(buff,"linked (short, ID %i, part %i/%i)",UDH2.data()[j].ID8bit,UDH2.data()[j].PartNumber8bit,UDH2.data()[j].AllParts8bit);
                                WxListCtrl5->SetItemData(tmp, 0);
                                WxListCtrl5->SetItem(tmp, 1, buff);
                                break;
                            }
                        }
                    }
                }
        
                tmp = WxListCtrl5->InsertItem(EntryNum++, "   Coding", 0);
                WxListCtrl5->SetItemData(tmp, 0);
                switch (SMS->GetCoding()) {
                case SMS_Coding_Unicode_No_Compression:
                    WxListCtrl5->SetItem(tmp, 1, "Unicode, no compression");
                    error = SMS->GetDecodedText(Buffer);
                    PrintError(error);
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "   Text", 0);
                    WxListCtrl5->SetItemData(tmp, 0);
                    WxListCtrl5->SetItem(tmp, 1, Buffer);
                    break;
                case SMS_Coding_Unicode_Compression:
                    WxListCtrl5->SetItem(tmp, 1, "Unicode, compression, no support from Gammu+ now");
                    break;
                case SMS_Coding_Default_No_Compression:
                    WxListCtrl5->SetItem(tmp, 1, "Default, no compression");
                    error = SMS->GetDecodedText(Buffer);
                    PrintError(error);
                    tmp = WxListCtrl5->InsertItem(EntryNum++, "   Text", 0);
                    WxListCtrl5->SetItemData(tmp, 0);
                    WxListCtrl5->SetItem(tmp, 1, Buffer);
                    break;
                case SMS_Coding_Default_Compression:
                    WxListCtrl5->SetItem(tmp, 1, "Default, compression, no support from Gammu+ now");
                    break;
                case SMS_Coding_8bit:
                    WxListCtrl5->SetItem(tmp, 1, "8 bit");
                    break;
                }
                break;
            case SMS_Report:
                tmp = WxListCtrl5->InsertItem(EntryNum++, "SMS report", 0);
            }
                                                
            if (!En->GetEntry()->GetNext(&SubEntry)) {
                break;
            }
        }
    }
}

/*
 * WxButton2Click
 */
void MainFrm::WxButton2Click(wxCommandEvent& event)
{
    bool                newe = TRUE, Start = TRUE, skip;
    GSM_Error           error;    
    GSM_CalendarEntry   *Entry;
    int                 Current,Max;
    wxProgressDialog    *Dialog = NULL;
    
    while (1) {
        if (newe) {
            Entry = new GSM_CalendarEntry;
            newe = false;
        }
        error = s->Phones->Current->GetNextCalendar(Entry,Start,&Current,&Max);
        if (error.Code == GSM_ERR_EMPTY) break;
        PrintError(error);
        if (Dialog == NULL) {
            if (Max != -1) {
                Dialog = new wxProgressDialog("Reading calendar", "", Max, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);                
            } else {
                Dialog = new wxProgressDialog("Reading calendar", "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
            }
        } else {
            if (Max != -1) {
                Dialog->Update((int)Current,"",&skip);
            } else {
                Dialog->UpdatePulse("",&skip);
            }
        }
        
        Backup.Add_Cal(Entry);
        newe = true;
        Start = false;
    }
    delete Dialog;
    DisplayCalendar();
}

/*
 * wxNotebook1PageChanged
 */
void MainFrm::wxNotebook1PageChanged(wxNotebookEvent& event)
{
    WxStatusBar1->SetStatusText(StatusStr[wxNotebook1->GetSelection()].data(),0);
}

void MainFrm::DisplayCalendar()
{
    GSM_Backup_CalEntry     *CalEntry;
    GSM_CalendarEntry       *CalEntry2;
    wchart                  Text;
    GSM_DateTime            DT;
    GSM_CalendarSubEntry    *SubEntry;
    long                    EntryNum = 0, tmp;
    char                    buff[200];

    if (WxCheckBox1->GetValue()) {
        sprintf(buff,"All calendar notes");
    } else {
        sprintf(buff,"Calendar for %s %02i-%02i-%04i",
            DayOfWeekStr(
                WxCalendarCtrl1->GetDate().GetYear(),
                WxCalendarCtrl1->GetDate().GetMonth(),
                WxCalendarCtrl1->GetDate().GetDay()),
            WxCalendarCtrl1->GetDate().GetDay(),
            WxCalendarCtrl1->GetDate().GetMonth(),
            WxCalendarCtrl1->GetDate().GetYear());        
    }
    StatusStr[3].clear();
    StatusStr[3].append(StringToUnicodeReturn(buff));
    WxStatusBar1->SetStatusText(StatusStr[3].data(),0);
    
    WxListCtrl6->DeleteAllItems();
    WxListCtrl7->DeleteAllItems();
    
    CalEntry = NULL;
    while (Backup.GetNext_Cal(&CalEntry)) {
        CalEntry2 = CalEntry->GetEntry();
        Text.clear();

        SubEntry = NULL;
        while (CalEntry2->GetNext(&SubEntry)) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                Text.append(SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                memcpy(&DT,SubEntry->GetDateTime(),sizeof(GSM_DateTime));
                break;
            default:
                break;
            }
        }
        if (!WxCheckBox1->GetValue() && (WxCalendarCtrl1->GetDate().GetYear()!=DT.Year ||
            WxCalendarCtrl1->GetDate().GetMonth()!=DT.Month ||
            WxCalendarCtrl1->GetDate().GetDay()!=DT.Day)) {
                continue;
        }

        sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                DayOfWeekStr(DT.Year,DT.Month,DT.Day),
                DT.Day,DT.Month,DT.Year,
                DT.Hour,DT.Minute,DT.Second);
        
        tmp = WxListCtrl6->InsertItem(EntryNum++, buff, 0);
        WxListCtrl6->SetItemData(tmp, 0);
        
        switch(CalEntry2->Type) {
        case Calendar_Type_Meeting:
            WxListCtrl6->SetItem(tmp, 1, "meeting");
            break;
        case Calendar_Type_Memo:
            WxListCtrl6->SetItem(tmp, 1, "memo");
            break;
        case Calendar_Type_Call:
            WxListCtrl6->SetItem(tmp, 1, "phone call");
            break;
        case Calendar_Type_Birthday:
            WxListCtrl6->SetItem(tmp, 1, "birthday");
            break;
        case Calendar_Type_Reminder:
            WxListCtrl6->SetItem(tmp, 1, "reminder");
            break;
        }
        
        WxListCtrl6->SetItem(tmp, 2, Text.data());        
    }    
}


/*
 * WxCalendarCtrl1SelChanged
 */
void MainFrm::WxCalendarCtrl1SelChanged(wxCalendarEvent& event)
{
    DisplayCalendar();
}

/*
 * WxCheckBox1Click
 */
void MainFrm::WxCheckBox1Click(wxCommandEvent& event)
{
    WxCalendarCtrl1->Enable(!WxCheckBox1->GetValue());
    DisplayCalendar();
}

/*
 * WxListCtrl6ItemActivated
 */
void MainFrm::WxListCtrl6ItemActivated(wxListEvent& event)
{
    GSM_Backup_CalEntry     *CalEntry;
    GSM_CalendarEntry       *CalEntry2;
    wchart                  Text;
    GSM_DateTime            DT;
    GSM_CalendarSubEntry    *SubEntry;
    long                    EntryNum = 0, tmp, item, item2=0;
    char                    buff[200];
    int                     RepeatEach,RepeatDay,RepeatMonth,RepeatDOW;

    WxListCtrl7->DeleteAllItems();
    
    item = WxListCtrl6->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    
    CalEntry = NULL;
    while (Backup.GetNext_Cal(&CalEntry)) {
        CalEntry2 = CalEntry->GetEntry();
        Text.clear();

        SubEntry = NULL;
        while (CalEntry2->GetNext(&SubEntry)) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                Text.append(SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                memcpy(&DT,SubEntry->GetDateTime(),sizeof(GSM_DateTime));
                break;
            default:
                break;
            }
        }
        if (!WxCheckBox1->GetValue() && (WxCalendarCtrl1->GetDate().GetYear()!=DT.Year ||
            WxCalendarCtrl1->GetDate().GetMonth()!=DT.Month ||
            WxCalendarCtrl1->GetDate().GetDay()!=DT.Day)) {
                continue;
        }
        item2++;
        if (item2-1 != item) continue;
        
        tmp = WxListCtrl7->InsertItem(EntryNum++, "Note type", 0);
        WxListCtrl7->SetItemData(tmp, 0);

        switch(CalEntry2->Type) {
        case Calendar_Type_Meeting:
            WxListCtrl7->SetItem(tmp, 1, "meeting");
            break;
        case Calendar_Type_Memo:
            WxListCtrl7->SetItem(tmp, 1, "memo");
            break;
        case Calendar_Type_Call:
            WxListCtrl7->SetItem(tmp, 1, "phone call");
            break;
        case Calendar_Type_Birthday:
            WxListCtrl7->SetItem(tmp, 1, "birthday");
            break;
        case Calendar_Type_Reminder:
            WxListCtrl7->SetItem(tmp, 1, "reminder");
            break;
        }

        RepeatEach      = -1;
        RepeatDay       = -1;
        RepeatMonth     = -1;
        RepeatDOW       = -1;
        SubEntry        = NULL;
        while (CalEntry2->GetNext(&SubEntry) == TRUE) {
            switch (SubEntry->GetType()) {
            case Calendar_Text_Text:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Text", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_Text_Phone:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Phone number", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_Text_Location:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Location", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                WxListCtrl7->SetItem(tmp, 1, SubEntry->GetText());
                break;
            case Calendar_DateTime_Start:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Start", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(SubEntry->GetDateTime()->Year,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Year,
                    SubEntry->GetDateTime()->Hour,SubEntry->GetDateTime()->Minute,SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_End:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "End", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                    DayOfWeekStr(SubEntry->GetDateTime()->Year,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Day),
                    SubEntry->GetDateTime()->Day,SubEntry->GetDateTime()->Month,SubEntry->GetDateTime()->Year,
                    SubEntry->GetDateTime()->Hour,SubEntry->GetDateTime()->Minute,SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_SilentAlarm:
            case Calendar_DateTime_ToneAlarm:
                if (SubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
                    tmp = WxListCtrl7->InsertItem(EntryNum++, "Silent alarm", 0);
                } else {
                    tmp = WxListCtrl7->InsertItem(EntryNum++, "Tone alarm", 0);
                }
                WxListCtrl7->SetItemData(tmp, 0);
                if (CalEntry2->Type == Calendar_Type_Birthday) {
                    sprintf(buff,"%02i:%02i:%02i %02i-%02i in each year",
                            SubEntry->GetDateTime()->Hour,
                            SubEntry->GetDateTime()->Minute,
                            SubEntry->GetDateTime()->Second,
                            SubEntry->GetDateTime()->Day,
                            SubEntry->GetDateTime()->Month);
                } else {
                    sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                            DayOfWeekStr(
                                    SubEntry->GetDateTime()->Year,
                                    SubEntry->GetDateTime()->Month,
                                    SubEntry->GetDateTime()->Day),                    
                            SubEntry->GetDateTime()->Day,
                            SubEntry->GetDateTime()->Month,
                            SubEntry->GetDateTime()->Year,
                            SubEntry->GetDateTime()->Hour,
                            SubEntry->GetDateTime()->Minute,
                            SubEntry->GetDateTime()->Second);
                }
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_DateTime_End_Repeat:
                tmp = WxListCtrl7->InsertItem(EntryNum++, "Repeat end", 0);
                WxListCtrl7->SetItemData(tmp, 0);
                sprintf(buff,"%s  %02i-%02i-%04i %02i:%02i:%02i",
                        DayOfWeekStr(
                                SubEntry->GetDateTime()->Year,
                                SubEntry->GetDateTime()->Month,
                                SubEntry->GetDateTime()->Day),
                        SubEntry->GetDateTime()->Day,
                        SubEntry->GetDateTime()->Month,
                        SubEntry->GetDateTime()->Year,
                        SubEntry->GetDateTime()->Hour,
                        SubEntry->GetDateTime()->Minute,
                        SubEntry->GetDateTime()->Second);
                WxListCtrl7->SetItem(tmp, 1, buff);
                break;
            case Calendar_Int_Repeat_Frequency:
                RepeatEach = SubEntry->GetInt();
                break;
            case Calendar_Int_Repeat_DayOfWeek:
                RepeatDOW = SubEntry->GetInt();
                break;                  
            case Calendar_Int_Repeat_Day:
                RepeatDay = SubEntry->GetInt();
                break;
            case Calendar_Int_Repeat_Month:
                RepeatMonth = SubEntry->GetInt();
                break;
            }
        }

        if (RepeatEach != -1 || RepeatDOW != -1 ||
            RepeatDay != -1 || RepeatMonth != -1) {
            tmp = WxListCtrl7->InsertItem(EntryNum++, "Repeat", 0);
            WxListCtrl7->SetItemData(tmp, 0);
            buff[0] = 0;
            if (RepeatEach == 1) sprintf(buff+strlen(buff),"each ");
            if (RepeatEach == 2) sprintf(buff+strlen(buff),"each second ");
            if (RepeatDOW != -1) {
                switch (RepeatDOW) {
                    case 1: sprintf(buff+strlen(buff),"Monday ");      break;
                    case 2: sprintf(buff+strlen(buff),"Tuesday ");     break;
                    case 3: sprintf(buff+strlen(buff),"Wednesday ");   break;
                    case 4: sprintf(buff+strlen(buff),"Thursday ");    break;
                    case 5: sprintf(buff+strlen(buff),"Friday ");      break;
                    case 6: sprintf(buff+strlen(buff),"Saturday ");    break;
                    case 7: sprintf(buff+strlen(buff),"Sunday ");      break;
                    default:sprintf(buff+strlen(buff)," ");
                }
            }
            if (RepeatDay != -1) {
                sprintf(buff+strlen(buff),"%i ",RepeatDay);
                if (RepeatMonth != -1) {
                    switch (RepeatMonth) {
                        case  1: sprintf(buff+strlen(buff),"January ");    break;
                        case  2: sprintf(buff+strlen(buff),"February ");   break;
                        case  3: sprintf(buff+strlen(buff),"March ");      break;
                        case  4: sprintf(buff+strlen(buff),"April ");      break;
                        case  5: sprintf(buff+strlen(buff),"May ");        break;
                        case  6: sprintf(buff+strlen(buff),"June ");       break;
                        case  7: sprintf(buff+strlen(buff),"July ");       break;
                        case  8: sprintf(buff+strlen(buff),"August ");     break;
                        case  9: sprintf(buff+strlen(buff),"September ");  break;
                        case 10: sprintf(buff+strlen(buff),"October ");    break;
                        case 11: sprintf(buff+strlen(buff),"November ");   break;
                        case 12: sprintf(buff+strlen(buff),"December ");   break;
                        default:sprintf(buff+strlen(buff)," ");
                    }
                } else {
                    sprintf(buff+strlen(buff),"month day ");
                }
            }
            WxListCtrl7->SetItem(tmp, 1, buff);
        }
    }
}

/*
 * Mnuconfiguration1147Click
 */
void MainFrm::Mnuconfiguration1147Click(wxCommandEvent& event)
{
    CfgDlg *dialog = new CfgDlg(this,-1,"Configuration",wxDefaultPosition,wxDefaultSize,AboutDlg_STYLE);

    dialog->ShowModal();

    dialog->Destroy();
}

/*
 * Mnumenuitem11020Click
 */
void MainFrm::Mnumenuitem11020Click(wxCommandEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
    GSM_File                        ReadSaveFile;
    GSM_FileFolderInfoListSubEntry  *SubEntry;
    int                             i,Num=0;
    wchart                          x;
    long                            item=-1,item2;
    bool                            Multiple = FALSE;

    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
    return;
            
    for (;;) {
        item = WxListCtrl1->GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
        if (item == -1) break;
        item2 = item;
        
        if (WxListCtrl1->GetItemText(item2)== "..") {
            Multiple = TRUE;
            break;
        }
        if (WxListCtrl1->GetItemText(0)== "..") item2--;
        SubEntry = NULL;
        for (i=0;i<=item2;i++) List.GetNext(&SubEntry);
        if (SubEntry->Info.Folder) {
            Multiple = TRUE;
            break;
        }
        Num++;
        if (Num==2) {
            Multiple = TRUE;
            break;
        }
    }
    if (Multiple) {
        WxDirDialog1->ShowModal();
        wxMessageBox("Not implemented",
                wxT("Error"),
                wxICON_WARNING | wxOK);
        return;
    }

    item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);
    if (WxListCtrl1->GetItemText(0)== "..") item--;
    SubEntry = NULL;
    for (i=0;i<=item;i++) List.GetNext(&SubEntry);
    CopyUnicode(FileFolderID,FileFolderID0);
    CopyUnicode(SubEntry->Info.GetID(),FileFolderID);

    Dialog = new wxProgressDialog("Reading file", SubEntry->Info.GetName(), 100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
    ReadSaveFile.Info.SetID(FileFolderID);
    while(true) {
        error = s->Phones->Current->GetFilePart(&ReadSaveFile);
        if (error.Code!=GSM_ERR_NONE) {
              PrintError(error);
        }

        if (!Dialog->Update((int)ReadSaveFile.Buffer.size()*100/ReadSaveFile.Info.Size,"",&skip)) break;
        if (ReadSaveFile.Info.Size == ReadSaveFile.Buffer.size()) break;
    }
    delete Dialog;
    WxSaveFileDialog1->SetFilename(SubEntry->Info.GetName());
    if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
    ReadSaveFile.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
}

/*
 * Mnuproperties1026Click
 */
void MainFrm::Mnuproperties1026Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnurename1024Click
 */
void MainFrm::Mnurename1024Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuaddfile1027Click
 */
void MainFrm::Mnuaddfile1027Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuaddfolder1022Click
 */
void MainFrm::Mnuaddfolder1022Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnudelete1023Click
 */
void MainFrm::Mnudelete1023Click(wxCommandEvent& event)
{
    wxMessageBox("Not implemented",
            wxT("Error"),
            wxICON_WARNING | wxOK);
}

/*
 * Mnuforward1148Click
 */
void MainFrm::Mnuforward1148Click(wxCommandEvent& event)
{
	// insert your code here
}

/*
 * WxListCtrl4RightClick
 */
void MainFrm::WxListCtrl4RightClick(wxListEvent& event)
{
    PopupMenu(WxPopupMenu2, wxDefaultPosition);
}
