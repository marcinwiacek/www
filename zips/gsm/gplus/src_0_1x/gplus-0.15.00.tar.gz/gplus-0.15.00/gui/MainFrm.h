//---------------------------------------------------------------------------
//
// Name:        MainFrm.h
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: MainFrm class declaration
//
//---------------------------------------------------------------------------

#ifndef __MainFrm_h__
#define __MainFrm_h__

#ifdef __BORLANDC__
        #pragma hdrstop
#endif

#ifndef WX_PRECOMP
        #include <wx/wx.h>
        #include <wx/frame.h>
#else
        #include <wx/wxprec.h>
#endif

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
#include <wx/dirdlg.h>
#include <wx/filedlg.h>
#include <wx/menu.h>
#include <wx/checkbox.h>
#include <wx/calctrl.h>
#include <wx/choice.h>
#include <wx/button.h>
#include <wx/listctrl.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/sizer.h>
#include <wx/statusbr.h>
////Header Include End
#include <wx/progdlg.h>

////Dialog Style Start
#undef MainFrm_STYLE
#define MainFrm_STYLE wxCAPTION | wxRESIZE_BORDER | wxSYSTEM_MENU | wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class MainFrm : public wxFrame
{
        private:
                DECLARE_EVENT_TABLE();
                
        public:
                MainFrm(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Project2"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = MainFrm_STYLE);
                virtual ~MainFrm();
                void Mnuexit1017Click1(wxCommandEvent& event);
                void WxListCtrl1ItemActivated(wxListEvent& event);
                void WxListCtrl1RightClick(wxListEvent& event);
                void WxListCtrl1BeginDrag(wxListEvent& event);
                void WxButton1Click(wxCommandEvent& event);
                void WxListCtrl2ItemActivated(wxListEvent& event);
                void WxButton3Click(wxCommandEvent& event);
        void Mnuabout1019Click(wxCommandEvent& event);
                void WxChoice1Selected(wxCommandEvent& event );
                void WxListCtrl4ItemActivated(wxListEvent& event);
                void WxButton2Click(wxCommandEvent& event);
                void wxNotebook1PageChanged(wxNotebookEvent& event);
		void WxCalendarCtrl1SelChanged(wxCalendarEvent& event);
		void WxCheckBox1Click(wxCommandEvent& event);
		void WxListCtrl6ItemActivated(wxListEvent& event);
	void Mnuconfiguration1147Click(wxCommandEvent& event);
		void WxListCtrl2ColLeftClick(wxListEvent& event);
	void Mnumenuitem11020Click(wxCommandEvent& event);
	void Mnuproperties1026Click(wxCommandEvent& event);
	void Mnurename1024Click(wxCommandEvent& event);
	void Mnuaddfile1027Click(wxCommandEvent& event);
	void Mnuaddfolder1022Click(wxCommandEvent& event);
	void Mnudelete1023Click(wxCommandEvent& event);
	void Mnuforward1148Click(wxCommandEvent& event);
		void WxListCtrl4RightClick(wxListEvent& event);
        private:
                //Do not add custom control declarations
                //wxDev-C++ will remove them. Add custom code after the block.
                ////GUI Control Declaration Start
		wxMenu *WxPopupMenu1;
		wxDirDialog *WxDirDialog1;
		wxMenu *WxPopupMenu2;
		wxFileDialog *WxOpenFileDialog1;
		wxFileDialog *WxSaveFileDialog1;
		wxMenuBar *WxMenuBar1;
		wxPanel *WxNoteBookPage8;
		wxPanel *WxNoteBookPage7;
		wxPanel *WxNoteBookPage6;
		wxListCtrl *WxListCtrl7;
		wxListCtrl *WxListCtrl6;
		wxGridSizer *WxGridSizer4;
		wxCheckBox *WxCheckBox1;
		wxCalendarCtrl *WxCalendarCtrl1;
		wxPanel *WxPanel5;
		wxBoxSizer *WxBoxSizer6;
		wxButton *WxButton2;
		wxPanel *WxPanel4;
		wxBoxSizer *WxBoxSizer5;
		wxPanel *WxNoteBookPage5;
		wxListCtrl *WxListCtrl5;
		wxBoxSizer *WxBoxSizer4;
		wxPanel *WxNoteBookPage4;
		wxNotebook *WxNotebook2;
		wxListCtrl *WxListCtrl4;
		wxGridSizer *WxGridSizer3;
		wxChoice *WxChoice1;
		wxButton *WxButton4;
		wxButton *WxButton3;
		wxPanel *WxPanel2;
		wxBoxSizer *WxBoxSizer3;
		wxPanel *WxNoteBookPage3;
		wxListCtrl *WxListCtrl3;
		wxListCtrl *WxListCtrl2;
		wxGridSizer *WxGridSizer2;
		wxButton *WxButton1;
		wxPanel *WxPanel1;
		wxBoxSizer *WxBoxSizer2;
		wxPanel *WxNoteBookPage1;
		wxListCtrl *WxListCtrl1;
		wxPanel *WxPanel3;
		wxBoxSizer *WxBoxSizer1;
		wxPanel *WxNoteBookPage2;
		wxNotebook *wxNotebook1;
		wxGridSizer *WxGridSizer1;
		wxStatusBar *WxStatusBar1;
                ////GUI Control Declaration End
                
        private:
                //Note: if you receive any error with these enum IDs, then you need to
                //change your old form code that are based on the #define control IDs.
                //#defines may replace a numeric value for the enum names.
                //Try copy and pasting the below block in your old form header files.
                enum
                {
                        ////GUI Enum Control ID Start
			ID_MNU_MENUITEM1_1020 = 1020,
			ID_MNU_DELETE_1023 = 1023,
			ID_MNU_ADDFOLDER_1022 = 1022,
			ID_MNU_ADDFILE_1027 = 1027,
			ID_MNU_RENAME_1024 = 1024,
			ID_MNU_PROPERTIES_1026 = 1026,
			
			ID_MNU_FORWARD_1148 = 1148,
			
			ID_MNU_MENUITEM1_1016 = 1016,
			ID_MNU_EXIT_1017 = 1017,
			ID_MNU_TOOLS_1146 = 1146,
			ID_MNU_CONFIGURATION_1147 = 1147,
			ID_MNU_HELP_1018 = 1018,
			ID_MNU_ABOUT_1019 = 1019,
			
			ID_WXNOTEBOOKPAGE8 = 1144,
			ID_WXNOTEBOOKPAGE7 = 1143,
			ID_WXNOTEBOOKPAGE6 = 1142,
			ID_WXLISTCTRL7 = 1141,
			ID_WXLISTCTRL6 = 1140,
			ID_WXCHECKBOX1 = 1139,
			ID_WXCALENDARCTRL1 = 1138,
			ID_WXPANEL5 = 1136,
			ID_WXBUTTON2 = 1145,
			ID_WXPANEL4 = 1118,
			ID_WXNOTEBOOKPAGE5 = 1116,
			ID_WXLISTCTRL5 = 1114,
			ID_WXNOTEBOOKPAGE4 = 1110,
			ID_WXNOTEBOOK2 = 1109,
			ID_WXLISTCTRL4 = 1103,
			ID_WXCHOICE1 = 1108,
			ID_WXBUTTON4 = 1107,
			ID_WXBUTTON3 = 1106,
			ID_WXPANEL2 = 1101,
			ID_WXNOTEBOOKPAGE3 = 1099,
			ID_WXLISTCTRL3 = 1096,
			ID_WXLISTCTRL2 = 1095,
			ID_WXBUTTON1 = 1097,
			ID_WXPANEL1 = 1070,
			ID_WXNOTEBOOKPAGE1 = 1029,
			ID_WXLISTCTRL1 = 1015,
			ID_WXPANEL3 = 1115,
			ID_WXNOTEBOOKPAGE2 = 1013,
			ID_WXNOTEBOOK1 = 1012,
			ID_WXSTATUSBAR1 = 1006,
                        ////GUI Enum Control ID End
                        ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
                };
                
        private:
                void OnClose(wxCloseEvent& event);
                void CreateGUIControls();
                void EnterFolder();
                void DisplayCalendar();
		void ReadPhonebook(int Num, wxString Name);
};

#endif
