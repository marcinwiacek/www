//---------------------------------------------------------------------------

#ifndef readfileH
#define readfileH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class ReadFileThread : public TThread
{
__published:
private:
public:
	void __fastcall Execute();
	__fastcall ReadFileThread(bool CreateSuspended);
};

class TRFile : public TForm
{
__published:	// IDE-managed Components
	TProgressBar *ProgressBar1;
	TButton *Button1;
	TLabel *Label2;
	void __fastcall FormShow(TObject *Sender);
private:	// User declarations
	ReadFileThread *TRFileThread;
public:		// User declarations
	__fastcall TRFile(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRFile *RFile;
//---------------------------------------------------------------------------
#endif
