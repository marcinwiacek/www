//----------------------------------------------------------------------------
#ifndef SDIMainH
#define SDIMainH
//----------------------------------------------------------------------------
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <StdCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <Controls.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <Classes.hpp>
#include <Windows.hpp>
#include <System.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>

#include "../../common/service/gsmmisc.h"
#include "../../common/gsmstate.h"



//----------------------------------------------------------------------------
class TSDIAppForm : public TForm
{
__published:
	TOpenDialog *OpenDialog;
	TSaveDialog *SaveDialog;
    TActionList *ActionList1;
	TAction *FileNew1;
    TAction *FileOpen1;
    TAction *FileSave1;
    TAction *FileSaveAs1;
    TAction *FileExit1;
	TEditCut *EditCut1;
    TEditCopy *EditCopy1;
	TEditPaste *EditPaste1;
    TAction *HelpAbout1;
    TStatusBar *StatusBar;
	TImageList *ImageList1;
    TMainMenu *MainMenu1;
    TMenuItem *File1;
    TMenuItem *FileExitItem;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TListView *ListView1;
	TMenuItem *Help1;
	TMenuItem *About1;
	TPopupMenu *PopupMenu1;
	TMenuItem *Rename1;
	TMenuItem *Addfolder1;
	TMenuItem *Addfile1;
	TMenuItem *Delete1;
	TMenuItem *N1;
	TMenuItem *N2;
	TMenuItem *Properties1;
	TMenuItem *Getfile1;
	TMenuItem *N3;
	TTabSheet *TabSheet2;
	TPanel *Panel1;
	TPanel *Panel2;
	TSplitter *Splitter1;
	TListView *ListView2;
	TComboBox *ComboBox1;
	TTabSheet *TabSheet3;
	TTabSheet *TabSheet4;void __fastcall FileNew1Execute(TObject *Sender);
		void __fastcall FileExit1Execute(TObject *Sender);
	void __fastcall EnterFolder();
	void __fastcall ListView1DblClick(TObject *Sender);
	void __fastcall About1Click(TObject *Sender);
	void __fastcall PopupMenu1Popup(TObject *Sender);
	void __fastcall Getfile1Click(TObject *Sender);

private:
public:
	FILE 				*DebFile;
	bool 				UseDeb;
	GSM_StateMachine 	*s;
	INI_File 			CFG;
	GSM_File			ReadSaveFile;

	virtual __fastcall TSDIAppForm(TComponent *AOwner);
};
//----------------------------------------------------------------------------
extern TSDIAppForm *SDIAppForm;
//----------------------------------------------------------------------------
#endif
