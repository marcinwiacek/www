//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "readfile.h"
#include "sdimain.h"

#include "../../common/service/gsmmisc.h"
#include "../../common/gsmstate.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRFile *RFile;

__fastcall ReadFileThread::ReadFileThread(bool CreateSuspended): TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void __fastcall ReadFileThread::Execute()
{
	GSM_Error error;

	RFile->ProgressBar1->Position = 0;
	SDIAppForm->ReadSaveFile.Buffer.clear();
	SDIAppForm->ReadSaveFile.Info.Size = 0;
	while(true) {
		error = SDIAppForm->s->Phones->Current->GetFilePart(&SDIAppForm->ReadSaveFile);
		if (error.Code!=GSM_ERR_NONE) {
			break;
		}

//		PrintTimeLeft("  Done: ", File->Buffer.size(),File->Info.Size);

		RFile->ProgressBar1->Position = int(SDIAppForm->ReadSaveFile.Buffer.size()*100/SDIAppForm->ReadSaveFile.Info.Size);
		if (SDIAppForm->ReadSaveFile.Info.Size == SDIAppForm->ReadSaveFile.Buffer.size()) break;
	}
	RFile->ModalResult = mrOk;
// ---- Place thread code here ----
}

//---------------------------------------------------------------------------
__fastcall TRFile::TRFile(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRFile::FormShow(TObject *Sender)
{
TRFileThread = new ReadFileThread(false);
}
//---------------------------------------------------------------------------

