//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SDIMain.h"
#include "About.h"
#include "ReadFile.h"

#include "../../common/service/gsmmisc.h"
#include "../../common/gsmstate.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TSDIAppForm *SDIAppForm;

wchar_t FileFolderID[500];
wchart ParentFolderID[20];
int ParentFolderIDNum = 1;
wchart CurrentFolderName;

boolean PrintError (GSM_Error error)
{
	unsigned char buffer[2000];

	if (error.Code == GSM_ERR_NONE) {
		return false;
	}
	sprintf(buffer,"%s",GSM_GetErrorInfo(error));
	Application->MessageBoxA(buffer,"Error",0);
	return true;
}
char *DayOfWeekStr(int Year, int Month, int Day)
{
	switch (DayOfWeek(Year,Month,Day)) {
	case 1: return "Mon";
	case 2: return "Tue";
	case 3: return "Wed";
	case 4: return "Thu";
	case 5: return "Fri";
	case 6: return "Sat";
	case 7: return "Sun";
	default:return "";
	}
}

//---------------------------------------------------------------------
void __fastcall TSDIAppForm::EnterFolder()
{
	BOOLEAN				Start2;
	wchar_t				name[20];
	char 				buff[200];
	GSM_MemoryType		Mem;
	TListColumn 		*ListColumn;
	TListItem 			*ListItem,*ListItem2;
	unsignedstring		Buffer2;
	BOOLEAN				Found;
	GSM_Error			error;
	GSM_FileFolderInfo 	FInfo;
	GSM_FileFolderInfoList	List;
	GSM_FileFolderInfoListSubEntry  *SubEntry;
	int j = 0;


	ListView1->Enabled = false;
	ListView1->Items->Clear();
	ListView1->Enabled = true;

	//StatusBar->SimpleText=ParentFolderIDNum;
	SDIAppForm->Caption=CurrentFolderName.data();

	//root
	if (ParentFolderIDNum == 1) {
		name[0] = 0;
			while (true) {

			error = s->Phones->Current->GetNextRootFolderID(name,&Mem);
			if (error.Code == GSM_ERR_EMPTY) break;
			if (error.Code != GSM_ERR_MEMORY && error.Code != GSM_ERR_NONE) return;
			ListItem = ListView1->Items->Add();
			if (Mem == MEM_PHONE) {
				sprintf(buff,"Phone memory (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
			} else {
				sprintf(buff,"Memory card (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
			}
			ListItem->Caption = buff;
			ListItem->SubItems->Add("");
			ListItem->SubItems->Add("Folder");
			ListItem->SubItems->Add("");
			ListItem->SubItems->Add("");
			Buffer2.clear();
			UnicodeToUTF8QuotedPrintable(name, &Buffer2);
			ListItem->SubItems->Add((char *)Buffer2.data());
		}
		return;
	}
	ListItem = ListView1->Items->Add();
	ListItem->Caption = "..";
	ListItem->SubItems->Add("");
	ListItem->SubItems->Add("Folder");
	ListItem->SubItems->Add("");
	ListItem->SubItems->Add("");
	Buffer2.clear();
	UnicodeToUTF8QuotedPrintable((wchar_t *)ParentFolderID[ParentFolderIDNum-2].data(), &Buffer2);
	ListItem->SubItems->Add((char *)Buffer2.data());

	List.Info.SetID(FileFolderID);
	Start2 = TRUE;
	while (1) {
		error = s->Phones->Current->GetFolderInfoList(&List,Start2);
		Start2 = FALSE;
		if (error.Code == GSM_ERR_FOLDER_MORE) {
//				StatusBar->SimpleText="Reading "+j;
//				j++;
//				PrintStdErr("Reading filesystem folder content: %i",j);
			continue;
		}
		if (error.Code == GSM_ERR_FOLDER_PART ||
			error.Code == GSM_ERR_EMPTY ||
			error.Code == GSM_ERR_MEMORY) {
			break;
		}
		if (error.Code != GSM_ERR_NONE) {
			break;
		}
		break;
	}
	SubEntry = NULL;
	while (List.GetNext(&SubEntry) == TRUE) {
		if (!List.SubEntryFullData) {
			error = s->Phones->Current->GetFileFolderInfo(&SubEntry->Info);
		}
		ListItem = ListView1->Items->Add();
		sprintf(buff,"%s",UnicodeToStringReturn(SubEntry->Info.GetName()));
		ListItem->Caption = buff;
		if (SubEntry->Info.Folder) {
			ListItem->SubItems->Add("");
			ListItem->SubItems->Add("Folder");
		} else {
			sprintf(buff, "%i",SubEntry->Info.Size);
			ListItem->SubItems->Add(buff);
			ListItem->SubItems->Add("File");
		}
		if (SubEntry->Info.ModificationDateTimeAvailable) {
			sprintf(buff, "%s %02i:%02i:%02i %02i-%02i-%04i",
				DayOfWeekStr(
					SubEntry->Info.ModificationDateTime.Year,
					SubEntry->Info.ModificationDateTime.Month,
					SubEntry->Info.ModificationDateTime.Day),
				SubEntry->Info.ModificationDateTime.Hour,
				SubEntry->Info.ModificationDateTime.Minute,
				SubEntry->Info.ModificationDateTime.Second,
				SubEntry->Info.ModificationDateTime.Day,
				SubEntry->Info.ModificationDateTime.Month,
				SubEntry->Info.ModificationDateTime.Year);
		} else {
			sprintf(buff, "");
		}
		ListItem->SubItems->Add(buff);
		ListItem->SubItems->Add("");
		Buffer2.clear();
		UnicodeToUTF8QuotedPrintable(SubEntry->Info.GetID(), &Buffer2);
		ListItem->SubItems->Add((char *)Buffer2.data());
	}
}

//---------------------------------------------------------------------
__fastcall TSDIAppForm::TSDIAppForm(TComponent *AOwner)
	: TForm(AOwner)
{
	GSM_Error 			error;
	wchar_t				name[20];
	char 				buff[200];
	GSM_MemoryType		Mem;
	TListColumn 		*ListColumn;
	TListItem 			*ListItem,*ListItem2;
	unsignedstring		Buffer2;

	DebFile = NULL;
	UseDeb = false;
	s = new GSM_StateMachine(DebFile,"",UseDeb);

	ListView1->Columns->Clear();

	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "Name";
	ListColumn->Width = 170;
	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "Size";
	ListColumn->Width = 100;
	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "Type";
	ListColumn->Width = 70;
	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "Modified";
	ListColumn->Width = 170;
	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "Attribs";
	ListColumn->Width = 70;
	ListColumn = ListView1->Columns->Add();
	ListColumn->Caption = "ID";
	ListColumn->Width = 0;

	s->ReadCfgFile(&CFG);
	error = s->OpenFromCfgFile(&CFG);
	if (PrintError(error)) {
		exit(0);
	}

	EnterFolder();
}
//---------------------------------------------------------------------

void __fastcall TSDIAppForm::FileNew1Execute(TObject *Sender)
{
  // Do nothing
}
//---------------------------------------------------------------------------




void __fastcall TSDIAppForm::FileExit1Execute(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------

void __fastcall TSDIAppForm::ListView1DblClick(TObject *Sender)
{
	int i;
	wchart x;

	if (ListView1->Selected==NULL) return;

	UTF8QuotedPrintableToUnicode( ListView1->Selected->SubItems->Strings[4].c_str(), FileFolderID, ListView1->Selected->SubItems->Strings[4].Length());
	if (ListView1->Selected->SubItems->Strings[1] == "Folder") {
		if (ListView1->Selected->Caption == "..") {
			for (i=CurrentFolderName.length(); i > 0; i--) {
				if (CurrentFolderName.data()[i]=='\\') {
					break;
				}
			}
			x.append(CurrentFolderName.data(),i);
			CurrentFolderName.clear();
			CurrentFolderName.append(x.data());

			ParentFolderID[ParentFolderIDNum-1].clear();
			ParentFolderIDNum--;
			CopyUnicode((wchar_t *)ParentFolderID[ParentFolderIDNum-1].data(),FileFolderID);
		} else {
			CurrentFolderName.push_back('\\');
			CurrentFolderName.append(StringToUnicodeReturn(ListView1->Selected->Caption.c_str()));
			ParentFolderID[ParentFolderIDNum].append(FileFolderID);
			ParentFolderIDNum++;
		}
		EnterFolder();
		return;
	}
	Getfile1->Click();
}
//---------------------------------------------------------------------------

void __fastcall TSDIAppForm::About1Click(TObject *Sender)
{
	AboutBox->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TSDIAppForm::PopupMenu1Popup(TObject *Sender)
{
//if root disable

	if (ListView1->Selected==NULL) {
			Getfile1->Enabled=false;
			Delete1->Enabled=false;
			Rename1->Enabled=false;
			Properties1->Enabled=false;
	} else {
			Delete1->Enabled=true;
			Rename1->Enabled=true;
			Properties1->Enabled=true;
			if (ListView1->Selected->SubItems->Strings[1] == "Folder") {
				Getfile1->Enabled=false;

			} else {
				Getfile1->Enabled=true;

			}
	}
}
//---------------------------------------------------------------------------

void __fastcall TSDIAppForm::Getfile1Click(TObject *Sender)
{
	UTF8QuotedPrintableToUnicode( ListView1->Selected->SubItems->Strings[4].c_str(), FileFolderID, ListView1->Selected->SubItems->Strings[4].Length());
	RFile->Label2->Caption = ListView1->Selected->Caption;
	ReadSaveFile.Info.SetID(FileFolderID);
	if (RFile->ShowModal()==mrOk) {
		SaveDialog->FileName=ReadSaveFile.Info.GetName();
		if (!SaveDialog->Execute()) return;
		ReadSaveFile.SaveToDisk(SaveDialog->FileName.c_str());
	}
}
//---------------------------------------------------------------------------


