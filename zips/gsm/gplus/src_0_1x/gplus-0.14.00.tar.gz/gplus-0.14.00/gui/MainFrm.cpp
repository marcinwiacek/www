//---------------------------------------------------------------------------
//
// Name:        MainFrm.cpp
// Author:      Marcinello
// Created:     2006-12-03 12:26:10
// Description: MainFrm class implementation
//
//---------------------------------------------------------------------------

#include "MainFrm.h"
#include "AboutDlg.h"

#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

FILE 			          *DebFile;
bool 			          UseDeb;
GSM_StateMachine 	      *s;
INI_File 		          CFG;

wchar_t 		          FileFolderID[500], FileFolderID0[500];
wchart 			          ParentFolderID[20];
int 			          ParentFolderIDNum = 1;
wchart 			          CurrentFolderName, CurrentFolderName0;
int     		          FileSystemNum = 0;
GSM_FileFolderInfoList	  List;

GSM_Backup                Backup;
int                       PbkNum = 0;

//----------------------------------------------------------------------------
// MainFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(MainFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(MainFrm::OnClose)
	EVT_MENU(ID_MNU_EXIT_1017, MainFrm::Mnuexit1017Click1)
	EVT_MENU(ID_MNU_ABOUT_1019, MainFrm::Mnuabout1019Click)
	EVT_CHOICE(ID_WXCHOICE1,MainFrm::WxChoice1Selected)
	EVT_BUTTON(ID_WXBUTTON3,MainFrm::WxButton3Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL2,MainFrm::WxListCtrl2ItemActivated)
	EVT_BUTTON(ID_WXBUTTON1,MainFrm::WxButton1Click)
	
	EVT_LIST_ITEM_ACTIVATED(ID_WXLISTCTRL1,MainFrm::WxListCtrl1ItemActivated)
	EVT_LIST_ITEM_RIGHT_CLICK(ID_WXLISTCTRL1,MainFrm::WxListCtrl1RightClick)
END_EVENT_TABLE()
////Event Table End

boolean PrintError (GSM_Error error)
{
	unsigned char buffer[2000];

	if (error.Code == GSM_ERR_NONE) return false;
	sprintf((char *)buffer,"%s",GSM_GetErrorInfo(error));
    	wxMessageBox(buffer,
        	wxT("Error"),
	        wxICON_WARNING | wxOK);
		return true;
}

MainFrm::MainFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
    GSM_Error error;
    
	CreateGUIControls();

	DebFile = NULL;
	UseDeb = false;
	s = new GSM_StateMachine(DebFile,"",UseDeb);
	s->ReadCfgFile(&CFG);

	error = s->OpenFromCfgFile(&CFG);
	if (PrintError(error)) {
		exit(0);
	}
    EnterFolder();	
}

MainFrm::~MainFrm()
{
}

void MainFrm::CreateGUIControls()
{
	//Do not add custom code here
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxStatusBar1 = new wxStatusBar(this, ID_WXSTATUSBAR1);

	WxGridSizer1 = new wxGridSizer(1, 1, 0, 0);
	this->SetSizer(WxGridSizer1);
	this->SetAutoLayout(true);

	wxNotebook1 = new wxNotebook(this, ID_WXNOTEBOOK1, wxPoint(0,0),wxSize(568,470));
	WxGridSizer1->Add(wxNotebook1,1,wxEXPAND | 0,0);

	WxNoteBookPage2 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE2, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage2, wxT("FileSystem"));

	WxBoxSizer1 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage2->SetSizer(WxBoxSizer1);
	WxNoteBookPage2->SetAutoLayout(true);

	WxPanel3 = new wxPanel(WxNoteBookPage2, ID_WXPANEL3, wxPoint(14,5), wxSize(564,25));
	WxBoxSizer1->Add(WxPanel3,0,wxALIGN_TOP | wxALL,5);

	WxListCtrl1 = new wxListCtrl(WxNoteBookPage2, ID_WXLISTCTRL1, wxPoint(5,40), wxSize(583,311), wxLC_REPORT | wxLC_SINGLE_SEL);
	WxListCtrl1->InsertColumn(0,wxT("Attribs"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Modified"),wxLIST_FORMAT_LEFT,170 );
	WxListCtrl1->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,70 );
	WxListCtrl1->InsertColumn(0,wxT("Size"),wxLIST_FORMAT_LEFT,80 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,170 );
	WxBoxSizer1->Add(WxListCtrl1,1,wxEXPAND | wxALL,5);

	WxNoteBookPage1 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE1, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage1, wxT("PhoneBook"));

	WxBoxSizer2 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage1->SetSizer(WxBoxSizer2);
	WxNoteBookPage1->SetAutoLayout(true);

	WxPanel1 = new wxPanel(WxNoteBookPage1, ID_WXPANEL1, wxPoint(0,0), wxSize(533,31));
	WxBoxSizer2->Add(WxPanel1,0,wxALIGN_TOP | 0,0);

	WxButton1 = new wxButton(WxPanel1, ID_WXBUTTON1, wxT("Get from phone"), wxPoint(8,5), wxSize(86,20), 0, wxDefaultValidator, wxT("WxButton1"));

	WxGridSizer2 = new wxGridSizer(1, 1, 0, 0);
	WxBoxSizer2->Add(WxGridSizer2, 1, wxEXPAND | 0, 0);

	WxListCtrl2 = new wxListCtrl(WxNoteBookPage1, ID_WXLISTCTRL2, wxPoint(11,6), wxSize(149,159), wxLC_REPORT);
	WxListCtrl2->InsertColumn(0,wxT("Time"),wxLIST_FORMAT_LEFT,150 );
	WxListCtrl2->InsertColumn(0,wxT("Number"),wxLIST_FORMAT_LEFT,130 );
	WxListCtrl2->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,250 );
	WxListCtrl2->InsertColumn(0,wxT("Location"),wxLIST_FORMAT_LEFT,50 );
	WxGridSizer2->Add(WxListCtrl2,1,wxEXPAND | wxALL,5);

	WxListCtrl3 = new wxListCtrl(WxNoteBookPage1, ID_WXLISTCTRL3, wxPoint(5,177), wxSize(162,162), wxLC_REPORT);
	WxListCtrl3->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,200 );
	WxListCtrl3->InsertColumn(0,wxT("Type"),wxLIST_FORMAT_LEFT,100 );
	WxGridSizer2->Add(WxListCtrl3,1,wxEXPAND | wxALL,5);

	WxNoteBookPage3 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE3, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage3, wxT("SMS"));

	WxBoxSizer3 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage3->SetSizer(WxBoxSizer3);
	WxNoteBookPage3->SetAutoLayout(true);

	WxPanel2 = new wxPanel(WxNoteBookPage3, ID_WXPANEL2, wxPoint(5,5), wxSize(523,36));
	WxBoxSizer3->Add(WxPanel2,0,wxALIGN_TOP | wxALL,5);

	WxButton3 = new wxButton(WxPanel2, ID_WXBUTTON3, wxT("Get from phone"), wxPoint(167,8), wxSize(86,22), 0, wxDefaultValidator, wxT("WxButton3"));

	WxButton4 = new wxButton(WxPanel2, ID_WXBUTTON4, wxT("Send"), wxPoint(259,8), wxSize(86,22), 0, wxDefaultValidator, wxT("WxButton4"));

	wxArrayString arrayStringFor_WxChoice1;
	WxChoice1 = new wxChoice(WxPanel2, ID_WXCHOICE1, wxPoint(7,9), wxSize(152,21), arrayStringFor_WxChoice1, 0, wxDefaultValidator, wxT("WxChoice1"));
	WxChoice1->SetSelection(-1);

	WxGridSizer3 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer3->Add(WxGridSizer3, 1, wxEXPAND | wxALL, 5);

	WxListCtrl4 = new wxListCtrl(WxNoteBookPage3, ID_WXLISTCTRL4, wxPoint(5,6), wxSize(174,172), wxLC_REPORT);
	WxGridSizer3->Add(WxListCtrl4,1,wxEXPAND | wxALL,5);

	WxNotebook2 = new wxNotebook(WxNoteBookPage3, ID_WXNOTEBOOK2, wxPoint(6,189),wxSize(172,174));
	WxGridSizer3->Add(WxNotebook2,1,wxEXPAND | wxALL,5);

	WxNoteBookPage4 = new wxPanel(WxNotebook2, ID_WXNOTEBOOKPAGE4, wxPoint(4,24), wxSize(164,146));
	WxNotebook2->AddPage(WxNoteBookPage4, wxT("SMS parts"));

	WxBoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
	WxNoteBookPage4->SetSizer(WxBoxSizer4);
	WxNoteBookPage4->SetAutoLayout(true);

	WxListCtrl5 = new wxListCtrl(WxNoteBookPage4, ID_WXLISTCTRL5, wxPoint(5,5), wxSize(150,135), wxLC_REPORT);
	WxBoxSizer4->Add(WxListCtrl5,1,wxEXPAND | wxALL,5);

	WxNoteBookPage5 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE5, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage5, wxT("Calendar"));

	WxBoxSizer5 = new wxBoxSizer(wxVERTICAL);
	WxNoteBookPage5->SetSizer(WxBoxSizer5);
	WxNoteBookPage5->SetAutoLayout(true);

	WxPanel4 = new wxPanel(WxNoteBookPage5, ID_WXPANEL4, wxPoint(5,5), wxSize(545,28));
	WxBoxSizer5->Add(WxPanel4,0,wxALIGN_CENTER | wxALL,5);

	WxMenuBar1 = new wxMenuBar();
	wxMenu *ID_MNU_MENUITEM1_1016_Mnu_Obj = new wxMenu(0);
	ID_MNU_MENUITEM1_1016_Mnu_Obj->Append(ID_MNU_EXIT_1017, wxT("&Exit"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_MENUITEM1_1016_Mnu_Obj, wxT("&File"));
	
	wxMenu *ID_MNU_HELP_1018_Mnu_Obj = new wxMenu(0);
	ID_MNU_HELP_1018_Mnu_Obj->Append(ID_MNU_ABOUT_1019, wxT("&About"), wxT(""), wxITEM_NORMAL);
	WxMenuBar1->Append(ID_MNU_HELP_1018_Mnu_Obj, wxT("&Help"));
	SetMenuBar(WxMenuBar1);

	WxSaveFileDialog1 =  new wxFileDialog(this, wxT("Choose a file"), wxT(""), wxT(""), wxT("*.*"), wxSAVE);

	WxPopupMenu1 = new wxMenu(wxT(""));WxPopupMenu1->Append(ID_MNU_ADDFILE_1027, wxT("Add file"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_MENUITEM1_1020, wxT("Read file"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_ADDFOLDER_1022, wxT("Add folder"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_RENAME_1024, wxT("Rename"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->Append(ID_MNU_DELETE_1023, wxT("Delete"), wxT(""), wxITEM_NORMAL);
	WxPopupMenu1->AppendSeparator();
	WxPopupMenu1->Append(ID_MNU_PROPERTIES_1026, wxT("Properties"), wxT(""), wxITEM_NORMAL);

	WxBoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
	WxBoxSizer5->Add(WxBoxSizer6, 1, wxEXPAND | wxALL, 5);

	WxPanel5 = new wxPanel(WxNoteBookPage5, ID_WXPANEL5, wxPoint(5,9), wxSize(183,202));
	WxBoxSizer6->Add(WxPanel5,0,wxALIGN_LEFT | wxALL,5);

	WxGridSizer4 = new wxGridSizer(2, 1, 0, 0);
	WxBoxSizer6->Add(WxGridSizer4, 1, wxEXPAND | wxALL, 5);

	WxCalendarCtrl1 = new wxCalendarCtrl(WxPanel5, ID_WXCALENDARCTRL1, wxDateTime(6,(wxDateTime::Month)12,2006),wxPoint(5,2), wxSize(172,147), wxCAL_SUNDAY_FIRST | wxCAL_SHOW_HOLIDAYS | wxCAL_NO_MONTH_CHANGE | wxCAL_SHOW_SURROUNDING_WEEKS | wxCAL_SEQUENTIAL_MONTH_SELECTION);

	WxCheckBox1 = new wxCheckBox(WxPanel5, ID_WXCHECKBOX1, wxT("WxCheckBox1"), wxPoint(7,157), wxSize(160,21), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxListCtrl6 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL6, wxPoint(5,5), wxSize(51,95), wxLC_REPORT);
	WxGridSizer4->Add(WxListCtrl6,1,wxEXPAND | wxALL,5);

	WxListCtrl7 = new wxListCtrl(WxNoteBookPage5, ID_WXLISTCTRL7, wxPoint(10,120), wxSize(41,74), wxLC_REPORT);
	WxGridSizer4->Add(WxListCtrl7,1,wxEXPAND | wxALL,5);

	WxNoteBookPage6 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE6, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage6, wxT("ToDo"));

	WxNoteBookPage7 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE7, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage7, wxT("Notes"));

	WxNoteBookPage8 = new wxPanel(wxNotebook1, ID_WXNOTEBOOKPAGE8, wxPoint(4,24), wxSize(560,442));
	wxNotebook1->AddPage(WxNoteBookPage8, wxT("MMS"));

	SetStatusBar(WxStatusBar1);
	SetTitle(wxT("Gammu+ GUI"));
	SetIcon(wxNullIcon);
	
	GetSizer()->Fit(this);
	GetSizer()->SetSizeHints(this);
	Center();
	
	////GUI Items Creation End
	
//    wxString buf;
//    buf.Printf(_T("ala"));
//    long tmp = WxListCtrl1->InsertItem(FileSystemNum, buf, 0);
//    WxListCtrl1->SetItemData(tmp, 0);

//    buf.Printf(_T("bela"));
//    WxListCtrl1->SetItem(tmp, 1, buf);

//    buf.Printf(_T("cela"));
//    WxListCtrl1->SetItem(tmp, 2, buf);	
}

void MainFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}

/*
 * Mnuexit1017Click1
 */
void MainFrm::Mnuexit1017Click1(wxCommandEvent& event)
{
	Close();
}

char *DayOfWeekStr(int Year, int Month, int Day)
{
	switch (DayOfWeek(Year,Month,Day)) {
		case 1: return "Mon";
		case 2: return "Tue";
		case 3: return "Wed";
		case 4: return "Thu";
		case 5: return "Fri";
		case 6: return "Sat";
		case 7: return "Sun";
		default:return "";
	}
}

void MainFrm::EnterFolder()
{
	wchart 				              x;
    wxProgressDialog                  *Dialog;
    bool                              skip;
	BOOLEAN				              Start2;
	wchar_t				              name[20];
	char 				              buff[200];
	GSM_MemoryType			          Mem;
	unsignedstring			          Buffer2;
	BOOLEAN				              Found;
	GSM_Error			              error;
	GSM_FileFolderInfo 		          FInfo,*FInfo2;
	GSM_FileFolderInfoListSubEntry    *SubEntry;
	int 				              j = 0,i;
	long 				              tmp;

    Dialog = new wxProgressDialog("Reading folder", CurrentFolderName.data(), 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
	if (ParentFolderIDNum == 1) {
        error.Code = GSM_ERR_MEMORY;
    } else {
    	List.Info.SetID(FileFolderID);
    	Start2 = TRUE;
    	while (1) {
    		error = s->Phones->Current->GetFolderInfoList(&List,Start2);
    		if (error.Code == GSM_ERR_MEMORY) {
                wxMessageBox("Folder not available",
                	wxT("Error"),
        	        wxICON_WARNING | wxOK);
        	        //kopiowanie sciezki
        	        
        		for (i=CurrentFolderName.length(); i > 0; i--) {
        			if (CurrentFolderName.data()[i]=='\\') break;
        		}
        		x.append(CurrentFolderName.data(),i);
        		CurrentFolderName.clear();
        		CurrentFolderName.append(x.data());
        
        		ParentFolderID[ParentFolderIDNum-1].clear();
        		ParentFolderIDNum--;
                        	        
        	    CopyUnicode(FileFolderID0,FileFolderID);
        	    break;
            }
            if (Start2) {
            	WxListCtrl1->DeleteAllItems();
            	FileSystemNum = 0;
    
                WxStatusBar1->SetStatusText(CurrentFolderName.data(),0);
    
            	tmp = WxListCtrl1->InsertItem(FileSystemNum++, _T(".."), 0);
            	WxListCtrl1->SetItemData(tmp, 0);
            	WxListCtrl1->SetItem(tmp, 1, _T(""));
            	WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
            	WxListCtrl1->SetItem(tmp, 3, _T(""));
            	WxListCtrl1->SetItem(tmp, 4, _T(""));
            }
    		Start2 = FALSE;
    		if (error.Code == GSM_ERR_FOLDER_MORE) {
                if (!Dialog->UpdatePulse("",&skip)) break;
    			continue;
    		}
    		if (error.Code == GSM_ERR_FOLDER_PART) {
                wxMessageBox("There was read only folder part (it's phone firmware problem)",
                	wxT("Error"),
        	        wxICON_WARNING | wxOK);
        	    break;
            }
    		if (error.Code == GSM_ERR_EMPTY) {
    			break;
    		}
    		if (error.Code != GSM_ERR_NONE) {
    			break;
    		}
    		break;
    	}
    }
	delete Dialog;

    if (error.Code == GSM_ERR_MEMORY) {
    	WxListCtrl1->DeleteAllItems();
    	FileSystemNum = 0;

        WxStatusBar1->SetStatusText(CurrentFolderName.data(),0);

		name[0] = 0;
		List.ClearAll();
		while (true) {
			error = s->Phones->Current->GetNextRootFolderID(name,&Mem);
			if (error.Code == GSM_ERR_EMPTY) break;
			if (error.Code != GSM_ERR_MEMORY && error.Code != GSM_ERR_NONE) return;

		    FInfo2 = new GSM_FileFolderInfo;
			if (Mem == MEM_PHONE) {
				sprintf(buff,"Phone memory (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
			} else {
				sprintf(buff,"Memory card (%c%c)",UnicodeToStringReturn(name)[0],UnicodeToStringReturn(name)[1]);
			}
			tmp = WxListCtrl1->InsertItem(FileSystemNum++, buff, 0);
			FInfo2->SetName(StringToUnicodeReturn(buff));
			WxListCtrl1->SetItemData(tmp, 0);
    		WxListCtrl1->SetItem(tmp, 1, _T(""));
    		FInfo2->Folder = TRUE;
    		WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
    		WxListCtrl1->SetItem(tmp, 3, _T(""));
    		WxListCtrl1->SetItem(tmp, 4, _T(""));

    		FInfo2->SetID(name);
    		List.AddSubEntry(FInfo2);
		}
		return;
    }
	
	SubEntry = NULL;
	while (List.GetNext(&SubEntry) == TRUE) {
		if (!List.SubEntryFullData) {
			error = s->Phones->Current->GetFileFolderInfo(&SubEntry->Info);
		}

		sprintf(buff,"%s",UnicodeToStringReturn(SubEntry->Info.GetName()));
        tmp = WxListCtrl1->InsertItem(FileSystemNum++, buff, 0);
		if (SubEntry->Info.Folder) {
            		WxListCtrl1->SetItem(tmp, 1, _T(""));
            		WxListCtrl1->SetItem(tmp, 2, _T("Folder"));
		} else {
			sprintf(buff, "%i",SubEntry->Info.Size);
            		WxListCtrl1->SetItem(tmp, 1, buff);
            		WxListCtrl1->SetItem(tmp, 2, _T("File"));
		}
		if (SubEntry->Info.ModificationDateTimeAvailable) {
			sprintf(buff, "%s %02i:%02i:%02i %02i-%02i-%04i",
				DayOfWeekStr(
					SubEntry->Info.ModificationDateTime.Year,
					SubEntry->Info.ModificationDateTime.Month,
					SubEntry->Info.ModificationDateTime.Day),
				SubEntry->Info.ModificationDateTime.Hour,
				SubEntry->Info.ModificationDateTime.Minute,
				SubEntry->Info.ModificationDateTime.Second,
				SubEntry->Info.ModificationDateTime.Day,
				SubEntry->Info.ModificationDateTime.Month,
				SubEntry->Info.ModificationDateTime.Year);
		} else {
			sprintf(buff, "");
		}
    	WxListCtrl1->SetItem(tmp, 3, buff);
    	
        sprintf(buff,"    ");	
    	if (SubEntry->Info.DRMForwardLock) buff[0] = 'P';
    	if (SubEntry->Info.ReadOnly) buff[1] = 'R';
    	if (SubEntry->Info.Hidden) buff[2] = 'H';
    	if (SubEntry->Info.System) buff[3] = 'S';
    	WxListCtrl1->SetItem(tmp, 4, buff);
	}
}

/*
 * WxListCtrl1ItemActivated
 */
void MainFrm::WxListCtrl1ItemActivated(wxListEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
	GSM_File			            ReadSaveFile;
	GSM_FileFolderInfoListSubEntry  *SubEntry;
    int 				            i;
	wchart 				            x;
    long 				           item;

	item = WxListCtrl1->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);

	if (WxListCtrl1->GetItemText(item)== "..") {
		for (i=CurrentFolderName.length(); i > 0; i--) {
			if (CurrentFolderName.data()[i]=='\\') break;
		}
		x.append(CurrentFolderName.data(),i);
		CurrentFolderName.clear();
		CurrentFolderName.append(x.data());

		ParentFolderID[ParentFolderIDNum-1].clear();
		ParentFolderIDNum--;
		CopyUnicode((wchar_t *)ParentFolderID[ParentFolderIDNum-1].data(),FileFolderID);
    		EnterFolder();
    		return;
	}
	if (WxListCtrl1->GetItemText(0)== "..") item--;    
	SubEntry = NULL;
	for (i=0;i<=item;i++) List.GetNext(&SubEntry);
	CopyUnicode(FileFolderID,FileFolderID0);
	CopyUnicode(SubEntry->Info.GetID(),FileFolderID);
	if (SubEntry->Info.Folder) {
		CurrentFolderName.push_back('\\');
		CurrentFolderName.append(SubEntry->Info.GetName());
		ParentFolderID[ParentFolderIDNum].append(FileFolderID);
		ParentFolderIDNum++;

	    EnterFolder();
		return;
	}

    Dialog = new wxProgressDialog("Reading file", SubEntry->Info.GetName(), 100, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
	ReadSaveFile.Info.SetID(FileFolderID);
	while(true) {
		error = s->Phones->Current->GetFilePart(&ReadSaveFile);
		if (error.Code!=GSM_ERR_NONE) {
//			printf("\n  ");
//			PrintError(error);
		}

        if (!Dialog->Update((int)ReadSaveFile.Buffer.size()*100/ReadSaveFile.Info.Size,"",&skip)) break;
		if (ReadSaveFile.Info.Size == ReadSaveFile.Buffer.size()) break;
	}		
	delete Dialog;
	WxSaveFileDialog1->SetFilename(SubEntry->Info.GetName());
	if (WxSaveFileDialog1->ShowModal()!=wxID_OK) return;
	ReadSaveFile.SaveToDisk((char *)WxSaveFileDialog1->GetPath().c_str());
}	   

/*
 * WxListCtrl1RightClick
 */
void MainFrm::WxListCtrl1RightClick(wxListEvent& event)
{
 //   PopupMenu(WxPopupMenu1, event.GetPoint());
}

/*
 * WxButton1Click
 */
void MainFrm::WxButton1Click(wxCommandEvent& event)
{
    GSM_PBKEntry        *Entry;
    boolean             newe = true;
    GSM_PBKStatus       Status;
    GSM_Error           error;
    int                 i=0,Pos=1,Pass=0;
    wxProgressDialog    *Dialog;
    bool                skip;
	long 				tmp;
	wchar_t             buff[40],buff2[40];
    char                buff3[50];
	char                buff0[40];
	GSM_PBKSubEntry 	*SubEntry;
    wxArrayString       choices;
    
    choices.Add(wxT("Phone phonebook"));
    choices.Add(wxT("SIM phonebook"));
    choices.Add(wxT("Own numbers"));
    choices.Add(wxT("Dialled calls"));
    choices.Add(wxT("Received calls"));
    choices.Add(wxT("Missed calls"));
    choices.Add(wxT("Call lists (dialled + received + missed)"));

    wxSingleChoiceDialog dialog2(this,
        wxT("Here are possible to read memories (phone or Gammu+)"),
                wxT("Please select a value"),
                choices);
    dialog2.SetSelection(0);

    if (dialog2.ShowModal() != wxID_OK) return;

    WxStatusBar1->SetStatusText(dialog2.GetStringSelection(),0);
        
    WxListCtrl2->DeleteAllItems();
    WxListCtrl3->DeleteAllItems();    
    PbkNum = 0;
    Backup.Delete_ME_PBK();

    switch (dialog2.GetSelection()) {
    case 0:
    case 1:
    case 2:
        if (dialog2.GetSelection()==0) Status.Memory=MEM_PHONE;
        if (dialog2.GetSelection()==1) Status.Memory=MEM_SIM;
        if (dialog2.GetSelection()==2) Status.Memory=MEM_SIM_OWN;
        error = s->Phones->Current->GetPBKStatus(&Status);
        Dialog = new wxProgressDialog("Reading "+dialog2.GetStringSelection(),"" , Status.Used, this, wxPD_AUTO_HIDE | wxPD_APP_MODAL | wxPD_SMOOTH | wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_CAN_ABORT);
        while (i!=Status.Used) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            }
            Entry->Location= Pos;
            Entry->Memory = Status.Memory;
    		error = s->Phones->Current->GetPBK(Entry);
    		Pos++;
            if (error.Code == GSM_ERR_NONE) {
                newe = true;
                i++;
                Dialog->Update((int)i,"",&skip);
                Backup.Add_ME_PBK(Entry);
    
                sprintf(buff0,"%i",Pos);
                tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
                WxListCtrl2->SetItemData(tmp, 0);
                buff[0] = 0;
                buff2[0] = 0;
        		SubEntry = NULL;
        		while (Entry->GetNext(&SubEntry) == TRUE) {
        			switch (SubEntry->GetType()) {
        			case PBK_Text_Name:
                        CopyUnicode(SubEntry->GetText(),buff);
                        break;
        			case PBK_Text_Phone_General:
        			case PBK_Text_Phone_Mobile:
        			case PBK_Text_Phone_Home:
        			case PBK_Text_Phone_Work:
        			case PBK_Text_Phone_Fax:
                        CopyUnicode(SubEntry->GetText(),buff2);
                        break;
                    default:
                        break;
                    }
                }
                WxListCtrl2->SetItem(tmp, 1, buff);
                WxListCtrl2->SetItem(tmp, 2, buff2);
                WxListCtrl2->SetItem(tmp, 3, "");
            }                
        }
    	delete Dialog;
        break;            
    case 3:
    case 4:
    case 5:
        Dialog = new wxProgressDialog("Reading "+dialog2.GetStringSelection(), "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
        error.Code = GSM_ERR_NONE;
        while (error.Code != GSM_ERR_EMPTY) {
            if (newe) {
                Entry = new GSM_PBKEntry;
                newe = false;
            }
            Entry->Location= Pos;
            if (dialog2.GetSelection()==3) Entry->Memory=MEM_PHONE_DIALLED;
            if (dialog2.GetSelection()==4) Entry->Memory=MEM_PHONE_RECEIVED;
            if (dialog2.GetSelection()==5) Entry->Memory=MEM_PHONE_MISSED;
    		error = s->Phones->Current->GetPBK(Entry);
            if (error.Code == GSM_ERR_NONE) {
                Dialog->UpdatePulse("",&skip);
                buff[0] = 0;
                buff2[0] = 0;
                buff3[0] = 0;
        		SubEntry = NULL;
        		while (Entry->GetNext(&SubEntry) == TRUE) {
        			switch (SubEntry->GetType()) {
        			case PBK_Text_Name:
                        CopyUnicode(SubEntry->GetText(),buff);
                        break;
        			case PBK_Text_Phone_General:
        			case PBK_Text_Phone_Mobile:
        			case PBK_Text_Phone_Home:
        			case PBK_Text_Phone_Work:
        			case PBK_Text_Phone_Fax:
                        CopyUnicode(SubEntry->GetText(),buff2);
                        break;
            		case PBK_DateTime_Call:
                    default:
                        break;
                    }
                }
        		SubEntry = NULL;
        		while (Entry->GetNext(&SubEntry) == TRUE) {
        			switch (SubEntry->GetType()) {
            		case PBK_DateTime_Call:
            			sprintf(buff3,"%s %02i:%02i:%02i %02i-%02i-%04i",
                				DayOfWeekStr(
                					SubEntry->GetDateTime()->Year,
                					SubEntry->GetDateTime()->Month,
                					SubEntry->GetDateTime()->Day),
            				SubEntry->GetDateTime()->Hour,
            				SubEntry->GetDateTime()->Minute,
            				SubEntry->GetDateTime()->Second,
            				SubEntry->GetDateTime()->Day,
            				SubEntry->GetDateTime()->Month,
            				SubEntry->GetDateTime()->Year);
                        if (newe) {
                            Entry = new GSM_PBKEntry;
                            newe = false;
                            Entry->Location= Pos;
                            if (dialog2.GetSelection()==3) Entry->Memory=MEM_PHONE_DIALLED;
                            if (dialog2.GetSelection()==4) Entry->Memory=MEM_PHONE_RECEIVED;
                            if (dialog2.GetSelection()==5) Entry->Memory=MEM_PHONE_MISSED;
                    		error = s->Phones->Current->GetPBK(Entry);                        
                        }
                        Backup.Add_ME_PBK(Entry);
                        newe = true;
                                                
                        sprintf(buff0,"%i",Pos);
                        tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
                        WxListCtrl2->SetItemData(tmp, 0);
                        WxListCtrl2->SetItem(tmp, 1, buff);
                        WxListCtrl2->SetItem(tmp, 2, buff2);
                        WxListCtrl2->SetItem(tmp, 3, buff3);
                        break;
                    default:
                        break;
                    }
                }
            }
    		Pos++;
        }
    	delete Dialog;
        break;
    case 6:
        Dialog = new wxProgressDialog("Reading "+dialog2.GetStringSelection(), "", 100, this, wxPD_APP_MODAL | wxPD_SMOOTH);
        for (Pass=0;Pass<3;Pass++) {
            Pos=1;
            error.Code = GSM_ERR_NONE;
            while (error.Code != GSM_ERR_EMPTY) {
                if (newe) {
                    Entry = new GSM_PBKEntry;
                    newe = false;
                }
                Entry->Location= Pos;
                if (Pass==0) Entry->Memory=MEM_PHONE_DIALLED;
                if (Pass==1) Entry->Memory=MEM_PHONE_RECEIVED;
                if (Pass==2) Entry->Memory=MEM_PHONE_MISSED;
        		error = s->Phones->Current->GetPBK(Entry);
                if (error.Code == GSM_ERR_NONE) {
                    Dialog->UpdatePulse("",&skip);
                    buff[0] = 0;
                    buff2[0] = 0;
                    buff3[0] = 0;
            		SubEntry = NULL;
            		while (Entry->GetNext(&SubEntry) == TRUE) {
            			switch (SubEntry->GetType()) {
            			case PBK_Text_Name:
                            CopyUnicode(SubEntry->GetText(),buff);
                            break;
            			case PBK_Text_Phone_General:
            			case PBK_Text_Phone_Mobile:
            			case PBK_Text_Phone_Home:
            			case PBK_Text_Phone_Work:
            			case PBK_Text_Phone_Fax:
                            CopyUnicode(SubEntry->GetText(),buff2);
                            break;
                		case PBK_DateTime_Call:
                        default:
                            break;
                        }
                    }
            		SubEntry = NULL;
            		while (Entry->GetNext(&SubEntry) == TRUE) {
            			switch (SubEntry->GetType()) {
                		case PBK_DateTime_Call:
                			sprintf(buff3,"%s %02i:%02i:%02i %02i-%02i-%04i",
                				DayOfWeekStr(
                					SubEntry->GetDateTime()->Year,
                					SubEntry->GetDateTime()->Month,
                					SubEntry->GetDateTime()->Day),
                				SubEntry->GetDateTime()->Hour,
                				SubEntry->GetDateTime()->Minute,
                				SubEntry->GetDateTime()->Second,
                				SubEntry->GetDateTime()->Day,
                				SubEntry->GetDateTime()->Month,
                				SubEntry->GetDateTime()->Year);
                            if (newe) {
                                Entry = new GSM_PBKEntry;
                                newe = false;
                                Entry->Location= Pos;
                                if (Pass==0) Entry->Memory=MEM_PHONE_DIALLED;
                                if (Pass==1) Entry->Memory=MEM_PHONE_RECEIVED;
                                if (Pass==2) Entry->Memory=MEM_PHONE_MISSED;
                        		error = s->Phones->Current->GetPBK(Entry);
                            }
                            Backup.Add_ME_PBK(Entry);
                            newe = true;
    
                            if (Pass==0) sprintf(buff0,"D %i",Pos);
                            if (Pass==1) sprintf(buff0,"R %i",Pos);
                            if (Pass==2) sprintf(buff0,"M %i",Pos);
                            
                            tmp = WxListCtrl2->InsertItem(PbkNum++, buff0, 0);
                            WxListCtrl2->SetItemData(tmp, 0);
                            WxListCtrl2->SetItem(tmp, 1, buff);
                            WxListCtrl2->SetItem(tmp, 2, buff2);
                            WxListCtrl2->SetItem(tmp, 3, buff3);
                            break;
                        default:
                            break;
                        }
                    }
                }
        		Pos++;
            }
        }
    	delete Dialog;
        break;
    }
}

/*
 * WxListCtrl2ItemActivated
 */
void MainFrm::WxListCtrl2ItemActivated(wxListEvent& event)
{
    wxProgressDialog                *Dialog;
    bool                            skip;
    GSM_Error                       error;
	GSM_File			            ReadSaveFile;
	GSM_PBKSubEntry  *SubEntry;
    int 				            i,EntryNum=0;
	wchart 				            x;
    long 				           item,tmp;
	GSM_Backup_PBKEntry	           *PBKEntry;
	char                           type[50],buff[50];
	wchar_t                        Value[500];
	
	item = WxListCtrl2->GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED);	
	
    WxListCtrl3->DeleteAllItems();

    PBKEntry = NULL;
    for (i=0;i<=item;i++) Backup.GetNext_ME_PBK(&PBKEntry);

    tmp = WxListCtrl3->InsertItem(EntryNum++, "Location", 0);
    WxListCtrl3->SetItemData(tmp, 0);
    WxListCtrl3->SetItem(tmp, 1, WxListCtrl2->GetItemText(item));
        
	SubEntry = NULL;
	while (PBKEntry->GetEntry()->GetNext(&SubEntry) == TRUE) {
		switch (SubEntry->GetType()) {
		case PBK_Text_Phone_General:
            sprintf(type,"General number");
            CopyUnicode(SubEntry->GetText(),Value);
			break;
		case PBK_Text_Phone_Mobile:
            sprintf(type,"Mobile number");                
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Phone_Home:
            sprintf(type,"Home number");           
            CopyUnicode(SubEntry->GetText(),Value);                     
			break;
		case PBK_Text_Phone_Work:
            sprintf(type,"Work number");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Phone_Fax:
            sprintf(type,"Fax number");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Email:
            sprintf(type,"Email address");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_URL:
            sprintf(type,"URL link");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Postal:
            sprintf(type,"Postal address");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_UserID:
            sprintf(type,"User ID");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Note:
            sprintf(type,"Text note");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_Text_Name:
            sprintf(type,"Name");
            CopyUnicode(SubEntry->GetText(),Value);                
			break;
		case PBK_DateTime_Call:
            sprintf(type,"Date & time");
			sprintf(buff,"%s %02i:%02i:%02i %02i-%02i-%04i",
				DayOfWeekStr(
					SubEntry->GetDateTime()->Year,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Day),
				SubEntry->GetDateTime()->Hour,
				SubEntry->GetDateTime()->Minute,
				SubEntry->GetDateTime()->Second,
				SubEntry->GetDateTime()->Day,
				SubEntry->GetDateTime()->Month,
				SubEntry->GetDateTime()->Year);
			StringToUnicode(buff,Value);
			break;
		}
        tmp = WxListCtrl3->InsertItem(EntryNum++, type, 0);
        WxListCtrl3->SetItemData(tmp, 0);
        WxListCtrl3->SetItem(tmp, 1, Value);
	}
}

/*
 * WxButton3Click
 */
void MainFrm::WxButton3Click(wxCommandEvent& event)
{
	GSM_SMSMMSFolders		Folders;
	GSM_SMSMMSFoldersSubEntry  *SubFolder;
	GSM_SMSMMSFoldersSubEntry  *SubEntry;
    GSM_Error error;
    char buff[200];
	GSM_SMSList		*Entry;
	BOOLEAN 		start = TRUE;
	int			i, j=0, smsnum=0, smsparts=0, z=0, lastfolder=0;
    
	error = s->Phones->Current->GetSMSFolders(&Folders);
	PrintError(error);
    
    WxChoice1->Clear();
    
	SubEntry = NULL;
	while (Folders.GetNext(&SubEntry) == TRUE) {
        buff[0] = 0;
        if (SubEntry->Memory == MEM_PHONE) sprintf(buff,"%s (phone)",UnicodeToStringReturn(SubEntry->GetName()));
        if (SubEntry->Memory == MEM_SIM) sprintf(buff,"%s (SIM)",UnicodeToStringReturn(SubEntry->GetName()));        
        WxChoice1->Append(buff);
	}    
	
	Entry = new GSM_SMSList;
	while (true) {
		error = s->Phones->Current->GetNextSMS(Entry,start);
		start = FALSE;		
		if (error.Code == GSM_ERR_EMPTY) break;
		if (error.Code == GSM_ERR_FOLDER_MORE ||
		    error.Code == GSM_ERR_FOLDER_PART ||
		    error.Code == GSM_ERR_NONE) {
			SubFolder = NULL;
			for (i=0;i<Entry->Folder;i++) Folders.GetNext(&SubFolder);
		}
		if (error.Code == GSM_ERR_FOLDER_MORE) {
			if (lastfolder != Entry->Folder) {
				j=0;
				lastfolder = Entry->Folder;
			}
			j++;
			z = 0;
//			PrintStdErr("Reading content of %s SMS folder: %i",UnicodeToStringReturn(SubFolder->GetName()),j);
//			PrintTimeLeftReset();
			continue;
		} else {
			z++;
		}
		if (error.Code == GSM_ERR_FOLDER_PART) {
//			PrintStdErr("");
//			printf("\nThere is available only part of SMS folder %s\n",UnicodeToStringReturn(SubFolder->GetName()));
			continue;
		}
		PrintError(error);

//		sprintf(buff,"Reading SMS from %s SMS folder: ",UnicodeToStringReturn(SubFolder->GetName()));
		if (j!=0) {
//			PrintTimeLeft(buff,z,j);
		} else {
//			sprintf(buff+strlen(buff),"%i",z);
//			PrintStdErr(buff);
		}
		Backup.Add_SMS(Entry);

		Entry = new GSM_SMSList;
	}
	delete (Entry);

	Backup.LinkSMS();
	Backup.SortSMSByFolderDT();	
}

/*
 * Mnuabout1019Click
 */
void MainFrm::Mnuabout1019Click(wxCommandEvent& event)
{
    AboutDlg *dialog = new AboutDlg(this,-1,"About...",wxDefaultPosition,wxDefaultSize,AboutDlg_STYLE);
    
    dialog->ShowModal();
    
    dialog->Destroy();
}

/*
 * WxChoice1Selected
 */
void MainFrm::WxChoice1Selected(wxCommandEvent& event )
{
	GSM_Backup_SMSEntry 	*En;
	GSM_SMSListSubEntry	*SubEntry;
	GSM_SMSEntry		*SMS;	
	boolean wrong;
	
	En = NULL;
	while (Backup.GetNext_SMS(&En)) {
        wrong = false;
		SubEntry = NULL;
		if (En->GetEntry()->GetNext(&SubEntry) == TRUE) {
			SMS = SubEntry->GetSMS();

            if (En->GetEntry()->Folder != WxChoice1->GetSelection()+1) {
                    continue;
            }
		}		
	}
}
