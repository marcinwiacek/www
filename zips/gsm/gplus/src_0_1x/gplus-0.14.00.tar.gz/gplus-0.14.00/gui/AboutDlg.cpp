//---------------------------------------------------------------------------
//
// Name:        AboutDlg.cpp
// Author:      Marcinello
// Created:     2006-12-05 00:38:26
// Description: AboutDlg class implementation
//
//---------------------------------------------------------------------------

#include "AboutDlg.h"
#include "../common/misc/misc.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// AboutDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(AboutDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(AboutDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON2,AboutDlg::WxButton2Click)
	EVT_BUTTON(ID_WXBUTTON1,AboutDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

AboutDlg::AboutDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

AboutDlg::~AboutDlg()
{
} 

void AboutDlg::CreateGUIControls()
{
	//Do not add custom code here
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("About..."));
	SetIcon(wxNullIcon);
	SetSize(8,8,385,233);
	Center();
	

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Check for engine update"), wxPoint(212,177), wxSize(157,25), 0, wxDefaultValidator, wxT("WxButton2"));

	WxStaticText9 = new wxStaticText(this, ID_WXSTATICTEXT9, wxT("Ready for many OS (win32, Linux, MacOS, ...) and phones"), wxPoint(13,38), wxDefaultSize, 0, wxT("WxStaticText9"));

	WxStaticText8 = new wxStaticText(this, ID_WXSTATICTEXT8, wxT("Available for free with full source"), wxPoint(14,22), wxDefaultSize, 0, wxT("WxStaticText8"));

	WxHyperLinkCtrl2 = new wxHyperlinkCtrl(this, ID_WXHYPERLINKCTRL2, wxT("www.mwiacek.com/gsm/money/money.htm "), wxT("http://www.mwiacek.com/gsm/money/money.htm"), wxPoint(90,120), wxSize(224, 17), wxNO_BORDER | wxHL_CONTEXTMENU, wxT("WxHyperLinkCtrl2"));
	WxHyperLinkCtrl2->SetFont(wxFont(8, wxSWISS, wxNORMAL,wxNORMAL, TRUE));

	WxStaticText7 = new wxStaticText(this, ID_WXSTATICTEXT7, wxT("Donations:"), wxPoint(13,119), wxDefaultSize, 0, wxT("WxStaticText7"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("&OK"), wxPoint(101,177), wxSize(101,25), 0, wxDefaultValidator, wxT("WxButton1"));

	WxStaticText5 = new wxStaticText(this, ID_WXSTATICTEXT5, wxT("Engine version:"), wxPoint(13,154), wxDefaultSize, 0, wxT("WxStaticText5"));

	WxHyperLinkCtrl1 = new wxHyperlinkCtrl(this, ID_WXHYPERLINKCTRL1, wxT("www.gammu.org "), wxT("http://www.gammu.org"), wxPoint(90,102), wxSize(196, 17), wxNO_BORDER | wxHL_CONTEXTMENU, wxT("WxHyperLinkCtrl1"));
	WxHyperLinkCtrl1->SetFont(wxFont(8, wxSWISS, wxNORMAL,wxNORMAL, TRUE));

	WxStaticText4 = new wxStaticText(this, ID_WXSTATICTEXT4, wxT("Online info:"), wxPoint(13,103), wxDefaultSize, 0, wxT("WxStaticText4"));

	WxStaticText3 = new wxStaticText(this, ID_WXSTATICTEXT3, wxT("GPL/LGPL for free, commercial on request"), wxPoint(90,86), wxDefaultSize, 0, wxT("WxStaticText3"));

	WxStaticText2 = new wxStaticText(this, ID_WXSTATICTEXT2, wxT("License:"), wxPoint(14,87), wxDefaultSize, 0, wxT("WxStaticText2"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("Written mainly in C++ using free compilators/tools (like wxWidgets) only"), wxPoint(13,53), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxStaticBox1 = new wxStaticBox(this, ID_WXSTATICBOX1, wxT("Gammu+ GUI"), wxPoint(6,6), wxSize(363,168));
	////GUI Items Creation End
}

void AboutDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void AboutDlg::WxButton1Click(wxCommandEvent& event)
{
    EndModal(wxID_OK);
}

/*
 * WxButton2Click
 */
void AboutDlg::WxButton2Click(wxCommandEvent& event)
{
	unsignedstring Stable,Test;
	
//    s->CheckRSS(&Stable, &Test);
//    if (Test.length()!=0) printf("You are using Gammu+ version %s, but there is already newer test version %s. See www.gammu.org for more.\n",VERSION,Test.data());
//	if (Stable.length()!=0) printf("You are using Gammu+ version %s, but there is already newer stable version %s. See www.gammu.org for more.\n",VERSION,Stable.data());
}
