/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

typedef struct {
 	char		*Parameter;
 	int		MinArguments;
 	int		MaxArguments;
 	void		(*Function) (GSM_StateMachine *s, INI_File *CFG, int argc, char *argv[]);
	char		*Params;
} CommandLineFunction;

FILE 		*DebFile 	= NULL;
bool 		UseDeb 	= false;
int  		PrevStdErr = 0;
GSM_DateTime	DTStart;
time_t		told=0;
BOOLEAN		toldfirst = TRUE;

void PrintError(GSM_Error error);
void PrintTimeLeftReset();
void PrintTimeLeft(char *buffer, int small_, int large_);
void PrintStdErr(char *format, ...);
char *DayOfWeekStr(int Year, int Month, int Day);
