//---------------------------------------------------------------------------
//
// Name:        BackupFundDlg.cpp
// Author:      Marcinello
// Created:     2007-02-17 22:20:42
// Description: BackupFuncDlg class implementation
//
//---------------------------------------------------------------------------

#include "BackupFundDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// BackupFuncDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(BackupFuncDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(BackupFuncDlg::OnClose)
END_EVENT_TABLE()
////Event Table End

BackupFuncDlg::BackupFuncDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

BackupFuncDlg::~BackupFuncDlg()
{
} 

void BackupFuncDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Untitled1"));
	SetIcon(wxNullIcon);
	SetSize(8,8,314,236);
	Center();
	

	WxButton4 = new wxButton(this, ID_WXBUTTON4, wxT("WxButton4"), wxPoint(203,175), wxSize(92,25), 0, wxDefaultValidator, wxT("WxButton4"));

	WxButton3 = new wxButton(this, ID_WXBUTTON3, wxT("WxButton3"), wxPoint(13,175), wxSize(92,24), 0, wxDefaultValidator, wxT("WxButton3"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("File format"), wxPoint(16,16), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Unselect all"), wxPoint(203,83), wxSize(81,22), 0, wxDefaultValidator, wxT("WxButton2"));

	WxCheckBox5 = new wxCheckBox(this, ID_WXCHECKBOX5, wxT("ToDo"), wxPoint(18,137), wxSize(200,20), 0, wxDefaultValidator, wxT("WxCheckBox5"));
	WxCheckBox5->Enable(false);

	WxCheckBox4 = new wxCheckBox(this, ID_WXCHECKBOX4, wxT("Notes"), wxPoint(18,118), wxSize(170,17), 0, wxDefaultValidator, wxT("WxCheckBox4"));
	WxCheckBox4->Enable(false);

	WxCheckBox3 = new wxCheckBox(this, ID_WXCHECKBOX3, wxT("Calendar"), wxPoint(18,98), wxSize(183,18), 0, wxDefaultValidator, wxT("WxCheckBox3"));

	WxCheckBox2 = new wxCheckBox(this, ID_WXCHECKBOX2, wxT("SIM phonebook"), wxPoint(18,78), wxSize(160,20), 0, wxDefaultValidator, wxT("WxCheckBox2"));

	wxArrayString arrayStringFor_WxComboBox1;
	WxComboBox1 = new wxComboBox(this, ID_WXCOMBOBOX1, wxT("WxComboBox1"), wxPoint(98,13), wxSize(194,21), arrayStringFor_WxComboBox1, 0, wxDefaultValidator, wxT("WxComboBox1"));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("Select all"), wxPoint(203,55), wxSize(81,22), 0, wxDefaultValidator, wxT("WxButton1"));

	WxCheckBox1 = new wxCheckBox(this, ID_WXCHECKBOX1, wxT("Phone phonebook"), wxPoint(18,57), wxSize(137,21), 0, wxDefaultValidator, wxT("WxCheckBox1"));

	WxStaticBox1 = new wxStaticBox(this, ID_WXSTATICBOX1, wxT("Features"), wxPoint(11,37), wxSize(283,129));
	////GUI Items Creation End
}

void BackupFuncDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}
