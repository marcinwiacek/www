//---------------------------------------------------------------------------
//
// Name:        BackupFundDlg.h
// Author:      Marcinello
// Created:     2007-02-17 22:20:42
// Description: BackupFuncDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __BACKUPFUNCDLG_h__
#define __BACKUPFUNCDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/stattext.h>
#include <wx/combobox.h>
#include <wx/button.h>
#include <wx/checkbox.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef BackupFuncDlg_STYLE
#define BackupFuncDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class BackupFuncDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		BackupFuncDlg(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = BackupFuncDlg_STYLE);
		virtual ~BackupFuncDlg();
	
	private:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxButton *WxButton4;
		wxButton *WxButton3;
		wxStaticText *WxStaticText1;
		wxButton *WxButton2;
		wxCheckBox *WxCheckBox5;
		wxCheckBox *WxCheckBox4;
		wxCheckBox *WxCheckBox3;
		wxCheckBox *WxCheckBox2;
		wxComboBox *WxComboBox1;
		wxButton *WxButton1;
		wxCheckBox *WxCheckBox1;
		wxStaticBox *WxStaticBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXBUTTON4 = 1014,
			ID_WXBUTTON3 = 1013,
			ID_WXSTATICTEXT1 = 1012,
			ID_WXBUTTON2 = 1011,
			ID_WXCHECKBOX5 = 1009,
			ID_WXCHECKBOX4 = 1008,
			ID_WXCHECKBOX3 = 1007,
			ID_WXCHECKBOX2 = 1006,
			ID_WXCOMBOBOX1 = 1005,
			ID_WXBUTTON1 = 1003,
			ID_WXCHECKBOX1 = 1002,
			ID_WXSTATICBOX1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
};

#endif
