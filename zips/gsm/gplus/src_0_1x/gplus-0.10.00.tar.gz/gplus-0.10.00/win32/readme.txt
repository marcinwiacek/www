It wasn't updated since 0.0.6, so I deleted it.

If somebody will be interested, it will be possible to upgrade it and add.
