/* (C) 2003 - 2006 by Marcin Wiacek www.mwiacek.com */

void GetFileFolderInfo(GSM_StateMachine *s, BOOLEAN DetailsAvail, GSM_FileFolderInfo *FInfo, int Level)
{
	int 				i,j=0;
	GSM_FileFolderInfoList		List;
	GSM_FileFolderInfoListSubEntry  *SubEntry;
	GSM_Error			error;
	BOOLEAN				Start = TRUE;

	if (DetailsAvail == FALSE) {
		error = s->Phones->Current->GetFileFolderInfo(FInfo);
		PrintError(error);
	}

	if (FInfo->GetID()[0] == 'c' || FInfo->GetID()[0] == 'C') {
		printf("(%s)",UnicodeToStringReturn(FInfo->GetID()));
		for (i=UnicodeLength(FInfo->GetID());i<6;i++) printf(" ");
	}
	
	if (FInfo->Folder == FALSE) {
		for (i=0;i<Level-1;i++) printf("|   ");
		if (Level!=0) printf("|---");
		printf("%s\n",UnicodeToStringReturn(FInfo->GetName()));
		return;
	}

	List.Info.SetID(FInfo->GetID());

	while (1) {
		error = s->Phones->Current->GetFolderInfoList(&List,Start);
		Start = FALSE;
		if (error.Code == GSM_ERR_FOLDER_MORE) {
			j++;
			PrintStdErr("Reading filesystem folder content: %i",j);
			continue;
		}
		if (error.Code == GSM_ERR_FOLDER_PART || error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);
		break;
	}
	PrintStdErr("");
	for (i=0;i<Level-1;i++) printf("|   ");
	if (Level!=0) printf("|---");
	if (error.Code == GSM_ERR_FOLDER_PART) printf("part of ");
	if (Level!=0) {
		printf("folder");
	} else {
		printf("drive");
	}
	printf(" %s\n",UnicodeToStringReturn(FInfo->GetName()));
	if (error.Code == GSM_ERR_EMPTY) return;
	if (error.Code == GSM_ERR_MEMORY) {
		printf("(currently unavailable)\n");
		return;
	}

	SubEntry = NULL;
	while (List.GetNext(&SubEntry) == TRUE) {
	       	GetFileFolderInfo(s,List.SubEntryFullData,&SubEntry->Info,Level+1);
	}
}

void GetFileSystem(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_FileFolderInfo	Info;
	GSM_Error		error;
	BOOLEAN			Start = TRUE;
	wchar_t			name[20];

	error = s.OpenFromFile();
	PrintError(error);

	name[0] = 0;
	while (true) {
		error = s.Phones->Current->GetNextRootFolderID(name);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		Info.Folder = TRUE;
		Info.SetID(name);
		Info.SetName(name);
		GetFileFolderInfo(&s,TRUE,&Info,0);
	}
}

void GetFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	File.Info.SetID(Buffer);

	printf("Reading file %s\n",argv[0]);

	GSM_GetCurrentDateTime(&DTStart);
	
	while(true) {
		error = s.Phones->Current->GetFilePart(&File);
		if (error.Code!=GSM_ERR_NONE) {
			printf("\n  ");
			PrintError(error);
		}

		PrintTimeLeft("  Done: ", File.Buffer.size(),File.Info.Size);

		if (File.Info.Size == File.Buffer.size()) break;
	}	
	PrintStdErr("");

	printf("\n  Saving to %s",UnicodeToStringReturn(File.Info.GetName()));
	error = File.SaveToDisk(UnicodeToStringReturn(File.Info.GetName()));
	PrintError(error);
}

void AddOneFile(GSM_StateMachine *s, GSM_File *File)
{
	int 			Pos = 0;
	GSM_Error		error;
	unsignedstring		Buffer2;

//	printf("Adding file %s to folder %s\n",argv[1],argv[0]);

	while(1) {
		error = s->Phones->Current->AddFilePart(File,&Pos);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		PrintTimeLeft("  Done: ", Pos,File->Info.Size);
	}	
	PrintStdErr("");

	UnicodeToUTF8QuotedPrintable(File->Info.GetID(), &Buffer2);
	printf("%cFile ID is %s         \n",13,Buffer2.data());
}

void AddFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];

	error = File.ReadFromDisk(StringToUnicodeReturn(argv[1]));
	PrintError(error);

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	File.Info.SetID(Buffer);

	File.Info.SetName(StringToUnicodeReturn(argv[1]));

	File.Info.DRMForwardLock = FALSE;
	File.Info.ReadOnly	 = FALSE;
	File.Info.Hidden	 = FALSE;
	File.Info.System	 = FALSE;

	AddOneFile(&s, &File);	
}

void AddFolder(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));
	FInfo.SetID(Buffer);

	FInfo.SetName(StringToUnicodeReturn(argv[1]));

	error = s.Phones->Current->AddFolder(&FInfo);
	PrintError(error);
}

void DeleteFolder(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));

	error = s.Phones->Current->DeleteFolder(Buffer);
	PrintError(error);
}

void DeleteFile(int argc, char *argv[])
{
	GSM_File		File;
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchar_t 		Buffer[500];
	GSM_FileFolderInfo 	FInfo;

	error = s.OpenFromFile();
	PrintError(error);

	UTF8QuotedPrintableToUnicode((unsigned char *)argv[0], Buffer, strlen(argv[0]));

	error = s.Phones->Current->DeleteFile(Buffer);
	PrintError(error);
}

void DisplayJava(int argc, char *argv[])
{
        GSM_StateMachine 	s(DebFile,"",UseDeb);
	GSM_Error		error;
	wchart			ID;
	unsignedstring		Buffer2;
	BOOLEAN NeedSubFolder;

	error = s.OpenFromFile();
	PrintError(error);

	while (true) {
		error = s.Phones->Current->GetJavaGamesFolderID(&ID, &NeedSubFolder);
		if (error.Code == GSM_ERR_FOLDER_MORE) continue;
		PrintError(error);
		break;
	}
	UnicodeToUTF8QuotedPrintable((wchar_t *)ID.data(), &Buffer2);
	printf("Folder for Java games is %s\n",Buffer2.data());

	while (true) {
		error = s.Phones->Current->GetJavaAppsFolderID(&ID, &NeedSubFolder);
		if (error.Code == GSM_ERR_FOLDER_MORE) continue;
		PrintError(error);
		break;
	}
	UnicodeToUTF8QuotedPrintable((wchar_t *)ID.data(), &Buffer2);
	printf("Folder for Java applications is %s\n",Buffer2.data());
}
