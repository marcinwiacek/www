/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "gsmback.h"

typedef basic_string<BOOLEAN> boollist;

void GSM_Backup::LinkSMS()
{
	boollist		List;
	GSM_Backup_SMSEntry 	*SMS2 = NULL;
	UDHList 		UDH,FirstSMSUDH;
	GSM_Backup_SMSEntry 	*Entry;
	GSM_SMSEntry		*EntrySMS,*FirstSMS;
	GSM_Error		error;
	GSM_SMSList		*SMSList;
	int			i,num,j;
	GSM_SMSListSubEntry 	*En;
	boollist		X;
	
	X.push_back(TRUE);

	//add SMS without UDH or with unknown UDH or with multiple UDH
	Entry = NULL;
	while (GetNext_SMS(&Entry)) {
		En = NULL;
		while (Entry->GetEntry()->GetNext(&En)) {
			EntrySMS = En->GetSMS();
			error = EntrySMS->DecodeUDH(&UDH);
			//add SMS without UDH or with unknown UDH or with multiple UDH
			if (error.Code != GSM_ERR_NONE || UDH.length()==0 || UDH.length()>1) {
				List.push_back(TRUE);
				SMSList = new GSM_SMSList;
				SMSList->Folder = Entry->GetEntry()->Folder;
				SMSList->Add(EntrySMS);
				Add_SMS0(&SMS2, SMSList);
			} else {
				List.push_back(FALSE);
			}
		}
	}
	//add sms from sequence
	while (true) {
		i = 0;
		num = -1;
		Entry = NULL;
		while (GetNext_SMS(&Entry)) {
			En = NULL;
			while (Entry->GetEntry()->GetNext(&En)) {
				EntrySMS = En->GetSMS();
				if (List.data()[i]==TRUE) {
					i++;
					continue;
				}
				error = EntrySMS->DecodeUDH(&UDH);
				//if first SMS from sequence
				if (UDH.length()==1 && UDH.data()[0].PartNumber8bit==1) {
					List.replace(i,1,X);
					num 		= i;
					FirstSMS 	= EntrySMS;
					error = EntrySMS->DecodeUDH(&FirstSMSUDH);

					SMSList = new GSM_SMSList;
					SMSList->Folder = Entry->GetEntry()->Folder;
					SMSList->Add(EntrySMS);
					break;
				}
				i++;
			}
			if (num!=-1) break;
		}
		if (num==-1) break;
		for (j=2;j<=FirstSMSUDH.data()[0].AllParts8bit;j++) {
			num = -1;
			i = 0;
			Entry = NULL;
			while (GetNext_SMS(&Entry)) {
				En = NULL;
				while (Entry->GetEntry()->GetNext(&En)) {
					EntrySMS = En->GetSMS();
					if (List.data()[i]==TRUE) {
						i++;
						continue;
					}
					error = EntrySMS->DecodeUDH(&UDH);
					//if next SMS from sequence
					if (UDH.length()==1 &&
					    UDH.data()[0].PartNumber8bit==j &&
					    UDH.data()[0].ID8bit==FirstSMSUDH.data()[0].ID8bit &&
					    UDH.data()[0].ID16bit==FirstSMSUDH.data()[0].ID16bit &&
						FirstSMS->PhoneNumber==EntrySMS->PhoneNumber &&
					        FirstSMS->SMSCNumber==EntrySMS->SMSCNumber &&
						SMSList->Folder == Entry->GetEntry()->Folder) {
						//sms type
						num = i;
						List.replace(i,1,X);
						SMSList->Add(EntrySMS);
						break;
					}
					i++;
				}
				if (num!=-1) break;
			}
			if (num==-1) break;
		}
		Add_SMS0(&SMS2, SMSList);
	}
	//add all other SMS
	i = 0;
	Entry = NULL;
	while (GetNext_SMS(&Entry)) {
		En = NULL;
		while (Entry->GetEntry()->GetNext(&En)) {
			EntrySMS = En->GetSMS();
			if (List.data()[i]==TRUE) {
				i++;
				continue;
			}
			SMSList = new GSM_SMSList;
			SMSList->Folder = Entry->GetEntry()->Folder;
			SMSList->Add(EntrySMS);
			Add_SMS0(&SMS2, SMSList);
			i++;
		}
	}
	delete(SMS);
	SMS = SMS2;
}

GSM_Backup::GSM_Backup()
{
	ME_PBK  = NULL;
	SM_PBK  = NULL;
	Cal	= NULL;
	SMS	= NULL;
}

GSM_Backup::~GSM_Backup()
{
	delete(ME_PBK);
	delete(SM_PBK);
	delete(Cal);
	delete(SMS);
}

GSM_Error GSM_Backup::ReadFromFile(char *FileName)
{
	return ReadFromTextFile(FileName);
}

BOOLEAN GSM_Backup::GetNext_SMS(GSM_Backup_SMSEntry **En)
{
	if ((*En) == NULL) {
		(*En) = SMS;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

BOOLEAN GSM_Backup::GetNext_Cal(GSM_Backup_CalEntry **En)
{
	if ((*En) == NULL) {
		(*En) = Cal;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

BOOLEAN GSM_Backup::GetNext_ME_PBK(GSM_Backup_PBKEntry **En)
{
	if ((*En) == NULL) {
		(*En) = ME_PBK;
	} else {
		(*En) = (*En)->GetNext();
	}
	if ((*En) == NULL) return FALSE;
	return TRUE;
}

BOOLEAN GSM_Backup::GetNext_SM_PBK(GSM_Backup_PBKEntry **En)
{
	return FALSE;
}

void GSM_Backup::Add_ME_PBK(GSM_PBKEntry *En)
{
	GSM_Backup_PBKEntry *Entry,*Entry2;

	Entry = new GSM_Backup_PBKEntry;
	Entry->SetEntry(En);

	if (ME_PBK == NULL) {
		ME_PBK = Entry;
	} else {
		Entry2 = ME_PBK;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
}

void GSM_Backup::Add_SM_PBK(GSM_PBKEntry *En)
{
}

void GSM_Backup::Add_Cal(GSM_CalendarEntry *En)
{
	GSM_Backup_CalEntry *Entry,*Entry2;

	Entry = new GSM_Backup_CalEntry;
	Entry->SetEntry(En);

	if (Cal == NULL) {
		Cal = Entry;
	} else {
		Entry2 = Cal;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
}

void GSM_Backup::Add_SMS(GSM_SMSList *En)
{
	Add_SMS0(&SMS,En);
}

void GSM_Backup::Add_SMS0(GSM_Backup_SMSEntry **Start, GSM_SMSList *En)
{
	GSM_Backup_SMSEntry *Entry,*Entry2;

	Entry = new GSM_Backup_SMSEntry;
	Entry->SetEntry(En);

	if (*Start == NULL) {
		*Start = Entry;
	} else {
		Entry2 = *Start;
		while (Entry2->GetNext()!=NULL) Entry2 = Entry2->GetNext();
		Entry2->SetNext(Entry);
	}
}

/* ------------------------------------------------------------------------- */

GSM_Backup_PBKEntry::GSM_Backup_PBKEntry()
{
	Next = NULL;
	Entry = NULL;
}

GSM_Backup_PBKEntry::~GSM_Backup_PBKEntry()
{
	delete(Next);
	delete(Entry);
}

void GSM_Backup_PBKEntry::SetNext(GSM_Backup_PBKEntry *Nxt)
{
	Next = Nxt;
}

GSM_Backup_PBKEntry *GSM_Backup_PBKEntry::GetNext()
{
	return Next;
}

GSM_PBKEntry *GSM_Backup_PBKEntry::GetEntry()
{
	return Entry;
}

void GSM_Backup_PBKEntry::SetEntry(GSM_PBKEntry *En)
{
	Entry = En;
}

/* ------------------------------------------------------------------------- */

GSM_Backup_CalEntry::GSM_Backup_CalEntry()
{
	Next = NULL;
	Entry = NULL;
}

GSM_Backup_CalEntry::~GSM_Backup_CalEntry()
{
	delete(Next);
	delete(Entry);
}

void GSM_Backup_CalEntry::SetNext(GSM_Backup_CalEntry *Nxt)
{
	Next = Nxt;
}

GSM_Backup_CalEntry *GSM_Backup_CalEntry::GetNext()
{
	return Next;
}

GSM_CalendarEntry *GSM_Backup_CalEntry::GetEntry()
{
	return Entry;
}

void GSM_Backup_CalEntry::SetEntry(GSM_CalendarEntry *En)
{
	Entry = En;
}

/* ------------------------------------------------------------------------- */

GSM_Backup_SMSEntry::GSM_Backup_SMSEntry()
{
	Next = NULL;
	Entry = NULL;
}

GSM_Backup_SMSEntry::~GSM_Backup_SMSEntry()
{
	delete(Next);
	delete(Entry);
}

void GSM_Backup_SMSEntry::SetNext(GSM_Backup_SMSEntry *Nxt)
{
	Next = Nxt;
}

GSM_Backup_SMSEntry *GSM_Backup_SMSEntry::GetNext()
{
	return Next;
}

GSM_SMSList *GSM_Backup_SMSEntry::GetEntry()
{
	return Entry;
}

void GSM_Backup_SMSEntry::SetEntry(GSM_SMSList *En)
{
	Entry = En;
}

