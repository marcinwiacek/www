/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include "../../../cfg/config.h" //msvc2005
#include "../../misc/cfg.h"
#include "../../misc/coding/coding.h"
#include "../gsmpbk.h"
#include "gsmback.h"

GSM_Error GSM_Backup::ReadFromTextFile(char *FileName)
{
	CFG_File 		File;
	CFG_File_Section 	*Section;
	wchar_t			*value, x[200];
	char			x2[100];
	GSM_PBKEntry		*PBKEntry;
	GSM_PBK_SubEntryType	PBKType;
	GSM_CalendarEntry	*CalEntry;
	GSM_Calendar_Type	CalType;
	GSM_DateTime		DT;
	int			i;

	if (!File.ReadFile(FileName)) return GSM_Return_Error(GSM_ERR_UNKNOWN);

	StringToUnicode("Backup",x);
	value = File.GetValue(x,StringToUnicodeReturn("Format"));
	if (value == NULL) return GSM_Return_Error(GSM_ERR_UNKNOWN);

	StringToUnicode("PhonePBK",x);
	Section = NULL;
	while (File.GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x,Section->GetName(),8) != 0) continue;

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Location"));
		if (value == NULL) continue;

		PBKEntry 		= new GSM_PBKEntry;
		PBKEntry->Location 	= atoi(UnicodeToStringReturn(value));
		PBKEntry->Memory	= MEM_PHONE;
		for (i=0;i<20;i++) {
			sprintf(x2,"Entry%02iType",i);
			value = File.GetValue(Section->GetName(),StringToUnicodeReturn(x2));
			if (value == NULL) continue;

			PBKType = PBK_Not_Assigned;
			if (!wcscmp(value,StringToUnicodeReturn("Name"))) 		PBKType = PBK_Text_Name;
			if (!wcscmp(value,StringToUnicodeReturn("NumberMobile"))) 	PBKType = PBK_Text_Phone_Mobile;
			if (!wcscmp(value,StringToUnicodeReturn("NumberHome"))) 	PBKType = PBK_Text_Phone_Home;
			if (!wcscmp(value,StringToUnicodeReturn("NumberWork"))) 	PBKType = PBK_Text_Phone_Work;
			if (!wcscmp(value,StringToUnicodeReturn("NumberFax"))) 		PBKType = PBK_Text_Phone_Fax;
			if (!wcscmp(value,StringToUnicodeReturn("NumberGeneral"))) 	PBKType = PBK_Text_Phone_General;
			if (!wcscmp(value,StringToUnicodeReturn("Postal"))) 		PBKType = PBK_Text_Postal;
			if (!wcscmp(value,StringToUnicodeReturn("Note"))) 		PBKType = PBK_Text_Note;
			if (!wcscmp(value,StringToUnicodeReturn("Email"))) 		PBKType = PBK_Text_Email;
			if (PBKType == PBK_Not_Assigned) continue;

			sprintf(x2,"Entry%02iText",i);
			value = File.GetValue(Section->GetName(),StringToUnicodeReturn(x2));
			if (value == NULL) continue;
			if (UnicodeLength(value)==0) continue;

			value[UnicodeLength(value)-1] = 0;
			PBKEntry->AddText(PBKType,value+1);
		}
		Add_ME_PBK(PBKEntry);
	}

	StringToUnicode("Calendar",x);
	Section = NULL;
	while (File.GetNextSection(&Section)==TRUE) {
		if (wcsncmp(x,Section->GetName(),8) != 0) continue;

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Type"));
		if (value == NULL) continue;

		CalType = Calendar_Type_Not_Assigned;
		if (!wcscmp(value,StringToUnicodeReturn("Meeting"))) 	CalType = Calendar_Type_Meeting;
		if (!wcscmp(value,StringToUnicodeReturn("Memo"))) 	CalType = Calendar_Type_Memo;
		if (!wcscmp(value,StringToUnicodeReturn("Call"))) 	CalType = Calendar_Type_Call;
		if (!wcscmp(value,StringToUnicodeReturn("Birthday"))) 	CalType = Calendar_Type_Birthday;
		if (!wcscmp(value,StringToUnicodeReturn("Reminder"))) 	CalType = Calendar_Type_Reminder;
		if (CalType == Calendar_Type_Not_Assigned) continue;

		CalEntry = new GSM_CalendarEntry;
		CalEntry->Type = CalType;

		// ----------------------- times ------------------------------

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("StartTime"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_Start, DT);
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("StopTime"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End, DT);
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("AlarmType"));
		if (value != NULL && !strcmp(UnicodeToStringReturn(value),"Silent")) {
			value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_SilentAlarm, DT);
			}
		} else {
			value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Alarm"));
			if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
				CalEntry->AddDateTime(Calendar_DateTime_ToneAlarm, DT);
			}
		}
		
		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("RepeatStopDate"));
		if (value != NULL && ReadVCalendarDateTime(UnicodeToStringReturn(value), &DT)==TRUE) {
			CalEntry->AddDateTime(Calendar_DateTime_End_Repeat, DT);
		}

		// ----------------------- texts ------------------------------

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("EventLocation"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Location, value+1);
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Text"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Text, value+1);
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("Phone"));
		if (value != NULL && UnicodeLength(value)!=0) {
			value[UnicodeLength(value)-1] = 0;
			CalEntry->AddText(Calendar_Text_Phone, value+1);
		}

		// ------------------------ int -------------------------------

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("RepeatDayOfWeek"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_DayOfWeek, atoi(UnicodeToStringReturn(value)));
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("RepeatDay"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Day, atoi(UnicodeToStringReturn(value)));
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("RepeatMonth"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Month, atoi(UnicodeToStringReturn(value)));
		}

		value = File.GetValue(Section->GetName(),StringToUnicodeReturn("RepeatFrequency"));
		if (value != NULL) {
			CalEntry->AddInt(Calendar_Int_Repeat_Frequency, atoi(UnicodeToStringReturn(value)));
		}

		Add_Cal(CalEntry);
	}

	return GSM_Return_Error(GSM_ERR_NONE);
}
