//---------------------------------------------------------------------------
//
// Name:        JavaDlg.cpp
// Author:      Marcinello
// Created:     2007-02-23 22:23:20
// Description: JavaDlg class implementation
//
//---------------------------------------------------------------------------

#include "JavaDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// JavaDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(JavaDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(JavaDlg::OnClose)
END_EVENT_TABLE()
////Event Table End

JavaDlg::JavaDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

JavaDlg::~JavaDlg()
{
} 

void JavaDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Java"));
	SetIcon(wxNullIcon);
	SetSize(8,8,514,342);
	Center();
	

	WxButton3 = new wxButton(this, ID_WXBUTTON3, wxT("Refresh"), wxPoint(331,288), wxSize(80,25), 0, wxDefaultValidator, wxT("WxButton3"));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Upload"), wxPoint(423,288), wxSize(81,23), 0, wxDefaultValidator, wxT("WxButton2"));

	WxListCtrl2 = new wxListCtrl(this, ID_WXLISTCTRL2, wxPoint(7,183), wxSize(498,96), wxLC_REPORT);

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("OK"), wxPoint(7,287), wxSize(84,23), 0, wxDefaultValidator, wxT("WxButton1"));

	WxListCtrl1 = new wxListCtrl(this, ID_WXLISTCTRL1, wxPoint(7,7), wxSize(496,170), wxLC_REPORT);
	////GUI Items Creation End
}

void JavaDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}
