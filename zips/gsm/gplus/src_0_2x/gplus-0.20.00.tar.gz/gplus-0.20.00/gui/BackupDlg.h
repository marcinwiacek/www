//---------------------------------------------------------------------------
//
// Name:        BackupDlg.h
// Author:      Marcinello
// Created:     2007-02-17 22:20:42
// Description: BackupDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __BackupDLG_h__
#define __BackupDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

#include "../common/service/backup/gsmback.h"

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/stattext.h>
#include <wx/combobox.h>
#include <wx/button.h>
#include <wx/checkbox.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef BackupDlg_STYLE
#define BackupDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class BackupDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		BackupDlg(GSM_Backup_FileFormatFunctions *Func2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = BackupDlg_STYLE);
		virtual ~BackupDlg();
		void WxButton3Click(wxCommandEvent& event);
		void WxButton4Click(wxCommandEvent& event);
		void WxComboBox1Selected(wxCommandEvent& event );
		void WxButton1Click(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
		void WxCheckBox1Click(wxCommandEvent& event);
		void WxCheckBox2Click(wxCommandEvent& event);
		void WxCheckBox3Click(wxCommandEvent& event);
	
	private:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxButton *WxButton4;
		wxButton *WxButton3;
		wxStaticText *WxStaticText1;
		wxButton *WxButton2;
		wxCheckBox *WxCheckBox5;
		wxCheckBox *WxCheckBox4;
		wxCheckBox *WxCheckBox3;
		wxCheckBox *WxCheckBox2;
		wxComboBox *WxComboBox1;
		wxButton *WxButton1;
		wxCheckBox *WxCheckBox1;
		wxStaticBox *WxStaticBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXBUTTON4 = 1014,
			ID_WXBUTTON3 = 1013,
			ID_WXSTATICTEXT1 = 1012,
			ID_WXBUTTON2 = 1011,
			ID_WXCHECKBOX5 = 1009,
			ID_WXCHECKBOX4 = 1008,
			ID_WXCHECKBOX3 = 1007,
			ID_WXCHECKBOX2 = 1006,
			ID_WXCOMBOBOX1 = 1005,
			ID_WXBUTTON1 = 1003,
			ID_WXCHECKBOX1 = 1002,
			ID_WXSTATICBOX1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};

    public:
        GSM_Backup_FileFormatFunctions *Func;        	
	private:
        
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void Check();

};

#endif
