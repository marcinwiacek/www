//---------------------------------------------------------------------------
//
// Name:        SMSSendDlg.h
// Author:      Marcinello
// Created:     2007-02-07 00:44:17
// Description: SMSSendDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __SMSSENDDLG_h__
#define __SMSSENDDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/checkbox.h>
#include <wx/combobox.h>
#include <wx/listctrl.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/statbox.h>
#include <wx/button.h>
////Header Include End

////Dialog Style Start
#undef SMSSendDlg_STYLE
#define SMSSendDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class SMSSendDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		SMSSendDlg(GSM_StateMachine *s2, int Parts2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = SMSSendDlg_STYLE);
		virtual ~SMSSendDlg();
		void WxButton2Click(wxCommandEvent& event);
		void WxButton4Click(wxCommandEvent& event);
		void WxEdit1Updated(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		void WxButton5Click(wxCommandEvent& event);
	
	public:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxCheckBox *WxCheckBox1;
		wxStaticText *WxStaticText2;
		wxComboBox *WxComboBox1;
		wxStaticBox *WxStaticBox2;
		wxListCtrl *WxListCtrl1;
		wxButton *WxButton5;
		wxStaticText *WxStaticText1;
		wxButton *WxButton4;
		wxButton *WxButton2;
		wxTextCtrl *WxEdit1;
		wxStaticBox *WxStaticBox1;
		wxButton *WxButton1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXCHECKBOX1 = 1019,
			ID_WXSTATICTEXT2 = 1018,
			ID_WXCOMBOBOX1 = 1017,
			ID_WXSTATICBOX2 = 1016,
			ID_WXLISTCTRL1 = 1015,
			ID_WXBUTTON5 = 1012,
			ID_WXSTATICTEXT1 = 1011,
			ID_WXBUTTON4 = 1010,
			ID_WXBUTTON2 = 1007,
			ID_WXEDIT1 = 1006,
			ID_WXSTATICBOX1 = 1004,
			ID_WXBUTTON1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void SMSSendDlg::SetInfo();
		
        int                 num,Parts;
        GSM_StateMachine    *s;        
};

#endif
