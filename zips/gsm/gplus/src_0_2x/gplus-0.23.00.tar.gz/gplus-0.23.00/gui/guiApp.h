//---------------------------------------------------------------------------
//
// Name:        guiApp.h
// Author:      Marcinello
// Created:     2007-01-25 18:04:29
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __MAINFRMApp_h__
#define __MAINFRMApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class MainFrmApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
