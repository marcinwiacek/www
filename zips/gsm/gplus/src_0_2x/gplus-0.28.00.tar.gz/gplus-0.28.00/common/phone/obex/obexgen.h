/* (C) 2003 - 2005 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../service/gsmmisc.h"
#include "../../device/gsmdev.h"
#include "../gsmphone.h"

#ifndef __obexgen
#define __obexgen

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_OBEXGEN:virtual public GSM_Phone
{
public:
        GSM_Phone_OBEXGEN(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("", "", "" ,"irdaobex", ""));
		Info.push_back(GSM_Phone_Info("5100", "NPM-6x", "Nokia 5100" ,"irdaobex", ""));

		ModuleName 	= "obexgen";
		ModulesUsed  	= "";
		ModulesRequired = "";
        }
        ~GSM_Phone_OBEXGEN() {
        }

	GSM_Error 	Open(char *FrameID);
        GSM_Error       Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID);
private:
	void AddBlock(char *Buffer, int *Pos, unsigned char ID, char *AddBuffer, int AddLength);

	GSM_Error 	ReplyOpen(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
};

#endif
