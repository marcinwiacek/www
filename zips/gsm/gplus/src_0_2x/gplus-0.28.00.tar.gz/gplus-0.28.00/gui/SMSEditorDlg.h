//---------------------------------------------------------------------------
//
// Name:        SMSEditorDlg.h
// Author:      Marcinello
// Created:     2007-02-06 23:39:09
// Description: SMSEditorDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __SMSEditorDLG_h__
#define __SMSEditorDLG_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/combobox.h>
#include <wx/stattext.h>
#include <wx/listctrl.h>
#include <wx/button.h>
#include <wx/textctrl.h>
#include <wx/checkbox.h>
#include <wx/statbox.h>
#include <wx/notebook.h>
#include <wx/panel.h>
////Header Include End

////Dialog Style Start
#undef SMSEditorDlg_STYLE
#define SMSEditorDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class SMSEditorDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		SMSEditorDlg(GSM_StateMachine *s2, GSM_SMSList *List2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = SMSEditorDlg_STYLE);
		virtual ~SMSEditorDlg();
		void WxMemo1Updated(wxCommandEvent& event);
		void WxCheckBox1Click(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
	
	public:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxButton *AddOriginalWxButton;
		wxTextCtrl *WxMemo3;
		wxStaticBox *WxStaticBox4;
		wxButton *SendWxButton;
		wxButton *CancelWxButton;
		wxCheckBox *ReplyWxCheckBox;
		wxComboBox *ValidityWxComboBox;
		wxStaticText *WxStaticText1;
		wxCheckBox *ReportWxCheckBox;
		wxComboBox *SMSCWxComboBox;
		wxStaticText *WxStaticText2;
		wxStaticBox *WxStaticBox7;
		wxButton *RecipientDeleteWxButton;
		wxButton *WxButton6;
		wxListCtrl *RecipientsWxListCtrl;
		wxStaticBox *WxStaticBox6;
		wxTextCtrl *NewRecipientWxEdit;
		wxButton *NewRecipientAddWxButton;
		wxStaticBox *WxStaticBox5;
		wxPanel *WxNoteBookPage3;
		wxTextCtrl *TextSMSPreviewWxMemo;
		wxTextCtrl *TextSMSWxMemo;
		wxCheckBox *TextSMSClassWxCheckBox;
		wxCheckBox *TextSMSUnicodeWxCheckBox;
		wxStaticBox *WxStaticBox3;
		wxStaticBox *WxStaticBox2;
		wxStaticBox *WxStaticBox1;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook1;
		wxPanel *WxNoteBookPage2;
		wxNotebook *WxNotebook2;
		wxPanel *WxPanel1;
		////GUI Control Declaration End
		void WxButton5Click(wxCommandEvent& event);
		void WxButton7Click(wxCommandEvent& event);
		void WxEdit1Updated(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
		void CancelWxButtonClick(wxCommandEvent& event);
		void TextSMSWxMemoUpdated(wxCommandEvent& event);
		void RecipientDeleteWxButtonClick(wxCommandEvent& event);
		void SendWxButtonClick(wxCommandEvent& event);
		void TextSMSUnicodeWxCheckBoxClick(wxCommandEvent& event);
		void NewRecipientAddWxButtonClick(wxCommandEvent& event);
		void NewRecipientWxEditUpdated(wxCommandEvent& event);
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_ADDORIGINALWXBUTTON = 1037,
			ID_WXMEMO3 = 1036,
			ID_WXSTATICBOX4 = 1035,
			ID_SENDWXBUTTON = 1018,
			ID_CANCELWXBUTTON = 1007,
			ID_REPLYWXCHECKBOX = 1040,
			ID_VALIDITYWXCOMBOBOX = 1039,
			ID_WXSTATICTEXT1 = 1038,
			ID_REPORTWXCHECKBOX = 1034,
			ID_SMSCWXCOMBOBOX = 1033,
			ID_WXSTATICTEXT2 = 1032,
			ID_WXSTATICBOX7 = 1031,
			ID_RECIPIENTDELETEWXBUTTON = 1029,
			ID_WXBUTTON6 = 1028,
			ID_RECIPIENTSWXLISTCTRL = 1027,
			ID_WXSTATICBOX6 = 1026,
			ID_NEWRECIPIENTWXEDIT = 1024,
			ID_NEWRECIPIENTADDWXBUTTON = 1023,
			ID_WXSTATICBOX5 = 1022,
			ID_WXNOTEBOOKPAGE3 = 1017,
			ID_TEXTSMSPREVIEWWXMEMO = 1014,
			ID_TEXTSMSWXMEMO = 1013,
			ID_TEXTSMSCLASSWXCHECKBOX = 1012,
			ID_TEXTSMSUNICODEWXCHECKBOX = 1011,
			ID_WXSTATICBOX3 = 1010,
			ID_WXSTATICBOX2 = 1009,
			ID_WXSTATICBOX1 = 1008,
			ID_WXNOTEBOOKPAGE1 = 1005,
			ID_WXNOTEBOOK1 = 1004,
			ID_WXNOTEBOOKPAGE2 = 1016,
			ID_WXNOTEBOOK2 = 1015,
			ID_WXPANEL1 = 1003,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
        void SetInfo();		
		
		GSM_SMSList       *List;
		GSM_StateMachine  *s;
		long              num;
};

#endif
