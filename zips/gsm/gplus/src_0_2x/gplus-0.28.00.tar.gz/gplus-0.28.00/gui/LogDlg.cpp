//---------------------------------------------------------------------------
//
// Name:        LogDlg.cpp
// Author:      Marcinello
// Created:     2007-03-25 19:52:31
// Description: LogDlg class implementation
//
//---------------------------------------------------------------------------

#include "LogDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// LogDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(LogDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(LogDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,LogDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

LogDlg::LogDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

LogDlg::~LogDlg()
{
} 

void LogDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Restore problems"));
	SetIcon(wxNullIcon);
	SetSize(8,8,550,268);
	Center();
	

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("OK"), wxPoint(207,209), wxSize(86,26), 0, wxDefaultValidator, wxT("WxButton1"));

	WxListCtrl1 = new wxListCtrl(this, ID_WXLISTCTRL1, wxPoint(1,6), wxSize(535,198), wxLC_REPORT);
	WxListCtrl1->InsertColumn(0,wxT("Value"),wxLIST_FORMAT_LEFT,200 );
	WxListCtrl1->InsertColumn(0,wxT("Name"),wxLIST_FORMAT_LEFT,330 );
	////GUI Items Creation End
}

void LogDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void LogDlg::WxButton1Click(wxCommandEvent& event)
{
	EndModal(wxID_OK);
}
