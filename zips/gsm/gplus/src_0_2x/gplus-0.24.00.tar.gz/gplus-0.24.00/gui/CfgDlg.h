//---------------------------------------------------------------------------
//
// Name:        CfgDlg.h
// Author:      Marcinello
// Created:     2007-01-25 22:01:44
// Description: CfgDlg class declaration
//
//---------------------------------------------------------------------------

#ifndef __CFGDLG_h__
#define __CFGDLG_h__

#include "../cfg/config.h"
#include "../common/service/gsmdata.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/textctrl.h>
#include <wx/combobox.h>
#include <wx/checkbox.h>
#include <wx/button.h>
#include <wx/stattext.h>
#include <wx/statbox.h>
////Header Include End

////Dialog Style Start
#undef CfgDlg_STYLE
#define CfgDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxCLOSE_BOX
////Dialog Style End

class CfgDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		CfgDlg(GSM_GPlusConfig *CFG2, GSM_StateMachine *s2, wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("Untitled1"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = CfgDlg_STYLE);
		virtual ~CfgDlg();
	
	private:
		//Do not add custom control declarations between 
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxStaticText *WxStaticText7;
		wxStaticText *WxStaticText6;
		wxStaticText *WxStaticText5;
		wxTextCtrl *WxEdit3;
		wxButton *WxButton1;
		wxTextCtrl *WxEdit2;
		wxComboBox *WxComboBox3;
		wxStaticText *WxStaticText4;
		wxCheckBox *WxCheckBox3;
		wxCheckBox *WxCheckBox2;
		wxComboBox *WxComboBox1;
		wxTextCtrl *WxEdit1;
		wxComboBox *WxComboBox2;
		wxCheckBox *WxCheckBox1;
		wxButton *WxButton2;
		wxButton *WxButton3;
		wxStaticText *WxStaticText3;
		wxStaticText *WxStaticText2;
		wxStaticText *WxStaticText1;
		wxStaticBox *WxStaticBox1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXSTATICTEXT7 = 1025,
			ID_WXSTATICTEXT6 = 1024,
			ID_WXSTATICTEXT5 = 1023,
			ID_WXEDIT3 = 1022,
			ID_WXBUTTON1 = 1021,
			ID_WXEDIT2 = 1020,
			ID_WXCOMBOBOX3 = 1019,
			ID_WXSTATICTEXT4 = 1018,
			ID_WXCHECKBOX3 = 1017,
			ID_WXCHECKBOX2 = 1016,
			ID_WXCOMBOBOX1 = 1013,
			ID_WXEDIT1 = 1003,
			ID_WXCOMBOBOX2 = 1014,
			ID_WXCHECKBOX1 = 1015,
			ID_WXBUTTON2 = 1009,
			ID_WXBUTTON3 = 1010,
			ID_WXSTATICTEXT3 = 1008,
			ID_WXSTATICTEXT2 = 1007,
			ID_WXSTATICTEXT1 = 1006,
			ID_WXSTATICBOX1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
		public:
            void SetConfig(GSM_GPlusConfig *CFG2, GSM_StateMachine *s2);
    		void WxComboBox1Selected(wxCommandEvent& event );
    		void WxComboBox2Selected(wxCommandEvent& event );
		void WxButton1Click(wxCommandEvent& event);
		void WxComboBox3Selected(wxCommandEvent& event );
		void WxEdit2Updated(wxCommandEvent& event);
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void WxChoice2Selected(wxCommandEvent& event );
		void SelectChoice2();
		void SelectChoice1();
		void WxChoice1Selected(wxCommandEvent& event );
		void WxButton2Click(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
        void SelectSet();
        void SaveSet();

        int                 Number;		
        bool                EditMode;
        GSM_StateMachine    *s;
        GSM_GPlusConfig     *CFG;          
};

#endif
