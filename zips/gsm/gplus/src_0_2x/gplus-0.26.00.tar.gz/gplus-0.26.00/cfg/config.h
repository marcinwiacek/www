
#define VERSION "0.26.00"
#define VERSION_WIN "0,26,0,0"

#define BLUETOOTH_RF_SEARCHING 1

//#define BLUEZ 1

//MS Visual C++ Express 2005 warnings
#if _MSC_VER == 1400
#  pragma warning( disable : 4996 4244 4333)
#  ifndef _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES
#    define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES  1
#  endif
#  ifndef _CRT_SECURE_NO_DEPRECATE
#    define _CRT_SECURE_NO_DEPRECATE  1
#  endif
#endif
