/* Martin Strigl */

#include "bluez.h"

GSM_Error GSM_Device_Bluetooth::Open(char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones)
{
        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Device_Bluetooth::Close()
{
        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Device_Bluetooth::Read(unsigned char *buf, int *len)
{
        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Device_Bluetooth::Write(const unsigned char *buf, int len)
{
        return GSM_Return_Error(GSM_ERR_UNKNOWN);
}
