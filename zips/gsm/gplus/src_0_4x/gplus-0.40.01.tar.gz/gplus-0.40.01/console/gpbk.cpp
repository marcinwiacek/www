void GetMemory(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
        GSM_Error 		error;
	GSM_PBKEntry 		Entry;
	GSM_PBKSubEntry 	*SubEntry;
	int			Start, End, Tmp, i, j,Num;

	Start = End = atoi(argv[1]);
	if (argc > 2) End = atoi(argv[2]);

	if (End < Start) {
		Tmp   = End;
		End   = Start;
		Start = Tmp;
		printf("Swapped last and first location\n");		
	}

	Entry.Memory = GSM_GetMemoryType(argv[0]);
	if (Entry.Memory == MEM_Unknown) {
		printf("Unknown memory type: %s\n",argv[0]);
		return;		
	}

	error = s->Open(CFG);
	PrintError(error);

	for (Tmp = Start; Tmp <= End; Tmp++) {	
		Entry.ClearAll();

		Entry.Memory = GSM_GetMemoryType(argv[0]);
		Entry.Location = Tmp;

		error = s->Phones->Current->GetPBK(&Entry);
		PrintError(error);

		Num = 1;
		SubEntry = NULL;
		while (Entry.GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case PBK_DateTime_Call_Length:
				printf("Date & time                   : %02i:%02i:%02i %02i-%02i-%04i",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year);
				break;
			case PBK_DateTime_Anniversary:
				printf("Anniversary                   : %02i-%02i-%04i",
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year);
				break;
			case PBK_DateTime_Modified:
				printf("Modified                      : %02i:%02i:%02i %02i-%02i-%04i",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year);
				break;
			case PBK_DateTime_Birthday:
				printf("Birthday                      : %02i-%02i-%04i",
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year);
				break;
			case PBK_ID_Caller_Group:
				printf("Caller group                 : \"%i\"",SubEntry->LongValue);
				break;
			case PBK_ID_Picture:
				printf("Picture ID                   : \"%i\"",SubEntry->LongValue);
				break;
			case PBK_ID_Ringtone:
				printf("Ringtone ID                  : \"%i\"",SubEntry->LongValue);
				break;
			case PBK_ID_Video_File:
				printf("Video file ID                : \"%i\"",SubEntry->LongValue);
				break;
			case PBK_Bool_PTT_Subscribed:
//				printf(" \"%i\"",SubEntry->GetLongValue());
				break;
			default:
				i=0;
				while(GetMemoryType[i].Type!=PBK_Not_Assigned) {
					if (GetMemoryType[i].Type==SubEntry->GetType()) {
						printf("%s",GetMemoryType[i].Name);
						for (j=0;j<30-strlen(GetMemoryType[i].Name);j++) printf(" ");
						printf(": %s",UnicodeToStringReturn(SubEntry->GetText()));
						break;
					}
					i++;
				}
			}
			
			if (SubEntry->CallLength != -1) {
				printf(" (length %i:%i:%i)",SubEntry->CallLength/(60*60),SubEntry->CallLength/60,SubEntry->CallLength%60);
			}
			if (Num == Entry.DefaultNumberNum) {
				printf(" (default)");
			}
			Num++;
			printf("\n");
		}
	}
}

