/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include <string.h>
#include <stdio.h>
#include <io.h>
#include <memory.h>
#include <winsock2.h>
#include <ws2bth.h>
#include <windows.h>

#include "../../../cfg/config.h"
#include "../../phone/gsmphone.h"
#include "blue_w32.h"

#ifdef BLUETOOTH_RF_SEARCHING

#pragma comment(lib, "ws2_32")
#pragma comment(lib, "irprops")

#endif

DEFINE_GUID(L2CAP_PROTOCOL_UUID,  0x00000100, 0x0000, 0x1000, 0x80, 0x00, 0x00, 0x80, 0x5F, 0x9B, 0x34, 0xFB);

GSM_Error GSM_Device_Bluetooth::Connect(char *address, int channel)
{
	SOCKADDR_BTH 			sab;
	int				i;
	GSM_Error			error;

	(*Debug)->Deb("[DEVICE    :   connecting to channel %i]\n",channel);

	error = Sock->Init(Debug);
	if (error.Code != GSM_ERR_NONE) return error;

	Device = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
	if (Device == INVALID_SOCKET) {
		return GSM_Return_Error(GSM_ERR_DRIVER_NOT_AVAILABLE);
	}

	memset (&sab, 0, sizeof(sab));
	sab.port 		= channel;
	sab.addressFamily 	= AF_BTH;
	sab.btAddr 		= 0;
	for (i=0;i<(int)strlen(address);i++) {
		if (address[i] >='0' && address[i] <='9') {
			sab.btAddr = sab.btAddr * 16;
			sab.btAddr = sab.btAddr + (address[i]-'0');
		}
		if (address[i] >='a' && address[i] <='f') {
			sab.btAddr = sab.btAddr * 16;
			sab.btAddr = sab.btAddr + (address[i]-'a'+10);
		}
		if (address[i] >='A' && address[i] <='F') {
			sab.btAddr = sab.btAddr * 16;
			sab.btAddr = sab.btAddr + (address[i]-'A'+10);
		}
	}

	if (connect (Device, (struct sockaddr *)&sab, sizeof(sab)) != 0) {
//		close(Device);
		return GSM_Return_Error(GSM_ERR_DEVICE_OPEN);
	}
	Opened = true;
	return GSM_Return_Error(GSM_ERR_NONE);
}

#ifdef BLUETOOTH_RF_SEARCHING

GSM_Error GSM_Device_Bluetooth::FindChannelInDevice(char *address, char *Prot, void *protocolInfo, BOOLEAN First)
{
	WSAQUERYSET 			querySet;
	DWORD				flags;
	GUID				protocol;
	int				i, result;
	BYTE 				buffer[2000];
	char 				addressAsString[1000];
	DWORD 				bufferLength, addressSize;
	WSAQUERYSET 			*pResults = (WSAQUERYSET*)&buffer;
	HANDLE				handle;
	GSM_Error			error;
	bool				found = false, one = false;
	int				channel;

	memset(&querySet, 0, sizeof(querySet));
	querySet.dwSize 	  = sizeof(querySet);
	protocol 		  = L2CAP_PROTOCOL_UUID;
	querySet.lpServiceClassId = &protocol;
	querySet.dwNameSpace 	  = NS_BTH;
	querySet.lpszContext 	  = address;

	flags = LUP_FLUSHCACHE  | LUP_RETURN_NAME |
		LUP_RETURN_TYPE | LUP_RETURN_ADDR |
		LUP_RETURN_BLOB | LUP_RETURN_COMMENT;

        result = WSALookupServiceBegin(&querySet, flags, &handle);
	if (result != 0) GSM_Return_Error(GSM_ERR_UNKNOWN);

	bufferLength = sizeof(buffer);
	while (1) {
                result = WSALookupServiceNext(handle, flags, &bufferLength, pResults);
		if (result != 0) break;
 		addressSize 		= sizeof(addressAsString);
		addressAsString[0] 	= 0;

		if (strstr(pResults->lpszServiceInstanceName,"SDP Server")!=NULL ||
			strstr(pResults->lpszServiceInstanceName,"Service Discovery")!=NULL) continue;

		if (WSAAddressToString(pResults->lpcsaBuffer->RemoteAddr.lpSockaddr, pResults->lpcsaBuffer->RemoteAddr.iSockaddrLength, (WSAPROTOCOL_INFO*)protocolInfo, addressAsString,&addressSize)==0) {
		}
		if (addressAsString[0] != 0) {
			one = true;
			for (i=strlen(addressAsString)-1;i>0;i--) {
				if (addressAsString[i] == ':') break;
			}
			if (First) {
				(*Debug)->Deb("[DEVICE    :     channel %02i - \"%s\"]\n",atoi(addressAsString+i+1),pResults->lpszServiceInstanceName);
				if (!found && Sock->CheckServiceName(pResults->lpszServiceInstanceName,Prot)) {
					channel = atoi(addressAsString+i+1);
					found = true;
				}
			} else {
				if (!found && Sock->CheckServiceName2(pResults->lpszServiceInstanceName,Prot)) {
					channel = atoi(addressAsString+i+1);
					found = true;
				}
			}
		}
	}
	if (!one) {
		return GSM_Return_Error(GSM_ERR_DEVICE_OPEN);
	} else {
		error.Code = GSM_ERR_NOT_SUPPORTED;
	}
	if (found) {
		error = Connect(address+1,channel);
		//fixme
	}
	result = WSALookupServiceEnd(handle);
	//fixme
	if (error.Code == GSM_ERR_NONE) Opened = true;
	return error;
}

GSM_Error GSM_Device_Bluetooth::FindChannelInAllDevices(char *Prot, void *protocolInfo)
{
	int			result;
	GSM_Error		error;
	WSAQUERYSET 		querySet;
	DWORD 			bufferLength, addressSize;
	char 			addressAsString[1000];
	DWORD			flags;
	HANDLE			handle;
	BYTE 			buffer[2000];
	WSAQUERYSET 		*pResults = (WSAQUERYSET*)&buffer;

	bufferLength = sizeof(buffer);

	flags = LUP_RETURN_NAME | LUP_CONTAINERS |
		LUP_RETURN_ADDR | LUP_FLUSHCACHE |
		LUP_RETURN_TYPE | LUP_RETURN_BLOB | LUP_RES_SERVICE;

	memset(&querySet, 0, sizeof(querySet));
      	querySet.dwSize 	= sizeof(querySet);
      	querySet.dwNameSpace 	= NS_BTH;

	(*Debug)->Deb("[DEVICE    : searching for phone\n");

	if (WSALookupServiceBeginA(&querySet, flags, &handle) != 0) {
	        Sock->Error("WSALookupServiceBegin");
		return GSM_Return_Error(GSM_ERR_DEVICE_OPEN);
	}

	while (1) {
		if (WSALookupServiceNextA(handle, flags, &bufferLength, pResults) != 0) break;

 		addressSize 		= sizeof(addressAsString);
		addressAsString[0] 	= 0;
		if (WSAAddressToString(pResults->lpcsaBuffer->RemoteAddr.lpSockaddr, pResults->lpcsaBuffer->RemoteAddr.iSockaddrLength, (WSAPROTOCOL_INFO *)protocolInfo, addressAsString,&addressSize)==0) {
			(*Debug)->Deb("[DEVICE    :   checking device %s (\"%s\")]\n",addressAsString,pResults->lpszServiceInstanceName);
			error = FindChannelInDevice(addressAsString,Prot,(WSAPROTOCOL_INFO *)protocolInfo, TRUE);
			if (error.Code == GSM_ERR_NOT_SUPPORTED) {
				error = FindChannelInDevice(addressAsString,Prot,(WSAPROTOCOL_INFO *)protocolInfo, FALSE);
			}
			if (error.Code == GSM_ERR_NONE) {
				result = WSALookupServiceEnd(handle);
				Opened = true;
				return error;
			}
		}
	}

	return GSM_Return_Error(GSM_ERR_TIMEOUT);
}

#endif

GSM_Error GSM_Device_Bluetooth::Open(char *Dev, char *Prot, char *Pho, char **DeviceModel, GSM_AllPhones *Phones)
{
#ifdef BLUETOOTH_RF_SEARCHING
	GSM_Error		error;
	int			protocolInfoSize;
	WSAPROTOCOL_INFO 	protocolInfo;
#endif

	(*Debug)->Deb("[DEVICE    : opening device blue\n");

	if (!strcmp(Prot,"blueobexfolders") || !strcmp(Prot,"bluephonet") || 
            !strcmp(Prot,"blueat") || !strcmp(Prot,"bluesyncmlserver") ||
	    !strcmp(Prot,"blueobexinbox")) {
#ifdef BLUETOOTH_RF_SEARCHING
		error = Sock->Init(Debug);
		if (error.Code != GSM_ERR_NONE) return error;

		Device = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
		if (Device == INVALID_SOCKET) {
			return GSM_Return_Error(GSM_ERR_DRIVER_NOT_AVAILABLE);
		}

		protocolInfoSize = sizeof(protocolInfo);
	        if (getsockopt(Device, SOL_SOCKET, SO_PROTOCOL_INFO, (char*)&protocolInfo, &protocolInfoSize) != 0) {
		        Sock->Error("getsockopt");
			closesocket(Device);
			return GSM_Return_Error(GSM_ERR_DEVICE_OPEN);
		}
		closesocket(Device);

		if (Dev[0] == 0) {
			return FindChannelInAllDevices(Prot,&protocolInfo);
		} else {
			(*Debug)->Deb("[DEVICE    :   connecting to device %s]\n",Dev);
			error = FindChannelInDevice(Dev,Prot,&protocolInfo,TRUE);
			if (error.Code == GSM_ERR_NOT_SUPPORTED) {
				error = FindChannelInDevice(Dev,Prot,&protocolInfo,FALSE);
			}
			return error;
		}
#else
		return GSM_Return_Error(GSM_ERR_SOURCE_NOT_COMPILED);
#endif
	}
	if (!strcmp(Prot,"bluerfphonet")) {
		if (Dev[0] == 0) {
			return GSM_Return_Error(GSM_ERR_DEVICE_OPEN);
		} else {
			return Connect(Dev, 15);
		}
	}

        return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

GSM_Error GSM_Device_Bluetooth::Close()
{
        (*Debug)->Deb("[STATE     : closing device]\n");

	if (!Opened) return GSM_Return_Error(GSM_ERR_NONE); 
	return Sock->Close(Device);
}

GSM_Error GSM_Device_Bluetooth::Read(unsigned char *buf, int *len)
{
	return Sock->Read(Device,buf,len);
}

GSM_Error GSM_Device_Bluetooth::Write(const unsigned char *buf, int len)
{
	return Sock->Write(Device,buf,len);
}
