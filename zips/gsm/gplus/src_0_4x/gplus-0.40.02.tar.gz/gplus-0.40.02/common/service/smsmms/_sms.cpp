
GSM_Error GSM_SMSMMSDecodedEntry::ReadFromSMS(GSM_SMSList *List)
{
	GSM_Phone_Bitmap_Types 		Type;
	SMS_UDH_Type 			Type2;	
	GSM_SMSListSubEntry 		*SMS2,*Prev=NULL;
	GSM_SMSMMSDecodedSubEntry 	*Sub2,*Sub3;
	wchar_t 			buff[400];
	wchart				buff5;
	unsignedstring 			dest,buffe;
    	unsignedstring              	UDH;
	unsignedstring  		buffik,buff2,buff3;
    	UDHList                     	UDH2;
	GSM_Error			error;
	unsigned int			j,i,s,pos,UPI,x,y;
	int 				found,ODI=-1;
	GSM_SMSNumbersSubEntry  	*Number;
	BOOLEAN				Linked=FALSE;
	Mono_Bitmap_FileEntry 		MonoFile,MonoFile2,MonoFile3;
	Mono_Bitmap_FileSubEntry	*SubMono,*SubMono2,*SubMono3;
	BOOLEAN				Siemens = TRUE;
	unsigned char			EMSFormat;

	ClearAll();

	SMS2 = NULL;
	while (List->GetNext(&SMS2)) {
	    	error = SMS2->GetSMS()->FindUDHType(&Linked, &found);
	   	if (error.Code != GSM_ERR_NONE) return error;

		if (SMS2->GetSMS()->GetCoding()==SMS_Coding_8bit && 
		    SMS2->GetSMS()->TPUDL>24 &&
		    SMS2->GetSMS()->GetClass()==1 &&
	    	    SMS2->GetSMS()->UserData.data()[0]=='/' &&
	    	    SMS2->GetSMS()->UserData.data()[1]=='/' &&
	    	    SMS2->GetSMS()->UserData.data()[2]=='S' &&
	  	    SMS2->GetSMS()->UserData.data()[3]=='E' &&
	    	    SMS2->GetSMS()->UserData.data()[4]=='O' &&
	    	    SMS2->GetSMS()->UserData.data()[5]==1) {
		} else {
			Siemens = FALSE;
		}

	}

	if (Siemens) {
	        Sub2= new GSM_SMSMMSDecodedSubEntry;
		SMS2 = NULL;
		while (List->GetNext(&SMS2)) {
			if (Sub2->File.Info.Size==0) {
				Sub2->File.Info.Size=SMS2->GetSMS()->UserData.data()[16]+
						SMS2->GetSMS()->UserData.data()[17]*256+
						SMS2->GetSMS()->UserData.data()[18]*256*256+
						SMS2->GetSMS()->UserData.data()[19]*256*256*256;
			} else {
				if (Sub2->File.Info.Size!=SMS2->GetSMS()->UserData.data()[16]+
						SMS2->GetSMS()->UserData.data()[17]*256+
						SMS2->GetSMS()->UserData.data()[18]*256*256+
						SMS2->GetSMS()->UserData.data()[19]*256*256*256) {
					delete(Sub2);
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
			}
			i=20+SMS2->GetSMS()->UserData.data()[20]+1;//file type
			j=i;
			i+=SMS2->GetSMS()->UserData.data()[j]+1;//file name
			if (Prev!=NULL) {
				for (s=20;s<i;s++) {
					if (SMS2->GetSMS()->UserData.data()[s]!=
                        Prev->GetSMS()->UserData.data()[s]) {
						delete(Sub2);
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
				}
			} else {
				Prev=SMS2;
			}
			j=Sub2->File.Info.Size-Sub2->File.Buffer.size();
			if (j>(unsigned int)(SMS2->GetSMS()->UserData.data()[6]+SMS2->GetSMS()->UserData.data()[7]*256)) {
				j=SMS2->GetSMS()->UserData.data()[6]+SMS2->GetSMS()->UserData.data()[7]*256;
			}
			if (i+j>SMS2->GetSMS()->UserData.size()) {
				delete(Sub2);
				return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
			}
			
			Sub2->File.Buffer.append(SMS2->GetSMS()->UserData.data()+i,j);
		}
		SMS2 = NULL;
		List->GetNext(&SMS2);
		if (StringCaseCmp((char *)SMS2->GetSMS()->UserData.data()+21, "vcs", 3)) {
			if (strstr((char *)Sub2->File.Buffer.data(),"BEGIN:VTODO")!=NULL) {
				Sub2->Text.append(StringToUnicodeReturn("text/x-vTodo"));
			} else {
				Sub2->Text.append(StringToUnicodeReturn("text/x-vCalendar"));
			}
		} else if (StringCaseCmp((char *)SMS2->GetSMS()->UserData.data()+21, "vcf", 3)) {
			Sub2->Text.append(StringToUnicodeReturn("text/x-vCard"));
		} else if (StringCaseCmp((char *)SMS2->GetSMS()->UserData.data()+21, "vnt", 3)) {
			Sub2->Text.append(StringToUnicodeReturn("text/x-vNote"));
		} else {
			Sub2->Text.append(StringToUnicodeReturn("text/plain"));
		}
		i=20+SMS2->GetSMS()->UserData.data()[20]+1;//file type
		buffe.clear();
		buffe.append(SMS2->GetSMS()->UserData.data()+i+1,SMS2->GetSMS()->UserData.data()[i]);
		s=0;
		for (j=buffe.size()-1;j>=0;j--) {
                	if (buffe.data()[j]=='\\') {
				s=j+1;
				break;
			}
            	}
		j=i;
		Sub2->File.Info.Name.clear();
		Sub2->File.Info.Name.append(StringToUnicodeReturn((char *)buffe.data()+s));
		Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
		Sub2->Type = MSG_MMSSMS_File;
		Add(Sub2);
		Number = NULL;
		while (SMS2->GetSMS()->PhoneNumbers.GetNext(&Number)) {
			error = Number->GetPhoneNumber(buff);
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMSSMS_Address_Phone_Source;
			Sub2->Text.append(buff);
			Add(Sub2);
		}
		if (SMS2->GetSMS()->GetType()==SMS_Deliver) {
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMS_DT_DateTime;
			SMS2->GetSMS()->GetDateTime(&Sub2->DT);
			Add(Sub2);
		}

		return GSM_Return_Error(GSM_ERR_NONE);
	}

	//Smart Messaging - profiles & Picture Images
	if (found == 1) {
		buff2.clear();
		SMS2 = NULL;
		while (List->GetNext(&SMS2)) {
			error = SMS2->GetSMS()->GetUDH(&UDH);
	               	if (error.Code != GSM_ERR_NONE) return error;

			dest.clear();
			buffik.clear();
			SMS2->GetSMS()->GetText(&buffik);
			buff2.append(buffik.data(),buffik.size());
		}

		i=1;
		while(i!=buff2.size()) {
			switch (buff2.data()[i]) {
			case SM30_ISOTEXT:
				Sub2= new GSM_SMSMMSDecodedSubEntry;
				Sub2->Text.append(StringToUnicodeReturn("text/plain"));
				Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
				Sub2->File.Buffer.append(buff2.data()+i+3,buff2.data()[i+1]*256 + buff2.data()[i+2]);
				Sub2->Type = MSG_MMSSMS_File;
				Add(Sub2);
				break;
			case SM30_UNICODETEXT:
				Sub2= new GSM_SMSMMSDecodedSubEntry;
				Sub2->Text.append(StringToUnicodeReturn("text/plain"));
				Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
				for(j=0;j<(unsigned int)(buff2.data()[i+1]*256 + buff2.data()[i+2])/2;j++) {
					buff[j]=buff2.data()[i+3+j*2]*256+buff2.data()[i+4+j*2];
				}
				buff[j]=0;
				UnicodeToUTF8(buff, &Sub2->File.Buffer);
				Sub2->Type = MSG_MMSSMS_File;
				Add(Sub2);
				break;
			case SM30_PROFILENAME:
				break;
			case SM30_SCREENSAVER:
			case SM30_OTA:
				buff3.clear();
				buff3.append(buff2.data()+i+7,buff2.data()[i+1]*256 + buff2.data()[i+2] + 3-7);
				MonoFile.ReadFromPhoneBitmap(GSM_NokiaPictureImage, buff3, 72,28);
				Sub2 = new GSM_SMSMMSDecodedSubEntry;
				Sub2->Text.append(StringToUnicodeReturn("image/bmp"));
				MonoFile.SaveToBMP(&Sub2->File.Buffer,1);
				Sub2->Type = MSG_MMSSMS_File;
				Add(Sub2);				
				break;
			case SM30_RINGTONE:
				break;
			}
			i = i + buff2.data()[i+1]*256 + buff2.data()[i+2] + 3;
		}

		SMS2 = NULL;
		List->GetNext(&SMS2);
		Number = NULL;
		while (SMS2->GetSMS()->PhoneNumbers.GetNext(&Number)) {
			error = Number->GetPhoneNumber(buff);
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMSSMS_Address_Phone_Source;
			Sub2->Text.append(buff);
			Add(Sub2);
		}
		if (SMS2->GetSMS()->GetType()==SMS_Deliver) {
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMS_DT_DateTime;
			SMS2->GetSMS()->GetDateTime(&Sub2->DT);
			Add(Sub2);
		}

		return GSM_Return_Error(GSM_ERR_NONE);
	}
	//0=text or linked text, 2 = EMS
	if (found == 0 || found == 2) {
		Sub3=NULL;
		Type2 = SMS_UDH_None;
		SMS2 = NULL;
		UPI=0;
		while (List->GetNext(&SMS2)) {
			SMS2->GetSMS()->GetDecodedText(buff);
			pos=0;

			error = SMS2->GetSMS()->DecodeUDH(&UDH2);
			if (error.Code != GSM_ERR_NONE) return error;
			for (j=0;j<(int)UDH2.size();j++) {
				Type = GSM_NokiaOperatorLogo;

				switch (UDH2.data()[j].Type) {
				case SMS_UDH_EMS_Text_Format:
				case SMS_UDH_EMS_Sound_Predef:
				case SMS_UDH_EMS_Animation_Predef:
				case SMS_UDH_EMS_Sound:
				case SMS_UDH_EMS_Animation_Medium:
				case SMS_UDH_EMS_Animation_Small:
				case SMS_UDH_EMS_Picture_Big:
				case SMS_UDH_EMS_Picture_Medium:
				case SMS_UDH_EMS_Picture:
					if (pos<(unsigned int)UDH2.data()[j].Text[2]) {
						buff5.clear();
						buff5.append(buff+pos,UDH2.data()[j].Text[2]-pos);
						dest.clear();
						UnicodeToUTF8(buff5.data(), &dest);
						if (Sub3!=NULL) {
							if (EMSFormat != 0x03) {
							        Sub2= new GSM_SMSMMSDecodedSubEntry;
								Sub2->File.Buffer.append(dest);
								Sub2->Text.append(StringToUnicodeReturn("text/plain"));
								Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
								Sub2->Type = MSG_MMSSMS_File;
								Add(Sub2);
								Sub3=Sub2;
								EMSFormat = 0x03;
							} else {
								Sub3->File.Buffer.append(dest);
							}
						} else {
						        Sub2= new GSM_SMSMMSDecodedSubEntry;
							Sub2->File.Buffer.append(dest);
							Sub2->Text.append(StringToUnicodeReturn("text/plain"));
							Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
							Sub2->Type = MSG_MMSSMS_File;
							Add(Sub2);
							Sub3=Sub2;
							EMSFormat = 0x03;
						}
						pos+=UDH2.data()[j].Text[2];
					}
					break;
				case SMS_UDH_Linked_Short:
				case SMS_UDH_Linked_Long:
				case SMS_UDH_EMS_UPI:
				case SMS_UDH_EMS_ODI:
					break;
				default:
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}

				if (UPI!=0) {
					if (Type2 == SMS_UDH_None) {
						switch (UDH2.data()[j].Type) {
						case SMS_UDH_EMS_Sound:
						case SMS_UDH_EMS_Picture:
							break;
						default:
							return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
						}				
					} else {
						if (UDH2.data()[j].Type == SMS_UDH_Linked_Short ||
						    UDH2.data()[j].Type == SMS_UDH_Linked_Long) {
						} else if (Type2 != UDH2.data()[j].Type) {
							return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
						}
					}
				}

				switch (UDH2.data()[j].Type) {
				case SMS_UDH_Linked_Short:
				case SMS_UDH_Linked_Long:
					break;
				case SMS_UDH_EMS_Text_Format:
					buff5.clear();
					buff5.append(buff+pos,UDH2.data()[j].Text[3]);
					dest.clear();
					UnicodeToUTF8(buff5.data(), &dest);
					if (Sub3 == NULL ||
					    (Sub3!=NULL && EMSFormat != UDH2.data()[j].Text[4])) {
					        Sub2= new GSM_SMSMMSDecodedSubEntry;
						Sub2->File.Buffer.append(dest);
						Sub2->Text.append(StringToUnicodeReturn("text/plain"));
						Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
						Sub2->Type = MSG_MMSSMS_File;
						EMSFormat = UDH2.data()[j].Text[4];
						if ((EMSFormat & 3) == 0) Sub2->TextAlign=MSG_Text_Align_Left;
						if ((EMSFormat & 3) == 1) Sub2->TextAlign=MSG_Text_Align_Right;
						if ((EMSFormat & 3) == 2) Sub2->TextAlign=MSG_Text_Align_Center;
						if ((EMSFormat & 12) == 4) Sub2->TextSize=MSG_Text_Size_Large;
						if ((EMSFormat & 12) == 8) Sub2->TextSize=MSG_Text_Size_Small;
						if ((EMSFormat & 16) == 16) Sub2->TextBold=TRUE;
						if ((EMSFormat & 32) == 32) Sub2->TextItalic=TRUE;
						if ((EMSFormat & 64) == 64) Sub2->TextUnderline=TRUE;
						if ((EMSFormat & 128) == 128) Sub2->TextStrikethrough=TRUE;
						Add(Sub2);
						Sub3=Sub2;
					} else {
						Sub3->File.Buffer.append(dest);
					}
					pos+=UDH2.data()[j].Text[3];
					break;
				case SMS_UDH_EMS_Sound_Predef:
					Sub2= new GSM_SMSMMSDecodedSubEntry;
					Sub2->Type = MSG_SMS_Sound_Predef;
					Sub2->IntVal = UDH2.data()[j].Text[3];
					Add(Sub2);
					break;
				case SMS_UDH_EMS_Sound:
					Sub3=NULL;
					if (Type2 == SMS_UDH_None) {
					        Sub2= new GSM_SMSMMSDecodedSubEntry;
						Type2=SMS_UDH_EMS_Sound;
					}
					if (UPI>0) UPI--;
					dest.clear();
					dest.append((unsigned char *)UDH2.data()[j].Text+3,UDH2.data()[j].Length-3);
					Sub2->File.Buffer.append(dest);
					Sub2->Text.append(StringToUnicodeReturn("text/x-vImelody"));
					Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
					Sub2->Type = MSG_MMSSMS_File;
					if (UPI==0) {
						Type2=SMS_UDH_None;
						Add(Sub2);
					}
					break;
				case SMS_UDH_EMS_Animation_Predef:
					Sub2= new GSM_SMSMMSDecodedSubEntry;
					Sub2->Type = MSG_SMS_Animation_Predef;
					Sub2->IntVal = UDH2.data()[j].Text[3];
					Add(Sub2);
					break;
				case SMS_UDH_EMS_Animation_Medium:
					Type=GSM_EMSMediumPicture;
					//no break;
				case SMS_UDH_EMS_Animation_Small:
					if (Type == GSM_NokiaOperatorLogo) {
						Type=GSM_EMSSmallPicture;
					}
			                s = (UDH2.data()[j].Text[1]-1)/PHONE_GetBitmapSize(Type,0,0);
					//no break;
				case SMS_UDH_EMS_Picture_Big:
					if (Type == GSM_NokiaOperatorLogo) {
						Type = GSM_EMSBigPicture;
				                s = 1;
					}
					//no break;
				case SMS_UDH_EMS_Picture_Medium:
					Sub3=NULL;
					if (Type == GSM_NokiaOperatorLogo) {
						Type = GSM_EMSMediumPicture;
				                s = 1;
					}
					for (i=0;i<s;i++) {
						if (3+i*PHONE_GetBitmapSize(Type,0,0)>(unsigned int)UDH2.data()[j].Length) break;
						buff2.clear();
						buff2.append((unsigned char *)UDH2.data()[j].Text+3+i*PHONE_GetBitmapSize(Type,0,0),PHONE_GetBitmapSize(Type,0,0));
						MonoFile.ClearAll();
						MonoFile.ReadFromPhoneBitmap(Type, buff2, 0,0);
						Sub2 = new GSM_SMSMMSDecodedSubEntry;
						Sub2->Text.append(StringToUnicodeReturn("image/bmp"));
						MonoFile.SaveToBMP(&Sub2->File.Buffer,1);
						Sub2->Type = MSG_MMSSMS_File;
						Add(Sub2);
					}
					break;
				case SMS_UDH_EMS_Picture:
					Sub3=NULL;
					buff2.clear();
					buff2.append((unsigned char *)UDH2.data()[j].Text+5,PHONE_GetBitmapSize(GSM_EMSPicture,UDH2.data()[j].Text[3]*8,UDH2.data()[j].Text[4]));
					MonoFile.ClearAll();
					MonoFile.ReadFromPhoneBitmap(GSM_EMSPicture, buff2, UDH2.data()[j].Text[3]*8,UDH2.data()[j].Text[4]);
					if (Type2 == SMS_UDH_None) {
					        Sub2= new GSM_SMSMMSDecodedSubEntry;
						Type2=SMS_UDH_EMS_Picture;
						MonoFile.SaveToBMP(&Sub2->File.Buffer,1);
					} else {
						MonoFile2.ClearAll();
						MonoFile2.ReadFromBMP(Sub2->File.Buffer);
						SubMono2=NULL;
						MonoFile2.GetNext(&SubMono2);
						SubMono=NULL;
						MonoFile.GetNext(&SubMono);
						SubMono3=new Mono_Bitmap_FileSubEntry(SubMono->GetWidth()+SubMono2->GetWidth(),SubMono2->GetHeight());
						for(y=0;y<(unsigned int)SubMono2->GetHeight();y++) {
							for(x=0;x<(unsigned int)SubMono2->GetWidth();x++) {
								if (SubMono2->IsPointBlack(x,y)) {
									SubMono3->SetPointColor(x, y, TRUE);
								}

							}
							for(x=0;x<(unsigned int)SubMono->GetWidth();x++) {
								if (SubMono->IsPointBlack(x,y)) {
									SubMono3->SetPointColor(x+SubMono2->GetWidth(), y, TRUE);
								}
							}		
						}
						MonoFile3.ClearAll();
						MonoFile3.AddSubEntry(SubMono3);
						Sub2->File.Buffer.clear();
						MonoFile3.SaveToBMP(&Sub2->File.Buffer,1);
					}
					if (UPI>0) UPI--;
					Sub2->Text.append(StringToUnicodeReturn("image/bmp"));
					Sub2->Type = MSG_MMSSMS_File;
					if (UPI==0) {
						Type2 = SMS_UDH_None;
						Add(Sub2);
					}
					break;
				case SMS_UDH_EMS_UPI: //parts
					if (UPI==0) {
						UPI=UDH2.data()[j].Text[2];
						Type2 = SMS_UDH_None;
					} else {
						return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
					}
					break;
				case SMS_UDH_EMS_ODI: //forward lock
					break;
				default:
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
			}

			if (pos!=UnicodeLength(buff)) {
				if (pos>(unsigned int)UnicodeLength(buff)) {
					return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
				}
				buff5.clear();
				buff5.append(buff+pos,UnicodeLength(buff)-pos);
				dest.clear();
				UnicodeToUTF8(buff5.data(), &dest);

				if (Sub3!=NULL) {
					if (EMSFormat != 0x03) {
					        Sub2= new GSM_SMSMMSDecodedSubEntry;
						Sub2->File.Buffer.append(dest);
						Sub2->Text.append(StringToUnicodeReturn("text/plain"));
						Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
						Sub2->Type = MSG_MMSSMS_File;
						Add(Sub2);
						Sub3=Sub2;
						EMSFormat = 0x03;
					} else {
						Sub3->File.Buffer.append(dest);
					}
				} else {
				        Sub2= new GSM_SMSMMSDecodedSubEntry;
					Sub2->File.Buffer.append(dest);
					Sub2->Text.append(StringToUnicodeReturn("text/plain"));
					Sub2->Text2.append(StringToUnicodeReturn("charset=utf8"));
					Sub2->Type = MSG_MMSSMS_File;
					Add(Sub2);
					Sub3=Sub2;
					EMSFormat = 0x03;
				}
			}
		}

		SMS2 = NULL;
		List->GetNext(&SMS2);
		Number = NULL;
		while (SMS2->GetSMS()->PhoneNumbers.GetNext(&Number)) {
			error = Number->GetPhoneNumber(buff);
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMSSMS_Address_Phone_Source;
			Sub2->Text.append(buff);
			Add(Sub2);
		}
		if (SMS2->GetSMS()->GetType()==SMS_Deliver) {
			Sub2 = new GSM_SMSMMSDecodedSubEntry;
			Sub2->Type = MSG_MMS_DT_DateTime;
			SMS2->GetSMS()->GetDateTime(&Sub2->DT);
			Add(Sub2);
		}

		return GSM_Return_Error(GSM_ERR_NONE);
	}
	return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

/* http://forum.nokia.com: OTA MMS Settings 1.0, OTA Settings 7.0 */
void GSM_SMSMMSDecodedEntry::AddWAPSMSParameterText(unsigned char ID, unsignedstring *Text, unsignedstring *Dest)
{
	Dest->push_back(0x87); 				//PARM with attributes
	Dest->push_back(ID);
	Dest->push_back(0x11); 				//VALUE
	Dest->push_back(0x03); 				//Inline string
	Dest->append(Text->data(),Text->length()); 	//Text
	Dest->push_back(0x00); 				//END Inline string
	Dest->push_back(0x01); 				//END PARMeter
}

void GSM_SMSMMSDecodedEntry::FixUDH(GSM_SMSList *Destination, BOOLEAN Long)
{
	GSM_SMSEntry 			SMS;
	unsignedstring 			buff2,buff,w;
	int 				j,i,UDHNum2=-1,z;
	BOOLEAN 			NonLinked=TRUE;	
	GSM_SMSListSubEntry 		*SMS2;
	unsigned char 			ID1,ID2;
	wchart				Dest;

	SMS2=NULL;
	j=0;
	while (Destination->GetNext(&SMS2)) j++;

	if (j<2) return;

	SMS2=NULL;
	j=0;
	while (Destination->GetNext(&SMS2)) j++;

	ID1 = SMS2->GetSMS()->MakeSMSIDFromTime();
	ID2 = SMS2->GetSMS()->MakeSMSIDFromTime();

	i = 0;
	while(UDHHeaders[i].Length!=0) {
		if ((UDHHeaders[i].Type==SMS_UDH_Linked_Short && !Long) ||
		    (UDHHeaders[i].Type==SMS_UDH_Linked_Long && Long)) {
			z=0;
			SMS2=NULL;
			while (Destination->GetNext(&SMS2)) {
				SMS2->GetSMS()->UserData[UDHHeaders[i].PartNumber8bit+1]=z+1;
				SMS2->GetSMS()->UserData[UDHHeaders[i].AllParts8bit+1]=j;
				if (UDHHeaders[i].ID8bit==-1) {
					SMS2->GetSMS()->UserData[UDHHeaders[i].ID16bit+1] = ID1;
					SMS2->GetSMS()->UserData[UDHHeaders[i].ID16bit+2] = ID2;
				} else {
					SMS2->GetSMS()->UserData[UDHHeaders[i].ID8bit+1] = ID1;
				}
				z++;
			}
			break;
		}
		i++;
	}
}

GSM_Error GSM_SMSMMSDecodedEntry::AddContentToSMS(GSM_SMSList *Destination, SMS_UDH_Type UDH2, unsignedstring *src, SMS_Coding_Type Coding, int *CharsLeft, BOOLEAN Long)
{
	GSM_SMSEntry 			SMS;
	unsignedstring 			buff2,buff,w;
	int 				j,i,UDHNum2=-1;
	BOOLEAN 			NonLinked=TRUE;	
	GSM_SMSListSubEntry 		*SMS2;
	wchart				Dest;

	if (UDH2!=SMS_UDH_None) {
		i = 0;
		while(UDHHeaders[i].Length!=0) {
			if (UDHHeaders[i].Type==UDH2) {
				buff.append(UDHHeaders[i].Text,UDHHeaders[i].Length);
				break;
			}
			i++;
		}
	}

	Destination->ClearAll();

	Dest.clear();
	if (Coding==SMS_Coding_Default_No_Compression ||
	    Coding==SMS_Coding_Unicode_No_Compression) {
		UTF8ToUnicode(src->data(), &Dest, src->size());
	}

	i=0;
	while(true) {
		SMS.TPUDL=0;
		SMS.SetCoding(Coding);
		SMS.UserData.clear();
		SMS.firstbyte &= 0xBF;
		if (buff2.size()!=0) SMS.SetUDH(&buff2);
		Destination->Add(&SMS);

		//should we add UDH, because we have more than 1 SMS ?
		SMS2=NULL;
		if (Destination->GetNext(&SMS2) && SMS2->GetNext()!=NULL && NonLinked) {
			i = 0;
			while(UDHHeaders[i].Length!=0) {
				if ((UDHHeaders[i].Type==SMS_UDH_Linked_Short && !Long) ||
				    (UDHHeaders[i].Type==SMS_UDH_Linked_Long && Long)) {
					buff2.push_back(UDHHeaders[i].Length);
					buff2.append(UDHHeaders[i].Text,UDHHeaders[i].Length);
					break;
				}
				i++;
			}
			Destination->ClearAll();
			NonLinked=FALSE;
			i=0;
			continue;
		}
		if (Coding==SMS_Coding_Default_No_Compression ||
		    Coding==SMS_Coding_Unicode_No_Compression) {
			if (Dest.size()==0) break;
			if (buff.size() == 0) {
				j=AddContentToSMS2(Destination, NULL, NULL, (wchar_t *)Dest.data()+i, Coding,CharsLeft);
			} else {
				j=AddContentToSMS2(Destination, &buff, NULL, (wchar_t *)Dest.data()+i, Coding,CharsLeft);
			}
			i+=j;
			if (i==Dest.size()) break;
		}
		if (Coding == SMS_Coding_8bit) {
			w.clear();
			w.append(src->data()+i,src->length()-i);
			if (buff.size()==0) {
				j=AddContentToSMS2(Destination, NULL, &w, NULL, Coding,CharsLeft);
			} else {
				j=AddContentToSMS2(Destination, &buff, &w, NULL, Coding,CharsLeft);
			}
			i+=j;
			if (i==src->length()) break;
		}
	};

	FixUDH(Destination, Long);

	return GSM_Return_Error(GSM_ERR_NONE);
}

//add UDH, if possible + as many text (Text1, Text2) as possible
int GSM_SMSMMSDecodedEntry::AddContentToSMS2(GSM_SMSList *Destination, unsignedstring *UDH1, unsignedstring *Text1, wchar_t *Text2, SMS_Coding_Type Coding, int *CharsLeft)
{
	wchar_t 		Buffer[500];
	wchart			buffer2,buffer3;
	unsignedstring 		buffer,buffer22,UDH;
	unsigned char 		buffer0[200];
	int			len2,len3,used;
	GSM_SMSListSubEntry 	*Sub;
	GSM_SMSEntry 		SMS;
	GSM_Error		error;
	BOOLEAN			x=TRUE;

	switch(Coding) {
	case SMS_Coding_Default_No_Compression: (*CharsLeft) = 160; break;
	case SMS_Coding_Unicode_No_Compression: (*CharsLeft) = 70;  break;
	case SMS_Coding_8bit		      : (*CharsLeft) = 140; //no break
	default                               : break;
	}

	//get last sms
	Sub = NULL;
	while (Destination->GetNext(&Sub)) {
		if (Sub->GetNext()==NULL) break;
	}
	if (Sub==NULL) return 0;
	if (Sub->GetSMS()->GetCoding()!=Coding) return 0;

	error = Sub->GetSMS()->GetUDH(&UDH);
	if (error.Code != GSM_ERR_NONE) return 0;

	if (UDH1!=NULL) {
		if (UDH.size()==0) {
			UDH.push_back(UDH1->size());
			UDH.append(UDH1->data(),UDH1->size());
		} else {
			buffer.append(UDH.data(),UDH.length());
			buffer.append(UDH1->data(),UDH1->length());
			UDH.clear();
			UDH.push_back(buffer.size()-1);
			UDH.append(buffer.data()+1,buffer.size()-1);
			buffer.clear();
		}
	}

	if (UDH.size()>140) return 0;

	if (Coding==SMS_Coding_Default_No_Compression ||
	    Coding==SMS_Coding_Unicode_No_Compression) {
		error = Sub->GetSMS()->GetDecodedText(Buffer);
		if (error.Code != GSM_ERR_NONE) return 0;
		buffer2.append(Buffer,UnicodeLength(Buffer));
		if (Text2!=NULL) buffer2.append(Text2,UnicodeLength(Text2));
	} else {
		error = Sub->GetSMS()->GetText(&buffer22);
		if (error.Code != GSM_ERR_NONE) {
			return 0;
		}
		if (Text1!=NULL) buffer22.append(Text1->data(),Text1->size());
	}

	switch(Coding) {
	case SMS_Coding_Default_No_Compression:
		error = GSM_EncodeSMSText(buffer0, buffer2.data(), &len3, &len2, 140-UDH.size(), &used, UDH.size());
		if (error.Code != GSM_ERR_NONE) return 0;
		buffer.append(buffer0,used);
		if (len3-UnicodeLength(Buffer)>=0) {
			(*CharsLeft) = (140-UDH.size())*8/7-len2;
			x=FALSE;
		}
		len3 = len3-UnicodeLength(Buffer);
		break;
	case SMS_Coding_Unicode_No_Compression:
		len2=0;
		for(len3=0;len3<(int)((140-UDH.size())/2);len3++) {
			if (len2==buffer2.size()) break;
			buffer.push_back(buffer2.data()[len3]/256);
			buffer.push_back(buffer2.data()[len3]%256);
			len2++;
		}

		if (len2-UnicodeLength(Buffer)>=0) {
			(*CharsLeft) = (140-UDH.size()-len2*2)/2;
			x=FALSE;
			len3 = len2-UnicodeLength(Buffer);
		}
		break;
	case SMS_Coding_8bit:
		len2=0;
		for(len3=0;len3<(int)((140-UDH.size()));len3++) {
			if (len2==buffer22.size()) break;
			buffer.push_back(buffer22.data()[len3]);
			len2++;
		}
		if (len2>=(int)(buffer22.size()-Text1->size())) {
			(*CharsLeft) = 140-UDH.size()-len2;
			x=FALSE;			
			len3=len2;
		}
		break;
	default:
		break;
	}

	if (x) return 0;

	//delete UDH
	Sub->GetSMS()->TPUDL=0;
	Sub->GetSMS()->firstbyte &= 0xBF;		
	Sub->GetSMS()->UserData.clear();

	error = Sub->GetSMS()->SetUDH(&UDH);
	if (error.Code != GSM_ERR_NONE) {
		(*CharsLeft)=0;
		return 0;
	}
	
	error = Sub->GetSMS()->SetText(&buffer,len2);
	if (error.Code != GSM_ERR_NONE) {
		(*CharsLeft)=0;
		return 0;
	}

	if (Text1==NULL && Text2==NULL) return 1;

	return len3;
}

GSM_Error GSM_SMSMMSDecodedEntry::SaveToSMS(GSM_SMSList *Destination, GSM_SMS_Types Type, int *CharsLeft)
{
	BOOLEAN				many=FALSE;
	GSM_SMSMMSDecodedSubEntry 	*Sub2,*Sub3;
	GSM_SMSEntry			SMS;
	GSM_SMSListSubEntry 	*Sub;
	int 				len2,len3,used,position=0;
	unsigned char 			id[4],EMSFormat;
	unsigned int 			i,j,z,pos;
	unsigned char			buff[500];
	unsignedstring			buff2,buff3,buff4,buff5;
	GSM_Error			error;
	wchart				Dest;
	SMS_Coding_Type 		Coding;
	GSM_SMSListSubEntry		*SMS2;
	Mono_Bitmap_FileEntry		Bitmap;
	Mono_Bitmap_FileSubEntry	*SubBitmap;
	int				EMSNumber=1,parts,EMSPos;

	Sub2=NULL;
	while (GetNext(&Sub2)) {
		Sub2->SMSPackedNum=-1;
	}

	Destination->ClearAll();
	if (Type == SMS_WAP_Bookmark) {
		Sub2=NULL;
		GetNext(&Sub2);

		i = 0;

		/* http://forum.nokia.com: OTA Settings 7.0 */
		buff2.push_back(0x01); 					//Push ID
		buff2.push_back(0x06); 					//PDU Type (push)
		buff2.push_back(0x2D); 					//Headers length (content type + headers)
		buff2.append((unsigned char *)"\x1F\x2B",2);		//Value length
		buff2.append((unsigned char *)"application/x-wap-prov.browser-bookmarks",40); //MIME-Type
		buff2.push_back(0x00); 					//end inline string
		buff2.append((unsigned char *)"\x81\xEA",2);		//charset UTF-8 short integer
	
		buff2.push_back(0x01);			// Version WBXML 1.1
		buff2.push_back(0x01);			// Unknown public identifier
		buff2.push_back(0x6A);			// charset UTF-8
		buff2.push_back(0x00);			// string table length

		buff2.push_back(0x45); 			//CHARACTERISTIC-LIST with content
			/* URL */
			buff2.push_back(0xC6); 		//CHARACTERISTIC with content and attributes
			buff2.push_back(0x7F);          //TYPE = BOOKMARK
			buff2.push_back(0x01); 		//END PARMeter

				/* TITLE */
				UnicodeToUTF8(Sub2->Text.data(), &buff3);
				AddWAPSMSParameterText(0x15, &buff3, &buff2);

				/* URL */
				buff3.clear();
				UnicodeToUTF8(Sub2->Text2.data(), &buff3);
				AddWAPSMSParameterText(0x17, &buff3, &buff2);

			buff2.push_back(0x01);		//END (CHARACTERISTIC)
		buff2.push_back(0x01);			//END (CHARACTERISTIC-LIST)

		AddContentToSMS(Destination, SMS_UDH_NokiaWAP, &buff2, SMS_Coding_8bit, CharsLeft, FALSE);

		SMS2 = NULL;
		while (Destination->GetNext(&SMS2)) {
			SMS2->GetSMS()->SetClass(1);
		}
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	if (Type == SMS_WAP_Push) {
		Sub2=NULL;
		GetNext(&Sub2);

		i = 0;

		buff2.push_back(0x01); 			//Push ID
		buff2.push_back(0x06); 			//PDU Type (push)
		buff2.push_back(28); 			//Headers length (content type + headers)
		buff2.append((unsigned char *)"\x1F\x23",2); //Value length
		buff2.append((unsigned char *)"application/vnd.wap.sic",23);//MIME-Type
		buff2.push_back(0x00); 			//end inline string
		buff2.append((unsigned char *)"\x81\xEA",2); //charset UTF-8 short int.

		buff2.push_back(0x02); 			// WBXML 1.2
		buff2.push_back(0x05); 			// SI 1.0 Public Identifier
		buff2.push_back(0x6A);			// charset UTF-8
		buff2.push_back(0x00);			// string table length
		buff2.push_back(0x45);			// SI with content
			buff2.push_back(0xC6);		// indication with content and attributes
				buff2.push_back(0x0B);	// address
					buff2.push_back(0x03); 	// Inline string
						UnicodeToUTF8(Sub2->Text2.data(), &buff3);//url
						buff2.append(buff3);	//Text
					buff2.push_back(0x00); 	// END Inline string
				buff2.push_back(0x01);		// END (indication)

				buff2.push_back(0x03); 		// Inline string
					buff3.clear();
					UnicodeToUTF8(Sub2->Text.data(), &buff3);//title
					buff2.append(buff3);	//Text
				buff2.push_back(0x00); 		// END Inline string

			buff2.push_back(0x01);		// END (indication)
		buff2.push_back(0x01);			// END (SI)

		AddContentToSMS(Destination, SMS_UDH_NokiaMMS, &buff2, SMS_Coding_8bit, CharsLeft, FALSE);

		SMS2 = NULL;
		while (Destination->GetNext(&SMS2)) {
			SMS2->GetSMS()->SetClass(1);
		}
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	if (Type == SMS_Indicators) {
		j=1;
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type == MSG_SMS_Fax_Indicator) {
				i = 0;
				while(UDHHeaders[i].Length!=0) {
					if (UDHHeaders[i].Type==SMS_UDH_Fax) {
						memcpy(buff+j,UDHHeaders[i].Text,4);
						buff[j+3]=Sub2->IntVal%256;
						j+=4;
						break;
					}
					i++;
				}
			}
			if (Sub2->Type == MSG_SMS_Voice_Indicator) {
				i = 0;
				while(UDHHeaders[i].Length!=0) {
					if (UDHHeaders[i].Type==SMS_UDH_Voice) {
						memcpy(buff+j,UDHHeaders[i].Text,4);
						buff[j+3]=Sub2->IntVal%256;
						j+=4;
						break;
					}
					i++;
				}
			}
			if (Sub2->Type == MSG_SMS_Email_Indicator) {
				i = 0;
				while(UDHHeaders[i].Length!=0) {
					if (UDHHeaders[i].Type==SMS_UDH_Email) {
						memcpy(buff+j,UDHHeaders[i].Text,4);
						buff[j+3]=Sub2->IntVal%256;
						j+=4;
						break;
					}
					i++;
				}
			}
			if (Sub2->Type == MSG_SMS_Other_Indicator) {
				i = 0;
				while(UDHHeaders[i].Length!=0) {
					if (UDHHeaders[i].Type==SMS_UDH_Other) {
						memcpy(buff+j,UDHHeaders[i].Text,4);
						buff[j+3]=Sub2->IntVal%256;
						j+=4;
						break;
					}
					i++;
				}
			}
		}
		buff[0]=j-1;
		buff2.append(buff,j);
		printf((char *)buff,"g");
		error = GSM_EncodeSMSText(buff, Dest.data(), &len3, &len2, 140-j, &used, j);
		error = SMS.SetText(&buff2,len2);
		SMS.SetUDH(&buff2);
		Destination->Add(&SMS);
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	if (Type == SMS_EMS_Short || Type == SMS_EMS_Long) {
		Coding=SMS_Coding_Default_No_Compression;
		*CharsLeft=160;
		if (SMSUnicode) {
			Coding=SMS_Coding_Unicode_No_Compression;
			*CharsLeft =70;
		}
		SMS.SetCoding(Coding);
		EMSPos=0;

		Destination->ClearAll();

		Sub2=NULL;
		Sub3=NULL;
		while (GetNext(&Sub2)) {
			//text, no formatting for now
			if (Sub2->Type == MSG_MMSSMS_File && !strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/plain")) {
				Dest.clear();
				UTF8ToUnicode(Sub2->File.Buffer.data(), &Dest, Sub2->File.Buffer.size());
				if (Dest.size()!=0) {
					id[0] = 0;

					switch (Sub2->TextAlign) {
					case MSG_Text_Align_Default:id[0] |= 3;break;
					case MSG_Text_Align_Left:break;
					case MSG_Text_Align_Center:id[0] |= 2;break;
					case MSG_Text_Align_Right:id[0] |= 1; break;
					}

					switch (Sub2->TextSize) {
					case MSG_Text_Size_Default:break;
					case MSG_Text_Size_Small:id[0] |= 8; break;
					case MSG_Text_Size_Large:id[0] |= 4;break;
					}

					if (Sub2->TextBold) 		id[0] |= 16;
				    	if (Sub2->TextItalic) 		id[0] |= 32;
					if (Sub2->TextUnderline) 	id[0] |= 64;
				    	if (Sub2->TextStrikethrough) 	id[0] |= 128;

					buff3.clear();
					if (id[0]!=3) {
						buff3.push_back(0x0A); /* ID for text format 	 */
						buff3.push_back(3);	/* Length of rest 		 */
						buff3.push_back(EMSPos);/* Position in EMS msg	*/
						buff3.push_back(3);	/* How many chars 		 */
						buff3.push_back(id[0]);	  /* Bits */
					}
				}

				i=0;
				while (i!=Dest.size()) {
					if (buff3.size() != 0) {
						j=AddContentToSMS2(Destination, &buff3, NULL, (wchar_t *)Dest.data()+i, Coding,CharsLeft);
					} else {
						j=AddContentToSMS2(Destination, NULL, NULL, (wchar_t *)Dest.data()+i, Coding,CharsLeft);
					}
					if (j==0) {
						SMS.TPUDL=0;
						SMS.SetCoding(Coding);
						SMS.UserData.clear();
						SMS.firstbyte &= 0xBF;
						if (buff2.size()!=0) SMS.SetUDH(&buff2);
						Destination->Add(&SMS);
						EMSPos=0;
					} else {
						if (buff3.size() != 0) {
							Sub = NULL;
							while (Destination->GetNext(&Sub)) {
								if (Sub->GetNext()==NULL) break;
							}
							buff4.clear();
							Sub->GetSMS()->GetUDH(&buff4);
							buff5.clear();
							buff5.push_back(EMSPos);
							buff5.push_back(j);
							Sub->GetSMS()->UserData.replace(3,2,buff5);
						}
						i+=j;
						EMSPos+=j;
					}
				};
				if (i!=0) {
					id[0] = 0x03;
					if (buff3.size()!=0) id[0] = buff3.data()[4];
					if (Sub3==NULL) {
						Sub2->SMSPackedNum=EMSNumber;
						Sub2->SMSPackedTextStartup=0;
						Sub2->SMSPackedTextLength=Dest.size();
						EMSNumber++;
						Sub3=Sub2;
						EMSFormat = id[0];
					} else {
						if (EMSFormat != id[0]) {
							Sub2->SMSPackedNum=EMSNumber;
							Sub2->SMSPackedTextStartup=0;
							Sub2->SMSPackedTextLength=Dest.size();
							EMSNumber++;
							Sub3=Sub2;
							EMSFormat = id[0];
						} else {
							Sub2->SMSPackedNum=EMSNumber-1;
							Sub2->SMSPackedTextStartup=Sub3->SMSPackedTextStartup+Sub3->SMSPackedTextLength;
							Sub2->SMSPackedTextLength=Dest.size();
							Sub3=Sub2;
						}
					}
				}
			}
			//melody
			if (Sub2->Type == MSG_MMSSMS_File && !strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/x-vImelody")) {
				Dest.clear();
				UTF8ToUnicode(Sub2->File.Buffer.data(), &Dest, Sub2->File.Buffer.size());
				if (Dest.size()!=0 && Sub2->DRMForwardLock) {
					buff3.clear();
					buff3.push_back(0x17); /* ID for ODI 		 */
					buff3.push_back(2);/* Length of rest 		 */
					buff3.push_back(1);	  /* Number of protected objects */
					buff3.push_back(1);/* 1=Protected,0=Not protected */
					j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
					if (j==0) {
						SMS.TPUDL=0;
						SMS.SetCoding(Coding);
						SMS.UserData.clear();
						SMS.firstbyte &= 0xBF;
						if (buff2.size()!=0) SMS.SetUDH(&buff2);
						Destination->Add(&SMS);
						j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
					}
				}
				if (Dest.size()>128) {
					j=140;
					SMS2=NULL;
					while (Destination->GetNext(&SMS2)) {
						j=140-SMS2->GetSMS()->UserData.size();
					}
					if (j<3) j = 140; //upi header
					if (j<4) j = 140;
					i=0;
					parts=0;
					while (true) {
						z=Dest.size()-i;
						if (z>128) z=128;
						if (z>j-3) z=j-3;
						i+=z;
						parts++;
						if (i==Dest.size()) break;
						j=140;
					}

					//upi
					buff3.clear();
					buff3.push_back(0x13);
					buff3.push_back(1);
					buff3.push_back(parts);
					j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
					if (j==0) {
						SMS.TPUDL=0;
						SMS.SetCoding(Coding);
						SMS.UserData.clear();
						SMS.firstbyte &= 0xBF;
						if (buff2.size()!=0) SMS.SetUDH(&buff2);
						Destination->Add(&SMS);
						j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
					}
				}

				j=140;
				SMS2=NULL;
				while (Destination->GetNext(&SMS2)) {
					j=140-SMS2->GetSMS()->UserData.size();
					if (SMS2->GetNext()==NULL) break;
				}

				i=0;
				while (i!=Dest.size()) {
				        // break;
					z=Dest.size()-i;
					if (z>128) z=128;
					if (z>j-3) { //no enough place
						if (Dest.size()>128) {
							z=j-3;
						} else {
							SMS2=NULL;
						}
					}

					if (SMS2==NULL) {
						SMS.TPUDL=0;
						SMS.SetCoding(Coding);
						SMS.UserData.clear();
						SMS.firstbyte &= 0xBF;
						if (buff2.size()!=0) SMS.SetUDH(&buff2);
						Destination->Add(&SMS);
						EMSPos=0;
					}
					buff3.clear();
					buff3.push_back(0x0C);
					buff3.push_back(z+1);//length
					buff3.push_back(EMSPos);
					buff3.append((unsigned char *)UnicodeToStringReturn(Dest.data()+i),z);

					j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
					if (j==0) {
						j=140;
						SMS2=NULL;
						continue;
					}

					i+=z;
					SMS2=NULL;
				};
				if (i!=0) {
					Sub3=NULL;
					Sub2->SMSPackedNum=EMSNumber;
					Sub2->SMSPackedTextStartup=0;
					Sub2->SMSPackedTextLength=Dest.size();
					EMSNumber++;
				}
			}
			if (Sub2->Type == MSG_SMS_Animation_Predef ||
			    Sub2->Type == MSG_SMS_Sound_Predef) {
				buff3.clear();
				if (Sub2->Type == MSG_SMS_Animation_Predef) {
					buff3.push_back(0x0D);
				} else {
					buff3.push_back(0x0B);
				}
				buff3.push_back(2);
				buff3.push_back(EMSPos);
				buff3.push_back(Sub2->IntVal);
				j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
				if (j==0) {
					SMS.TPUDL=0;
					SMS.SetCoding(Coding);
					SMS.UserData.clear();
					SMS.firstbyte &= 0xBF;
					if (buff2.size()!=0) SMS.SetUDH(&buff2);
					Destination->Add(&SMS);
					j=AddContentToSMS2(Destination, &buff3, NULL, NULL, Coding,CharsLeft);
				}
				Sub2->SMSPackedNum=EMSNumber;
				EMSNumber++;
			}
			//should we add UDH, because we have more than 1 SMS ?
			SMS2=NULL;
			if (Destination->GetNext(&SMS2) && SMS2->GetNext()!=NULL && buff2.size()==0) {
				i = 0;
				while(UDHHeaders[i].Length!=0) {
					if ((UDHHeaders[i].Type==SMS_UDH_Linked_Short && Type==SMS_EMS_Short) ||
					    (UDHHeaders[i].Type==SMS_UDH_Linked_Long && Type==SMS_EMS_Long)) {
						buff2.push_back(UDHHeaders[i].Length);
						buff2.append(UDHHeaders[i].Text,UDHHeaders[i].Length);
						break;
					}
					i++;
				}
				Sub3=NULL;
				EMSNumber=1;
				EMSPos=0;
				Destination->ClearAll();
				Sub2=NULL;
				while (GetNext(&Sub2)) {
					Sub2->SMSPackedNum=-1;
				}
				Sub2=NULL;
				continue;
			}
		}
		FixUDH(Destination, (Type == SMS_EMS_Long));
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	if (Type == SMS_Nokia_VCARD) {
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type != MSG_MMSSMS_File) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
			if (strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/x-vCard")) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
		}
		Sub2=NULL;
		if (!GetNext(&Sub2)) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

		error = AddContentToSMS(Destination, SMS_UDH_NokiaPhonebook, &Sub2->File.Buffer, SMS_Coding_Default_No_Compression, CharsLeft, FALSE);
		if (error.Code != GSM_ERR_NONE) return error;	
	}
	if (Type == SMS_Nokia_VCALENDAR) {
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type != MSG_MMSSMS_File) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
			if (strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/x-vCalendar")) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
		}
		Sub2=NULL;
		if (!GetNext(&Sub2)) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

		error = AddContentToSMS(Destination, SMS_UDH_NokiaCalendar, &Sub2->File.Buffer, SMS_Coding_Default_No_Compression, CharsLeft, FALSE);
		if (error.Code != GSM_ERR_NONE) return error;	
	}
	if (Type == SMS_Nokia_VTODO) {
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type != MSG_MMSSMS_File) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
			if (strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/x-vTodo")) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
		}
		Sub2=NULL;
		if (!GetNext(&Sub2)) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

		error = AddContentToSMS(Destination, SMS_UDH_NokiaCalendar, &Sub2->File.Buffer, SMS_Coding_Default_No_Compression, CharsLeft, FALSE);
		if (error.Code != GSM_ERR_NONE) return error;	
	}
	if (Type == SMS_Nokia_Picture || Type == SMS_Nokia_Profile) {
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type != MSG_MMSSMS_File) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
			if (strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/plain") &&
			    strcmp(UnicodeToStringReturn(Sub2->Text.data()),"image/bmp")) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
		}
		Sub2=NULL;
		if (!GetNext(&Sub2)) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

		buff2.push_back(0x30);//version 3.0
		//picture
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (!strcmp(UnicodeToStringReturn(Sub2->Text.data()),"image/bmp")) {
				Bitmap.ReadFromBMP(Sub2->File.Buffer);
				SubBitmap = NULL;
				Bitmap.GetNext(&SubBitmap);
				SubBitmap->SaveToPhoneBitmap(GSM_NokiaPictureImage,&buff3);

				if (Type == SMS_Nokia_Picture) {
					buff2.push_back(SM30_OTA);
				} else {
					buff2.push_back(SM30_SCREENSAVER);
				}
				buff2.push_back(0x01);//size
				buff2.push_back(0x00);//size
				buff2.push_back(0x00);
				buff2.push_back(72);//width
				buff2.push_back(28);//height
				buff2.push_back(0x01);
				buff2.append(buff3.data(),buff3.size());
			}
		}
		//text
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (!strcmp(UnicodeToStringReturn(Sub2->Text.data()),"text/plain")) {
				buff3.clear();
				UTF8ToUnicode(Sub2->File.Buffer.data(), &Dest, Sub2->File.Buffer.size());
//w profile jest profilename
				if (SMSUnicode) {
					buff2.push_back(SM30_UNICODETEXT);
					buff2.push_back((Dest.size()*2)/256);
					buff2.push_back((Dest.size()*2)%256);
					for(i=0;i<Dest.size();i++) {
						buff2.push_back(Dest.data()[i]/256);
						buff2.push_back(Dest.data()[i]%256);
					}
				} else {
					UnicodeToISO88591(Dest.data(), &buff3, TRUE);
					buff2.push_back(SM30_ISOTEXT);
					buff2.push_back(buff3.size()/256);
					buff2.push_back(buff3.size()%256);
					buff2.append(buff3.data(),buff3.size());
				}
			}
		}

		error = AddContentToSMS(Destination, SMS_UDH_NokiaProfile, &buff2, SMS_Coding_8bit, CharsLeft, FALSE);
		if (error.Code != GSM_ERR_NONE) return error;	

		if (SMSUnicode) {
			*CharsLeft = *CharsLeft/2;
		}

		SMS2 = NULL;
		while (Destination->GetNext(&SMS2)) {
			SMS2->GetSMS()->SetClass(1);
		}
	}
	if (Type == SMS_Siemens_File) {
		Sub2=NULL;
		while (GetNext(&Sub2)) {
			if (Sub2->Type != MSG_MMSSMS_File) {
				return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
			}
		}
		Sub2=NULL;
		if (!GetNext(&Sub2)) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
		if (Sub2->File.Info.Name.size()<5) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
		if (Sub2->File.Info.Name.data()[Sub2->File.Info.Name.size()-4]!='.') return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);

		buff2.push_back(3);//length
		buff2.append((unsigned char *)UnicodeToStringReturn(Sub2->File.Info.Name.data()+(Sub2->File.Info.Name.size()-3)),3);
		buff2.push_back(Sub2->File.Info.Name.size());//length
		buff2.append((unsigned char *)UnicodeToStringReturn(Sub2->File.Info.Name.data()),Sub2->File.Info.Name.size());
		if (buff2.size()+20>140) return GSM_Return_Error(GSM_ERR_GPLUS_NOT_SUPPORTED);
		i=140-(buff2.size()+20);//length for each
		j=Sub2->File.Buffer.size()/i;
		if (j*i<Sub2->File.Buffer.size()) j++; //number of sms
		SMS.SetCoding(SMS_Coding_8bit);
		SMS.SetClass(1);
		pos=0;
		for (z=0;z<j;z++) {
			SMS.UserData.clear();
			SMS.UserData.append((unsigned char *)"//SEO",5);
			SMS.UserData.push_back(1);
			SMS.UserData.push_back(i%256);
			SMS.UserData.push_back(i/256);
			if (z==0) {
				id[0] = SMS.MakeSMSIDFromTime();
				id[1] = SMS.MakeSMSIDFromTime();
				id[2] = SMS.MakeSMSIDFromTime();
				id[3] = SMS.MakeSMSIDFromTime();
			}	
			SMS.UserData.append(id,4);
			SMS.UserData.push_back((z+1)%256);
			SMS.UserData.push_back((z+1)/256);
			SMS.UserData.push_back(j%256);
			SMS.UserData.push_back(j/256);
			SMS.UserData.push_back(Sub2->File.Buffer.size()%256);
			SMS.UserData.push_back(Sub2->File.Buffer.size()/256);
			SMS.UserData.push_back(Sub2->File.Buffer.size()/(256*256));
			SMS.UserData.push_back(Sub2->File.Buffer.size()/(256*256*256));
			SMS.UserData.append(buff2.data(),buff2.size());
			
			if (Sub2->File.Buffer.size()-pos>=i) {
				SMS.UserData.append(Sub2->File.Buffer.data()+pos,i);
				pos+=i;
			} else {
				SMS.UserData.append(Sub2->File.Buffer.data()+pos,Sub2->File.Buffer.size()-pos);
				while (true) {
					if (SMS.UserData.size()==140) break;
					SMS.UserData.push_back(0);
				}
			}
			SMS.TPUDL = SMS.UserData.size();
			Destination->Add(&SMS);
		}
		return GSM_Return_Error(GSM_ERR_NONE);
	}
	return GSM_Return_Error(GSM_ERR_NONE);
}
