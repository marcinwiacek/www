/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../service/gsmmisc.h"
#include "../../device/gsmdev.h"
#include "../gsmphone.h"

#ifndef __OBEXGEN
#define __OBEXGEN

#define OBEX_OP_CONNECT		0x00
#define OBEX_OP_DISCONNECT	0x01
#define OBEX_OP_PUT		0x02
#define OBEX_OP_GET		0x03
#define OBEX_OP_SET_PATH	0x05
#define OBEX_RESP_CONTINUE 	0x90
#define OBEX_RESP_SUCCESS  	0xA0
#define OBEX_RESP_FORBIDDEN	0xC3

#define OBEX_HEAD_NAME		0x01
#define OBEX_HEAD_LENGTH 	0xC3
#define OBEX_HEAD_CONNECTION_ID 0xCB
#define OBEX_HEAD_TYPE		0x42
#define OBEX_HEAD_TIME_ISO	0x44
#define OBEX_HEAD_TARGET	0x46
#define OBEX_HEAD_BODY		0x48
#define OBEX_HEAD_BODY_END	0x49
#define OBEX_HEAD_WHO 		0x4A

typedef enum {
	OBEX_NONE = 1,
	OBEX_FOLDERS,
	OBEX_SYNCML,
	OBEX_IRMC
} GSM_OBEXService;

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_OBEXGEN:virtual public GSM_Phone
{
public:
        GSM_Phone_OBEXGEN(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("", "", "" ,"irdaobexfolders", ""));
		Info.push_back(GSM_Phone_Info("", "", "" ,"blueobexfolders", ""));
		Info.push_back(GSM_Phone_Info("", "", "" ,"blueobexinbox", ""));
		Info.push_back(GSM_Phone_Info("", "", "" ,"bluesyncmlserver", ""));
		Info.push_back(GSM_Phone_Info("5100", "NPM-6x", "Nokia 5100" ,"irdaobex", ""));

		ModuleName 	= "obexgen";
		ModulesUsed  	= "";
		ModulesRequired = "";
        }
        ~GSM_Phone_OBEXGEN() {
        }

	GSM_Error 	Open(char *FrameID, char *Device, char *Prot);
        GSM_Error       Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID);
	GSM_Error 	GetNextRootFolderID(wchar_t *ID, GSM_MemoryType *MemType);
	GSM_Error 	GetFolderInfoList(GSM_FileFolderInfoList *FInfo, BOOLEAN Start);
	GSM_Error 	GetFilePart(GSM_File *File);
	GSM_Error 	AddFilePart(GSM_File *File, int *Pos);

	GSM_Error 	GetPBKStatus(GSM_PBKStatus *Status);
	GSM_Error 	GetPBK(GSM_PBKEntry *Entry);

	GSM_Error 	GetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	GetNextNote(GSM_NoteEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	GetNextToDo(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max);

	GSM_Error 	GetIMEI(unsigned char *IMEI);
	GSM_Error 	GetCodeNameModel(unsigned char *Model);
	GSM_Error 	GetFirmwareVersion(unsigned char *Firm);
	GSM_Error 	GetManufacturer(unsigned char *Manufacturer);

	GSM_Error 	GetNextSMSMMSIDFromFolder(BOOLEAN start, GSM_SMSMMSFoldersSubEntry *SMSFolder, GSM_SMSList *SMS, GSM_MMSEntry *MMS, int *Current, int *MaxInFolder);
	GSM_Error 	GetSMSMMSFolders(GSM_SMSMMSFolders *Folders);

private:
	unsignedstring			CFGDevice, CFGProtocol;
	unsigned char   		ConnectionID[4];
	GSM_FileFolderInfoListSubEntry  *RootFolderSubEntry;
	GSM_FileFolderInfoList 		RootFolder;
	GSM_File			Capability;
	GSM_File			PhonePBK,Notes,Calendar,SyncMLSMS;
	int 				CalendarID,NoteID,ToDoID;
	GSM_OBEXService			Service;
	wchart				SMSID;

	GSM_Error 	SyncMLGetPBKStatus(GSM_PBKStatus *Status);
	GSM_Error 	SyncMLGetPBK(GSM_PBKEntry *Entry);
	GSM_Error 	SyncMLGetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	SyncMLGetNextNote(GSM_NoteEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	SyncMLGetNextToDo(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max);
	GSM_Error 	SyncMLGetIMEI(unsigned char *IMEI);
	GSM_Error 	SyncMLGetCodeNameModel(unsigned char *Model);
	GSM_Error 	SyncMLGetFirmwareVersion(unsigned char *Firm);
	GSM_Error 	SyncMLGetManufacturer(unsigned char *Manufacturer);
	GSM_Error 	SyncMLReadCapability();
	GSM_Error 	SyncMLGet(unsignedstring MIME, unsignedstring ServerID, unsignedstring ServerFileID, GSM_File *File2);
	GSM_Error 	SyncMLSendFile(unsignedstring Buffer);
	GSM_Error 	SyncMLGetFile(unsignedstring *Buffer);
	GSM_Error 	SyncMLDecodeFromSMS(GSM_SMSList *SMS, unsignedstring buffer, unsigned char *SRC);

	GSM_Error 	FoldersGetIMEI(unsigned char *IMEI);
	GSM_Error 	FoldersGetCodeNameModel(unsigned char *Model);
	GSM_Error 	FoldersGetFirmwareVersion(unsigned char *Firm);
	GSM_Error 	FoldersGetManufacturer(unsigned char *Manufacturer);
	GSM_Error 	FoldersReadCapability();

	void 		AddBlock(unsignedstring *Buffer, unsigned char ID, const unsigned char *AddBuffer, int AddLength);
	GSM_Error 	GetFile(GSM_File *File, unsignedstring Type);
	GSM_Error 	AddFile(GSM_File *File, int *Pos, unsignedstring Type);
	GSM_Error 	SetPath(wchart *Path);
	GSM_Error 	ResetConnection();
	GSM_Error 	Open2();

	GSM_Error 	ReplyGetFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	ReplyOpen(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error	ReplySetPath(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
	GSM_Error 	ReplyAddFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S);
};

#endif
