
GSM_Error GSM_Phone_OBEXGEN::GetNextRootFolderID(wchar_t *ID, GSM_MemoryType *MemType)
{
	FileFolderInfo 	FInfo;
	GSM_Error 	error;

	if (Service != OBEX_FOLDERS) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	if (ID[0] == 0) {
		GetFolderInfoList(&RootFolder, TRUE);
		RootFolderSubEntry = NULL;
	}

	if (!RootFolder.GetNext(&RootFolderSubEntry)) return GSM_Return_Error(GSM_ERR_EMPTY);
	CopyUnicode(RootFolderSubEntry->Info.ID.data(),ID);
	(*Debug)->Deb("root name '%s'\n",UnicodeToStringReturn(RootFolderSubEntry->Info.Name.data()));

	*MemType = RootFolderSubEntry->Memory;

	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::GetFolderInfoList(GSM_FileFolderInfoList *FInfo, BOOLEAN Start)
{
	GSM_File 		File;
        GSM_Error       	error;
	unsignedstring  	Buffer,Type;
	wchart			buf2;
	FileFolderInfo 		*Info;
	wchart 			name,Name2;
	TiXmlDocument 		doc;
	TiXmlNode* 		node;
	TiXmlElement* 		todoElement;
	GSM_MemoryType Memory;

	if (Service != OBEX_FOLDERS) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	FInfo->ClearAll();

	File.Info.ID.append(FInfo->Info.ID);
	Type.append((unsigned char *)"x-obex/folder-listing",21);
	Type.push_back(0x00);
	while (1) {
		error = GetFile(&File, Type);
		if (error.Code != GSM_ERR_NONE && error.Code != GSM_ERR_EMPTY) return error;
		if (error.Code == GSM_ERR_EMPTY) break;
	}

	File.RemoveDTD();
	
	(*Debug)->Deb("%s\n",(char *)File.Buffer.data());

	doc.Parse((char *)File.Buffer.data());
	todoElement = doc.FirstChildElement("folder-listing");
	if (todoElement == NULL) {
		FInfo->SubEntryFullData = TRUE;
	        return GSM_Return_Error(GSM_ERR_NONE);
	}

	for (node = todoElement->FirstChild( "folder" );node;node = node->NextSibling( "folder")) {
		if (!node->ToElement()->Attribute("name")) continue;

		Info = new FileFolderInfo;

		Info->ReadOnly  	= FALSE;
		Info->Hidden    	= FALSE;
		Info->System    	= FALSE;
		Info->DRMForwardLock 	= FALSE;
		Info->Folder    	= TRUE;
		Info->ModificationDateTimeAvailable = FALSE;
		if (node->ToElement()->Attribute("modified")) {
			Info->ModificationDateTimeAvailable = ReadVCalendarDateTime(node->ToElement()->Attribute("modified"), &Info->ModificationDateTime);
		}
		Info->Name.append(StringToUnicodeReturn(node->ToElement()->Attribute("name")));
		Memory = MEM_PHONE;
		if (node->ToElement()->Attribute("mem-type")) {
			if (!strcmp(node->ToElement()->Attribute("mem-type"),"MMC")) {
				Memory = MEM_MEMORY_CARD;
			}
		}
		Name2.clear();
		Name2.append(FInfo->Info.ID);
		Name2.append(Info->Name);
		Name2.push_back('\\');
		Info->SetID(Name2.data());
		FInfo->AddSubEntry(Info,Memory);
	}
	for (node = todoElement->FirstChild( "file" );node;node = node->NextSibling( "file")) {
		if (!node->ToElement()->Attribute("name")) continue;

		Info = new FileFolderInfo;

		Info->ReadOnly  	= FALSE;
		Info->Hidden    	= FALSE;
		Info->System    	= FALSE;
		Info->DRMForwardLock 	= FALSE;
		Info->Folder    	= FALSE;
		Info->Size = 0;
		if (node->ToElement()->Attribute("size")) Info->Size = atoi(node->ToElement()->Attribute("size"));
		Info->ModificationDateTimeAvailable = FALSE;
		if (node->ToElement()->Attribute("modified")) {
			Info->ModificationDateTimeAvailable = ReadVCalendarDateTime(node->ToElement()->Attribute("modified"), &Info->ModificationDateTime);
		}
		Info->Name.append(StringToUnicodeReturn(node->ToElement()->Attribute("name")));
		Name2.clear();
		Name2.append(FInfo->Info.ID);
		Name2.append(Info->Name);
		Info->SetID(Name2.data());

		FInfo->AddSubEntry(Info,MEM_Unknown);
	}

	FInfo->SubEntryFullData = TRUE;

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::FoldersReadCapability()
{
	GSM_File 		File;
	GSM_Error 		error;
	unsignedstring 		Type;
	unsignedstring		RemoteFile;
	TiXmlDocument 		doc;
	unsignedstring 		Buffer;
	unsignedstring  	req,MIME,ServerID,ServerFileID;
	wchart			buf2,name,Name2;

	if (Capability.Info.Size != -1) return GSM_Return_Error(GSM_ERR_NONE);

	Type.append((unsigned char *)"x-obex/capability",17);
	Type.push_back(0x00);
	while (1) {
		error = GetFile(&Capability, Type);
		if (error.Code != GSM_ERR_NONE && error.Code != GSM_ERR_EMPTY) return error;
		if (error.Code == GSM_ERR_EMPTY) break;
	}
	Capability.RemoveDTD();
	(*Debug)->Deb("%s\n",(char *)Capability.Buffer.data());

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::FoldersGetIMEI(unsigned char *IMEI)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = FoldersReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	TiXmlHandle docHandle( &doc );
	todoElement = docHandle.FirstChild("Capability").FirstChild("General").FirstChild("SN").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	sprintf((char *)IMEI,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::FoldersGetCodeNameModel(unsigned char *Model)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = FoldersReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	TiXmlHandle docHandle( &doc );
	todoElement = docHandle.FirstChild("Capability").FirstChild("General").FirstChild("Model").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	sprintf((char *)Model,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::FoldersGetFirmwareVersion(unsigned char *Firm)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = FoldersReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	TiXmlHandle docHandle( &doc );
	todoElement = docHandle.FirstChild("Capability").FirstChild("General").FirstChild("SW").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	sprintf((char *)Firm,"%s",todoElement->Attribute("Version"));

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::FoldersGetManufacturer(unsigned char *Manufacturer)
{
	GSM_Error 		error;
	TiXmlDocument 		doc;
	TiXmlElement* 		todoElement;

	error = FoldersReadCapability();
	if (error.Code != GSM_ERR_NONE) return error;

	doc.Parse((char *)Capability.Buffer.data());
	TiXmlHandle docHandle( &doc );
	todoElement = docHandle.FirstChild("Capability").FirstChild("General").FirstChild("Manufacturer").Element();
	if (todoElement == NULL) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
	sprintf((char *)Manufacturer,"%s",todoElement->GetText());

        return GSM_Return_Error(GSM_ERR_NONE);
}
