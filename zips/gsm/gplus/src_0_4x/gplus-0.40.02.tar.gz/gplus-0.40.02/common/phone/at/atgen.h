/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#include <stdio.h>

#include "../../service/gsmmisc.h"
#include "../../device/gsmdev.h"
#include "../gsmphone.h"

#ifndef __atgen
#define __atgen

class GSM_Protocol;
class GSM_Protocol_Message;

class GSM_Phone_ATGEN:virtual public GSM_Phone
{
public:
        GSM_Phone_ATGEN(DebugInfo **Deb, GSM_Device **Dev, GSM_AllProtocols **Prot, GSM_AllPhones **Pho):GSM_Phone(Deb,Dev,Prot,Pho) {
		Info.push_back(GSM_Phone_Info("", "", "" ,"irdaat", ""));
		Info.push_back(GSM_Phone_Info("", "", "" ,"blueat", ""));
		Info.push_back(GSM_Phone_Info("", "", "" ,"at115200", ""));

		ModuleName 	= "atgen";
		ModulesUsed  	= "";
		ModulesRequired = "";
        }
        ~GSM_Phone_ATGEN() {
        }

	GSM_Error 	Open(char *FrameID, char *Device, char *Prot);
        GSM_Error       Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID);

	GSM_Error 	GetIMEI(unsigned char *IMEI);
	GSM_Error 	GetManufacturer(unsigned char *Manufacturer);
private:
	GSM_Error 	ReplyGetIMEI(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *IMEI);
	GSM_Error 	ReplyGetManufacturer(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *Manufacturer);
};

#endif
