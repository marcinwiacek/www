void Backup(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
	unsigned char       		Model[50];
    	unsigned char       		Man[50];
    	unsigned char       		Firm[50];
    	char        			buff[200];
        GSM_Error 			error;
	GSM_Backup			Backup;
	GSM_PBKStatus 			Status;
	GSM_PBKEntry 			*PBKEntry;
	GSM_CalendarEntry		*CalEntry;
	GSM_ToDoEntry 			*ToDoEntry;
	GSM_NoteEntry 			*NoteEntry;
	GSM_FMStation       		*FMEntry;
	GSM_WAPBookmark			*WAPEntry;
	int				i,Pos,Current,Max;
	char				ch;
	BOOLEAN				newe,Start;
	GSM_Backup_FileFormatFunctions	Func;

	if (strstr(argv[0],".xml")) {
		Backup.GetFileFunctions(Backup_XML, &Func);
	} else {
		Backup.GetFileFunctions(Backup_Gammu, &Func);
	}

	error = s->Open(CFG);
	PrintError(error);

	error = s->Phones->Current->GetManufacturer(Man);
	if (error.Code != GSM_ERR_NONE) Man[0] = 0;

    	error = s->Phones->Current->GetCodeNameModel((unsigned char *)buff);
    	if (error.Code != GSM_ERR_NONE) buff[0] = 0;

	error = s->Phones->Current->GetModel(Model);
	if (error.Code != GSM_ERR_NONE) Model[0] = 0;

	error = s->Phones->Current->GetFirmwareVersion(Firm);
	if (error.Code != GSM_ERR_NONE) Firm[0] = 0;

        sprintf(Backup.DeviceModel,"%s", Man);
        sprintf(Backup.DeviceModel+strlen(Backup.DeviceModel)," %s",buff);
        sprintf(Backup.DeviceModel+strlen(Backup.DeviceModel)," (%s)",Model);
        sprintf(Backup.DeviceModel+strlen(Backup.DeviceModel)," %s",Firm);
                       
    	error = s->Phones->Current->GetIMEI((unsigned char *)Backup.DeviceIMEI);
    	if (error.Code != GSM_ERR_NONE) Backup.DeviceIMEI[0] = 0;

	if (Func.SIMPBK) {
		newe = TRUE;
		Status.Memory=MEM_SIM;
		error = s->Phones->Current->GetPBKStatus(&Status);
		if (error.Code == GSM_ERR_NONE) {
			printf("Do you want to backup phonebook from SIM ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			if (ch == 'Y') {
				i = 0;
				Pos=1;
				while (i!=Status.Used) {
					if (newe) {
				                PBKEntry = new GSM_PBKEntry;
						newe = FALSE;
					}
					PBKEntry->Location= Pos;
			            	PBKEntry->Memory = Status.Memory;
			            	error = s->Phones->Current->GetPBK(PBKEntry);				
					Pos++;
					i++;
					if (error.Code != GSM_ERR_NONE) continue;
					Backup.Add_PBK(PBKEntry);
					newe=TRUE;
				}
			}		
		}
		if (!newe) delete (PBKEntry);
	}

	if (Func.PhonePBK) {
		newe = TRUE;
		Status.Memory=MEM_PHONE;
		error = s->Phones->Current->GetPBKStatus(&Status);
		if (error.Code == GSM_ERR_NONE) {
			printf("Do you want to backup phonebook from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			if (ch == 'Y') {
				i = 0;
				Pos=1;
				while (i!=Status.Used) {
					if (newe) {
				                PBKEntry = new GSM_PBKEntry;
						newe = FALSE;
					}
			                PBKEntry = new GSM_PBKEntry;
					PBKEntry->Location= Pos;
			            	PBKEntry->Memory = Status.Memory;
			            	error = s->Phones->Current->GetPBK(PBKEntry);				
					Pos++;
					i++;
					if (error.Code != GSM_ERR_NONE) continue;
					Backup.Add_PBK(PBKEntry);
					newe=TRUE;
				}
			}
		}
		if (!newe) delete (PBKEntry);
	}

	if (Func.Calendar) {
		CalEntry = new GSM_CalendarEntry;
		newe = TRUE;
		Start = TRUE;
	        error = s->Phones->Current->GetNextCalendar(CalEntry,Start,&Current,&Max);
		if (error.Code == GSM_ERR_NONE) {
			printf("Do you want to backup calendar from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			Start = TRUE;
			if (ch == 'Y') {
				while (1) {
				        if (newe) {
						CalEntry = new GSM_CalendarEntry;
						newe = FALSE;
				        }
				        error = s->Phones->Current->GetNextCalendar(CalEntry,Start,&Current,&Max);
				        if (error.Code == GSM_ERR_EMPTY) break;
				        Backup.Add_Cal(CalEntry);
					Start = FALSE;
					newe = TRUE;
				}
			}	
		}
		if (!newe) delete (CalEntry);
	}

	if (Func.ToDo) {
		ToDoEntry = new GSM_ToDoEntry;
		newe = TRUE;
		Start = TRUE;
	        error = s->Phones->Current->GetNextToDo(ToDoEntry,Start,&Current,&Max);
		if (error.Code == GSM_ERR_NONE) {
			printf("Do you want to backup todo from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			Start = TRUE;
			if (ch == 'Y') {
				while (1) {
				        if (newe) {
						ToDoEntry = new GSM_ToDoEntry;
						newe = FALSE;
				        }
				        error = s->Phones->Current->GetNextToDo(ToDoEntry,Start,&Current,&Max);
				        if (error.Code == GSM_ERR_EMPTY) break;
				        Backup.Add_ToDo(ToDoEntry);
					Start = FALSE;
					newe = TRUE;
				}
			}	
		}
		if (!newe) delete (ToDoEntry);
	}

	if (Func.Notes) {
		NoteEntry = new GSM_NoteEntry;
		newe = TRUE;
		Start = TRUE;
	        error = s->Phones->Current->GetNextNote(NoteEntry,Start,&Current,&Max);
		if (error.Code == GSM_ERR_NONE) {
		printf("Do you want to backup notes from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			Start = TRUE;
			if (ch == 'Y') {
				while (1) {
				        if (newe) {
						NoteEntry = new GSM_NoteEntry;
						newe = FALSE;
				        }
				        error = s->Phones->Current->GetNextNote(NoteEntry,Start,&Current,&Max);
				        if (error.Code == GSM_ERR_EMPTY) break;
				        Backup.Add_Note(NoteEntry);
					Start = FALSE;
					newe = TRUE;
				}
			}	
		}
		if (!newe) delete (NoteEntry);
	}

	if (Func.FMStations) {
		FMEntry = new GSM_FMStation;
		newe = FALSE;
	        FMEntry->Location = 1;
	        error = s->Phones->Current->GetFMStation(FMEntry);
		if (error.Code == GSM_ERR_NONE || error.Code == GSM_ERR_EMPTY) {
			printf("Do you want to backup FM stations from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			Start = TRUE;
			if (ch == 'Y') {
				i = 1;
				while (1) {
					if (newe) {
						FMEntry = new GSM_FMStation;
						newe = FALSE;
			        	}
				        FMEntry->Location = i;
				        error = s->Phones->Current->GetFMStation(FMEntry);
				        if (error.Code == GSM_ERR_INVALID_LOCATION) break;
				        if (error.Code == GSM_ERR_EMPTY) {
						i++;
						continue;
		        		}	
				        Backup.Add_FMStation(FMEntry);
				        i++;
				        newe = TRUE;
				}
			}
		}
		if (!newe) delete (FMEntry);
	}

	if (Func.WAPBookmarks) {
		WAPEntry = new GSM_WAPBookmark;
		newe = FALSE;
	        WAPEntry->Location = 1;
	        error = s->Phones->Current->GetWAPBookmark(WAPEntry);
		if (error.Code == GSM_ERR_NONE || error.Code == GSM_ERR_EMPTY) {
			printf("Do you want to backup WAP bookmarks from phone ? (Y/N)");
			do {
			      ch = toupper(getc(stdin));
			} while(ch != 'Y' && ch != 'N');
			Start = TRUE;
			if (ch == 'Y') {
				i = 1;
				while (1) {
					if (newe) {
						WAPEntry = new GSM_WAPBookmark;
						newe = FALSE;
			        	}
				        WAPEntry->Location = i;
				        error = s->Phones->Current->GetWAPBookmark(WAPEntry);
				        if (error.Code != GSM_ERR_NONE) break;
				        Backup.Add_WAPBookmark(WAPEntry);
				        i++;
				        newe = TRUE;
				}
			}
		}
		if (!newe) delete (WAPEntry);
	}


	if (strstr(argv[0],".xml")) {
	    	error = Backup.SaveToFile(argv[0],Func,Backup_XML);
	} else {
	    	error = Backup.SaveToFile(argv[0],Func,Backup_Gammu);
	}
}

void Restore(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
        GSM_Error 		error;
	GSM_Backup		Backup;
	GSM_PBKStatus 		Status;
	GSM_Backup_PBKEntry	*PBKEntry;
	GSM_PBKEntry 		PBKEntry2;
	GSM_Backup_CalEntry	*CalEntry;
	GSM_CalendarEntry	CalEntry2;
	int			i;
	char			ch;

	error = Backup.ReadFromFile(argv[0]);
	PrintError(error);

	error = s->Open(CFG);
	PrintError(error);

	Status.Memory=MEM_PHONE;
	error = s->Phones->Current->GetPBKStatus(&Status);
	if (error.Code != GSM_ERR_NONE) {
		PrintError(error);
	} else {
		printf("Do you want to restore phone phonebook ?");
		do {
		      ch = toupper(getc(stdin));
		} while(ch != 'Y' && ch != 'N');
		if (ch == 'Y') {
			PBKEntry2.Memory=MEM_PHONE;
			for(i=1;i<=Status.Used + Status.Free;i++) {
				PBKEntry = NULL;
				while (Backup.GetNext_PBK(&PBKEntry)) {
					if (PBKEntry->GetEntry()->Memory != MEM_PHONE) continue;
					if (PBKEntry->GetEntry()->Location != i) continue;
					error = s->Phones->Current->SetPBK(PBKEntry->GetEntry());
					PrintError(error);
					break;
				}
				if (PBKEntry != NULL && PBKEntry->GetEntry()->Location == i) continue;
				PBKEntry2.Location = i;
				error = s->Phones->Current->DeletePBK(&PBKEntry2);
				PrintError(error);
			}
		}
	}

	printf("Do you want to restore phone calendar ?");
	do {
	      ch = toupper(getc(stdin));
	} while(ch != 'Y' && ch != 'N');
	if (ch == 'Y') {
		CalEntry = NULL;
		while (Backup.GetNext_Cal(&CalEntry)) {
			error = s->Phones->Current->AddCalendar(CalEntry->GetEntry());
			PrintError(error);
		}
	}
}

void ClearAll(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
        GSM_Error 		error;
	GSM_CalendarEntry 	Entry;
	char			ch;
	int				Current,Max;

	error = s->Open(CFG);
	PrintError(error);

	printf("Do you want to clear phone calendar ?");
	do {
	      ch = toupper(getc(stdin));
	} while(ch != 'Y' && ch != 'N');
	if (ch == 'Y') {
		while (1) {
			error = s->Phones->Current->GetNextCalendar(&Entry,TRUE,&Current,&Max);
			if (error.Code == GSM_ERR_EMPTY) break;
			PrintError(error);
	
			error = s->Phones->Current->DeleteCalendar(&Entry);
			PrintError(error);		
		}
	}
}

