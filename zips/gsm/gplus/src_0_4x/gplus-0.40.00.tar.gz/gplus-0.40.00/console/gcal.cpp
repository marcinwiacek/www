void GetAllCalendar(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
        GSM_Error 		error;
	GSM_CalendarEntry 	Entry;
	GSM_CalendarSubEntry 	*SubEntry;
	BOOLEAN			start = TRUE;
	int			RepeatEach,RepeatDay,RepeatMonth,RepeatDOW,Current,Max;

	error = s->Open(CFG);
	PrintError(error);

	while (1) {
		error = s->Phones->Current->GetNextCalendar(&Entry,start,&Current,&Max);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		printf("\nNote type    : ");
		switch(Entry.Type) {
		case Calendar_Type_Meeting:
			printf("meeting\n");
			break;
		case Calendar_Type_Memo:
			printf("memo\n");
			break;
		case Calendar_Type_Call:
			printf("phone call\n");
			break;
		case Calendar_Type_Birthday:
			printf("birthday\n");
			break;
		case Calendar_Type_Reminder:
			printf("reminder\n");
			break;
		}

		RepeatEach 	= -1;
		RepeatDay 	= -1;
		RepeatMonth 	= -1;
		RepeatDOW 	= -1;
		SubEntry 	= NULL;
		while (Entry.GetNext(&SubEntry) == TRUE) {
			switch (SubEntry->GetType()) {
			case Calendar_Text_Text:
				printf("Text         : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_Text_Phone:
				printf("Phone number : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_Text_Location:
				printf("Location     : \"%s\"\n",UnicodeToStringReturn(SubEntry->GetText()));
				break;
			case Calendar_DateTime_Start:
				printf("Start time   : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_DateTime_End:
				printf("End time     : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_DateTime_SilentAlarm:
			case Calendar_DateTime_ToneAlarm:
				if (SubEntry->GetType() == Calendar_DateTime_SilentAlarm) {
					printf("Silent alarm : ");
				} else {
					printf("Tone alarm   : ");
				}
				if (Entry.Type == Calendar_Type_Birthday) {
					printf("%02i:%02i:%02i %02i-%02i in each year\n",
						SubEntry->GetDateTime()->Hour,
						SubEntry->GetDateTime()->Minute,
						SubEntry->GetDateTime()->Second,
						SubEntry->GetDateTime()->Day,
						SubEntry->GetDateTime()->Month);
				} else {
					printf("%02i:%02i:%02i %02i-%02i-%04i %s\n",
						SubEntry->GetDateTime()->Hour,
						SubEntry->GetDateTime()->Minute,
						SubEntry->GetDateTime()->Second,
						SubEntry->GetDateTime()->Day,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Year,
						DayOfWeekStr(
							SubEntry->GetDateTime()->Year,
							SubEntry->GetDateTime()->Month,
							SubEntry->GetDateTime()->Day));
				}
				break;
			case Calendar_DateTime_End_Repeat:
				printf("Repeat end   : %02i:%02i:%02i %02i-%02i-%04i %s\n",
					SubEntry->GetDateTime()->Hour,
					SubEntry->GetDateTime()->Minute,
					SubEntry->GetDateTime()->Second,
					SubEntry->GetDateTime()->Day,
					SubEntry->GetDateTime()->Month,
					SubEntry->GetDateTime()->Year,
					DayOfWeekStr(
						SubEntry->GetDateTime()->Year,
						SubEntry->GetDateTime()->Month,
						SubEntry->GetDateTime()->Day));
				break;
			case Calendar_Int_Repeat_Frequency:
				RepeatEach = SubEntry->GetInt();
				break;
			case Calendar_Int_Repeat_DayOfWeek:
				RepeatDOW = SubEntry->GetInt();
				break;			
			case Calendar_Int_Repeat_Day:
				RepeatDay = SubEntry->GetInt();
				break;
			case Calendar_Int_Repeat_Month:
				RepeatMonth = SubEntry->GetInt();
				break;
			}
		}

		if (RepeatEach != -1 || RepeatDOW != -1 ||
		    RepeatDay != -1 || RepeatMonth != -1) {
			printf("Repeat note  : ");
			if (RepeatEach == 1) printf("each ");
			if (RepeatEach == 2) printf("each second ");
			if (RepeatDOW != -1) {
				switch (RepeatDOW) {
					case 1: printf("Monday ");	break;
					case 2: printf("Tuesday ");	break;
					case 3: printf("Wednesday ");	break;
					case 4: printf("Thursday ");	break;
					case 5: printf("Friday ");	break;
					case 6: printf("Saturday ");	break;
					case 7: printf("Sunday ");	break;
					default:printf(" ");
				}
			}
			if (RepeatDay != -1) {
				printf("%i ",RepeatDay);
				if (RepeatMonth != -1) {
					switch (RepeatMonth) {
						case  1: printf("January ");	break;
						case  2: printf("February ");	break;
						case  3: printf("March ");	break;
						case  4: printf("April ");	break;
						case  5: printf("May ");	break;
						case  6: printf("June ");	break;
						case  7: printf("July ");	break;
						case  8: printf("August ");	break;
						case  9: printf("September ");	break;
						case 10: printf("October ");	break;
						case 11: printf("November ");	break;
						case 12: printf("December ");	break;
						default:printf(" ");
					}
				} else {
					printf("month day ");
				}
			}
			printf("\n");
		}

		start = FALSE;
	}
}

void GetAllNotes(GSM_StateMachine *s, GSM_GPlusConfig *CFG, int argc, char *argv[])
{
        GSM_Error 		error;
	GSM_NoteEntry	 	Entry;
	BOOLEAN			start = TRUE;
	int Current,Max;

	error = s->Open(CFG);
	PrintError(error);

	while (1) {
		error = s->Phones->Current->GetNextNote(&Entry,start,&Current,&Max);
		if (error.Code == GSM_ERR_EMPTY) break;
		PrintError(error);

		printf("text %s\n",UnicodeToStringReturn(Entry.Text.data()));

		start = FALSE;
	}
}

