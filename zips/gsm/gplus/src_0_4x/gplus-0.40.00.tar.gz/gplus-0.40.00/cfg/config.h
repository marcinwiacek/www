
#define VERSION "0.40.0"
#define VERSION_WIN "0,40,0,0"

#define BLUETOOTH_RF_SEARCHING 1

//MS Visual C++ Express 2005 (and later) warnings
#if _MSC_VER == 1400 || _MSC_VER == 1500
#  pragma warning( disable : 4996 4244 4333)
#  ifndef _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES
#    define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES  1
#  endif
#  ifndef _CRT_SECURE_NO_DEPRECATE
#    define _CRT_SECURE_NO_DEPRECATE  1
#  endif
#endif

//#define POSTGRESQL 1

#define     WBXML_ENCODER_USE_STRTBL 1
#define     WBXML_SUPPORT_WML 1
#define     WBXML_SUPPORT_WTA 1
#define     WBXML_SUPPORT_SI 1
#define     WBXML_SUPPORT_SL 1
#define     WBXML_SUPPORT_CO 1
#define     WBXML_SUPPORT_PROV 1
#define     WBXML_SUPPORT_EMN 1
#define     WBXML_SUPPORT_DRMREL 1
#define     WBXML_SUPPORT_OTA_SETTINGS 1
#define     WBXML_SUPPORT_SYNCML 1
#define     WBXML_SUPPORT_WV 1
#define     HAVE_EXPAT 1
//#define	    WBXML_LIB_VERBOSE 1
