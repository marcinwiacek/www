<?php
	$database = pg_connect("host=127.0.0.1 dbname=gplus_sms_mms user=postgres password=postgres");
	if (!$database) echo "error1";
	if (isset($_GET['fileid']) && isset($_GET['fileid2'])) {
		$sql="select content,type2 from daemon.\"inbox_decoded\" where id=".$_GET['fileid']." and seq_num=".$_GET['fileid2'];
		$result = pg_query($database,$sql);
		if (!$result) echo "error2";
		$result2 = pg_fetch_array($result);
		header("Content-type: ".$result2['type2']);

		if ($result2['type2']=="text/plain" ||
		    $result2['type2']=="text/x-vCard" ||
		    $result2['type2']=="text/x-vNote" ||
		    $result2['type2']=="text/x-vTodo" ||
		    $result2['type2']=="text/x-vImelody" ||
		    $result2['type2']=="text/x-vCalendar" ||
		    $result2['type2']=="application/smil") {
			echo $result2["content"];
			exit;
		}

		$len=strlen($result2["content"]);
		for ($i=0;$i<$len;$i+=2) {
			echo chr(intval($result2["content"][$i].$result2["content"][$i+1],16));
		}
		exit;
	}

	echo "<html><head>";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" >";
	echo "</head><body>";
	if(!$database) echo "error";

	echo "<form method=get name=formula>";
	echo "<select name=id size=5 onChange=document.formula.submit()>";
	$result = @pg_query($database,"select id from daemon.\"inbox_decoded\" where type=2 order by dt");
        while ($result2 = @pg_fetch_array($result)) {
		echo "<option";
		if (isset($_GET['id']) && $result2['id']==$_GET['id']) echo " selected";
		echo ">".$result2["id"]."</option>";
	}
	echo "</select></form><p>";
	echo "<script>document.formula.id.focus();</script>";
	if (!isset($_GET['id'])) exit;

	echo "<hr>";
	echo "From: ";
	$sql="select content from daemon.\"inbox_decoded\" where id=".$_GET['id']." and type=1";
	$result = pg_query($database,$sql);
        $result2 = pg_fetch_array($result);
	echo $result2["content"]."<br>";

	echo "Sent: ";
	$sql="select dt from daemon.\"inbox_decoded\" where id=".$_GET['id']." and type=2";
	$result = pg_query($database,$sql);
        $result2 = pg_fetch_array($result);
	echo $result2["dt"]."<br>";

	$first = true;
	$sql="select type,content,type2,id,seq_num,filename from daemon.\"inbox_decoded\" where id=".$_GET['id']." and type=0 order by seq_num";
	$result = pg_query($database,$sql);
        while ($result2 = pg_fetch_array($result)) {
		if (strstr($result2["type2"],"image/")) {
		} else if ($result2["type2"]=="text/plain") {
		} else {
			if ($first) echo "Attachments: ";
			$first = false;
			echo "<a href=ala.php?fileid=".$_GET['id']."&fileid2=".$result2['seq_num'].">";
			if ($results2["filename"]!='') {
				echo $results2["filename"];
			} else {
				echo "attachment";
			}
			echo "</a>";
		}
	}
	if (!$first) echo "<br>";

	echo "<hr>";
	$sql="select type,content,type2,id,seq_num,bold,italic,underline,strikethrough,small,large from daemon.\"inbox_decoded\" where id=".$_GET['id']." and type=0 order by seq_num";
	$result = pg_query($database,$sql);
        while ($result2 = pg_fetch_array($result)) {
		if (strstr($result2["type2"],"image/")) {
			echo "<img src=ala.php?fileid=".$_GET['id']."&fileid2=".$result2['seq_num'].">";
		} else if ($result2["type2"]=="text/plain") {
			if ($result2["bold"]=='t') echo "<b>";
			if ($result2["underline"]=='t') echo "<u>";
			echo $result2["content"];
			if ($result2["underline"]=='t') echo "</u>";
			if ($result2["bold"]=='t') echo "</b>";
		} else {
		}
	}

	echo "</body></html>";
?>
