/* (C) 2003 - 2007 by Marcin Wiacek www.mwiacek.com */

#ifndef gsm_pbk_h
#define gsm_pbk_h

#ifdef WIN32
#  include <windows.h>
#endif

#include "gsmmisc.h"
#include "../misc/misc.h"

typedef enum {
	PBK_Not_Assigned = 1,

	PBK_Text_Phone_General,
	PBK_Text_Phone_Car,
	PBK_Text_Phone_Home,
	PBK_Text_Phone_Work,
	PBK_Text_Phone_Fax,
	PBK_Text_Phone_Fax_Home,
	PBK_Text_Phone_Fax_Work,
	PBK_Text_Phone_Video,
	PBK_Text_Phone_Video_Home,
	PBK_Text_Phone_Video_Work,
	PBK_Text_Phone_Mobile,
	PBK_Text_Phone_Mobile_Home,
	PBK_Text_Phone_Mobile_Work,
	PBK_Text_Phone_Internet,
	PBK_Text_Phone_Internet_Home,
	PBK_Text_Phone_Internet_Work,
	PBK_Text_Phone_Assistant,
	PBK_Text_Postal_ZIP,
	PBK_Text_Postal_Street,
	PBK_Text_Postal_City,
	PBK_Text_Postal_State,
	PBK_Text_Postal_ZIP_Code,
	PBK_Text_Postal_PO_Box,
	PBK_Text_Postal_Country,
	PBK_Text_Postal_Extension,
	PBK_Text_Postal_Region,

	PBK_Text_Postal_ZIP_Home,
	PBK_Text_Postal_Street_Home,
	PBK_Text_Postal_City_Home,
	PBK_Text_Postal_State_Home,
	PBK_Text_Postal_ZIP_Code_Home,
	PBK_Text_Postal_PO_Box_Home,
	PBK_Text_Postal_Country_Home,
	PBK_Text_Postal_Extension_Home,
	PBK_Text_Postal_Region_Home,

	PBK_Text_Postal_ZIP_Work,
	PBK_Text_Postal_Street_Work,
	PBK_Text_Postal_City_Work,
	PBK_Text_Postal_State_Work,
	PBK_Text_Postal_ZIP_Code_Work,
	PBK_Text_Postal_PO_Box_Work,
	PBK_Text_Postal_Country_Work,
	PBK_Text_Postal_Extension_Work,
	PBK_Text_Postal_Region_Work,

	PBK_Text_Email,
	PBK_Text_Email_Home,
	PBK_Text_Email_Work,
	PBK_Text_Pager,
	PBK_Text_URL,
	PBK_Text_URL_Home,
	PBK_Text_URL_Work,
	PBK_Text_Spouse,
	PBK_Text_Children,
	PBK_Text_UserID,
	PBK_Text_Note,
	PBK_Text_Name,
	PBK_Text_Name_Last,
	PBK_Text_Name_First,
	PBK_Text_Name_Middle,
	PBK_Text_Name_Formal,
	PBK_Text_Name_Title,
	PBK_Text_Name_Suffix,
	PBK_Text_Name_Nick,
	PBK_Text_Company_Name,
	PBK_Text_Department_Name,
	PBK_Text_Job_Title,
	PBK_Text_Assistant,
	PBK_Text_PTT,
	PBK_Text_Video_Sharing_SIP,
	PBK_Text_Share_View,
	PBK_DateTime_Call_Length,
	PBK_DateTime_Modified,
	PBK_DateTime_Anniversary,
	PBK_DateTime_Birthday,
	PBK_ID_Caller_Group,
	PBK_ID_Picture,
	PBK_ID_Ringtone,
	PBK_ID_Video_File,
	PBK_Bool_PTT_Subscribed
} GSM_PBK_SubEntryType;

typedef enum {
	VCARD_10 = 1,
	VCARD_21
} GSM_VCARDType;

class GSM_PBKSubEntry
{
	friend class GSM_PBKEntry;
public:
	GSM_PBKSubEntry();
	~GSM_PBKSubEntry();

	GSM_Error		SetError;
	GSM_PBK_SubEntryType 	GetType();
	GSM_Error 		SetToText(GSM_PBK_SubEntryType Typ, wchar_t *Txt);
	wchar_t			*GetText();
	GSM_Error 		SetToDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2);
	GSM_DateTime		*GetDateTime();
	GSM_Error 		SetToLong(GSM_PBK_SubEntryType Typ, long long2);
	long			LongValue;
	GSM_Error 		SetToBool(GSM_PBK_SubEntryType Typ, bool bool2);
	bool			BoolValue;

	long			VoiceTag;
	GSM_Error		VoiceTagSetError;
	long			CallLength;
	unsignedint		SMSLists;
	GSM_Error		SMSListsSetError;

	GSM_PBKSubEntry		*GetNext();
private:
	void 			SetNext(GSM_PBKSubEntry *Nxt);

	GSM_DateTime		DT;
	GSM_PBKSubEntry		*Next;
	wchar_t			*Text;
	GSM_PBK_SubEntryType	Type;
};

class GSM_PBKEntry
{
public:
	GSM_PBKEntry();
	~GSM_PBKEntry();

	int 			Location;
	GSM_MemoryType		Memory;
	int			DefaultNumberNum;

	void 			ClearAll();	
	BOOLEAN 		GetNext(GSM_PBKSubEntry **En);
	GSM_Error	 	AddText(GSM_PBK_SubEntryType Typ, wchar_t *Txt);
	GSM_Error	 	AddDateTime(GSM_PBK_SubEntryType Typ, GSM_DateTime DT2);
	GSM_Error	 	AddLong(GSM_PBK_SubEntryType Typ, long long2);
	GSM_Error	 	AddBool(GSM_PBK_SubEntryType Typ, bool bool2);
	GSM_Error 		EncodeToVCARD(unsignedstring *dest, GSM_VCARDType Type);
	GSM_Error 		DecodeFromVCARD(unsignedstring *src);
private:
	GSM_PBKSubEntry		*Entries;
};

typedef struct {
	int 			Used;
	int 			Free;
	GSM_MemoryType		Memory;
} GSM_PBKStatus;

typedef enum {
	GSM_CallerName = 1,
	GSM_CallerDefaultName
} GSM_Caller_Group_Types;

class GSM_CallerGroupSubEntry
{
	friend class GSM_CallerGroupEntry;
public:
	GSM_CallerGroupSubEntry();
	~GSM_CallerGroupSubEntry();

	GSM_Caller_Group_Types 		Type;
	wchart				Text;

	GSM_CallerGroupSubEntry		*GetNext();
private:
	void 				SetNext(GSM_CallerGroupSubEntry *Nxt);

	GSM_CallerGroupSubEntry		*Next;
};

class GSM_CallerGroupEntry
{
public:
	GSM_CallerGroupEntry();
	~GSM_CallerGroupEntry();

	int				Location;

	void 				ClearAll();
	BOOLEAN 			GetNext(GSM_CallerGroupSubEntry **En);
	BOOLEAN 			AddSubEntry(GSM_CallerGroupSubEntry *En);
private:
	GSM_CallerGroupSubEntry		*Entries;
};

typedef struct {
 	char			*Name;
	GSM_PBK_SubEntryType 	Type;
} GetMemoryTypes;

static GetMemoryTypes GetMemoryType[] = {
	"General phone", 		PBK_Text_Phone_General,
	"Car phone", 			PBK_Text_Phone_Car,
	"Home phone", 			PBK_Text_Phone_Home,
	"Work phone", 			PBK_Text_Phone_Work,
	"Fax phone", 			PBK_Text_Phone_Fax,
	"Home fax phone", 		PBK_Text_Phone_Fax_Home,
	"Work fax phone", 		PBK_Text_Phone_Fax_Work,
	"Video phone",			PBK_Text_Phone_Video,
	"Home video phone",		PBK_Text_Phone_Video_Home,
	"Work video phone",		PBK_Text_Phone_Video_Work,
	"Mobile phone",			PBK_Text_Phone_Mobile,
	"Home mobile phone",		PBK_Text_Phone_Mobile_Home,
	"Work mobile phone",		PBK_Text_Phone_Mobile_Work,
	"Internet phone",		PBK_Text_Phone_Internet,
	"Home internet phone",		PBK_Text_Phone_Internet_Home,
	"Work internet phone",		PBK_Text_Phone_Internet_Work,
	"Assistant's phone",		PBK_Text_Phone_Assistant,
	"Postal/ZIP",			PBK_Text_Postal_ZIP,
	"Street",			PBK_Text_Postal_Street,
	"City",				PBK_Text_Postal_City,
	"State",			PBK_Text_Postal_State,
	"ZIP code",			PBK_Text_Postal_ZIP_Code,
	"PO box",			PBK_Text_Postal_PO_Box,
	"Country",			PBK_Text_Postal_Country,
	"Extension",			PBK_Text_Postal_Extension,
	"Region",			PBK_Text_Postal_Region,
	"Postal/ZIP (home)",		PBK_Text_Postal_ZIP_Home,
	"Street (home)",		PBK_Text_Postal_Street_Home,
	"City (home)",			PBK_Text_Postal_City_Home,
	"State (home)",			PBK_Text_Postal_State_Home,
	"ZIP code (home)",		PBK_Text_Postal_ZIP_Home,
	"PO box (home)",		PBK_Text_Postal_PO_Box_Home,
	"Country (home)",		PBK_Text_Postal_Country_Home,
	"Extension (home)",		PBK_Text_Postal_Extension_Home,
	"Region (home)",		PBK_Text_Postal_Region_Home,
	"Postal/ZIP (work)",		PBK_Text_Postal_ZIP_Work,
	"Street (work)",		PBK_Text_Postal_Street_Work,
	"City (work)",			PBK_Text_Postal_City_Work,
	"State (work)",			PBK_Text_Postal_State_Work,
	"ZIP code (work)",		PBK_Text_Postal_ZIP_Code_Work,
	"PO box (work)",		PBK_Text_Postal_PO_Box_Work,
	"Country (work)",		PBK_Text_Postal_Country_Work,
	"Extension (work)",		PBK_Text_Postal_Extension_Work,
	"Region (work)",		PBK_Text_Postal_Region_Work,
	"Email",			PBK_Text_Email,
	"Home email",			PBK_Text_Email_Home,
	"Work email",			PBK_Text_Email_Work,
	"Pager",			PBK_Text_Pager,
	"URL",				PBK_Text_URL,
	"URL (home)",			PBK_Text_URL_Home,
	"URL (work)",			PBK_Text_URL_Work,
	"Spouse",			PBK_Text_Spouse,
	"Children",			PBK_Text_Children,
	"User ID",			PBK_Text_UserID,
	"Note",				PBK_Text_Note,
	"Name",				PBK_Text_Name,
	"Last name",			PBK_Text_Name_Last,
	"First name",			PBK_Text_Name_First,
	"Middle name",			PBK_Text_Name_Middle,
	"Formal name",			PBK_Text_Name_Formal,
	"Title",			PBK_Text_Name_Title,
	"Suffix",			PBK_Text_Name_Suffix,
	"Nickname",			PBK_Text_Name_Nick,
	"Company name",			PBK_Text_Company_Name,
	"Department name",		PBK_Text_Department_Name,
	"Job title",			PBK_Text_Job_Title,
	"Assistant's name",		PBK_Text_Assistant,
	"Push to talk",			PBK_Text_PTT,
	"Video sharing SIP",		PBK_Text_Video_Sharing_SIP,
	"Share view",			PBK_Text_Share_View,
	"",				PBK_Not_Assigned	
};

#endif
