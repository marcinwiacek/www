/* (C) 2003 - 2008 by Marcin Wiacek www.mwiacek.com */

#include "../../protocol/gsmprot.h"
#include "obexgen.h"
#include "../../misc/xml/tinyxml.h"
#include "../../misc/wbxml/wbxml.h" /* libwbxml2 */

#include "_syncml.cpp"
#include "_folders.cpp"

GSM_Error GSM_Phone_OBEXGEN::Dispatch(GSM_Protocol_Message *msg, void *Struct, int RequestID)
{
	AnsStruct 	AS;

	AS.RequestID  = RequestID;
	AS.FrameFound = false;

//Continue
if(Ans("\x90",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);
if(Ans("\x90",0x00,0x00,ID_AddFilePart+ID,&AS))return ReplyAddFilePart(msg,Debug,(unsigned char *)Struct);

//Success
if(Ans("\xA0",0x00,0x00,ID_GetIMEI+ID,&AS))return ReplyOpen(msg,Debug,(unsigned char *)Struct);
if(Ans("\xA0",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);
if(Ans("\xA0",0x00,0x00,ID_AddFilePart+ID,&AS))return ReplyAddFilePart(msg,Debug,(unsigned char *)Struct);

if(Ans("\xC3",0x00,0x00,ID_AddFilePart+ID,&AS))return ReplyAddFilePart(msg,Debug,(unsigned char *)Struct);

if(Ans("\xC4",0x00,0x00,ID_GetFilePart+ID,&AS))return ReplyGetFilePart(msg,Debug,(unsigned char *)Struct);

	if (AS.FrameFound) return GSM_Return_Error(GSM_ERR_FRAME_NOT_REQUESTED);
        return GSM_Return_Error(GSM_ERR_FRAME_TYPE_UNKNOWN);
}

void GSM_Phone_OBEXGEN::AddBlock(unsignedstring *Buffer, unsigned char ID, const unsigned char *AddBuffer, int AddLength)
{	
	Buffer->push_back(ID);
	Buffer->push_back((AddLength+3)/256);
	Buffer->push_back((AddLength+3)%256);
	if (AddLength != 0) Buffer->append(AddBuffer,AddLength);
}

GSM_Error GSM_Phone_OBEXGEN::ReplySetPath(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::SetPath(wchart *Path)
{	
	GSM_File 	File;
        GSM_Error       error;
	unsignedstring  Buffer,Type,req,Now;
	wchart		buf2;
	wchart 		name;
	int 		i=0;

	(*Debug)->Deb("Path '%s'\n",UnicodeToStringReturn(Path->data()));
	while (true) {
		req.clear();
		/* Flags */
		req.push_back(2); req.push_back(0x00);
		/* connection ID block */
		req.push_back(OBEX_HEAD_CONNECTION_ID);
		req.append(ConnectionID,4);
		/* Name block */
		AddBlock(&req, OBEX_HEAD_NAME, Now.data(), Now.size());
		(*Debug)->Deb("SENT: Set path %i\n",Now.size());
		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_SET_PATH+128, 10, ID_GetIMEI+ID, &req);
		if (error.Code != GSM_ERR_NONE) return error;

		if (Path->size()==i) return GSM_Return_Error(GSM_ERR_NONE);

		Now.clear();
		while (1) {
			if (Path->size()==i) break;
			if (Path->data()[i] == '\\') {
				i++;
				break;
			}
			Now.push_back(Path->data()[i]/256);
			Now.push_back(Path->data()[i]%256);
			i++;
		}

		if (Now.size()==0) return GSM_Return_Error(GSM_ERR_NONE);

		Now.push_back(0);
		Now.push_back(0);
	}
}

GSM_Error GSM_Phone_OBEXGEN::ReplyGetFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	GSM_File 	*File = (GSM_File *)S;
	unsigned int 		Pos=0;

	switch (msg->Type) {
		case OBEX_RESP_CONTINUE : (*Debug)->Deb("RECEIVED: Get file continue\n"); break;
		case OBEX_RESP_SUCCESS  : (*Debug)->Deb("RECEIVED: Get file last\n");     break;
		default   		: return GSM_Return_Error(GSM_ERR_UNKNOWN);
	}

	while(Pos < msg->Buffer.size()) {
		if (msg->Buffer.data()[Pos]==OBEX_HEAD_LENGTH) { //file size
			File->Info.Size = msg->Buffer.data()[Pos+1]*256*256*256+
					  msg->Buffer.data()[Pos+2]*256*256+
					  msg->Buffer.data()[Pos+3]*256+
					  msg->Buffer.data()[Pos+4];
			(*Debug)->Deb("  size\n");
			Pos+=5;
			continue;
		}
		switch (msg->Buffer.data()[Pos]) {
		case OBEX_HEAD_NAME: 
			(*Debug)->Deb("  name\n"); 
			break;
		case OBEX_HEAD_TYPE:
			(*Debug)->Deb("  type\n");
			break;			
		case OBEX_HEAD_TIME_ISO:
			(*Debug)->Deb("  datetime\n");
			break;			
		case OBEX_HEAD_BODY: //file content
		case OBEX_HEAD_BODY_END: //last file content
			(*Debug)->Deb("  content\n");
			File->Buffer.append((const unsigned char *)msg->Buffer.data()+Pos+3,msg->Buffer.data()[Pos+1]*256+msg->Buffer.data()[Pos+2]-3);
			break;
		default:
			(*Debug)->Deb("  unknown\n");

		        return GSM_Return_Error(GSM_ERR_UNKNOWN);
			break;
		}
		Pos+=msg->Buffer.data()[Pos+1]*256+msg->Buffer.data()[Pos+2];
	}
	switch (msg->Type) {
		case OBEX_RESP_CONTINUE: return GSM_Return_Error(GSM_ERR_NONE);		
		case OBEX_RESP_SUCCESS: return GSM_Return_Error(GSM_ERR_EMPTY);
	}
	return GSM_Return_Error(GSM_ERR_UNKNOWN);
}

GSM_Error GSM_Phone_OBEXGEN::GetFile(GSM_File *File, unsignedstring Type)
{
	GSM_Error 	error;
	unsignedstring  Buffer,req;
	wchart		buf2;
	unsigned int	i;

	/* connection ID block */
	req.push_back(OBEX_HEAD_CONNECTION_ID);
	req.append(ConnectionID,4);

	(*Debug)->Deb("'%s'\n",UnicodeToStringReturn(File->Info.ID.data()));
	if (File->Buffer.size() == 0x00) {
		if (File->Info.ID.size()!=0) {
			i = File->Info.ID.size()-1;
			while (1) {
				if (File->Info.ID.data()[i] == '\\') break;
				if (i==0) return GSM_Return_Error(GSM_ERR_UNKNOWN);
				i--;
			}
			buf2.clear();
			buf2.append(File->Info.ID.data(),i+1);
		}
		if (Service == OBEX_FOLDERS) {
			error = SetPath(&buf2);
			if (error.Code != GSM_ERR_NONE) return error;
		}

		/* Name block */
		if (File->Info.ID.size()!=0) {
			buf2.clear();
			buf2.append(File->Info.ID.data()+i+1,File->Info.ID.size()-i-1);
			for (i=0;i<buf2.size();i++) {
				Buffer.push_back(buf2.data()[i]/256);
				Buffer.push_back(buf2.data()[i]%256);
			}
			if (buf2.size()!=0) {
				Buffer.push_back(0); Buffer.push_back(0);
			}
			AddBlock(&req, OBEX_HEAD_NAME, Buffer.data(),Buffer.size());
		}
		File->Info.Name.clear();
		File->Info.Name.append(buf2);

		/* Type block */
		AddBlock(&req, OBEX_HEAD_TYPE, Type.data(), Type.size());

		(*Debug)->Deb("SENT: Get file start\n");
	} else {
		(*Debug)->Deb("SENT: Get file continue\n");
	}

	error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_GET+128, 10, ID_GetFilePart+ID, File);
	if (error.Code == GSM_ERR_NONE && File->Buffer.size() == 0x00) {
		req.clear();
		/* connection ID block */
		req.push_back(OBEX_HEAD_CONNECTION_ID);
		req.append(ConnectionID,4);

		(*Debug)->Deb("SENT: Get file continue\n");
		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_GET+128, 10, ID_GetFilePart+ID, File);
	}
	return error;
}

GSM_Error GSM_Phone_OBEXGEN::GetFilePart(GSM_File *File)
{
	unsignedstring Type;

	if (Service != OBEX_FOLDERS) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	return GetFile(File, Type);
}

GSM_Error GSM_Phone_OBEXGEN::ReplyAddFilePart(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	if (msg->Type==OBEX_RESP_FORBIDDEN) return GSM_Return_Error(GSM_ERR_INSIDE_PHONE_MENU);
	return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::AddFilePart(GSM_File *File, int *Pos)
{
	unsignedstring Type;

	if (Service != OBEX_FOLDERS && Service != OBEX_NONE) return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);

	return AddFile(File, Pos, Type);
}

GSM_Error GSM_Phone_OBEXGEN::AddFile(GSM_File *File, int *Pos, unsignedstring Type)
{
	GSM_Error 	error;
	unsignedstring  Buffer,req;
	wchart		buf2;
	unsigned int	i,j;
	char		Buff[200];

	(*Debug)->Deb("add file '%s'\n",UnicodeToStringReturn(File->Info.ID.data()));

	j = 2000;
	if (File->Info.Size - *Pos < 2000) j = File->Info.Size - *Pos;

	/* connection ID block */
	req.push_back(OBEX_HEAD_CONNECTION_ID);
	req.append(ConnectionID,4);

	if (*Pos == 0) {		
		if (File->Info.ID.size()!=0 || Service == OBEX_FOLDERS) {
			i = File->Info.ID.size()-1;
			while (1) {
				if (File->Info.ID.data()[i] == '\\') break;
				if (i==0) return GSM_Return_Error(GSM_ERR_UNKNOWN);
				i--;
			}
			buf2.clear();
			buf2.append(File->Info.ID.data(),i+1);
		}
		if (Service == OBEX_FOLDERS) {
			(*Debug)->Deb(" setting to '%s'\n",UnicodeToStringReturn(buf2.data()));
			error = SetPath(&buf2);
			if (error.Code != GSM_ERR_NONE) return error;
		}

		/* Name block */
	        Buffer.clear();
		if (File->Info.Name.size()!=0) {
			for (i=0;i<File->Info.Name.size();i++) {
				Buffer.push_back(File->Info.Name.data()[i]/256);
				Buffer.push_back(File->Info.Name.data()[i]%256);
			}
			if (Buffer.size()!=0) {
				Buffer.push_back(0); Buffer.push_back(0);
			}
			AddBlock(&req, OBEX_HEAD_NAME, Buffer.data(),Buffer.size());
		}

		File->Info.ID.append(File->Info.Name);

		/* Type block */
		if (Type.size()!=0) {
			AddBlock(&req, OBEX_HEAD_TYPE, Type.data(), Type.size());
		}

		if (File->Info.ModificationDateTimeAvailable) {
			Buff[0] = 0;
			SaveVCalendarDateTime(&File->Info.ModificationDateTime, Buff);
			Buffer.clear();
			Buffer.append((unsigned char *)Buff,strlen(Buff));
			Buffer.push_back('Z');
			AddBlock(&req, OBEX_HEAD_TIME_ISO, Buffer.data(),Buffer.size());
		}

		/* File length */
		req.push_back(OBEX_HEAD_LENGTH);
		req.push_back(File->Info.Size / (256*256*256));
		req.push_back(File->Info.Size / (256*256));
		req.push_back(File->Info.Size / 256);
		req.push_back(File->Info.Size % 256);
	}

	if (*Pos == 0) {
		Write((unsigned char *)req.data(), req.size(), OBEX_OP_PUT, 10, ID_AddFilePart+ID, File);
		req.clear();
		/* connection ID block */
		req.push_back(OBEX_HEAD_CONNECTION_ID);
		req.append(ConnectionID,4);
	}

	if (*Pos + j == File->Info.Size) {
		(*Debug)->Deb("SENT: Add file last\n");

		/* data */
		if (j!=0) AddBlock(&req, OBEX_HEAD_BODY_END, File->Buffer.data(),j);
		*Pos += j;

		error = Write((unsigned char *)req.data(), req.size(), OBEX_OP_PUT+128, 10, ID_AddFilePart+ID, File);
		if (error.Code != GSM_ERR_NONE) return error;

		return GSM_Return_Error(GSM_ERR_EMPTY);
	} else {
		(*Debug)->Deb("SENT: Add file continue\n");
		/* data */
		AddBlock(&req, OBEX_HEAD_BODY, File->Buffer.data()+(*Pos),j);
		*Pos += j;
		return Write((unsigned char *)req.data(), req.size(), OBEX_OP_PUT, 10, ID_AddFilePart+ID, File);
	}
}

GSM_Error GSM_Phone_OBEXGEN::Open(char *FrameID, char *Device, char *Prot)
{
	CFGDevice.append((unsigned char *)Device,strlen(Device));
	CFGProtocol.append((unsigned char *)Prot,strlen(Prot));
	if (!strcmp(Prot,"bluesyncmlserver")) {
		Service = OBEX_SYNCML;
	} else if (!strcmp(Prot,"blueobexinbox")) {
		Service = OBEX_NONE;
	} else {
		Service = OBEX_FOLDERS;
	}
	return Open2();
}

GSM_Error GSM_Phone_OBEXGEN::ReplyOpen(GSM_Protocol_Message *msg, DebugInfo **Debug, unsigned char *S)
{
	unsigned int Pos=4;

	while(Pos < msg->Buffer.size()) {
		switch (msg->Buffer.data()[Pos]) {
		case OBEX_HEAD_CONNECTION_ID: // Connection ID
			memcpy(ConnectionID,msg->Buffer.data()+Pos+1,4);
			Pos+=5;
			break;
		case OBEX_HEAD_WHO: // Response to OBEX_HEAD_TARGET
			Pos+=19;
			break;
		default:
		        return GSM_Return_Error(GSM_ERR_UNKNOWN);
			break;
		}
	}

        return GSM_Return_Error(GSM_ERR_NONE);
}

GSM_Error GSM_Phone_OBEXGEN::Open2()
{
	GSM_File 		File;
        GSM_Error       	error;
	unsignedstring  	req,MIME,ServerID,ServerFileID;
	wchart			buf2,name,Name2;
	unsigned char 		req2[200];

	req.push_back(0x10); // version 1.0
	req.push_back(0x00); // no flags
	req.push_back(0x08); req.push_back(0x00);// max size of packet = 4*256

	switch (Service) {
	case OBEX_NONE:
		break;
	case OBEX_SYNCML:
		sprintf((char *)req2,"SYNCML-SYNC");
		AddBlock(&req, OBEX_HEAD_TARGET, req2, 11);
		break;
	case OBEX_FOLDERS:
		/* Folder Browsing Service UUID */
		req2[0] = 0xF9; req2[1] = 0xEC; req2[2] = 0x7B;
		req2[3] = 0xC4; req2[4] = 0x95; req2[5] = 0x3C;
		req2[6] = 0x11; req2[7] = 0xD2; req2[8] = 0x98;
		req2[9] = 0x4E; req2[10]= 0x52; req2[11]= 0x54;
		req2[12]= 0x00; req2[13]= 0xDC; req2[14]= 0x9E;
		req2[15]= 0x09;
		AddBlock(&req, OBEX_HEAD_TARGET, req2, 16);
		break;
	}

	return Write((unsigned char *)req.data(), req.size(), OBEX_OP_CONNECT+128, 4, ID_GetIMEI+ID, &req);
}

GSM_Error GSM_Phone_OBEXGEN::ResetConnection()
{
	GSM_Error error;

	error = (*Device)->Close();
	if (error.Code != GSM_ERR_NONE) return error;

#ifdef WIN32
	Sleep(150);
#else
	usleep(15000);
#endif

	error=(*Device)->Open((char *)CFGDevice.data(),(char *)CFGProtocol.data(),NULL,NULL,NULL);
	if (error.Code != GSM_ERR_NONE) return error;

	return Open2();
}

GSM_Error GSM_Phone_OBEXGEN::GetPBKStatus(GSM_PBKStatus *Status)
{
	switch (Service) {
	case OBEX_SYNCML : return SyncMLGetPBKStatus(Status);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextCalendar(GSM_CalendarEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	switch (Service) {
	case OBEX_SYNCML : return SyncMLGetNextCalendar(Entry, start, Current, Max);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetPBK(GSM_PBKEntry *Entry)
{
	switch (Service) {
	case OBEX_SYNCML : return SyncMLGetPBK(Entry);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextNote(GSM_NoteEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	switch (Service) {
	case OBEX_SYNCML : return SyncMLGetNextNote(Entry, start, Current, Max);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetNextToDo(GSM_ToDoEntry *Entry, BOOLEAN start, int *Current, int *Max)
{
	switch (Service) {
	case OBEX_SYNCML : return SyncMLGetNextToDo(Entry, start, Current, Max);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetIMEI(unsigned char *IMEI)
{
	switch (Service) {
	case OBEX_SYNCML  : return SyncMLGetIMEI(IMEI);
	case OBEX_FOLDERS : return FoldersGetIMEI(IMEI);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetCodeNameModel(unsigned char *Model)
{
	switch (Service) {
	case OBEX_SYNCML  : return SyncMLGetCodeNameModel(Model);
	case OBEX_FOLDERS : return FoldersGetCodeNameModel(Model);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetFirmwareVersion(unsigned char *Firm)
{
	switch (Service) {
	case OBEX_SYNCML  : return SyncMLGetFirmwareVersion(Firm);
	case OBEX_FOLDERS : return FoldersGetFirmwareVersion(Firm);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}

GSM_Error GSM_Phone_OBEXGEN::GetManufacturer(unsigned char *Manufacturer)
{
	switch (Service) {
	case OBEX_SYNCML  : return SyncMLGetManufacturer(Manufacturer);
	case OBEX_FOLDERS : return FoldersGetManufacturer(Manufacturer);
	}
	return GSM_Return_Error(GSM_ERR_NOT_SUPPORTED);
}
