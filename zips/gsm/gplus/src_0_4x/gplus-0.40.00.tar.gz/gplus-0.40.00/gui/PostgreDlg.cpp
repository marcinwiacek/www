//---------------------------------------------------------------------------
//
// Name:        PostgreDlg.cpp
// Author:      Marcinello
// Created:     2007-10-29 23:14:13
// Description: PostgreDlg class implementation
//
//---------------------------------------------------------------------------

#include "PostgreDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// PostgreDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(PostgreDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(PostgreDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,PostgreDlg::WxButton1Click)
	EVT_BUTTON(ID_WXBUTTON2,PostgreDlg::WxButton2Click)
END_EVENT_TABLE()
////Event Table End

PostgreDlg::PostgreDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

PostgreDlg::~PostgreDlg()
{
} 

void PostgreDlg::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("PostgreSQL database details"));
	SetIcon(wxNullIcon);
	SetSize(8,8,440,314);
	Center();
	

	WxStaticText5 = new wxStaticText(this, ID_WXSTATICTEXT5, wxT("Database"), wxPoint(6,108), wxDefaultSize, 0, wxT("WxStaticText5"));
	WxStaticText5->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxStaticText4 = new wxStaticText(this, ID_WXSTATICTEXT4, wxT("Port (optional)"), wxPoint(6,66), wxDefaultSize, 0, wxT("WxStaticText4"));
	WxStaticText4->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxStaticText3 = new wxStaticText(this, ID_WXSTATICTEXT3, wxT("IP address"), wxPoint(6,31), wxDefaultSize, 0, wxT("WxStaticText3"));
	WxStaticText3->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxStaticText2 = new wxStaticText(this, ID_WXSTATICTEXT2, wxT("Password"), wxPoint(8,191), wxDefaultSize, 0, wxT("WxStaticText2"));
	WxStaticText2->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("User"), wxPoint(8,152), wxDefaultSize, 0, wxT("WxStaticText1"));
	WxStaticText1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, wxT(""), wxPoint(118,28), wxSize(299,29), 0, wxDefaultValidator, wxT("WxEdit1"));
	WxEdit1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxEdit2 = new wxTextCtrl(this, ID_WXEDIT2, wxT(""), wxPoint(118,65), wxSize(299,29), 0, wxDefaultValidator, wxT("WxEdit2"));
	WxEdit2->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxEdit3 = new wxTextCtrl(this, ID_WXEDIT3, wxT(""), wxPoint(118,103), wxSize(300,31), 0, wxDefaultValidator, wxT("WxEdit3"));
	WxEdit3->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxEdit4 = new wxTextCtrl(this, ID_WXEDIT4, wxT(""), wxPoint(118,145), wxSize(302,30), 0, wxDefaultValidator, wxT("WxEdit4"));
	WxEdit4->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxEdit5 = new wxTextCtrl(this, ID_WXEDIT5, wxT(""), wxPoint(118,183), wxSize(304,32), wxTE_PASSWORD, wxDefaultValidator, wxT("WxEdit5"));
	WxEdit5->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("OK"), wxPoint(8,238), wxSize(101,33), 0, wxDefaultValidator, wxT("WxButton1"));
	WxButton1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxButton2 = new wxButton(this, ID_WXBUTTON2, wxT("Cancel"), wxPoint(328,240), wxSize(97,32), 0, wxDefaultValidator, wxT("WxButton2"));
	WxButton2->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));
	////GUI Items Creation End
}

void PostgreDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void PostgreDlg::WxButton1Click(wxCommandEvent& event)
{
    EndModal(wxID_OK);
}

/*
 * WxButton2Click
 */
void PostgreDlg::WxButton2Click(wxCommandEvent& event)
{
    EndModal(wxID_CANCEL);
}
