//---------------------------------------------------------------------------
//
// Name:        PhoneFrm.h
// Author:      Marcinello
// Created:     2007-01-25 19:28:55
// Description: PhoneFrm class declaration
//
//---------------------------------------------------------------------------

#ifndef __PHONEFRM_h__
#define __PHONEFRM_h__

#include "MainFrm.h"

#include "../cfg/config.h"
#include "../common/service/smsmms/gsmmsg.h"
#include "../common/service/gsmmisc.h"
#include "../common/service/backup/gsmback.h"
#include "../common/gsmstate.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/frame.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/menu.h>
#include <wx/dirdlg.h>
#include <wx/checkbox.h>
#include <wx/calctrl.h>
#include <wx/mediactrl.h>
#include <wx/listbox.h>
#include <wx/textctrl.h>
#include <wx/combobox.h>
#include <wx/listctrl.h>
#include <wx/splitter.h>
#include <wx/button.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/sizer.h>
////Header Include End

////Dialog Style Start
#undef PhoneFrm_STYLE
#define PhoneFrm_STYLE wxCAPTION | wxSYSTEM_MENU | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

typedef enum {
	PhoneFrm_Phone=1,
	PhoneFrm_Backup,
	PhoneFrm_DB
} PhoneFrm_Type;

class OnlineInfoData {
public:
	char	DeviceProductCode[100];
        char    DeviceCodeName[100];
        char    DeviceFirmware[100];
};

#ifdef POSTGRESQL
#else
#define PGconn int
#endif

class PhoneFrm : public wxMDIChildFrame
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:

		PhoneFrm(GSM_GPlusConfig *CFG2, PGconn *pg2, PhoneFrm_Type Type2, GSM_Backup *Backup2, MainFrm *parent2, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style, const wxString& name, GSM_StateMachine *s2, unsigned char *Man, unsigned char *Model, unsigned char *Firm);
		virtual ~PhoneFrm();
        void GetOnlineInfo();
        void    DisplaySMSFolder();
        void    ClearMMSView();
        BOOLEAN ReadSMSMMSFolder(int Num2, GSM_SMSMMSFoldersSubEntry *SubFolder);
        		
	public:
		//Do not add custom control declarations between
                //GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxMenu *PbkSingleWxPopupMenu;
		wxMenu *NoteSingleWxPopupMenu;
		wxMenu *CalSingleWxPopupMenu;
		wxMenu *ToDoSingleWxPopupMenu;
		wxMenu *MMSSingleUpWxPopupMenu;
		wxMenu *SMSSingleUpWxPopupMenu;
		wxMenu *FilesMultipleWxPopupMenu;
		wxDirDialog *WxDirDialog1;
		wxListCtrl *FMWxListCtrl;
		wxBoxSizer *WxBoxSizer24;
		wxButton *WxButton4;
		wxPanel *WxPanel30;
		wxBoxSizer *WxBoxSizer23;
		wxPanel *FMStationWxNoteBookPage;
		wxListCtrl *WAPBookmarksWxListCtrl;
		wxBoxSizer *WxBoxSizer22;
		wxButton *WxButton3;
		wxPanel *WxPanel29;
		wxBoxSizer *WxBoxSizer21;
		wxPanel *WAPBookmarksWxNoteBookPage;
		wxListCtrl *JavaDownWxListCtrl;
		wxGridSizer *WxGridSizer16;
		wxPanel *WxPanel27;
		wxListCtrl *JavaUpWxListCtrl;
		wxGridSizer *WxGridSizer15;
		wxPanel *WxPanel26;
		wxSplitterWindow *WxSplitterWindow8;
		wxBoxSizer *WxBoxSizer19;
		wxButton *AppAddWxButton;
		wxButton *GameAddWxButton;
		wxButton *JavaGetWxButton;
		wxPanel *WxPanel25;
		wxBoxSizer *WxBoxSizer18;
		wxPanel *JavaWxNoteBookPage;
		wxListCtrl *ToDoDownWxListCtrl;
		wxGridSizer *WxGridSizer14;
		wxPanel *WxPanel23;
		wxListCtrl *ToDoUpWxListCtrl;
		wxGridSizer *WxGridSizer13;
		wxPanel *WxPanel21;
		wxSplitterWindow *WxSplitterWindow6;
		wxBoxSizer *WxBoxSizer16;
		wxButton *ToDoGetWxButton;
		wxPanel *WxPanel20;
		wxBoxSizer *WxBoxSizer15;
		wxPanel *ToDoWxNoteBookPage;
		wxTextCtrl *NotesWxMemo;
		wxGridSizer *WxGridSizer12;
		wxPanel *WxPanel19;
		wxListCtrl *NotesWxListCtrl;
		wxGridSizer *WxGridSizer11;
		wxPanel *WxPanel18;
		wxSplitterWindow *WxSplitterWindow5;
		wxBoxSizer *WxBoxSizer14;
		wxButton *NotesGetWxButton;
		wxPanel *WxPanel17;
		wxBoxSizer *WxBoxSizer13;
		wxPanel *NotesWxNoteBookPage;
		wxListCtrl *CalendarDownWxListCtrl;
		wxGridSizer *WxGridSizer10;
		wxPanel *WxPanel15;
		wxListCtrl *CalendarUpWxListCtrl;
		wxGridSizer *WxGridSizer9;
		wxPanel *WxPanel14;
		wxSplitterWindow *WxSplitterWindow4;
		wxCheckBox *CalendarWxCheckBox;
		wxCalendarCtrl *WxCalendarCtrl1;
		wxPanel *WxPanel13;
		wxBoxSizer *WxBoxSizer11;
		wxButton *CalendarSearchWxButton;
		wxTextCtrl *CalendarSearchWxEdit;
		wxButton *CalendarGetWxButton;
		wxPanel *WxPanel12;
		wxBoxSizer *WxBoxSizer8;
		wxPanel *CalendarWxNoteBookPage;
		wxListCtrl *MMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer7;
		wxPanel *WxNoteBookPage4;
		wxMediaCtrl *MMSFileWxMediaCtrl;
		wxTextCtrl *MMSFileWxMemo;
		wxBoxSizer *WxBoxSizer10;
		wxListBox *MMSNumbersWxListBox;
		wxButton *MMSSaveWxButton;
		wxComboBox *MMFilesWxComboBox;
		wxPanel *WxPanel11;
		wxBoxSizer *WxBoxSizer9;
		wxPanel *WxNoteBookPage3;
		wxNotebook *WxNotebook3;
		wxGridSizer *WxGridSizer8;
		wxPanel *WxPanel10;
		wxListCtrl *MMSUpWxListCtrl;
		wxGridSizer *WxGridSizer7;
		wxPanel *WxPanel9;
		wxSplitterWindow *WxSplitterWindow3;
		wxButton *MMSSearchWxButton;
		wxTextCtrl *MMSSearchWxEdit;
		wxButton *MMSGetWxButton;
		wxComboBox *MMSWxComboBox;
		wxPanel *WxPanel8;
		wxBoxSizer *WxBoxSizer6;
		wxPanel *MMSWxNoteBookPage;
		wxListCtrl *SMSDetailsWxListCtrl;
		wxBoxSizer *WxBoxSizer5;
		wxPanel *WxNoteBookPage2;
		wxTextCtrl *SMSWxMemo;
		wxMediaCtrl *SMSWxMediaCtrl;
		wxBoxSizer *WxBoxSizer20;
		wxButton *SMSSaveWxButton;
		wxComboBox *SMSFilesWxComboBox;
		wxListBox *SMSNumbersWxListBox;
		wxPanel *WxPanel28;
		wxBoxSizer *WxBoxSizer4;
		wxPanel *WxNoteBookPage1;
		wxNotebook *WxNotebook2;
		wxGridSizer *WxGridSizer6;
		wxPanel *WxPanel7;
		wxListCtrl *SMSUpWxListCtrl;
		wxGridSizer *WxGridSizer5;
		wxPanel *WxPanel6;
		wxSplitterWindow *WxSplitterWindow2;
		wxButton *SMSSearchWxButton;
		wxButton *SMSSendWxButton;
		wxTextCtrl *SMSWxEdit;
		wxButton *SMSGetWxButton;
		wxComboBox *SMSWxComboBox;
		wxPanel *WxPanel5;
		wxBoxSizer *WxBoxSizer3;
		wxPanel *SMSWxNoteBookPage;
		wxListCtrl *PBKDownWxListCtrl;
		wxGridSizer *WxGridSizer4;
		wxPanel *WxPanel4;
		wxListCtrl *PBKUpWxListCtrl;
		wxGridSizer *WxGridSizer3;
		wxPanel *WxPanel3;
		wxSplitterWindow *WxSplitterWindow1;
		wxButton *PbkSearchWxButton;
		wxTextCtrl *PbkWxEdit;
		wxComboBox *PBKWxComboBox;
		wxButton *PbkGetWxButton;
		wxPanel *WxPanel2;
		wxBoxSizer *WxBoxSizer2;
		wxPanel *PhoneBookWxNoteBookPage;
		wxListCtrl *FilesWxListCtrl;
		wxButton *AddFileWxButton;
		wxButton *FilesGetWxButton;
		wxPanel *WxPanel1;
		wxBoxSizer *WxBoxSizer1;
		wxPanel *FilesWxNoteBookPage;
		wxListCtrl *InfoDownWxListCtrl;
		wxBoxSizer *WxBoxSizer17;
		wxPanel *WxPanel24;
		wxListCtrl *InfoWxListCtrl;
		wxGridSizer *WxGridSizer2;
		wxPanel *WxPanel22;
		wxSplitterWindow *WxSplitterWindow7;
		wxButton *OnlineInfoWxButton;
		wxButton *RestoreWxButton;
		wxButton *BackupWxButton;
		wxPanel *WxPanel16;
		wxBoxSizer *WxBoxSizer12;
		wxPanel *InfoWxNoteBookPage;
		wxNotebook *WxNotebook1;
		wxGridSizer *WxGridSizer1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_MNU_SENDOVERSMS_1228 = 1228,
			
			ID_MNU_SENDOVERSMS_1231 = 1231,
			
			ID_MNU_SENDOVERSMS_1229 = 1229,
			
			ID_MNU_SENDOVERSMS_1230 = 1230,
			
			ID_MNU_SAVETOFILE_1104 = 1104,
			
			ID_MNU_FORWARD_1095 = 1095,
			ID_MNU_SENDNEWSMSTOSMSNUMBERS_1144 = 1144,
			
			ID_MNU_READ_1227 = 1227,
			
			ID_FMWXLISTCTRL = 1246,
			ID_WXBUTTON4 = 1244,
			ID_WXPANEL30 = 1243,
			ID_FMSTATIONWXNOTEBOOKPAGE = 1241,
			ID_WAPBOOKMARKSWXLISTCTRL = 1240,
			ID_WXBUTTON3 = 1235,
			ID_WXPANEL29 = 1234,
			ID_WAPBOOKMARKSWXNOTEBOOKPAGE = 1232,
			ID_JAVADOWNWXLISTCTRL = 1214,
			ID_WXPANEL27 = 1211,
			ID_JAVAUPWXLISTCTRL = 1210,
			ID_WXPANEL26 = 1208,
			ID_WXSPLITTERWINDOW8 = 1207,
			ID_APPADDWXBUTTON = 1218,
			ID_GAMEADDWXBUTTON = 1217,
			ID_JAVAGETWXBUTTON = 1215,
			ID_WXPANEL25 = 1205,
			ID_JAVAWXNOTEBOOKPAGE = 1203,
			ID_TODODOWNWXLISTCTRL = 1184,
			ID_WXPANEL23 = 1180,
			ID_TODOUPWXLISTCTRL = 1183,
			ID_WXPANEL21 = 1177,
			ID_WXSPLITTERWINDOW6 = 1176,
			ID_TODOGETWXBUTTON = 1173,
			ID_WXPANEL20 = 1172,
			ID_TODOWXNOTEBOOKPAGE = 1170,
			ID_NOTESWXMEMO = 1169,
			ID_WXPANEL19 = 1165,
			ID_NOTESWXLISTCTRL = 1167,
			ID_WXPANEL18 = 1163,
			ID_WXSPLITTERWINDOW5 = 1156,
			ID_NOTESGETWXBUTTON = 1154,
			ID_WXPANEL17 = 1153,
			ID_NOTESWXNOTEBOOKPAGE = 1150,
			ID_CALENDARDOWNWXLISTCTRL = 1127,
			ID_WXPANEL15 = 1119,
			ID_CALENDARUPWXLISTCTRL2 = 1126,
			ID_WXPANEL14 = 1118,
			ID_WXSPLITTERWINDOW4 = 1110,
			ID_CALENDARWXCHECKBOX = 1117,
			ID_WXCALENDARCTRL1 = 1116,
			ID_WXPANEL13 = 1109,
			ID_CALENDARSEARCHWXBUTTON = 1141,
			ID_CALENDARSEARCHWXEDIT = 1140,
			ID_CALENDARGETWXBUTTON = 1120,
			ID_WXPANEL12 = 1105,
			ID_CALENDARWXNOTEBOOKPAGE = 1090,
			ID_MMSDOWNWXLISTCTRL = 1089,
			ID_WXNOTEBOOKPAGE4 = 1085,
			ID_MMSFILEWXMEDIACTRL = 1103,
			ID_MMSFILEWXMEMO = 1102,
			ID_MMSNUMBERSWXLISTBOX = 1219,
			ID_MMSSAVEWXBUTTON = 1101,
			ID_MMFILESWXCOMBOBOX = 1099,
			ID_WXPANEL11 = 1098,
			ID_WXNOTEBOOKPAGE3 = 1084,
			ID_WXNOTEBOOK3 = 1083,
			ID_WXPANEL10 = 1077,
			ID_MMSUPWXLISTCTRL = 1079,
			ID_WXPANEL9 = 1076,
			ID_WXSPLITTERWINDOW3 = 1075,
			ID_MMSSEARCHWXBUTTON = 1143,
			ID_MMSSEARCHWXEDIT = 1142,
			ID_MMSGETWXBUTTON = 1074,
			ID_MMSWXCOMBOBOX = 1073,
			ID_WXPANEL8 = 1072,
			ID_MMSWXNOTEBOOKPAGE = 1070,
			ID_SMSDETAILSWXLISTCTRL = 1065,
			ID_WXNOTEBOOKPAGE2 = 1063,
			ID_SMSWXMEMO = 1226,
			ID_SMSWXMEDIACTRL = 1225,
			ID_SMSSAVEWXBUTTON = 1223,
			ID_SMSFILESWXCOMBOBOX = 1222,
			ID_SMSNUMBERSWXLISTBOX = 1221,
			ID_WXPANEL28 = 1220,
			ID_WXNOTEBOOKPAGE1 = 1059,
			ID_WXNOTEBOOK2 = 1058,
			ID_WXPANEL7 = 1067,
			ID_SMSUPWXLISTCTRL = 1056,
			ID_WXPANEL6 = 1066,
			ID_WXSPLITTERWINDOW2 = 1054,
			ID_SMSSEARCHWXBUTTON = 1096,
			ID_SMSSENDWXBUTTON = 1094,
			ID_SMSWXEDIT = 1091,
			ID_SMSGETWXBUTTON = 1069,
			ID_SMSWXCOMBOBOX = 1068,
			ID_WXPANEL5 = 1053,
			ID_SMSWXNOTEBOOKPAGE = 1046,
			ID_PBKDOWNWXLISTCTRL2 = 1043,
			ID_WXPANEL4 = 1039,
			ID_PBKUPWXLISTCTRL2 = 1042,
			ID_WXPANEL3 = 1037,
			ID_WXSPLITTERWINDOW1 = 1022,
			ID_PBKSEARCHWXBUTTON = 1139,
			ID_PBKWXEDIT = 1138,
			ID_PBKWXCOMBOBOX = 1045,
			ID_PBKGETWXBUTTON = 1044,
			ID_WXPANEL2 = 1021,
			ID_PHONEBOOKWXNOTEBOOKPAGE = 1018,
			ID_FILESWXLISTCTRL = 1016,
			ID_ADDFILEWXBUTTON = 1148,
			ID_FILESGETWXBUTTON = 1017,
			ID_WXPANEL1 = 1015,
			ID_FILESWXNOTEBOOKPAGE = 1006,
			ID_INFODOWNWXLISTCTRL = 1201,
			ID_WXPANEL24 = 1199,
			ID_INFOWXLISTCTRL = 1196,
			ID_WXPANEL22 = 1194,
			ID_WXSPLITTERWINDOW7 = 1190,
			ID_ONLINEINFOWXBUTTON = 1202,
			ID_RESTOREWXBUTTON = 1147,
			ID_BACKUPWXBUTTON = 1146,
			ID_WXPANEL16 = 1134,
			ID_INFOWXNOTEBOOKPAGE = 1003,
			ID_WXNOTEBOOK1 = 1002,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};

    public:	
		void FilesWxListCtrlItemActivated(wxListEvent& event);
		void WxNotebook1PageChanged(wxNotebookEvent& event);
		void FilesGetWxButtonClick(wxCommandEvent& event);
		void PbkGetWxButtonClick(wxCommandEvent& event);
		void PBKWxComboBoxSelected(wxCommandEvent& event );
		void PBKUpWxListCtrlColLeftClick(wxListEvent& event);
		void SMSGetWxButtonClick(wxCommandEvent& event);
		void SMSWxComboBoxSelected(wxCommandEvent& event );
		void SMSUpWxListCtrlSelected(wxListEvent& event);
		void MMSGetWxButtonClick(wxCommandEvent& event);
		void MMSWxComboBoxSelected(wxCommandEvent& event );
		void MMSUpWxListCtrlItemActivated(wxListEvent& event);
		void PBKUpWxListCtrlSelected(wxListEvent& event);
		void SMSSendWxButtonClick(wxCommandEvent& event);
	    void Mnuforward1095Click(wxCommandEvent& event);
		void SMSUpWxListCtrlRightClick(wxListEvent& event);
		void SMSSearchWxButtonClick(wxCommandEvent& event);
		void WxNoteBookPage3UpdateUI(wxUpdateUIEvent& event);
		void MMFilesWxComboBoxSelected(wxCommandEvent& event );
		void MMSFileWxMediaCtrlMediaLoaded(wxMediaEvent& event);
		void MMSSaveWxButtonClick(wxCommandEvent& event);
		void MMSUpWxListCtrlSelected(wxListEvent& event);
	    void Mnusavetofile1104Click(wxCommandEvent& event);
		void MMSUpWxListCtrlRightClick(wxListEvent& event);
		void CalendarGetWxButtonClick(wxCommandEvent& event);
		void WxCalendarCtrl1SelChanged(wxCalendarEvent& event);
		void CalendarWxCheckBoxClick(wxCommandEvent& event);
		void CalendarUPWxListCtrlSelected(wxListEvent& event);
		void PbkSearchWxButtonClick(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
    	void Mnusendnewsmstosmsnumbers1144Click(wxCommandEvent& event);
		void MMSSearchWxButtonClick(wxCommandEvent& event);
		void CalendarSearchWxButtonClick(wxCommandEvent& event);
    	void Mnuuploadfile1145Click(wxCommandEvent& event);
		void BackupWxButtonClick(wxCommandEvent& event);
		void RestoreWxButtonClick(wxCommandEvent& event);
		void AddFileWxButtonClick(wxCommandEvent& event);
		void NotesGetWxButtonClick(wxCommandEvent& event);
		void ToDoGetWxButtonClick(wxCommandEvent& event);
		void NotesWxListCtrlSelected(wxListEvent& event);
		void ToDoWxListCtrlSelected(wxListEvent& event);
		void JavaWxButtonClick(wxCommandEvent& event);
		void OnlineInfoWxButtonClick(wxCommandEvent& event);
		void JavaGetWxButtonClick(wxCommandEvent& event);
		void JavaUpWxListCtrlSelected(wxListEvent& event);
		void JavaAddWxButtonClick(wxCommandEvent& event);
		void GameAddWxButtonClick(wxCommandEvent& event);
		void AppAddWxButtonClick(wxCommandEvent& event);
	    void Mnusendnewsmstosmsnumbers1144Click1(wxCommandEvent& event);
		void SMSFilesWxComboBoxSelected(wxCommandEvent& event );
		void SMSWxMediaCtrlMediaLoaded(wxMediaEvent& event);
		void SMSSaveWxButtonClick(wxCommandEvent& event);
		void FilesWxListCtrlRightClick(wxListEvent& event);
	    void Mnuread1227Click(wxCommandEvent& event);
		void PBKUpWxListCtrlRightClick(wxListEvent& event);
	    void Mnusendoversms1228Click(wxCommandEvent& event);
		void CalendarUpWxListCtrlRightClick(wxListEvent& event);
	    void Mnusendoversms1229Click(wxCommandEvent& event);
	    void Mnusendoversms1230Click(wxCommandEvent& event);
		void ToDoUpWxListCtrlRightClick(wxListEvent& event);
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();

#ifdef POSTGRESQL
	    PGconn                              *conn;
#else
        int                                 *conn;
#endif

        GSM_GPlusConfig                     *CFG;
        GSM_StateMachine                    *s;
        GSM_Backup                          *Backup;
    	OnlineInfoData			            OnlineInfo;

        PhoneFrm_Type                       Type;
		MainFrm                             *parent;
        wchart                              StatusStr[15], StatusStr2[15];

        //files
        wchar_t                             FileFolderID[500], FileFolderID0[500];
        wchart                              ParentFolderID[20];
        int                                 ParentFolderIDNum;
        wchart                              CurrentFolderName, CurrentFolderName0;
        int                                 FileSystemNum;
        
        //pbk
        wchart                              PBKMemoryName[10];
        GSM_MemoryType                      PBKMemoryNum[10];
        int                                 PBKMemoryLen;
        bool                                SortPBKReverse;
        //int                               SortPBK = 0;
        //bool                              FirstPBK = true;

        //sms,mms
        unsignedint                         ReadSMSMMS;
        GSM_SMSMMSDecodedEntry              Decoded;
        
        //calendar
        bool                                FirstCalendar;
        
        //todo
        bool                                FirstToDo;
        
        bool                                FirstNote;
        bool                                FirstWAPBookmark;
        bool                                FirstFMStation;
        
		void    DeleteP(wxString Str);
		int     FindPage(wxString Str);
        void    FindFeatures(GSM_Backup_FileFormatFunctions *Func);		
		
		BOOLEAN EnterFolder(BOOLEAN display);
        GSM_FileFolderInfoListsSubEntry *GetFolderContent(const wchar_t *FileFolderID1);		
		void    DisplayFolder();
        BOOLEAN FindJADFiles(long *Num, FileFolderInfo *FInfo, BOOLEAN DetailsAvail, unsignedstring Name, BOOLEAN Game);
        BOOLEAN ReadOneFile(GSM_File *File);
        bool    UploadFile(GSM_File *File);
        void    AddJava(BOOLEAN Game);
        void    SaveAllFiles(wchart MyPath, BOOLEAN root);        
        BOOLEAN PhoneFrm::CheckJava();

		
        BOOLEAN GetPbkMemories();
        void    DisplayPBK(GSM_MemoryType Mem, long *PbkNum,long *ReceivedSec,long *DialledSec); 
        void    FindNumber(wchar_t *Number);
        bool    RestorePBK(GSM_MemoryType Mem, wxString Text, wxListCtrl *List, int *Num);        
       
        BOOLEAN ReadSMSMMSFolders(BOOLEAN SMS);
        void    ClearSMSView();    
        void    FindMMSFile(GSM_Backup_MMSEntry **En);  
        void    SendSMS(GSM_SMSList *List, wxListCtrl *ListCtrl);        
        
        void    DisplayCalendar();
        BOOLEAN CheckCalendar();        
        void    ReadCalendar();        
        void    RestoreCalendar(wxListCtrl *List, int *Num);
       
        void    DisplayNotes();   
        void    RestoreNotes();
        BOOLEAN CheckNotes();
        void    ReadNotes();
		void NotesWxListCtrlRightClick(wxListEvent& event);
	    void Mnusendoversms1231Click(wxCommandEvent& event);
                
        void    RestoreToDo(wxListCtrl *List, int *Num);
        void    DisplayToDo();
        BOOLEAN CheckToDo();        
        void    ReadToDo();

		void WxButton3Click(wxCommandEvent& event);
		void DisplayWAPBookmarks();
        void ReadWAPBookmark();
        BOOLEAN CheckWAPBookmark();

		void WxButton4Click(wxCommandEvent& event);
        void DisplayFMStations();	
        void ReadFMStation();        	
        BOOLEAN CheckFMStation();
		void WxButton2Click(wxCommandEvent& event);
};

#endif
