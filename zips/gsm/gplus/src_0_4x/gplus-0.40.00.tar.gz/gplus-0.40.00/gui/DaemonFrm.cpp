//---------------------------------------------------------------------------
//
// Name:        DaemonFrm.cpp
// Author:      Marcinello
// Created:     2007-11-01 22:50:00
// Description: DaemonFrm class implementation
//
//---------------------------------------------------------------------------

#include "DaemonFrm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// DaemonFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(DaemonFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(DaemonFrm::OnClose)
END_EVENT_TABLE()
////Event Table End

DaemonFrm::DaemonFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

DaemonFrm::~DaemonFrm()
{
}

void DaemonFrm::CreateGUIControls()
{
	//Do not add custom code between
        //GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxPanel1 = new wxPanel(this, ID_WXPANEL1, wxPoint(0,0), wxSize(492,168));
	WxPanel1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxCheckBox1 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX1, wxT("Add SMS from inbox to database and delete from phone"), wxPoint(11,17), wxSize(467,28), 0, wxDefaultValidator, wxT("WxCheckBox1"));
	WxCheckBox1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxCheckBox2 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX2, wxT("Add MMS from inbox to database and delete from phone"), wxPoint(11,48), wxSize(469,24), 0, wxDefaultValidator, wxT("WxCheckBox2"));
	WxCheckBox2->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxCheckBox3 = new wxCheckBox(WxPanel1, ID_WXCHECKBOX3, wxT("Put decoded SMS/MMS content to database too"), wxPoint(11,75), wxSize(469,27), 0, wxDefaultValidator, wxT("WxCheckBox3"));
	WxCheckBox3->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	WxButton1 = new wxButton(WxPanel1, ID_WXBUTTON1, wxT("Start"), wxPoint(155,118), wxSize(153,37), 0, wxDefaultValidator, wxT("WxButton1"));
	WxButton1->SetFont(wxFont(9, wxSWISS, wxNORMAL,wxNORMAL, FALSE));

	SetTitle(wxT("Daemon"));
	SetIcon(wxNullIcon);
	SetSize(8,8,500,205);
	Center();
	
	////GUI Items Creation End
}

void DaemonFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}
