/*

  X G N O K I I

  A Linux/Unix GUI for Nokia mobile phones.

  Released under the terms of the GNU GPL, see file COPYING for more details.

*/

#ifndef XGNOKII_SPEED_H
#define XGNOKII_SPEED_H

extern void GUI_CreateSpeedDialWindow (void);

extern void GUI_ShowSpeedDial (void);

#endif
