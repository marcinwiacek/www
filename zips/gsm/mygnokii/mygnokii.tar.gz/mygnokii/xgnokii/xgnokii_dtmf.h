/*

  X G N O K I I

  A Linux/Unix GUI for Nokia mobile phones.

  Released under the terms of the GNU GPL, see file COPYING for more details.

*/

#ifndef XGNOKII_DTMF_H
#define XGNOKII_DTMF_H

extern void GUI_CreateDTMFWindow ();

extern void GUI_ShowDTMF ();

#endif
