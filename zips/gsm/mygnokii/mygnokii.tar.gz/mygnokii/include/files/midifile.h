GSM_Error loadmid(char *filename, GSM_Ringtone *ringtone);
